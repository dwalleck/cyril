//! KAS settings handshake (cyril-nhzw): marshal the user's kiro-cli settings
//! (`<validated-kiro-home>/settings/cli.json`) into an `AgentSettings` object attached as
//! `clientCapabilities._meta.kiro.settings` at `initialize`. Without it, KAS runs
//! with its bare fallback flags (no toolSearch, no thinking, `invoke_sub_agent`
//! instead of `orchestrate_subagent`, …).
//!
//! The mapping is a **verbatim replica of v2's `zme()`** (extracted from
//! `kiro-tui-2.8.1.js`) — respecting the user's config and giving v2 parity rather
//! than inventing cyril's own posture. Prove-it confirmed KAS reads this handshake
//! (`experiments/conductor-spike/probe-kas-settings-subagent-orchestration-2.10.0.py`).
//!
//! One later row comes from Kiro's 2.32.0 TUI (`B1()` → `ZOn()`): the workflow
//! gate `workflows` + `goal`, following `chat.enableWorkflows` (ADR-0013,
//! cyril-sm36).
//!
//! KAS-only: v2 advertises no `_meta.kiro.settings` (`V2Engine` stays empty).

use serde_json::{Map, Value};

/// Read the global kiro-cli settings map at `path`.
///
/// An **absent** file yields an empty map (a KAS session with no user overrides is
/// legitimate). A **corrupt** file (unreadable, or not a JSON object) also yields an
/// empty map, but logs a `warn!` — missing and corrupt are distinct, and a parse
/// failure must never abort the `initialize` handshake. Load-bearing (CLAUDE.md:
/// don't collapse missing/corrupt; log before falling back), so this is real
/// runtime behavior, not a `debug_assert!`.
fn read_settings_at(path: &std::path::Path) -> Map<String, Value> {
    match std::fs::read_to_string(path) {
        Ok(s) => match serde_json::from_str::<Value>(&s) {
            Ok(Value::Object(m)) => m,
            Ok(_) => {
                tracing::warn!(path = %path.display(), "kiro cli.json is not a JSON object; using KAS defaults");
                Map::new()
            }
            Err(e) => {
                tracing::warn!(path = %path.display(), error = %e, "kiro cli.json parse failed; using KAS defaults");
                Map::new()
            }
        },
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => {
            tracing::debug!(path = %path.display(), "no kiro cli.json; using KAS defaults");
            Map::new()
        }
        Err(e) => {
            tracing::warn!(path = %path.display(), error = %e, "kiro cli.json read failed; using KAS defaults");
            Map::new()
        }
    }
}

/// Read the global kiro-cli settings (`<kiro-home>/settings/cli.json`, where
/// `<kiro-home>` follows [`crate::kiro_agent_config::resolve_kiro_home`]).
/// Missing home or file → empty map (see
/// [`read_settings_at`]). Workspace-scoped overlay is out of scope for v1
/// (tracked: cyril-sa39).
fn read_cli_settings(environment: &crate::types::SpawnEnvironment) -> Map<String, Value> {
    use std::ffi::OsStr;
    let home = environment
        .effective_var(OsStr::new("HOME"))
        .or_else(|| environment.effective_var(OsStr::new("USERPROFILE")))
        .map(std::path::PathBuf::from);
    let value = environment.effective_var(OsStr::new("KIRO_HOME"));
    match crate::kiro_agent_config::resolve_kiro_home(home.as_deref(), value.as_deref()) {
        Some(dir) => read_settings_at(&dir.join("settings/cli.json")),
        None => {
            tracing::debug!("selected environment has no Kiro settings home; using KAS defaults");
            Map::new()
        }
    }
}

/// The v2 `zme()` boolean mapping: `cli.json` key → `AgentSettings` key. A present
/// **boolean** value becomes `{enabled: <bool>}`; a non-boolean value is ignored.
/// Verbatim from `kiro-tui-2.8.1.js` (the independent source of truth).
const BOOL_MAP: &[(&str, &str)] = &[
    ("chat.enableThinking", "thinking"),
    ("chat.enableKnowledge", "knowledge"),
    ("chat.enableCodeIntelligence", "codeIntelligence"),
    ("chat.enableTodoList", "todoList"),
    ("chat.enableCheckpoint", "checkpoint"),
    ("chat.enableTangentMode", "tangentMode"),
    ("chat.disableAutoCompaction", "disableAutoCompaction"),
    ("chat.enableSubagent", "_subagent"),
    ("chat.enableDelegate", "_delegate"),
];

/// `AgentSettings` keys defaulted to `{enabled: true}` when absent after mapping.
/// `subagentOrchestration` has no `cli.json` source key — it is always default-on
/// (which selects the `orchestrate_subagent` tool; prove-it confirmed).
const DEFAULTS_ON: &[&str] = &[
    "codeIntelligence",
    "knowledge",
    "thinking",
    "subagentOrchestration",
];

/// The user's workflow opt-in, read like Kiro's `ea("chat.enableWorkflows", false)`:
/// only a boolean value counts; absent or any other type is `false`.
///
/// Kiro's `available` half is its `workflows` rollout row, which cyril cannot
/// evaluate (the Rust host sets `KIRO_ENABLED_FEATURES`; cyril spawns KAS
/// directly). In 2.32.0 that row is `treatment_percent: 100`, `segment: "all"`
/// ("generally available to all users on the KAS engine"), and this marshal
/// runs only for the KAS engine — so available is always true here.
/// `chat.enableWorkflows` is not in Kiro's workspace-overridable key set, so
/// the global `cli.json` this module reads is the only source.
fn workflows_enabled(e: &Map<String, Value>) -> bool {
    match e.get("chat.enableWorkflows") {
        Some(Value::Bool(enabled)) => *enabled,
        Some(other) => {
            tracing::warn!(value = %other, "kiro cli.json chat.enableWorkflows is not a boolean; workflows stay off");
            false
        }
        None => false,
    }
}

/// A numeric-but-not-boolean value, cloned. `serde_json`'s `is_number()` is already
/// false for `Value::Bool`, so a JSON `true` in a numeric slot is dropped (matching
/// zme's `typeof === "number"`), not coerced to 1.
fn num(v: &Value) -> Option<Value> {
    v.is_number().then(|| v.clone())
}

/// Marshal a kiro-cli settings map into an `AgentSettings` JSON object, replicating
/// v2's `zme()`. Pure and total: any map in → a valid object out.
pub(crate) fn marshal_agent_settings(e: &Map<String, Value>) -> Value {
    let mut n = Map::new();
    for (src, dst) in BOOL_MAP {
        if let Some(Value::Bool(b)) = e.get(*src) {
            n.insert((*dst).to_string(), serde_json::json!({ "enabled": b }));
        }
    }
    for k in DEFAULTS_ON {
        n.entry((*k).to_string())
            .or_insert_with(|| serde_json::json!({ "enabled": true }));
    }
    // The workflow gate (ADR-0013 decision 1, cyril-sm36): Kiro's TUI 2.32.0
    // `ab()`/`ZOn()` — `enabled = available && ea("chat.enableWorkflows", false)`
    // and, when available, `workflows` AND `goal` both set to it, stated
    // explicitly even when off.
    let workflows = serde_json::json!({ "enabled": workflows_enabled(e) });
    n.insert("workflows".to_string(), workflows.clone());
    n.insert("goal".to_string(), workflows);
    // `toolSearch` — gated on a boolean `toolSearch.enabled`; numeric extras only.
    if let Some(Value::Bool(enabled)) = e.get("toolSearch.enabled") {
        let mut ts = Map::new();
        ts.insert("enabled".to_string(), Value::Bool(*enabled));
        if let Some(v) = e.get("toolSearch.minPct").and_then(num) {
            ts.insert("minPct".to_string(), v);
        }
        if let Some(v) = e.get("toolSearch.minTokens").and_then(num) {
            ts.insert("minTokens".to_string(), v);
        }
        n.insert("toolSearch".to_string(), Value::Object(ts));
    }
    // `compaction` — gated on at least one numeric exclude; each field only if numeric.
    let pct = e
        .get("compaction.excludeContextWindowPercent")
        .and_then(num);
    let msg = e.get("compaction.excludeMessages").and_then(num);
    if pct.is_some() || msg.is_some() {
        let mut c = Map::new();
        c.insert("enabled".to_string(), Value::Bool(true));
        if let Some(v) = pct {
            c.insert("excludePercent".to_string(), v);
        }
        if let Some(v) = msg {
            c.insert("excludeMessages".to_string(), v);
        }
        n.insert("compaction".to_string(), Value::Object(c));
    }
    // `knowledge` (extended) — when `chat.enableKnowledge` is a boolean, zme
    // OVERWRITES the bool-map/default `knowledge` with the full tuning object.
    // Arrays for patterns; numeric-only for maxFiles/chunkSize/chunkOverlap;
    // indexType restricted to the two valid enum values. Absent → knowledge keeps
    // its default-on `{enabled:true}`.
    if let Some(Value::Bool(enabled)) = e.get("chat.enableKnowledge") {
        let mut k = Map::new();
        k.insert("enabled".to_string(), Value::Bool(*enabled));
        if let Some(Value::Array(a)) = e.get("knowledge.defaultIncludePatterns") {
            k.insert("includePatterns".to_string(), Value::Array(a.clone()));
        }
        if let Some(Value::Array(a)) = e.get("knowledge.defaultExcludePatterns") {
            k.insert("excludePatterns".to_string(), Value::Array(a.clone()));
        }
        if let Some(v) = e.get("knowledge.maxFiles").and_then(num) {
            k.insert("maxFiles".to_string(), v);
        }
        if let Some(v) = e.get("knowledge.chunkSize").and_then(num) {
            k.insert("chunkSize".to_string(), v);
        }
        if let Some(v) = e.get("knowledge.chunkOverlap").and_then(num) {
            k.insert("chunkOverlap".to_string(), v);
        }
        if let Some(Value::String(s)) = e.get("knowledge.indexType")
            && (s == "fast" || s == "accurate")
        {
            k.insert("indexType".to_string(), Value::String(s.clone()));
        }
        n.insert("knowledge".to_string(), Value::Object(k));
    }
    Value::Object(n)
}

/// The opaque `_meta.kiro.settings` content for the KAS handshake
/// advertisement (cyril-nhzw). Captured once from the selected launch environment
/// before constructing the engine. Content only: the presence-derived keys
/// (`hooks` per [ADR-0010]'s direction, fs dialect flags) are assembled by
/// `engine::client_capabilities` from the adapter set (cyril-dn91) — this
/// module no longer decides advertisement structure.
pub(crate) fn settings_extra_value(
    environment: &crate::types::SpawnEnvironment,
) -> serde_json::Value {
    marshal_agent_settings(&read_cli_settings(environment))
}

#[cfg(test)]
mod tests {
    #![allow(clippy::unwrap_used, clippy::expect_used)]

    use super::*;

    #[test]
    fn selected_home_fallback_and_snapshot_ignore_later_file_changes() {
        use crate::protocol::engine::{Engine, KasEngine};
        use crate::types::SpawnEnvironment;
        let root = tempfile::tempdir().unwrap();
        let settings = root.path().join(".kiro/settings");
        std::fs::create_dir_all(&settings).unwrap();
        let file = settings.join("cli.json");
        std::fs::write(&file, r#"{"chat.enableThinking":false}"#).unwrap();
        for home_key in ["HOME", "USERPROFILE"] {
            let environment = SpawnEnvironment::Replace(std::collections::BTreeMap::from([
                (home_key.into(), root.path().as_os_str().to_owned()),
                ("KIRO_HOME".into(), "".into()),
            ]));
            let engine = KasEngine {
                settings: settings_extra_value(&environment),
                ..Default::default()
            };
            std::fs::write(&file, r#"{"chat.enableThinking":true}"#).unwrap();
            assert_eq!(
                engine.settings_extra().unwrap()["thinking"]["enabled"],
                false
            );
            assert_eq!(
                settings_extra_value(&environment)["thinking"]["enabled"],
                true
            );
            std::fs::write(&file, r#"{"chat.enableThinking":false}"#).unwrap();
        }
        let empty = SpawnEnvironment::Replace(std::collections::BTreeMap::new());
        assert_eq!(settings_extra_value(&empty)["thinking"]["enabled"], true);
    }

    #[test]
    fn absent_file_defaults() {
        // Claim 7: a nonexistent settings file yields an empty map, never an error
        // or panic (a KAS session with no user cli.json is normal). Fails if the
        // reader errors/propagates on NotFound instead of returning empty.
        let dir = tempfile::tempdir().unwrap();
        let missing = dir.path().join("nope/cli.json");
        assert!(read_settings_at(&missing).is_empty());
    }

    #[test]
    fn malformed_file_defaults() {
        // Claim 8 (stress: missing ≠ corrupt): a file that exists but is invalid
        // JSON must yield an empty map, NOT panic and NOT abort initialize. Fails
        // under `serde_json::from_str(..).unwrap()` or `?`-propagation.
        let dir = tempfile::tempdir().unwrap();
        let bad = dir.path().join("cli.json");
        std::fs::write(&bad, "{ this is not json").unwrap();
        assert!(read_settings_at(&bad).is_empty());
        // A JSON value that isn't an object (e.g. an array) is also tolerated.
        let arr = dir.path().join("arr.json");
        std::fs::write(&arr, "[1,2,3]").unwrap();
        assert!(read_settings_at(&arr).is_empty());
    }

    fn map(pairs: &[(&str, Value)]) -> Map<String, Value> {
        pairs
            .iter()
            .map(|(k, v)| (k.to_string(), v.clone()))
            .collect()
    }
    fn on() -> Value {
        serde_json::json!({ "enabled": true })
    }

    #[test]
    fn defaults_only() {
        // Claim 4: an empty settings map yields EXACTLY the four default-on keys
        // plus Kiro's explicit-off workflow gate pair (`workflows`, `goal`;
        // cyril-sm36), nothing else. Fails if a default is missing or a
        // non-default key leaks.
        let got = marshal_agent_settings(&Map::new());
        let obj = got.as_object().unwrap();
        assert_eq!(obj.len(), 6, "the 4 defaults + the gate pair: {got}");
        for k in [
            "codeIntelligence",
            "knowledge",
            "thinking",
            "subagentOrchestration",
        ] {
            assert_eq!(obj.get(k), Some(&on()), "default {k}");
        }
    }

    #[test]
    fn all_bool_keys_map() {
        // Claim 2: each of the 9 bool cli.json keys present=true maps to its
        // AgentSettings key as {enabled:true}, per the zme table (no renamed key).
        let src: Vec<(&str, Value)> = BOOL_MAP
            .iter()
            .map(|(s, _)| (*s, Value::Bool(true)))
            .collect();
        let got = marshal_agent_settings(&map(&src));
        let obj = got.as_object().unwrap();
        for (_, dst) in BOOL_MAP {
            assert_eq!(obj.get(*dst), Some(&on()), "mapped key {dst}: {got}");
        }
    }

    #[test]
    fn nonbool_ignored() {
        // Claim 3 (stress): a non-default key with a NON-boolean value must be
        // omitted (no coercion), and a default key with a non-bool value falls back
        // to its default. Fails under `as_bool().unwrap_or(true)`-style coercion.
        let got = marshal_agent_settings(&map(&[
            ("chat.enableCheckpoint", Value::String("yes".into())), // non-default → omit
            ("chat.enableThinking", serde_json::json!(1)),          // default key, non-bool
        ]));
        let obj = got.as_object().unwrap();
        assert_eq!(
            obj.get("checkpoint"),
            None,
            "non-bool non-default omitted: {got}"
        );
        assert_eq!(
            obj.get("thinking"),
            Some(&on()),
            "thinking falls to default-on: {got}"
        );
    }

    #[test]
    fn false_preserved() {
        // Claim 4b (stress): a default key explicitly set to `false` stays
        // {enabled:false} — the default-on pass must NOT overwrite it. Fails under
        // `if v { insert }` (which drops false, then default-on re-adds it as true).
        let got = marshal_agent_settings(&map(&[("chat.enableThinking", Value::Bool(false))]));
        assert_eq!(
            got.as_object().unwrap().get("thinking"),
            Some(&serde_json::json!({ "enabled": false })),
            "explicit false preserved, not defaulted-on: {got}"
        );
    }

    #[test]
    fn toolsearch_shapes() {
        // Claim 5: toolSearch emitted with numeric minPct/minTokens when present;
        // stress: a boolean in a numeric slot (minPct=true) is dropped, not coerced.
        let full = marshal_agent_settings(&map(&[
            ("toolSearch.enabled", Value::Bool(true)),
            ("toolSearch.minPct", serde_json::json!(0)),
            ("toolSearch.minTokens", serde_json::json!(500)),
        ]));
        assert_eq!(
            full.as_object().unwrap().get("toolSearch"),
            Some(&serde_json::json!({ "enabled": true, "minPct": 0, "minTokens": 500 })),
            "full toolSearch: {full}"
        );
        let bool_pct = marshal_agent_settings(&map(&[
            ("toolSearch.enabled", Value::Bool(true)),
            ("toolSearch.minPct", Value::Bool(true)), // not a number → dropped
        ]));
        assert_eq!(
            bool_pct.as_object().unwrap().get("toolSearch"),
            Some(&serde_json::json!({ "enabled": true })),
            "bool minPct dropped, not coerced: {bool_pct}"
        );
    }

    #[test]
    fn toolsearch_needs_enabled() {
        // Claim 5b (stress): minPct present but no `enabled` → toolSearch OMITTED
        // entirely. Fails if the object is built from a partial field.
        let got = marshal_agent_settings(&map(&[("toolSearch.minPct", serde_json::json!(5))]));
        assert_eq!(
            got.as_object().unwrap().get("toolSearch"),
            None,
            "no enabled → omit: {got}"
        );
    }

    #[test]
    fn knowledge_extended() {
        // zme's `chat.enableKnowledge` block: a boolean source OVERWRITES the
        // default `knowledge` with the full tuning object — arrays for patterns,
        // numeric tuning kept, a bool in a numeric slot dropped (not coerced), and
        // indexType only for the two valid enum values. Fails if the extended block
        // is dropped (knowledge stays a bare `{enabled}` from the default/bool-map).
        let got = marshal_agent_settings(&map(&[
            ("chat.enableKnowledge", Value::Bool(true)),
            ("knowledge.maxFiles", serde_json::json!(200)),
            ("knowledge.chunkSize", Value::Bool(true)), // non-number → dropped
            ("knowledge.indexType", Value::String("accurate".into())),
            (
                "knowledge.defaultIncludePatterns",
                serde_json::json!(["*.rs"]),
            ),
        ]));
        assert_eq!(
            got.as_object().unwrap().get("knowledge"),
            Some(&serde_json::json!({
                "enabled": true,
                "maxFiles": 200,
                "indexType": "accurate",
                "includePatterns": ["*.rs"]
            })),
            "knowledge extended block: {got}"
        );
        // Invalid indexType dropped; explicit `false` preserved (not defaulted-on).
        let bad_idx = marshal_agent_settings(&map(&[
            ("chat.enableKnowledge", Value::Bool(false)),
            ("knowledge.indexType", Value::String("turbo".into())),
        ]));
        assert_eq!(
            bad_idx.as_object().unwrap().get("knowledge"),
            Some(&serde_json::json!({ "enabled": false })),
            "invalid indexType dropped, false preserved: {bad_idx}"
        );
    }

    #[test]
    fn compaction_shapes() {
        // Claim 6 (stress: one-sided): only excludeMessages present → compaction
        // has enabled+excludeMessages, no excludePercent invented; neither → omitted.
        let one = marshal_agent_settings(&map(&[(
            "compaction.excludeMessages",
            serde_json::json!(3),
        )]));
        assert_eq!(
            one.as_object().unwrap().get("compaction"),
            Some(&serde_json::json!({ "enabled": true, "excludeMessages": 3 })),
            "one-sided compaction: {one}"
        );
        let none = marshal_agent_settings(&Map::new());
        assert_eq!(
            none.as_object().unwrap().get("compaction"),
            None,
            "no exclude → omit"
        );
    }

    #[test]
    fn marshal_live_fixture() {
        // Claim 9 (integration / CI fence for behavioral claims 10-11): a realistic
        // cli.json — flat dotted keys ALONGSIDE a nested `chat` object that must be
        // IGNORED (zme reads flat keys only), absent mapped keys, and unmapped keys —
        // must produce exactly the zme-derived AgentSettings. A key-name typo in the
        // table passes the narrow unit fixtures but breaks here. Oracle: the expected
        // object independently hand-derived in .cyril-nhzw/cheapest-falsifier.py.
        let cli = r#"{
            "chat": { "enableKnowledge": true, "showThinking": true, "agentEngine": "v3" },
            "chat.defaultModel": "claude-opus-4.8",
            "chat.disableMarkdownRendering": false,
            "chat.enableThinking": true,
            "chat.enableTodoList": true,
            "introspect.progressiveMode": true,
            "toolSearch.enabled": true,
            "toolSearch.minPct": 0,
            "toolSearch.minTokens": 0
        }"#;
        let e: Map<String, Value> = serde_json::from_str(cli).unwrap();
        let got = marshal_agent_settings(&e);
        // Nested `chat.enableKnowledge` is ignored (no FLAT key) → knowledge via
        // default; codeIntelligence/subagentOrchestration via default; unmapped keys
        // (defaultModel, disableMarkdownRendering, progressiveMode) dropped.
        let expected = serde_json::json!({
            "thinking": { "enabled": true },
            "todoList": { "enabled": true },
            "knowledge": { "enabled": true },
            "codeIntelligence": { "enabled": true },
            "subagentOrchestration": { "enabled": true },
            "toolSearch": { "enabled": true, "minPct": 0, "minTokens": 0 },
            "workflows": { "enabled": false },
            "goal": { "enabled": false }
        });
        assert_eq!(got, expected, "live fixture marshal mismatch");
    }

    /// The two keys Kiro's TUI derives from the workflow gate (`ZOn`).
    fn gate_keys(got: &Value) -> (Option<&Value>, Option<&Value>) {
        (got.get("workflows"), got.get("goal"))
    }

    /// ADR-0013 decision 1 (cyril-sm36): the workflow gate follows the user's
    /// flat global `chat.enableWorkflows`, read like Kiro's `ea(key, false)` —
    /// only a boolean counts, anything else is the default `false` — and both
    /// `workflows` and `goal` carry that value, always stated explicitly. A
    /// nested `chat` object and a lookalike `workflows.enabled` key are not
    /// Kiro's setting and must not move the gate.
    #[rstest::rstest]
    #[case::enabled(&[("chat.enableWorkflows", Value::Bool(true))], true)]
    #[case::disabled(&[("chat.enableWorkflows", Value::Bool(false))], false)]
    #[case::absent(&[], false)]
    #[case::string_true(&[("chat.enableWorkflows", Value::String("true".into()))], false)]
    #[case::number_one(&[("chat.enableWorkflows", serde_json::json!(1))], false)]
    #[case::nested_chat_object_ignored(
        &[("chat", serde_json::json!({ "enableWorkflows": true }))],
        false
    )]
    #[case::lookalike_key_ignored(&[("workflows.enabled", Value::Bool(true))], false)]
    fn workflow_gate_follows_chat_enable_workflows(
        #[case] source: &[(&str, Value)],
        #[case] enabled: bool,
    ) {
        let got = marshal_agent_settings(&map(source));
        let expected = serde_json::json!({ "enabled": enabled });
        assert_eq!(
            gate_keys(&got),
            (Some(&expected), Some(&expected)),
            "workflows and goal both {{enabled:{enabled}}}: {got}"
        );
    }

    /// End to end through the launch environment: a `cli.json` planted where
    /// Kiro reads it (`$KIRO_HOME/settings/cli.json`, else
    /// `<home>/.kiro/settings/cli.json`) reaches `initialize` as
    /// `clientCapabilities._meta.kiro.settings.{workflows,goal}`. The fake
    /// environment replaces every variable, so no real home is consulted.
    #[rstest::rstest]
    #[case::kiro_home("KIRO_HOME", "")]
    #[case::home("HOME", ".kiro")]
    #[case::userprofile("USERPROFILE", ".kiro")]
    fn initialize_carries_workflow_gate_from_selected_cli_json(
        #[case] variable: &str,
        #[case] relative_home: &str,
    ) {
        use crate::protocol::engine::{KasEngine, client_capabilities};
        use crate::types::SpawnEnvironment;
        let root = tempfile::tempdir().unwrap();
        let settings_dir = root.path().join(relative_home).join("settings");
        std::fs::create_dir_all(&settings_dir).unwrap();
        std::fs::write(
            settings_dir.join("cli.json"),
            r#"{"chat.enableWorkflows":true}"#,
        )
        .unwrap();
        let environment = SpawnEnvironment::Replace(std::collections::BTreeMap::from([(
            variable.into(),
            root.path().as_os_str().to_owned(),
        )]));
        let engine = KasEngine {
            settings: settings_extra_value(&environment),
            ..Default::default()
        };
        let caps = client_capabilities(&engine);
        let settings = caps
            .meta
            .as_ref()
            .and_then(|meta| meta.get("kiro"))
            .and_then(|kiro| kiro.get("settings"))
            .expect("_meta.kiro.settings");
        assert_eq!(
            gate_keys(settings),
            (Some(&on()), Some(&on())),
            "gate on from {variable}: {settings}"
        );
    }

    #[rstest::rstest]
    #[case::home_equal("HOME", "home")]
    #[case::home_ancestor("HOME", "ancestor")]
    #[case::userprofile_ancestor("USERPROFILE", "ancestor")]
    #[case::trimmed_override("HOME", "trimmed")]
    #[case::blank_override("HOME", "whitespace")]
    fn initialize_workflow_gate_uses_validated_selected_profile(
        #[case] home_variable: &str,
        #[case] kind: &str,
    ) {
        use crate::protocol::engine::{KasEngine, client_capabilities};
        use crate::types::SpawnEnvironment;
        let root = tempfile::tempdir().unwrap();
        let home = root.path().join("home");
        let override_root = root.path().join("profile ü");
        let value = match kind {
            "home" => home.as_os_str().to_owned(),
            "ancestor" => root.path().as_os_str().to_owned(),
            "trimmed" => format!(" \t{} \u{2003}", override_root.display()).into(),
            _ => " \t\u{2003} ".into(),
        };
        for (profile, enabled) in [
            (home.join(".kiro"), kind != "trimmed"),
            (override_root, kind == "trimmed"),
            (home.clone(), false),
            (root.path().to_path_buf(), false),
        ] {
            let settings = profile.join("settings");
            std::fs::create_dir_all(&settings).unwrap();
            std::fs::write(
                settings.join("cli.json"),
                serde_json::json!({"chat.enableWorkflows": enabled}).to_string(),
            )
            .unwrap();
        }
        let environment = SpawnEnvironment::Replace(std::collections::BTreeMap::from([
            (home_variable.into(), home.into_os_string()),
            ("KIRO_HOME".into(), value),
        ]));
        let engine = KasEngine {
            settings: settings_extra_value(&environment),
            ..Default::default()
        };
        let caps = client_capabilities(&engine);
        let settings = caps
            .meta
            .as_ref()
            .and_then(|meta| meta.get("kiro"))
            .and_then(|kiro| kiro.get("settings"))
            .expect("_meta.kiro.settings");
        assert_eq!(
            gate_keys(settings),
            (Some(&on()), Some(&on())),
            "{kind} must select the validated profile, not an invalid-root cli.json: {settings}"
        );
    }
}
