//! Free-path KAS spawn discovery (KAS-1 Part A, cyril-evwh; versioned dirs +
//! callback auth, cyril-dcc6).
//!
//! Resolves the argv that spawns the bundled `@kiro/agent` ACP server directly
//! over stdio with `--auth=acp-callback` — the non-path flags are byte-equal
//! to kiro-cli's own spawn (probe-verified against /proc; the node binary is
//! whatever cyril resolves). KAS then requests credentials via
//! `_kiro/auth/getAccessToken`, answered by [`super::auth`] through kiro-cli's
//! `chat _ get-kas-token` helper (cyril-zbu7); the credential store is read
//! only when kiro-cli lacks that helper. Reuses
//! [`AgentCommand`] as the spawn description so `AgentProcess::spawn` consumes
//! it unchanged.

use std::ffi::OsStr;
use std::path::{Path, PathBuf};

use crate::types::AgentCommand;

/// A precondition for the free-path spawn that was not satisfied. Each variant
/// names the specific missing item so the bridge can emit an actionable
/// `BridgeDisconnected` (spec B6) instead of a silent hang or a v2 fallback.
#[derive(Debug, PartialEq, Eq)]
pub(crate) enum KasMissing {
    /// No kiro data dir can be resolved from the platform's data-directory
    /// sources, and no path override was given.
    NoHome,
    /// The KAS server bundle (`acp-server.js`) is not a file at the resolved path.
    Server(PathBuf),
    /// No `node` runtime (`KIRO_AGENT_PATH` unset/missing and none on `PATH`).
    Node,
    /// kiro-cli cannot provide a KAS access token right now (cyril-zbu7):
    /// `why` is the typed helper failure's actionable diagnostic — kiro-cli
    /// absent, wedged, failing, logged out, or answering malformed — so a
    /// missing binary is never misreported as "run `kiro-cli login`".
    AuthUnavailable { why: String },
}

impl KasMissing {
    /// A user-facing, actionable reason for the `BridgeDisconnected` (spec B6).
    pub(crate) fn reason(&self) -> String {
        #[cfg(windows)]
        const MISSING_DATA_DIR: &str = "no Windows local data directory (LOCALAPPDATA and the known-folder lookup unavailable)";
        #[cfg(not(windows))]
        const MISSING_DATA_DIR: &str = "no home directory (HOME unset)";
        match self {
            KasMissing::NoHome => format!(
                "cannot locate the KAS bundle: {MISSING_DATA_DIR}. \
                 Set KIRO_KAS_SERVER_PATH to the acp-server.js path."
            ),
            KasMissing::Server(p) => format!(
                "KAS bundle not found at {}. Run `kiro-cli acp --agent-engine v3` \
                 once to self-extract it, or set KIRO_KAS_SERVER_PATH.",
                p.display()
            ),
            KasMissing::Node => "node runtime not found. Install Node.js (on PATH) or set \
                 KIRO_AGENT_PATH to the node binary."
                .to_string(),
            KasMissing::AuthUnavailable { why } => format!("KAS auth unavailable: {why}"),
        }
    }
}

/// `<home>`-relative default for `$XDG_DATA_HOME` (XDG Base Directory spec) —
/// the fallback kiro-cli's own `dirs`-based resolution uses on XDG targets.
#[cfg(any(not(any(windows, target_os = "macos", target_os = "ios")), test))]
const XDG_DATA_HOME_DEFAULT_REL: &str = ".local/share";
/// kiro-cli's data dir name under the XDG data home. The resolved data
/// dir is the parent of the KAS extraction root.
#[cfg(any(not(any(windows, target_os = "macos", target_os = "ios")), test))]
const KIRO_DATA_DIR_NAME: &str = "kiro-cli";
/// Data-dir-relative KAS self-extraction root. kiro ≥2.10.0 extracts into
/// versioned `<semver>-<sha256>/` dirs under it; older releases extracted the
/// bundle directly at the root (the legacy layout).
const KAS_ROOT_REL: &str = "kas";
/// Data-dir-relative credential store: the sqlite database `kiro-cli login`
/// maintains — consulted only by the stored-token fallback.
const STORE_FILE_NAME: &str = "data.sqlite3";
/// Path of the ACP server entry inside one extraction (versioned dir or the
/// legacy root itself).
const SERVER_IN_ROOT_REL: &str = "node_modules/@kiro/agent/dist/server/acp-server.js";

/// kiro-cli's data dir (cyril-brui): `$XDG_DATA_HOME/kiro-cli` when
/// `XDG_DATA_HOME` is set, non-empty and absolute, else
/// `<home>/.local/share/kiro-cli` — the `dirs::data_local_dir` rule kiro-cli
/// resolves through on the targets `dirs` routes to `lin.rs` (Linux, Android,
/// the BSDs, illumos, Redox — `dirs-6.0.0/src/lib.rs`). Strace-proven on
/// Linux 2.24.0: `settings list` under `HOME=<tmp> XDG_DATA_HOME=<x>` opens
/// `<x>/kiro-cli/data.sqlite3` and never touches `<tmp>/.local/share`; see
/// `.cyril-brui/evidence.md`. An empty or relative value falls back to
/// `<home>` with a warning naming it.
///
/// Pure (no env reads) so every branch is unit-testable on every host
/// without env mutation (`set_var` is `unsafe` in Rust 2024, forbidden in
/// this workspace); [`kiro_data_dir_from_env`] is the one production caller,
/// and `env_wrappers_resolve_xdg_data_home_like_kiro_cli` drives the wrappers
/// themselves through a re-entered child process with a private environment.
#[cfg(any(not(any(windows, target_os = "macos", target_os = "ios")), test))]
fn kiro_data_dir(home: Option<&Path>, xdg_data_home: Option<&OsStr>) -> Option<PathBuf> {
    if let Some(value) = xdg_data_home {
        let xdg = Path::new(value);
        // `is_absolute` is false for the empty string too.
        if xdg.is_absolute() {
            return Some(xdg.join(KIRO_DATA_DIR_NAME));
        }
        tracing::warn!(
            value = ?value,
            "XDG_DATA_HOME is not an absolute path; kiro data dir falls back to <home>/.local/share"
        );
    }
    home.map(|h| h.join(XDG_DATA_HOME_DEFAULT_REL).join(KIRO_DATA_DIR_NAME))
}

/// macOS/iOS use `<home>/Library/Application Support/kiro-cli`, matching
/// kiro-cli's `dirs::data_local_dir` rule (`dirs-6.0.0/src/mac.rs`).
/// Pure like the other platform helpers; XDG and LOCALAPPDATA play no role.
#[cfg(any(target_os = "macos", target_os = "ios", test))]
fn apple_kiro_data_dir(home: Option<&Path>) -> Option<PathBuf> {
    home.map(|h| h.join("Library/Application Support/kiro-cli"))
}

/// Windows uses `%LOCALAPPDATA%\Kiro-Cli`, or the Windows local-app-data
/// known folder if the environment value is absent or not absolute. The
/// fallback is lazy and injected so unavailable/invalid roots are testable
/// on every host without mutating the process environment.
#[cfg(any(windows, test))]
fn windows_kiro_data_dir(
    local_app_data: Option<&OsStr>,
    known_folder: impl FnOnce() -> Option<PathBuf>,
) -> Option<PathBuf> {
    if let Some(value) = local_app_data {
        let local = Path::new(value);
        if local.is_absolute() {
            return Some(local.join("Kiro-Cli"));
        }
        tracing::warn!(
            value = ?value,
            "LOCALAPPDATA is not an absolute path; kiro data dir falls back to the Windows known folder"
        );
    }
    let Some(local) = known_folder() else {
        tracing::debug!("Windows local-app-data known folder unavailable");
        return None;
    };
    if !local.is_absolute() {
        tracing::warn!(path = %local.display(), "Windows local-app-data known folder is not absolute");
        return None;
    }
    Some(local.join("Kiro-Cli"))
}

/// The one platform resolution of kiro-cli's data dir (the KAS bundle root).
/// Windows uses local AppData, macOS/iOS use Library/Application Support,
/// and other targets follow the XDG/HOME rules.
fn kiro_data_dir_from_env() -> Option<PathBuf> {
    #[cfg(windows)]
    {
        windows_kiro_data_dir(
            std::env::var_os("LOCALAPPDATA").as_deref(),
            dirs::data_local_dir,
        )
    }
    #[cfg(any(target_os = "macos", target_os = "ios"))]
    {
        apple_kiro_data_dir(crate::kiro_agent_config::home_dir().as_deref())
    }
    #[cfg(not(any(windows, target_os = "macos", target_os = "ios")))]
    {
        let xdg_data_home = std::env::var_os("XDG_DATA_HOME");
        kiro_data_dir(
            crate::kiro_agent_config::home_dir().as_deref(),
            xdg_data_home.as_deref(),
        )
    }
}

/// kiro-cli's credential store under `data_dir` — read ONLY by the
/// stored-token fallback for a kiro-cli without `chat _ get-kas-token`
/// (cyril-zbu7 amendment).
fn store_path(data_dir: &Path) -> PathBuf {
    data_dir.join(STORE_FILE_NAME)
}

/// kiro-cli's credential store — `<kiro data dir>/data.sqlite3`, under
/// `%LOCALAPPDATA%\Kiro-Cli` on Windows, Library/Application Support on
/// macOS/iOS, or the XDG/HOME root on other targets. Consulted only by the
/// stored-token fallback ([`super::auth`]).
pub(crate) fn default_store_path() -> Option<PathBuf> {
    kiro_data_dir_from_env().map(|d| store_path(&d))
}

/// The KAS self-extraction root under `data_dir`.
fn kas_root(data_dir: &Path) -> PathBuf {
    data_dir.join(KAS_ROOT_REL)
}

/// Strictly parse a versioned-extraction dir name — `<MAJOR.MINOR.PATCH>-<sha>`
/// with exactly 64 lowercase hex sha digits (e.g. `2.11.0-05e9…`) — into its
/// semver tuple. Deliberately NOT [`super::version::parse_semver`]: that parser
/// is lenient by design (it tolerates `kiro-cli 2.8.1-beta` CLI output), and
/// leniency here would admit non-extraction dirs (`v2.10.0-…`, `2.10-…`) as
/// spawn candidates.
fn dir_version(name: &str) -> Option<(u32, u32, u32)> {
    let (ver, sha) = name.split_once('-')?;
    if sha.len() != 64
        || !sha
            .bytes()
            .all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
    {
        return None;
    }
    let mut parts = ver.split('.');
    let mut num = || -> Option<u32> {
        let p = parts.next()?;
        if p.is_empty() || !p.bytes().all(|b| b.is_ascii_digit()) {
            return None;
        }
        p.parse().ok()
    };
    let v = (num()?, num()?, num()?);
    if parts.next().is_some() {
        return None;
    }
    Some(v)
}

/// Pick the versioned-extraction dir to spawn from `entries`
/// (`(dir_name, has_server_entry)` pairs listed from the kas root):
/// a dir matching `cli_version` exactly beats the newest by semver-tuple
/// order; dirs failing the name grammar or lacking the inner `acp-server.js`
/// (partial extractions) are never candidates; version ties resolve to the
/// greatest dir name, so duplicate re-extractions pick deterministically.
/// `None` means no versioned candidate — the caller falls back to the legacy
/// unversioned layout.
fn select_server(entries: &[(String, bool)], cli_version: Option<(u32, u32, u32)>) -> Option<&str> {
    let mut exact: Option<&str> = None;
    let mut newest: Option<((u32, u32, u32), &str)> = None;
    for (name, has_server) in entries {
        if !has_server {
            continue;
        }
        let Some(v) = dir_version(name) else { continue };
        if Some(v) == cli_version && exact.is_none_or(|b| name.as_str() > b) {
            exact = Some(name);
        }
        if newest.is_none_or(|(bv, bn)| (v, name.as_str()) > (bv, bn)) {
            newest = Some((v, name));
        }
    }
    if exact.is_some() {
        return exact;
    }
    let (_, name) = newest?;
    if let Some((maj, min, pat)) = cli_version {
        // An entry matching the CLI version would have set `exact`, so reaching
        // here with a known version means a MISMATCHED bundle is about to spawn
        // (fresh upgrade not yet self-extracted, or the matching extraction is
        // partial) — leave a breadcrumb (dcc6 review F5).
        tracing::warn!(
            cli_version = format_args!("{maj}.{min}.{pat}"),
            selected = name,
            "no KAS extraction matches the installed kiro-cli; spawning the newest"
        );
    }
    Some(name)
}

/// Treat an env value as "not provided" when unset or empty/whitespace-only —
/// so `KIRO_AGENT_PATH=""` falls back to PATH rather than spawning the empty
/// string as a binary.
///
/// Shared with the KAS wire adapters: a required wire string that is present
/// but blank identifies nothing, so it is the same fact as a missing one (see
/// `convert/kas/powers.rs`).
pub(crate) fn nonempty(v: Option<String>) -> Option<String> {
    v.filter(|s| !s.trim().is_empty())
}

/// First `node<EXE_SUFFIX>` found in a PATH-style variable, if any. Uses
/// [`std::env::split_paths`] so the separator (`:` vs `;`) is correct per
/// platform; `EXE_SUFFIX` adds `.exe` on Windows.
fn find_on_path(path_var: Option<&OsStr>, exists: impl Fn(&Path) -> bool) -> Option<PathBuf> {
    let exe = format!("node{}", std::env::consts::EXE_SUFFIX);
    let path_var = path_var?;
    std::env::split_paths(path_var)
        .map(|dir| dir.join(&exe))
        .find(|cand| exists(cand))
}

/// Resolve the free-path spawn argv from explicit inputs, using `exists` to test
/// file presence. Pure (no env reads, no real filesystem), so the precheck
/// matrix is unit-testable. Preconditions are load-bearing for correctness — a
/// missing item must surface as the right typed `Err`, not a later opaque spawn
/// failure — so they are enforced as runtime returns, not `debug_assert!`.
fn resolve(
    data_dir: Option<&Path>,
    server_override: Option<&str>,
    node_override: Option<&str>,
    path_var: Option<&OsStr>,
    kas_entries: &[(String, bool)],
    cli_version: Option<(u32, u32, u32)>,
    exists: impl Fn(&Path) -> bool,
) -> Result<AgentCommand, KasMissing> {
    // 1. server.js — override, else the selected versioned dir under
    //    <kiro data dir>/<kas root>, else the legacy unversioned layout; must
    //    exist.
    let server: PathBuf = match server_override {
        Some(s) => PathBuf::from(s),
        None => {
            let root = kas_root(data_dir.ok_or(KasMissing::NoHome)?);
            match select_server(kas_entries, cli_version) {
                Some(dir) => root.join(dir).join(SERVER_IN_ROOT_REL),
                None => {
                    // dcc6 re-review N3: kiro ≥2.10.0 always extracts versioned
                    // dirs, so a known modern CLI reaching the legacy fallback
                    // is the same mismatch class as the F5 warn above (upgrade
                    // not yet self-extracted; stale legacy bundle spawns).
                    // Below 2.10.0 the legacy layout IS current — no warn.
                    if let Some((maj, min, pat)) = cli_version
                        && (maj, min, pat) >= (2, 10, 0)
                    {
                        tracing::warn!(
                            cli_version = format_args!("{maj}.{min}.{pat}"),
                            "no versioned KAS extraction found for a >=2.10.0 kiro-cli; spawning the legacy unversioned bundle"
                        );
                    }
                    root.join(SERVER_IN_ROOT_REL)
                }
            }
        }
    };
    if !exists(&server) {
        return Err(KasMissing::Server(server));
    }

    // 2. node — override (must exist), else the first `node` on PATH.
    let node: PathBuf = match node_override {
        Some(n) => {
            let p = PathBuf::from(n);
            if !exists(&p) {
                return Err(KasMissing::Node);
            }
            p
        }
        None => find_on_path(path_var, &exists).ok_or(KasMissing::Node)?,
    };

    Ok(
        AgentCommand::new(node.to_string_lossy().into_owned()).with_args(vec![
            "--experimental-wasm-modules".to_string(),
            server.to_string_lossy().into_owned(),
            "--transport=stdio".to_string(),
            "--auth=acp-callback".to_string(),
        ]),
    )
}

/// List the kas extraction root: one `(dir_name, has_server_entry)` pair per
/// directory entry. A missing root yields an empty list (normal on a machine
/// where kiro-cli has never self-extracted — `resolve` then reports the
/// actionable `Server` error); an unreadable root warns before the same
/// fallback (dcc6 review F13 — the `Server` reason's "run kiro-cli acp to
/// self-extract" remedy is wrong for a permissions problem, so the log line
/// must carry the real cause). Individual entries that can't be read or hold
/// non-UTF-8 names are skipped with a debug line (F12) — a skipped entry
/// could otherwise silently cost the exact-match dir.
fn list_kas_entries(root: &Path) -> Vec<(String, bool)> {
    let entries = match std::fs::read_dir(root) {
        Ok(e) => e,
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Vec::new(),
        Err(e) => {
            tracing::warn!(root = %root.display(), error = %e, "kas root unreadable; treating as never extracted");
            return Vec::new();
        }
    };
    entries
        .filter_map(|entry| {
            let entry = match entry {
                Ok(e) => e,
                Err(e) => {
                    tracing::debug!(root = %root.display(), error = %e, "unreadable kas dir entry skipped");
                    return None;
                }
            };
            let name = match entry.file_name().into_string() {
                Ok(n) => n,
                Err(raw) => {
                    tracing::debug!(root = %root.display(), name = ?raw, "non-UTF-8 kas dir entry skipped");
                    return None;
                }
            };
            let has_server = root.join(&name).join(SERVER_IN_ROOT_REL).is_file();
            Some((name, has_server))
        })
        .collect()
}

/// The installed kiro-cli's semver tuple, from `<kiro-cli> --version` run on
/// the SAME resolved kiro-cli the login gate and the `getAccessToken`
/// responder ask (`token_source`, cyril-zbu7 Review 3) — so probe, gate and
/// responder provably use one binary.
/// `None` (binary absent, non-zero exit, unparseable output) is warn-logged —
/// selection then prefers the newest extraction instead of an exact match,
/// which is the best available guess when the CLI can't be asked.
async fn installed_cli_version(
    token_source: &super::auth::KasTokenSource,
) -> Option<(u32, u32, u32)> {
    let step =
        super::version::invocation_version(token_source.kiro_cli(), token_source.environment())
            .await
            .and_then(|v| super::version::parse_semver(&v));
    match step {
        Ok(v) => Some(v),
        Err(e) => {
            tracing::warn!(error = %e, "kiro-cli version unavailable; selecting newest KAS extraction");
            None
        }
    }
}

/// Resolve the free-path KAS spawn from the real environment + filesystem.
/// `KIRO_KAS_SERVER_PATH` / `KIRO_AGENT_PATH` override the defaults.
/// `token_source` is the kiro-cli the login gate asks — the same source the
/// session's `getAccessToken` responder uses.
pub(crate) async fn resolve_kas_command(
    token_source: &super::auth::KasTokenSource,
) -> Result<AgentCommand, KasMissing> {
    // Resolved ONCE per spawn: the root scan and `resolve` both derive from
    // this value (F19b), and an invalid directory environment value warns
    // once rather than once per consumer.
    let data_dir = kiro_data_dir_from_env();
    let server_override = nonempty(std::env::var("KIRO_KAS_SERVER_PATH").ok());
    let node_override = nonempty(std::env::var("KIRO_AGENT_PATH").ok());
    let path_var = std::env::var_os("PATH");
    // The dir scan + `kiro-cli --version` subprocess only run when they can
    // influence selection: an override names the server directly (and must win
    // without paying that cost), and no data dir means no root to scan
    // (`resolve` reports `NoHome`). The match makes the data-dir-is-present
    // invariant of the scanning arm structural (dcc6 review F14 — no dead
    // unwrap_or_default).
    let (kas_entries, cli_version) = match (server_override.as_deref(), data_dir.as_deref()) {
        (Some(_), _) | (None, None) => (Vec::new(), None),
        (None, Some(d)) => (
            list_kas_entries(&kas_root(d)),
            installed_cli_version(token_source).await,
        ),
    };
    let cmd = resolve(
        data_dir.as_deref(),
        server_override.as_deref(),
        node_override.as_deref(),
        path_var.as_deref(),
        &kas_entries,
        cli_version,
        |p| p.is_file(),
    )?;
    // Login gate (C14a, cyril-zbu7): with `--auth=acp-callback` the responder
    // is load-bearing for every turn, so ask kiro-cli for the token exactly
    // as the responder will (`chat _ get-kas-token`, which refreshes an
    // expired token) — kiro-cli absent, wedged, failing, logged out, or
    // answering malformed fails the spawn here with its precise diagnostic,
    // instead of as a dead first turn. The token itself is dropped unused.
    if let Err(e) = token_source.fetch(false).await {
        return Err(KasMissing::AuthUnavailable { why: e.to_string() });
    }
    Ok(cmd)
}

#[cfg(test)]
mod tests {
    #![allow(clippy::unwrap_used, clippy::expect_used)]

    use super::*;
    use std::collections::HashSet;
    use std::ffi::OsString;

    /// Build an `exists` closure that returns true only for the given paths.
    /// `use<>` (precise capturing): the closure owns `set` and borrows nothing,
    /// so the return type captures none of the input lifetimes (edition 2024).
    fn exists_set(paths: &[&str]) -> impl Fn(&Path) -> bool + use<> {
        let set: HashSet<PathBuf> = paths.iter().map(PathBuf::from).collect();
        move |p: &Path| set.contains(p)
    }

    /// The resolved kiro data dir `resolve` receives (what
    /// `kiro_data_dir(Some("/home/u"), None)` yields — the pre-brui default).
    const DATA_DIR: &str = "/home/u/.local/share/kiro-cli";
    fn default_server() -> String {
        format!("{DATA_DIR}/{KAS_ROOT_REL}/{SERVER_IN_ROOT_REL}")
    }
    /// `resolve` with no versioned-dir candidates and no CLI version — the
    /// legacy layout the pre-slice tests exercise.
    fn resolve_legacy(
        data_dir: Option<&Path>,
        server_override: Option<&str>,
        node_override: Option<&str>,
        path_var: Option<&OsStr>,
        exists: impl Fn(&Path) -> bool,
    ) -> Result<AgentCommand, KasMissing> {
        resolve(
            data_dir,
            server_override,
            node_override,
            path_var,
            &[],
            None,
            exists,
        )
    }
    /// A `<dir>/node` candidate carrying the platform exe suffix (`node.exe` on
    /// Windows), so the injected `exists` set matches what [`find_on_path`]
    /// actually looks for. `PathBuf` hashing/equality is separator-agnostic, so
    /// the forward slashes here still match `find_on_path`'s `Path::join` output.
    fn node(dir: &str) -> String {
        format!("{dir}/node{}", std::env::consts::EXE_SUFFIX)
    }

    // C2: happy path — defaults resolve to the exact probe-proven argv.
    #[test]
    fn resolve_happy_path_builds_probe_argv() {
        let path = OsString::from("/usr/bin");
        let exists = exists_set(&[&default_server(), &node("/usr/bin")]);
        let cmd = resolve_legacy(Some(Path::new(DATA_DIR)), None, None, Some(&path), exists)
            .expect("all preconditions present");
        // Compare as paths, not strings: on Windows `find_on_path`/`Path::join`
        // yield `\` separators and a `.exe` suffix that an exact string compare
        // against a Unix literal would fail.
        assert_eq!(Path::new(cmd.program()), Path::new(&node("/usr/bin")));
        let args = cmd.args();
        assert_eq!(args.len(), 4);
        assert_eq!(args[0], "--experimental-wasm-modules");
        assert_eq!(Path::new(&args[1]), Path::new(&default_server()));
        assert_eq!(args[2], "--transport=stdio");
        assert_eq!(args[3], "--auth=acp-callback");
    }

    // cyril-jxmv C6: the KAS free path REPLACES the CLI argv, so the agent
    // location derived from the resolved command is Native even when the
    // user's `--agent-command` routed through the WSL launcher. Deriving
    // from the pre-resolve argv is the buggy implementation this catches.
    #[test]
    fn kas_free_resolved_command_classifies_native() {
        use crate::platform::path::{AgentLocation, resolve_agent_location};
        let path = OsString::from("/usr/bin");
        let exists = exists_set(&[&default_server(), &node("/usr/bin")]);
        let cmd = resolve_legacy(Some(Path::new(DATA_DIR)), None, None, Some(&path), exists)
            .expect("all preconditions present");
        assert_eq!(
            resolve_agent_location(None, cmd.program()),
            AgentLocation::Native,
            "resolved node argv must classify Native"
        );
        // The pre-resolve CLI program would have classified Wsl — the
        // divergence that makes the placement claim non-vacuous.
        assert_eq!(resolve_agent_location(None, "wsl"), AgentLocation::Wsl);
    }

    // C3a: server missing while node IS present → Server, NOT Node (the
    // wrong-missing-item bug: checking node first / reporting the wrong path).
    #[test]
    fn resolve_missing_server_reports_server_not_node() {
        let path = OsString::from("/usr/bin");
        let exists = exists_set(&[&node("/usr/bin")]); // server absent
        let err =
            resolve_legacy(Some(Path::new(DATA_DIR)), None, None, Some(&path), exists).unwrap_err();
        assert_eq!(err, KasMissing::Server(PathBuf::from(default_server())));
    }

    // C3b: server+token present, no node anywhere → Node.
    #[test]
    fn resolve_missing_node() {
        let path = OsString::from("/usr/bin");
        let exists = exists_set(&[&default_server()]); // no node on PATH
        let err =
            resolve_legacy(Some(Path::new(DATA_DIR)), None, None, Some(&path), exists).unwrap_err();
        assert_eq!(err, KasMissing::Node);
    }

    // Stress: a node override that does not exist → Node (not a silent spawn).
    #[test]
    fn resolve_node_override_missing_errors() {
        let exists = exists_set(&[&default_server()]);
        let err = resolve_legacy(
            Some(Path::new(DATA_DIR)),
            None,
            Some("/no/such/node"),
            None,
            exists,
        )
        .unwrap_err();
        assert_eq!(err, KasMissing::Node);
    }

    // Stress: a server-override path WITH SPACES is preserved as ONE arg, not split.
    #[test]
    fn resolve_server_path_with_spaces_is_one_arg() {
        let spaced = "/opt/my kas/acp-server.js";
        let exists = exists_set(&[spaced, &node("/usr/bin")]);
        let path = OsString::from("/usr/bin");
        let cmd = resolve_legacy(
            Some(Path::new(DATA_DIR)),
            Some(spaced),
            None,
            Some(&path),
            exists,
        )
        .expect("override + node present");
        assert!(
            cmd.args().contains(&spaced.to_string()),
            "spaced server path must be one arg, got {:?}",
            cmd.args()
        );
    }

    // Stress: no data dir (no home, no absolute XDG_DATA_HOME) and no
    // override → NoHome (can't build the default path).
    #[test]
    fn resolve_no_home_no_override_errors() {
        let err = resolve_legacy(None, None, None, None, |_| true).unwrap_err();
        assert_eq!(err, KasMissing::NoHome);
    }

    // Stress: empty / whitespace env value is treated as unset.
    #[test]
    fn nonempty_treats_blank_as_unset() {
        assert_eq!(nonempty(None), None);
        assert_eq!(nonempty(Some(String::new())), None);
        assert_eq!(nonempty(Some("   ".to_string())), None);
        assert_eq!(nonempty(Some("/x".to_string())), Some("/x".to_string()));
    }

    // find_on_path returns the FIRST matching dir's node (PATH order honored).
    #[test]
    fn find_on_path_returns_first_match() {
        let path = std::env::join_paths(["/a", "/b"]).unwrap();
        let exists = exists_set(&[&node("/b")]); // only /b has node
        assert_eq!(
            find_on_path(Some(&path), exists),
            Some(PathBuf::from(node("/b")))
        );
    }

    const SHA_A: &str = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
    const SHA_B: &str = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
    fn e(name: &str, has_server: bool) -> (String, bool) {
        (name.to_string(), has_server)
    }

    // C1 fence: a dir matching the CLI version wins even when a NEWER dir
    // exists (kills the always-pick-newest implementation).
    #[test]
    fn picks_exact_version_match() {
        let entries = [
            e(&format!("2.10.0-{SHA_A}"), true),
            e(&format!("2.11.0-{SHA_B}"), true),
        ];
        let want = format!("2.10.0-{SHA_A}");
        assert_eq!(
            select_server(&entries, Some((2, 10, 0))),
            Some(want.as_str())
        );
    }

    // C2 fence: with no exact match, ordering is SEMVER-tuple, not lexical —
    // 2.10.0 > 2.9.0 (a lexicographic max picks "2.9.0" and fails here).
    #[test]
    fn picks_newest_semver_not_lex() {
        let entries = [
            e(&format!("2.9.0-{SHA_A}"), true),
            e(&format!("2.10.0-{SHA_B}"), true),
        ];
        let got = select_server(&entries, Some((2, 11, 0))).expect("candidates exist");
        assert!(
            got.starts_with("2.10.0-"),
            "lexicographic-max bug: got {got}"
        );
    }

    // C3 fence: CLI version unavailable → newest, not an error (kills the
    // err-when-kiro-cli-missing implementation).
    #[test]
    fn no_cli_version_falls_back_newest() {
        let entries = [
            e(&format!("2.10.0-{SHA_A}"), true),
            e(&format!("2.11.0-{SHA_B}"), true),
        ];
        let got = select_server(&entries, None).expect("candidates exist");
        assert!(got.starts_with("2.11.0-"), "got {got}");
    }

    // C4 fence: a dir without the inner acp-server.js (partial extraction) is
    // never a candidate (kills the name-glob-only implementation).
    #[test]
    fn partial_extraction_skipped() {
        let entries = [
            e(&format!("2.10.0-{SHA_A}"), true),
            e(&format!("2.11.0-{SHA_B}"), false),
        ];
        let got = select_server(&entries, Some((2, 11, 0))).expect("complete candidate exists");
        assert!(
            got.starts_with("2.10.0-"),
            "picked a partial extraction: {got}"
        );
        // All candidates partial → None (falls back to legacy at the caller).
        assert_eq!(
            select_server(&[e(&format!("2.11.0-{SHA_B}"), false)], None),
            None
        );
    }

    // C4 grammar fence: names outside `<semver>-<sha64 lowercase hex>` are
    // ignored — 63-char sha, non-hex, uppercase hex, `v` prefix, two-part
    // version, trailing component, lock-file suffix.
    #[test]
    fn malformed_dir_names_ignored() {
        let bad = [
            format!("2.10.0-{}", &SHA_A[..63]),
            format!("2.10.0-{}", "z".repeat(64)),
            format!("2.10.0-{}", SHA_A.to_uppercase()),
            format!("v2.10.0-{SHA_A}"),
            format!("2.10-{SHA_A}"),
            format!("2.10.0.1-{SHA_A}"),
            format!("2.10.0-{SHA_A}.lock"),
            // Pre-release names are pinned as rejected. Mechanism: the split
            // at the FIRST '-' leaves `rc.1-<sha>` (69 chars) as the sha
            // segment, failing the 64-hex check (dcc6 review, test-analyzer).
            format!("2.10.0-rc.1-{SHA_A}"),
        ];
        let entries: Vec<_> = bad.iter().map(|n| e(n, true)).collect();
        assert_eq!(select_server(&entries, Some((2, 10, 0))), None);
    }

    // Duplicate re-extractions of the SAME version pick deterministically
    // (greatest dir name), independent of listing order.
    #[test]
    fn duplicate_same_version_is_deterministic() {
        let a = format!("2.10.0-{SHA_A}");
        let b = format!("2.10.0-{SHA_B}");
        for entries in [[e(&a, true), e(&b, true)], [e(&b, true), e(&a, true)]] {
            assert_eq!(select_server(&entries, Some((2, 10, 0))), Some(b.as_str()));
            assert_eq!(select_server(&entries, None), Some(b.as_str()));
        }
        // When the lexically-greater duplicate is a PARTIAL extraction, the
        // complete lesser one wins (dcc6 review, test-analyzer).
        let entries = [e(&a, true), e(&b, false)];
        assert_eq!(select_server(&entries, Some((2, 10, 0))), Some(a.as_str()));
    }

    // Empty listing → None (the caller's legacy fallback path).
    #[test]
    fn empty_listing_selects_nothing() {
        assert_eq!(select_server(&[], Some((2, 10, 0))), None);
        assert_eq!(select_server(&[], None), None);
    }

    // C5 fence: when BOTH the legacy layout and a versioned dir exist, the
    // versioned dir wins (kills the legacy-checked-first implementation).
    #[test]
    fn versioned_beats_legacy() {
        let dir = format!("2.10.0-{SHA_A}");
        let versioned = format!("{DATA_DIR}/{KAS_ROOT_REL}/{dir}/{SERVER_IN_ROOT_REL}");
        let path = OsString::from("/usr/bin");
        let exists = exists_set(&[
            &default_server(), // legacy present too
            &versioned,
            &node("/usr/bin"),
        ]);
        let cmd = resolve(
            Some(Path::new(DATA_DIR)),
            None,
            None,
            Some(&path),
            &[e(&dir, true)],
            Some((2, 10, 0)),
            exists,
        )
        .expect("all preconditions present");
        assert_eq!(
            Path::new(&cmd.args()[1]),
            Path::new(&versioned),
            "legacy-first bug: picked {}",
            cmd.args()[1]
        );
    }

    // C7 fence: KIRO_KAS_SERVER_PATH bypasses the glob — the override wins
    // even when versioned candidates exist (kills the glob-anyway impl).
    #[test]
    fn override_beats_versioned() {
        let dir = format!("2.11.0-{SHA_B}");
        let versioned = format!("{DATA_DIR}/{KAS_ROOT_REL}/{dir}/{SERVER_IN_ROOT_REL}");
        let override_path = "/opt/custom/acp-server.js";
        let path = OsString::from("/usr/bin");
        let exists = exists_set(&[override_path, &versioned, &node("/usr/bin")]);
        let cmd = resolve(
            Some(Path::new(DATA_DIR)),
            Some(override_path),
            None,
            Some(&path),
            &[e(&dir, true)],
            Some((2, 11, 0)),
            exists,
        )
        .expect("override + node present");
        assert_eq!(cmd.args()[1], override_path);
    }

    // C6 fence: nothing found anywhere → Server whose reason names the
    // searched kas root (kills the wrong-variant / path-less-message impl).
    #[test]
    fn nothing_found_names_search_root() {
        let path = OsString::from("/usr/bin");
        let exists = exists_set(&[&node("/usr/bin")]);
        let err = resolve(
            Some(Path::new(DATA_DIR)),
            None,
            None,
            Some(&path),
            &[],
            Some((2, 11, 0)),
            exists,
        )
        .unwrap_err();
        let KasMissing::Server(p) = &err else {
            panic!("expected Server, got {err:?}");
        };
        assert!(
            p.starts_with(format!("{DATA_DIR}/{KAS_ROOT_REL}")),
            "got {}",
            p.display()
        );
        // `reason()` renders the path with the host separator (`kiro-cli\kas`
        // on Windows, where the `/`s come from the POSIX-style fixture
        // literal), so build the expected substring from the same `Path`
        // the code renders rather than from a `/`-joined literal.
        let root = kas_root(Path::new(DATA_DIR)).display().to_string();
        assert!(
            err.reason().contains(&root),
            "reason must name the searched root {root}: {}",
            err.reason()
        );
    }

    // Real-filesystem listing: complete extraction, partial extraction, and a
    // `.lock` FILE sibling (as kiro-cli actually leaves them) pair correctly;
    // a missing root lists empty.
    #[test]
    fn list_kas_entries_real_fs() {
        let tmp = tempfile::tempdir().expect("tempdir");
        let root = tmp.path().join("kas");
        let complete = format!("2.10.0-{SHA_A}");
        let partial = format!("2.11.0-{SHA_B}");
        let server_dir = root
            .join(&complete)
            .join("node_modules/@kiro/agent/dist/server");
        std::fs::create_dir_all(&server_dir).expect("mkdir complete");
        std::fs::write(server_dir.join("acp-server.js"), "//").expect("write entry");
        std::fs::create_dir_all(root.join(&partial)).expect("mkdir partial");
        std::fs::write(root.join(format!("{complete}.lock")), "").expect("write lock");

        let mut entries = list_kas_entries(&root);
        entries.sort();
        assert_eq!(
            entries,
            vec![
                (complete.clone(), true),
                (format!("{complete}.lock"), false),
                (partial.clone(), false),
            ]
        );
        // The full pipeline over this real layout picks the complete dir.
        assert_eq!(
            select_server(&entries, Some((2, 11, 0))),
            Some(complete.as_str()),
            "partial/lock entries must not be candidates"
        );
        // Missing root → empty, not an error.
        assert!(list_kas_entries(&root.join("nope")).is_empty());
    }

    // C8 fence: the non-path flags are byte-equal to kiro-cli's own KAS
    // spawn as captured from /proc (prove-it-prototype oracle) — a missing
    // `--auth=acp-callback` (the pre-dcc6 argv) fails here by construction.
    #[test]
    fn argv_matches_kiro_cli_own_spawn() {
        let path = OsString::from("/usr/bin");
        let exists = exists_set(&[&default_server(), &node("/usr/bin")]);
        let cmd = resolve_legacy(Some(Path::new(DATA_DIR)), None, None, Some(&path), exists)
            .expect("all preconditions present");
        let flags: Vec<&str> = cmd
            .args()
            .iter()
            .map(String::as_str)
            .filter(|a| a.starts_with("--"))
            .collect();
        assert_eq!(
            flags,
            [
                "--experimental-wasm-modules",
                "--transport=stdio",
                "--auth=acp-callback"
            ],
            "flag drift vs the /proc-captured kiro-cli spawn"
        );
    }

    // ── cyril-brui: XDG_DATA_HOME-aware kiro data dir ──────────────────────

    const HOME_U: &str = "/home/u";
    fn xdg(v: &str) -> Option<&OsStr> {
        Some(OsStr::new(v))
    }
    /// A fake dir that is ABSOLUTE on the host platform: `/<name>` on unix,
    /// `C:\<name>` on Windows — a bare `/xdg` is drive-relative there, so it
    /// would fail the resolver's `is_absolute` check and turn a valid-XDG
    /// fixture into an invalid one on the Windows CI leg.
    fn abs_fixture(name: &str) -> PathBuf {
        if cfg!(windows) {
            PathBuf::from(format!("C:\\{name}"))
        } else {
            PathBuf::from(format!("/{name}"))
        }
    }

    // C1 fence: an absolute, non-empty XDG_DATA_HOME wins for ANY home —
    // including no home at all (kills the ignore-XDG / home-first impl).
    #[test]
    fn kiro_data_dir_prefers_absolute_xdg_data_home() {
        let abs = abs_fixture("xdg");
        for home in [Some(Path::new(HOME_U)), None] {
            assert_eq!(
                kiro_data_dir(home, Some(abs.as_os_str())),
                Some(abs.join(KIRO_DATA_DIR_NAME)),
                "home={home:?}"
            );
        }
        // Unicode + embedded space survive the join untouched.
        let spaced = abs_fixture("tmp/ü data");
        assert_eq!(
            kiro_data_dir(Some(Path::new(HOME_U)), Some(spaced.as_os_str())),
            Some(spaced.join(KIRO_DATA_DIR_NAME))
        );
    }

    // C2 fence: without XDG_DATA_HOME the default is today's
    // `<home>/.local/share/kiro-cli`, and no home means no data dir (so
    // `NoHome` still fires). Pins the exact spelling.
    #[test]
    fn kiro_data_dir_defaults_to_home_local_share_without_xdg() {
        assert_eq!(
            kiro_data_dir(Some(Path::new(HOME_U)), None),
            Some(PathBuf::from("/home/u/.local/share/kiro-cli"))
        );
        assert_eq!(kiro_data_dir(None, None), None);
    }

    // C3 fence: an EMPTY, whitespace-only, or RELATIVE XDG_DATA_HOME is
    // invalid under kiro-cli's dirs-sys rule — fall back to
    // `<home>/.local/share` AND say so exactly once, naming the value (never
    // a silent fallback onto a store that may hold a different login). Kills
    // both the silent-fallback and the join-the-relative-value impls.
    #[test]
    fn invalid_xdg_data_home_falls_back_to_home_with_warning() {
        let (_guard, capture, dispatch) = crate::test_support::capture_json_subscriber();
        for value in ["", "   ", "relative/data"] {
            for home in [Some(Path::new(HOME_U)), None] {
                let before = capture.captured().len();
                let got = tracing::dispatcher::with_default(&dispatch, || {
                    kiro_data_dir(home, xdg(value))
                });
                let want = home.map(|h| h.join(XDG_DATA_HOME_DEFAULT_REL).join(KIRO_DATA_DIR_NAME));
                assert_eq!(got, want, "value={value:?} home={home:?}");
                let events = capture.captured();
                let warns: Vec<_> = events[before..]
                    .iter()
                    .filter(|e| e["level"] == "WARN")
                    .collect();
                assert_eq!(
                    warns.len(),
                    1,
                    "value={value:?} home={home:?}: expected exactly one WARN, got {events:?}"
                );
                let fields = &warns[0]["fields"];
                assert!(
                    fields["value"].as_str().is_some_and(|v| v.contains(value)),
                    "WARN must name the offending value: {fields}"
                );
                assert!(
                    fields["message"]
                        .as_str()
                        .is_some_and(|m| m.contains("XDG_DATA_HOME")),
                    "WARN must name the variable: {fields}"
                );
            }
        }
        // Positive control for the "exactly one" half: a VALID value emits
        // no WARN at all under the same capture.
        let before = capture.captured().len();
        let abs = abs_fixture("xdg");
        tracing::dispatcher::with_default(&dispatch, || {
            kiro_data_dir(Some(Path::new(HOME_U)), Some(abs.as_os_str()))
        });
        assert!(
            capture.captured()[before..]
                .iter()
                .all(|e| e["level"] != "WARN"),
            "valid XDG_DATA_HOME must not warn"
        );
    }

    // C4+C5 fence: the KAS extraction root that `resolve` scans and names
    // follows the resolved data dir, so an XDG user is never told "bundle not
    // found at ~/.local/…" while kiro-cli itself runs from $XDG_DATA_HOME
    // (cyril-brui).
    #[test]
    fn kas_root_follows_xdg_data_home() {
        let abs = abs_fixture("xdg");
        let data_dir = kiro_data_dir(Some(Path::new(HOME_U)), Some(abs.as_os_str()))
            .expect("absolute XDG resolves");
        assert_eq!(
            kas_root(&data_dir),
            abs.join(KIRO_DATA_DIR_NAME).join("kas")
        );
        // Unset XDG: today's default.
        let default_dir =
            kiro_data_dir(Some(Path::new(HOME_U)), None).expect("home fallback resolves");
        assert_eq!(
            kas_root(&default_dir),
            PathBuf::from("/home/u/.local/share/kiro-cli/kas")
        );
        // The full resolver searches under the XDG root and NAMES it when
        // the bundle is absent — the exact wrong message the issue reports.
        let path = OsString::from("/usr/bin");
        let exists = exists_set(&[&node("/usr/bin")]);
        let err = resolve(Some(&data_dir), None, None, Some(&path), &[], None, exists).unwrap_err();
        assert_eq!(
            err,
            KasMissing::Server(kas_root(&data_dir).join(SERVER_IN_ROOT_REL))
        );
    }

    #[test]
    fn apple_server_selection_uses_native_root() {
        let root = tempfile::tempdir().expect("tempdir");
        let home = root.path().join("Profile ü With Spaces");
        let data_dir = apple_kiro_data_dir(Some(&home)).expect("home resolves");
        let expected_data = home.join("Library/Application Support/kiro-cli");
        let exact = format!("2.24.0-{SHA_A}");
        let newer = format!("2.25.0-{SHA_B}");
        for version in [&exact, &newer] {
            let server = expected_data
                .join("kas")
                .join(version)
                .join("node_modules/@kiro/agent/dist/server/acp-server.js");
            std::fs::create_dir_all(server.parent().unwrap()).expect("extraction directory");
            std::fs::write(server, "//").expect("server entry");
        }
        let node = root.path().join("node");
        std::fs::write(&node, "").expect("node file");
        let entries = list_kas_entries(&kas_root(&data_dir));
        let command = resolve(
            Some(&data_dir),
            None,
            Some(node.to_str().unwrap()),
            None,
            &entries,
            Some((2, 24, 0)),
            Path::is_file,
        )
        .expect("Apple Application Support installation is discoverable");
        let expected_server = expected_data
            .join("kas")
            .join(exact)
            .join("node_modules/@kiro/agent/dist/server/acp-server.js");
        assert_eq!(Path::new(command.program()), node);
        let [_, server, _, _] = command.args() else {
            panic!("the Apple server path, including spaces and Unicode, must remain one argument");
        };
        assert_eq!(Path::new(server), expected_server);
    }

    #[test]
    fn apple_data_dir_without_home_reports_missing_bundle() {
        let data_dir = apple_kiro_data_dir(None);
        assert_eq!(data_dir, None);
        assert_eq!(
            resolve_legacy(data_dir.as_deref(), None, None, None, |_| true).unwrap_err(),
            KasMissing::NoHome
        );
    }

    #[test]
    fn windows_appdata_server_selection_uses_appdata_root() {
        let root = tempfile::tempdir().expect("tempdir");
        let local = root.path().join("Profile With Spaces/AppData/Local");
        let data_dir = windows_kiro_data_dir(Some(local.as_os_str()), || {
            panic!("valid LOCALAPPDATA must not consult the known folder")
        })
        .expect("absolute LOCALAPPDATA resolves");
        let expected_data = root
            .path()
            .join("Profile With Spaces/AppData/Local/Kiro-Cli");
        let exact = format!("2.24.0-{SHA_A}");
        let newer = format!("2.25.0-{SHA_B}");
        for version in [&exact, &newer] {
            let server = expected_data
                .join("kas")
                .join(version)
                .join("node_modules/@kiro/agent/dist/server/acp-server.js");
            std::fs::create_dir_all(server.parent().unwrap()).expect("extraction directory");
            std::fs::write(server, "//").expect("server entry");
        }
        let node = root.path().join("node");
        std::fs::write(&node, "").expect("node file");
        let entries = list_kas_entries(&kas_root(&data_dir));
        let command = resolve(
            Some(&data_dir),
            None,
            Some(node.to_str().unwrap()),
            None,
            &entries,
            Some((2, 24, 0)),
            Path::is_file,
        )
        .expect("AppData installation is discoverable");
        let expected_server = expected_data
            .join("kas")
            .join(exact)
            .join("node_modules/@kiro/agent/dist/server/acp-server.js");
        assert_eq!(Path::new(command.program()), node);
        let [_, server, _, _] = command.args() else {
            panic!("the AppData server path, including spaces, must remain one argument");
        };
        assert_eq!(Path::new(server), expected_server);
    }

    #[test]
    fn windows_data_dir_falls_back_to_known_folder() {
        let known = abs_fixture("Users/Profile With Spaces/AppData/Local");
        for value in [None, xdg(""), xdg("   "), xdg("relative/AppData")] {
            assert_eq!(
                windows_kiro_data_dir(value, || Some(known.clone())),
                Some(known.join("Kiro-Cli")),
                "LOCALAPPDATA={value:?}"
            );
        }
    }

    #[test]
    fn windows_without_local_data_root_reports_missing_bundle() {
        for value in [None, xdg(""), xdg("relative/AppData")] {
            for known in [None, Some(PathBuf::from("relative/known-folder"))] {
                let data_dir = windows_kiro_data_dir(value, || known);
                assert_eq!(
                    resolve_legacy(data_dir.as_deref(), None, None, None, |_| true).unwrap_err(),
                    KasMissing::NoHome,
                    "an unavailable Windows data root must not become a relative launch root"
                );
            }
        }
    }

    /// The expected root for the isolated environment: local AppData on
    /// Windows, XDG where supported, and Library/Application Support on
    /// macOS/iOS. Each variable points to a different root, so consulting
    /// a competing variable makes both consumers fail.
    fn expected_data_dir_on_host(home: &Path, xdg: &Path, local: &Path) -> PathBuf {
        if cfg!(windows) {
            local.join("Kiro-Cli")
        } else if cfg!(any(target_os = "macos", target_os = "ios")) {
            home.join("Library/Application Support/kiro-cli")
        } else {
            xdg.join(KIRO_DATA_DIR_NAME)
        }
    }

    /// Where discovery looks for the kiro data dir on THIS unix host given the
    /// child's private HOME and XDG_DATA_HOME — derived from the production
    /// resolvers themselves (Review 4): XDG/HOME on Linux and the other XDG
    /// targets, `~/Library/Application Support/kiro-cli` on macOS/iOS (which
    /// ignore XDG_DATA_HOME). Fixtures planted here are found on every unix CI
    /// leg.
    #[cfg(unix)]
    fn unix_resolver_data_dir(home: &Path, xdg: &Path) -> PathBuf {
        if cfg!(any(target_os = "macos", target_os = "ios")) {
            apple_kiro_data_dir(Some(home)).expect("home resolves")
        } else {
            kiro_data_dir(Some(home), Some(xdg.as_os_str())).expect("absolute XDG resolves")
        }
    }

    // Review F1/F2 (PR #140): the env wrapper `resolve_kas_command` reads the
    // REAL environment, so the pure fences above cannot see a wrapper that
    // reads the wrong variable (R1: `XDG_DATA_DIR`). Re-enter this test binary
    // with private HOME + XDG_DATA_HOME + LOCALAPPDATA — never mutating the runner's
    // environment (the `tests/spawn_isolation.rs` idiom) — and drive the
    // wrapper. No auth is touched: PATH holds no kiro-cli, and nothing is
    // spawned beyond this binary (the fake node is never run).
    #[tokio::test]
    async fn env_wrappers_resolve_xdg_data_home_like_kiro_cli() {
        const CHILD: &str = "CYRIL_BRUI_XDG_WRAPPER_CHILD";
        let Some(completed) = std::env::var_os(CHILD) else {
            // Parent: lay out <home>, <xdg>, a fake node, a fake versioned
            // extraction under the dir the wrappers must resolve on this
            // host, then re-run exactly this test in a child process.
            let root = tempfile::tempdir().expect("tempdir");
            let home = root.path().join("home");
            let xdg = root.path().join("xdg");
            let local = root.path().join("Profile With Spaces/AppData/Local");
            let node = root.path().join("node");
            std::fs::create_dir_all(&home).expect("home dir");
            std::fs::write(&node, "").expect("fake node file");
            let server_dir = kas_root(&expected_data_dir_on_host(&home, &xdg, &local))
                .join(format!("2.24.0-{SHA_A}"))
                .join("node_modules/@kiro/agent/dist/server");
            std::fs::create_dir_all(&server_dir).expect("fake extraction");
            std::fs::write(server_dir.join("acp-server.js"), "//").expect("fake entry");
            let completed = root.path().join("completed");
            let status = std::process::Command::new(
                std::env::current_exe().expect("current test binary"),
            )
            .args([
                "--exact",
                "protocol::kas::discovery::tests::env_wrappers_resolve_xdg_data_home_like_kiro_cli",
                "--nocapture",
            ])
            .env(CHILD, &completed)
            .env("HOME", &home)
            .env("USERPROFILE", &home)
            .env("XDG_DATA_HOME", &xdg)
            .env("LOCALAPPDATA", &local)
            .env("KIRO_AGENT_PATH", &node)
            // No kiro-cli anywhere on PATH: the version probe fails and
            // selection takes the newest extraction; nothing real can run.
            .env("PATH", root.path())
            .env_remove("KIRO_KAS_SERVER_PATH")
            .status()
            .expect("re-run this test binary");
            assert!(status.success(), "child-side wrapper assertions failed");
            assert_eq!(
                std::fs::read_to_string(&completed).expect("completion marker"),
                "wrappers checked"
            );
            return;
        };
        // Child: the real environment IS the private one the parent set.
        let home = PathBuf::from(std::env::var_os("HOME").expect("HOME"));
        let xdg = PathBuf::from(std::env::var_os("XDG_DATA_HOME").expect("XDG_DATA_HOME"));
        let local = PathBuf::from(std::env::var_os("LOCALAPPDATA").expect("LOCALAPPDATA"));
        // The bundle under this host's resolved data dir is found (a wrong-
        // variable wrapper would report `Server`/`NoHome` instead), so the
        // spawn reaches the login gate — which refuses it because no kiro-cli
        // can be run (cyril-zbu7: the gate asks kiro-cli, never a store).
        let data_dir = expected_data_dir_on_host(&home, &xdg, &local);
        assert!(kas_root(&data_dir).is_dir(), "fixture extraction present");
        // The stored-token fallback's store follows the same resolver (R2).
        assert_eq!(
            default_store_path(),
            Some(data_dir.join(STORE_FILE_NAME)),
            "default_store_path must follow the resolver on this host"
        );
        // The real free-path source over the child's private PATH and HOME,
        // with an executable probe confined to the test's private root —
        // `on_path()` would also probe the host's real TUI fallback dirs
        // (/usr/local/bin, /opt/homebrew/bin), where a real kiro-cli may live.
        // Nothing is found, so the bare `kiro-cli` spawn fails on PATH=root.
        let root = home.parent().expect("private root").to_path_buf();
        let path_var = std::env::var_os("PATH");
        let source = crate::protocol::kas::auth::KasTokenSource::free_path(
            path_var.as_deref(),
            Some(&home),
            None,
            |p: &Path| p.starts_with(&root) && p.is_file(),
        );
        let err = resolve_kas_command(&source)
            .await
            .expect_err("no kiro-cli is runnable, so the login gate must refuse the spawn");
        let KasMissing::AuthUnavailable { why } = &err else {
            panic!("expected AuthUnavailable (bundle found, kiro-cli absent), got {err:?}");
        };
        assert!(
            why.contains("kiro-cli chat _ get-kas-token")
                && why.contains(crate::protocol::kas::auth::FREE_PATH_REMEDY),
            "the gate must name the helper it could not run and where it looked: {why}"
        );
        std::fs::write(completed, "wrappers checked").expect("completion marker");
    }

    // cyril-zbu7 C1 (red-first): the free-path login gate asks kiro-cli —
    // `kiro-cli chat _ get-kas-token`, no `--force-refresh` — and never reads
    // the sqlite store. Child env: a fake kiro-cli (committed fixture,
    // symlinked so no freshly written executable is exec'd) is the only
    // kiro-cli on PATH, the bundle is a fake extraction, and NO data.sqlite3
    // exists anywhere — a store-reading gate refuses the spawn; the
    // get-kas-token gate passes and journals exactly that argv.
    #[cfg(unix)]
    #[tokio::test]
    async fn free_gate_asks_kiro_cli_get_kas_token_not_the_store() {
        const CHILD: &str = "CYRIL_ZBU7_FREE_GATE_CHILD";
        let Some(completed) = std::env::var_os(CHILD) else {
            let root = tempfile::tempdir().expect("tempdir");
            let home = root.path().join("home");
            let xdg = root.path().join("xdg");
            let bin = root.path().join("bin");
            std::fs::create_dir_all(&home).expect("home dir");
            std::fs::create_dir_all(&bin).expect("bin dir");
            std::os::unix::fs::symlink(
                concat!(
                    env!("CARGO_MANIFEST_DIR"),
                    "/tests/fixtures/fake-kiro-cli.sh"
                ),
                bin.join("kiro-cli"),
            )
            .expect("fake kiro-cli symlink");
            let node = root.path().join("node");
            std::fs::write(&node, "").expect("fake node file");
            let server_dir = kas_root(&unix_resolver_data_dir(&home, &xdg))
                .join(format!("2.24.0-{SHA_A}"))
                .join("node_modules/@kiro/agent/dist/server");
            std::fs::create_dir_all(&server_dir).expect("fake extraction");
            std::fs::write(server_dir.join("acp-server.js"), "//").expect("fake entry");
            let completed = root.path().join("completed");
            let status = std::process::Command::new(
                std::env::current_exe().expect("current test binary"),
            )
            .args([
                "--exact",
                "protocol::kas::discovery::tests::free_gate_asks_kiro_cli_get_kas_token_not_the_store",
                "--nocapture",
            ])
            .env(CHILD, &completed)
            .env("HOME", &home)
            .env("XDG_DATA_HOME", &xdg)
            .env("KIRO_AGENT_PATH", &node)
            // A PRIVATE PATH holding only the fake: no system dir, so no real
            // kiro-cli can ever run against the developer's login. The
            // fixture's `#!/bin/sh` is resolved by the kernel, its commands
            // are shell builtins, and KIRO_AGENT_PATH makes node lookup moot.
            .env("PATH", &bin)
            .env_remove("KIRO_KAS_SERVER_PATH")
            .status()
            .expect("re-run this test binary");
            assert!(status.success(), "child-side gate assertions failed");
            assert_eq!(
                std::fs::read_to_string(&completed).expect("completion marker"),
                "gate checked"
            );
            let journal =
                std::fs::read_to_string(bin.join("kiro-cli-argv.txt")).expect("fake journal");
            assert!(
                journal.ends_with("chat\n_\nget-kas-token\n"),
                "the gate must run a plain `kiro-cli chat _ get-kas-token`: {journal:?}"
            );
            assert!(!journal.contains("--force-refresh"), "{journal:?}");
            assert!(
                !unix_resolver_data_dir(&home, &xdg)
                    .join(STORE_FILE_NAME)
                    .exists(),
                "no credential store may be created or required"
            );
            return;
        };
        let cmd = resolve_kas_command(&crate::protocol::kas::auth::KasTokenSource::on_path())
            .await
            .expect("kiro-cli answers get-kas-token, so the gate must pass without a store");
        assert!(
            cmd.args().iter().any(|a| a.ends_with("acp-server.js")),
            "{cmd:?}"
        );
        std::fs::write(completed, "gate checked").expect("completion marker");
    }

    // cyril-zbu7 Review 3 (red-first): with kiro-cli ONLY in a TUI fallback
    // location (`~/.local/bin`, not on PATH), bundle selection's version probe
    // asks the same binary the gate and responder ask — so the exact-version
    // extraction (2.24.0, what the fake reports) wins over the newer 2.25.0
    // that a failed probe would fall back to, and one journal records both
    // the `--version` probe and the `get-kas-token` gate.
    #[cfg(unix)]
    #[tokio::test]
    async fn version_probe_and_token_source_share_the_fallback_kiro_cli() {
        const CHILD: &str = "CYRIL_ZBU7_SHARED_KIRO_CLI_CHILD";
        let Some(completed) = std::env::var_os(CHILD) else {
            let root = tempfile::tempdir().expect("tempdir");
            let home = root.path().join("home");
            let xdg = root.path().join("xdg");
            let local_bin = home.join(".local/bin");
            std::fs::create_dir_all(&local_bin).expect("~/.local/bin");
            let empty_path = root.path().join("empty-path");
            std::fs::create_dir_all(&empty_path).expect("private PATH dir");
            std::os::unix::fs::symlink(
                concat!(
                    env!("CARGO_MANIFEST_DIR"),
                    "/tests/fixtures/fake-kiro-cli.sh"
                ),
                local_bin.join("kiro-cli"),
            )
            .expect("fake kiro-cli symlink");
            let node = root.path().join("node");
            std::fs::write(&node, "").expect("fake node file");
            for version in ["2.24.0", "2.25.0"] {
                let server_dir = kas_root(&unix_resolver_data_dir(&home, &xdg))
                    .join(format!("{version}-{SHA_A}"))
                    .join("node_modules/@kiro/agent/dist/server");
                std::fs::create_dir_all(&server_dir).expect("fake extraction");
                std::fs::write(server_dir.join("acp-server.js"), "//").expect("fake entry");
            }
            let completed = root.path().join("completed");
            let status = std::process::Command::new(
                std::env::current_exe().expect("current test binary"),
            )
            .args([
                "--exact",
                "protocol::kas::discovery::tests::version_probe_and_token_source_share_the_fallback_kiro_cli",
                "--nocapture",
            ])
            .env(CHILD, &completed)
            .env("HOME", &home)
            .env("XDG_DATA_HOME", &xdg)
            .env("KIRO_AGENT_PATH", &node)
            // A PRIVATE, EMPTY PATH dir: PATH is walked before the TUI
            // fallbacks, so a system dir here (e.g. a distro /usr/bin/kiro-cli)
            // would run the REAL kiro-cli against the developer's login. The
            // fixture's `#!/bin/sh` is resolved by the kernel, its commands
            // are shell builtins, and KIRO_AGENT_PATH makes node lookup moot.
            .env("PATH", &empty_path)
            .env_remove("KIRO_KAS_SERVER_PATH")
            .status()
            .expect("re-run this test binary");
            assert!(status.success(), "child-side assertions failed");
            assert_eq!(
                std::fs::read_to_string(&completed).expect("completion marker"),
                "shared checked"
            );
            let journal =
                std::fs::read_to_string(local_bin.join("kiro-cli-argv.txt")).expect("journal");
            assert_eq!(
                journal, "--version\nchat\n_\nget-kas-token\n",
                "probe and gate must both run the ~/.local/bin kiro-cli"
            );
            return;
        };
        let source = crate::protocol::kas::auth::KasTokenSource::on_path();
        let cmd = resolve_kas_command(&source)
            .await
            .expect("the fallback kiro-cli answers both the probe and the gate");
        let server = cmd
            .args()
            .iter()
            .find(|a| a.ends_with("acp-server.js"))
            .expect("server arg");
        assert!(
            server.contains(&format!("2.24.0-{SHA_A}")),
            "the probe must ask the fallback kiro-cli (2.24.0), not fail into newest: {server}"
        );
        std::fs::write(completed, "shared checked").expect("completion marker");
    }

    // F19b drift fence, kept at the resolution level (cyril-brui): the
    // extraction root derives from the ONE kiro data dir on every env branch
    // — a change that re-homes it (a second resolution, a stray extra
    // segment) fails here.
    #[test]
    fn kas_root_shares_kiro_data_dir() {
        let abs = abs_fixture("xdg");
        let cases: [(Option<&Path>, Option<&OsStr>); 3] = [
            (Some(Path::new(HOME_U)), None),
            (Some(Path::new(HOME_U)), Some(abs.as_os_str())),
            (None, Some(abs.as_os_str())),
        ];
        for (home, xdg) in cases {
            let data_dir = kiro_data_dir(home, xdg).expect("branch resolves");
            assert_eq!(
                kas_root(&data_dir).parent(),
                Some(data_dir.as_path()),
                "home={home:?} xdg={xdg:?}"
            );
            assert_eq!(
                store_path(&data_dir).parent(),
                Some(data_dir.as_path()),
                "home={home:?} xdg={xdg:?}"
            );
        }
    }

    // Each KasMissing variant yields a non-empty, actionable reason.
    #[test]
    fn missing_reasons_are_actionable() {
        assert!(KasMissing::NoHome.reason().contains("KIRO_KAS_SERVER_PATH"));
        assert!(
            KasMissing::Server(PathBuf::from("/x"))
                .reason()
                .contains("kiro-cli acp")
        );
        assert!(KasMissing::Node.reason().contains("KIRO_AGENT_PATH"));
        // F4: the gate's reason carries the helper's diagnostic verbatim.
        let unavailable = KasMissing::AuthUnavailable {
            why: "kiro-cli could not provide a KAS access token: You are not logged in. \
                  Please log in with `kiro-cli login`."
                .to_string(),
        };
        assert!(unavailable.reason().contains("kiro-cli login"));
        assert!(unavailable.reason().contains("KAS auth unavailable"));
    }
}
