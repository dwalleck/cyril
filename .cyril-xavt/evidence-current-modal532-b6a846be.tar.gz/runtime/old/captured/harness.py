#!/usr/bin/python3.14
"""One-attempt current-X owned KAS consumer; no operation/model/real auth.

The captured892 scenario and peer are retained from X's archived 7ec12973 source.
The separate controlled specimen exercises clipped halfwidth/current viewport and
retained identifying path through actual App keys/permission response. Pyte and
raw ANSI establish decoded text/wire only, never native CJK glyph fidelity.
Run only after the parent binds completed qualification and explicitly authorizes.
"""
import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import select
import shutil
import signal
import sys
import tempfile
import time
import traceback

from owned_cleanup import close_tui, cleanup_owned

HERE = Path(__file__).resolve().parent
EJ_HARNESS = HERE / 'ej-owned-base-harness.py'
SAFE_WIRE = HERE / 'wire-agent-nonsecret.jsonl'
AUTH_FIXTURE = HERE / 'fake-kiro-cli.sh'
NODE = Path('/usr/bin/node')
SYSTEM_PYTHON = Path('/usr/bin/python3.14')
DRAFT = 'D'
REASON = 'REJECT_DRAFT_NOT_SUBMITTED'
PERMISSION_ID = 4
BINARY = Path('/tmp/cyril-xavt-af78-default-App-qualified-20261022T172641751658Z')
BINARY_SHA = 'c82cc1fc28cc78635137b78542ec6ae64be8fa64948c4530c4a3a0fc566eb916'
SOURCE_PIN = Path('/home/dwalleck/.claude/tmp/cyril-batch3-qualification-20261020-ipe924db/xavt-af78-current-assembled-ten-command-qualification-attempt1-20261022T171551124566Z/private-default-App-source-pin.json')
CAPABILITY_RECEIPT = Path('/tmp/cyril-nk4o-two-repair-consumer-prepare-20261022/runtime-capability-run02.json')
ASSET_PINS = {
    "ej-owned-base-harness.py": "32589c8913520328cc38768c038448756762dde292c9d2b7d59014521812c90a",
    "wide_overwrite.py": "0ce4ddf57372fb428355dc0f02088fb0fb1a75499ccd796f27b899f34a400beb",
    "wire-agent-nonsecret.jsonl": "40149c755431b350c36aeaa96fbeb1a0ed14e0346dbd8116b93c69942c31bae9",
    "fake-kiro-cli.sh": "61586cd278cb555d29f84b49805a1811705112713d0b6774feec42310d0ced6d",
    "owned_cleanup.py": "f0b45fc01256ce6810f4aae4a44c6a7ea9cc02d2926ad92872c5c7c11fd23cce"
}




def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def journal(path, value):
    with path.open('a') as stream:
        stream.write(json.dumps(value, ensure_ascii=False) + '\n')


def fixtures(case):
    records = [json.loads(line) for line in SAFE_WIRE.read_text().splitlines()]
    tool = records[3]
    permission = records[4]
    assert tool['method'] == 'session/update' and tool['toolCall']['sessionUpdate'] == 'tool_call'
    assert tool['toolCall']['status'] == 'pending'
    assert permission['method'] == 'session/request_permission' and permission['id'] == PERMISSION_ID
    assert tool['sessionId'] == permission['sessionId']
    assert tool['toolCall']['toolCallId'] == permission['toolCall']['toolCallId']
    assert 'rawInput' not in permission['toolCall']
    raw = tool['toolCall']['rawInput']
    assert len(raw['command'].encode()) == 892
    assert hashlib.sha256(raw['command'].encode()).hexdigest() == '1c9636e678e54cb857c2b9e7079c45df8e0870995c1e43a51834d4902d56292c'
    if case == 'retained-halfwidth':
        # A separately labeled controlled specimen, never a captured-wire claim.
        # Keep Execute/IDs/options/stub provenance; replace only joined raw input.
        tool = {**tool, 'toolCall': {**tool['toolCall'], 'rawInput':
                {'command': 'ｶﾞ\n:', 'path': '界界'}}}
        raw = tool['toolCall']['rawInput']
    elif case != 'captured':
        raise AssertionError(f'unknown frozen specimen: {case}')
    # Captured mode retains original payload fields; controlled mode is explicit.
    # Recreate ACP envelopes; no _meta or helper-domain fields are introduced.
    frames = [
        {'jsonrpc': '2.0', 'method': tool['method'], 'params':
         {'sessionId': tool['sessionId'], 'update': tool['toolCall']}},
        {'jsonrpc': '2.0', 'id': permission['id'], 'method': permission['method'], 'params':
         {key: permission[key] for key in ['sessionId', 'toolCall', 'options']}},
    ]
    return tool['sessionId'], raw, frames


def agent():
    output = Path(os.environ['EJ7Y_SMOKE_OUTPUT'])
    case = json.loads((output / 'case.json').read_text())['case']
    session, raw, frames = fixtures(case)
    prompt, emitted, decided, incoming = None, False, False, b''

    def send(frame):
        journal(output / 'agent-wire.jsonl', frame)
        print(json.dumps(frame, ensure_ascii=False), flush=True)

    def text(value):
        send({'jsonrpc': '2.0', 'method': 'session/update', 'params': {'sessionId': session,
              'update': {'sessionUpdate': 'agent_message_chunk', 'content': {'type': 'text', 'text': value}}}})

    while True:
        ready, _, _ = select.select([sys.stdin.fileno()], [], [], 0.02)
        if ready:
            chunk = os.read(sys.stdin.fileno(), 65536)
            if not chunk:
                return
            incoming += chunk
            while b'\n' in incoming:
                line, incoming = incoming.split(b'\n', 1)
                frame = json.loads(line)
                journal(output / 'client-wire.jsonl', frame)
                method, ident = frame.get('method'), frame.get('id')
                if method == 'initialize':
                    send({'jsonrpc': '2.0', 'id': ident, 'result': {'protocolVersion': 1,
                          'agentCapabilities': {'loadSession': True, '_meta': {'kiro': {}}},
                          'agentInfo': {'name': 'xavt-exact-safe-captured-peer', 'version': '0.66.43'}, 'authMethods': []}})
                elif method == 'session/new':
                    # Use the original session ID, never rewrite captured frames.
                    send({'jsonrpc': '2.0', 'id': ident, 'result': {'sessionId': session}})
                elif method == 'session/prompt':
                    assert prompt is None
                    prompt = ident
                    text('XAVT_OWNED_READY\n')
                elif method == 'session/cancel':
                    pass
                elif method and ident is not None:
                    send({'jsonrpc': '2.0', 'id': ident, 'result': {}})
                elif ident == PERMISSION_ID:
                    assert emitted and not decided
                    assert frame.get('result', {}).get('outcome') == {'outcome': 'selected', 'optionId': 'reject'}
                    assert 'rejectionReason' not in frame.get('result', {}).get('_meta', {}).get('kiro', {})
                    decided = True
                    # Deliberately no tool_call_update/completed: Reject did not execute.
                    text('\nXAVT_OWNED_REJECTED_NO_EXECUTION\n')
                    send({'jsonrpc': '2.0', 'id': prompt, 'result': {'stopReason': 'end_turn'}})
                    prompt = None
        control = output / 'control.json'
        if control.exists() and not emitted:
            assert prompt is not None
            emitted = True
            for frame in frames:
                send(frame)


def entry_inputs():
    # Existing actual capability receipt, not a claim that an App has run.
    if not callable(getattr(os, 'pidfd_open', None)) or not callable(getattr(signal, 'pidfd_send_signal', None)):
        raise RuntimeError('Linux pidfd APIs required before any owned App launch')
    if Path(sys.executable).resolve(strict=True) != SYSTEM_PYTHON:
        raise RuntimeError('Use the explicitly qualified system Python3.14, not uv Python')
    pins = {HERE / name: value for name, value in ASSET_PINS.items()}
    pins.update({
        BINARY: BINARY_SHA,
        SYSTEM_PYTHON: '7579d289e4d95778305acd13fc71be2a3800f7f6a202619505875234659c2c60',
        NODE: 'ed30fdcc71cd7134c5324aeedea64f1088f0dfd22bfba3834fcbee0402c28c5a',
        SOURCE_PIN: 'bf9394fd5ee0098395c330b3cc5f08cd4c1d6ccae6da1f9a332393cf9c2e1f38',
        CAPABILITY_RECEIPT: 'f549d0fb0a77548bd9187df50dfc4615d6497327ca6e075924af7ac0f53d7f16',
    })
    identities = {}
    for path, expected in pins.items():
        actual = digest(path)
        if actual != expected:
            raise RuntimeError(f'Frozen input identity changed: {path}: {actual}')
        identities[str(path)] = actual
    if Path(shutil.which('node') or '').resolve(strict=True) != NODE:
        raise RuntimeError('Owned KAS launcher must select the pinned Node executable')
    if not os.access(AUTH_FIXTURE, os.X_OK):
        raise RuntimeError('Exact existing inert auth fixture must retain executable mode')
    if importlib.metadata.version('pyte') != '0.8.2' or importlib.metadata.version('wcwidth') != '0.9.3':
        raise RuntimeError('Decoder versions differ from the supplied actual system-Python capability receipt')
    import pyte.screens
    if digest(Path(pyte.screens.__file__)) != '43bcd10d5555f6a8e53a1f9c0e557a47ec801b3914533d5b51af5828a5242ecb':
        raise RuntimeError('Recorded installed terminal decoder source changed')
    return identities


def controlled_case(tui, output, receipt, raw, frames):
    assert raw == {'command': 'ｶﾞ\n:', 'path': '界界'}

    def responses():
        return [frame for frame in tui.wire('client-wire.jsonl')
                if frame.get('id') == PERMISSION_ID and 'method' not in frame]

    def pending():
        assert not responses(), f'unexpected permission answer: {responses()}'

    def cell(x, y):
        return tui.screen.buffer[y][x].data

    def row(y):
        return ''.join(cell(x, y) for x in range(tui.columns))

    def composer(width, height):
        # Reuse the accepted literal closed-composer observation, adapted only
        # to these explicit geometries and the frozen one-line D fixture.
        if tui.screen.lines != height or tui.screen.columns != width:
            return False
        top = '┌ > ' + '─' * (width - 5) + '┐'
        bottom = '└' + '─' * (width - 2) + '┘'
        return (row(height - 6) == top and row(height - 2) == bottom
                and all(cell(x, y) == '│' for y in (height - 5, height - 4, height - 3)
                        for x in (0, width - 1)))

    def resize(width, height):
        # Decoder dimensions/ioctl/raw growth alone are not App-rendered shape.
        # The new right corner must be absent before the transition. This wait
        # shares resize's existing 30-second budget; it adds no sleep/budget.
        if height - 2 < tui.rows and width - 1 < tui.columns:
            assert cell(width - 1, height - 2) != '┘', 'new composer corner already present before resize'
        deadline = time.monotonic() + 30
        tui.resize(width, height)
        tui.wait(lambda: composer(width, height), f'actual closed App composer at {width}x{height}',
                 timeout=max(0, deadline - time.monotonic()))

    def context(command, phase):
        pending()
        return (cell(2, 1) == '┌' and cell(8, 1) == '┐'
                and cell(5, 2) == '界' and cell(5, 3) == '界'
                and cell(7, 4) == command
                and (cell(3, 5) == '▸' if phase == 'option' else cell(4, 5) == '█'))

    def capture(name, phase):
        pending()
        assert tui.input_draft() == DRAFT, f'chat draft changed: {tui.input_draft()!r}'
        (output / (name + '.txt')).write_text(tui.visible())
        receipt['observations'].append({
            'capture': name + '.txt', 'phase': phase, 'columns': tui.columns, 'rows': tui.rows,
            'raw_byte_offset': tui.raw_size, 'view': tui.view(),
            'decoded_literal_cells': {f'{x},{y}': cell(x, y) for x, y in
                                     [(2, 1), (8, 1), (5, 2), (5, 3), (7, 4), (3, 5), (4, 5)]},
            'chat_draft': tui.input_draft(), 'permission_unanswered': True,
        })

    tui.wait(lambda: 'XAVT_OWNED_READY' in tui.visible(), 'owned safe peer ready')
    tui.paste(DRAFT)
    tui.wait(lambda: tui.input_draft() == DRAFT, 'chat draft retained')
    tui.command(cases=[0])
    tui.wait(lambda: tui.box_has('界界') and tui.box_has('ｶﾞ') and tui.box_has('▸ Allow'),
             'controlled joined target/command body')
    tui.key('down')
    tui.key('down')
    tui.wait(lambda: tui.box_has('▸ Deny'), 'offered manual RejectOnce selected')
    tui.send(b'r')
    tui.wait(lambda: tui.box_has('Rejecting: Deny'), 'reason editor')
    tui.paste('r')
    tui.wait(lambda: tui.box_has('r█'), 'single-character reason draft')
    resize(11, 13)
    tui.key('shift-home')
    tui.wait(lambda: context(' ', 'reason'), 'two retained path rows, clipped command, reason cursor')
    capture('01-reason-clipped-pair-before-enter', 'reason')
    tui.send(b'\r')
    tui.drain(0.4)
    assert context(' ', 'reason')
    capture('02-reason-clipped-pair-after-enter', 'reason')
    tui.key('shift-end')
    tui.wait(lambda: context(':', 'reason'), 'same retained path and reachable command tail in reason phase')
    capture('03-reason-tail-with-two-identifying-path-rows', 'reason')
    tui.send(b'\r')
    tui.drain(0.4)
    assert context(':', 'reason')
    capture('03b-reason-tail-enter-still-refused', 'reason')
    tui.key('shift-home')
    tui.wait(lambda: context(' ', 'reason'), 'reason viewport returned to clipped first row')
    tui.send(b'\x1b')
    tui.wait(lambda: context(' ', 'option'), 'Escape restores selected option without answering')
    capture('04-option-clipped-pair-before-enter', 'option')
    tui.send(b'\r')
    tui.drain(0.4)
    assert context(' ', 'option')
    capture('05-option-clipped-pair-after-enter', 'option')
    before = tui.raw_size
    resize(12, 13)
    tui.key('shift-home')
    tui.wait(lambda: tui.view() is not None and 'ｶﾞ' in '\n'.join(tui.view()['content'])
             and tui.box_has('▸ Deny'),
             'whole pair in the actual command viewport at two body cells')
    assert 'ｶﾞ'.encode() in (output / 'terminal.ansi').read_bytes()[before:], 'whole pair not emitted during the new width frame'
    capture('06-two-cell-whole-pair-raw-and-decoded', 'option')
    resize(11, 13)
    tui.key('shift-end')
    tui.wait(lambda: context(':', 'option'), 'identifying two-row path and reachable one-grapheme tail')
    capture('07-retained-path-and-command-tail-before-enter', 'option')
    tui.send(b'\r')
    tui.drain(0.4)
    assert context(':', 'option')
    capture('07b-option-tail-enter-still-refused', 'option')
    # The immutable guard requires both capped meaningful graphemes in this
    # current viewport; earlier viewing does not accumulate confirmation.
    resize(80, 40)
    tui.key('shift-home')
    tui.wait(lambda: tui.view() is not None and '\n'.join(tui.view()['content']) == raw['command']
             and tui.box_has(raw['path']) and tui.box_has('▸ Deny'),
             'both command graphemes and identifying path before one manual rejection')
    capture('07c-restored-full-context-before-manual-reject', 'option')
    tui.send(b'\r')
    tui.wait(lambda: len(responses()) == 1, 'one offered manual RejectOnce response')
    response = responses()[0]
    assert response['result']['outcome'] == {'outcome': 'selected', 'optionId': 'reject'}
    assert 'rejectionReason' not in response['result'].get('_meta', {}).get('kiro', {})
    tui.wait(lambda: 'XAVT_OWNED_REJECTED_NO_EXECUTION' in tui.visible(), 'owned no-execution prompt completion')
    tui.wait(lambda: tui.input_draft() == DRAFT, 'chat draft retained after rejection')
    (output / '08-rejected-clean-stop.txt').write_text(tui.visible())
    sent = tui.wire('agent-wire.jsonl')
    actual_frames = [frame for frame in sent if frame.get('method') == 'session/request_permission'
                     or (frame.get('method') == 'session/update' and frame['params']['update'].get('sessionUpdate') == 'tool_call')]
    assert actual_frames == frames, 'controlled raw payload changed in actual wire'
    assert not any(frame.get('method', '').startswith(('fs/', 'terminal/', '_kiro/auth/')) for frame in sent)
    assert not any(frame.get('method') == 'session/update' and frame['params']['update'].get('status') == 'completed' for frame in sent)
    assert len([frame for frame in sent if frame.get('method') == 'session/request_permission']) == 1
    assert len(responses()) == 1
    receipt.update(result='PASS', command_bytes=len(raw['command'].encode()),
                   command_and_path_exact=True, reason_clipped_enter_refused=True,
                   option_clipped_enter_refused=True, whole_pair_emitted_at_width12=True,
                   reason_tail_enter_refused=True, option_tail_enter_refused=True,
                   retained_two_row_path_and_tail_navigation=True,
                   full_command_and_identifying_path_before_manual_reject=True,
                   permission_response=response, permission_response_count=1,
                   draft_retained=DRAFT, reason_draft_preserved_not_submitted=True,
                   completed_frame_replayed=False, operation_executed=False,
                   native_CJK_glyph_fidelity='NOT_CLAIMED')


def captured_case(tui, output, receipt, raw, frames):
    def responses():
        return [frame for frame in tui.wire('client-wire.jsonl') if frame.get('id') == PERMISSION_ID and 'method' not in frame]

    def pending():
        assert not responses(), f'unexpected permission answer: {responses()}'

    def capture(name, *, draft=True, selected=None):
        pending()
        if draft:
            assert tui.input_draft() == DRAFT, f'chat draft changed: {tui.input_draft()!r}'
        view = tui.view()
        if view is not None:
            box = view['box']
            cells = []
            for y in range(box['top'] + 1, box['bottom']):
                interior = ''.join(tui.screen.buffer[y][x].data for x in range(box['left'] + 1, box['right']))
                if interior.startswith('    ') and interior.strip() and not interior.lstrip().startswith('↑'):
                    cells.append(interior[4:])
            view['content_cells'] = cells
        if selected:
            assert tui.box_has('▸ ' + selected), f'selected option not drawn: {selected}'
        (output / (name + '.txt')).write_text(tui.visible())
        item = {'capture': name + '.txt', 'columns': tui.columns, 'rows': tui.rows,
                'raw_byte_offset': tui.raw_size, 'view': view, 'chat_draft': tui.input_draft(),
                'permission_unanswered': True}
        receipt['observations'].append(item)
        return view

    def visible_context(view):
        # OwnedTui extracts only the preview rows, not horizontally clipped title.
        assert view is not None and 'Preview unavailable' not in '\n'.join(view['body'])
        return view

    tui.wait(lambda: 'XAVT_OWNED_READY' in tui.visible(), 'owned pending prompt')
    tui.paste(DRAFT)
    tui.wait(lambda: tui.input_draft() == DRAFT, 'initial chat draft')
    tui.command(cases=[0])
    tui.wait(lambda: 'Permission Required' in tui.visible() and tui.status_start() == 1,
             'captured shell modal with first page')
    first = visible_context(capture('01-command-first-page', selected='Allow'))
    seen = {}
    page = 1
    while True:
        view = visible_context(capture(f'02-command-page-{page:02d}', selected='Allow'))
        status = view['status']
        assert status is not None and len(view['content']) == status['visible']
        for index, row in enumerate(view['content_cells'], status['start']):
            assert index not in seen or seen[index] == row, f'overlap mismatch at {index}'
            seen[index] = row
        if status['end'] == status['total']:
            break
        assert page < 10
        previous = status['start']
        tui.key('pgdn')
        tui.wait(lambda: tui.status_start() != previous, 'next command page')
        page += 1
    assert sorted(seen) == list(range(1, max(seen) + 1))
    rows = [seen[index] for index in sorted(seen)]
    cwd_index = next(index for index, value in enumerate(rows) if value.startswith('Cwd: '))
    actual_command = ''.join(rows[:cwd_index - 1]) + rows[cwd_index - 1].rstrip()
    actual_cwd = (''.join(rows[cwd_index:])[len('Cwd: '):]).rstrip()
    assert actual_command == raw['command'], f'modal command differs: {actual_command!r}'
    assert actual_cwd == raw['cwd'], f'modal cwd differs: {actual_cwd!r}'
    write_json(output / 'render-wire-reconciliation.json', {
        'result': 'PASS', 'command_bytes': len(actual_command.encode()),
        'command_sha256': hashlib.sha256(actual_command.encode()).hexdigest(),
        'full_command_equals_original_wire': True, 'cwd': actual_cwd,
        'cwd_equals_original_wire': True, 'rows': rows, 'pages': page,
        'all_24_sed_segments_present': all(actual_command.count(f'XAVT_SEG_{index:02d}') == 2 for index in range(1,25)),
        'permission_rawInput_absent': 'rawInput' not in frames[1]['params']['toolCall'],
        'title_not_used_as_command_evidence': True})
    # Inspect a reject-only reason draft and return without submitting it.
    tui.key('down')
    tui.key('down')
    tui.wait(lambda: tui.box_has('▸ Deny'), 'offered RejectOnce selected')
    tui.send(b'r')
    tui.wait(lambda: tui.box_has('Rejecting: Deny'), 'reason editor')
    tui.paste(REASON)
    tui.wait(lambda: tui.box_has(REASON + '█'), 'reason draft')
    tui.key('shift-home')
    tui.await_start(1)
    capture('03-reason-draft-command-start')
    tui.key('shift-end')
    tui.wait(lambda: tui.view() is not None and raw['cwd'] in '\n'.join(tui.view()['content']), 'reason draft command tail and cwd')
    capture('04-reason-draft-command-tail')
    assert tui.box_has(REASON + '█')
    tui.send(b'\x1b')
    tui.wait(lambda: tui.box_has('▸ Deny') and not tui.box_has('Rejecting: Deny'), 'Escape returns to RejectOnce without answering')
    capture('05-options-restored', selected='Deny')
    tui.key('up')
    tui.key('up')
    tui.wait(lambda: tui.box_has('▸ Allow'), 'Allow selected only for blocked-Enter checks')
    # Original live geometry: one preview row, then shift to cwd-only tail.
    tui.resize(80, 14)
    tui.key('shift-end')
    tui.wait(lambda: tui.view() is not None and len(tui.view()['content']) == 1
             and tui.view()['content'][0].startswith('Cwd: '), 'cwd-only current viewport')
    capture('06-cwd-only-before-enter', selected='Allow')
    tui.send(b'\r')
    tui.drain(0.4)
    capture('07-cwd-only-after-enter', selected='Allow')
    tui.resize(12, 10)
    capture('08-tiny-before-enter', draft=False)
    tui.send(b'\r')
    tui.drain(0.4)
    capture('09-tiny-after-enter', draft=False)
    tui.resize(80, 40)
    tui.key('shift-home')
    tui.await_start(1)
    capture('10-restored-command-before-reject', selected='Allow')
    tui.key('down')
    tui.key('down')
    tui.wait(lambda: tui.box_has('▸ Deny'), 'one offered manual RejectOnce')
    capture('11-manual-reject-selected', selected='Deny')
    tui.send(b'\r')
    tui.wait(lambda: len(responses()) == 1, 'one rejection response')
    response = responses()[0]
    assert response['result']['outcome'] == {'outcome': 'selected', 'optionId': 'reject'}
    assert 'rejectionReason' not in response['result'].get('_meta', {}).get('kiro', {})
    tui.wait(lambda: 'XAVT_OWNED_REJECTED_NO_EXECUTION' in tui.visible(), 'clean owned prompt completion after rejection')
    tui.wait(lambda: tui.input_draft() == DRAFT, 'chat draft retained after rejection')
    (output / '12-rejected-clean-stop.txt').write_text(tui.visible())
    sent = tui.wire('agent-wire.jsonl')
    actual_frames = [frame for frame in sent if frame.get('method') == 'session/request_permission'
                     or (frame.get('method') == 'session/update' and frame['params']['update'].get('sessionUpdate') == 'tool_call')]
    assert actual_frames == frames, 'captured payload changed in emitted wire'
    assert not any(frame.get('method', '').startswith(('fs/', 'terminal/', '_kiro/auth/')) for frame in sent)
    assert not any(frame.get('method') == 'session/update' and frame['params']['update'].get('status') == 'completed' for frame in sent)
    assert len([frame for frame in sent if frame.get('method') == 'session/request_permission']) == 1
    receipt.update(result='PASS', command_bytes=892, command_and_cwd_exact=True,
                   pages=page, draft_retained=DRAFT, reason_draft_preserved_not_submitted=True,
                   cwd_only_enter_refused=True, tiny_enter_refused=True,
                   permission_response=response, permission_response_count=1,
                   clean_owned_prompt_end=True, completed_frame_replayed=False,
                   operation_executed=False)


def interrupted(signum, _frame):
    raise SystemExit(128 + signum)


def main(args):
    identities = entry_inputs()
    session, raw, frames = fixtures(args.case)
    spec = importlib.util.spec_from_file_location('ej_owned', EJ_HARNESS)
    assert spec is not None and spec.loader is not None
    ej = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(ej)
    # This established launcher must dispatch this safe X peer, not EJ's actor.
    ej.__file__ = str(Path(__file__).resolve())
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    for name in ['harness.py', *ASSET_PINS]:
        (output / name).write_bytes((HERE / name).read_bytes())
    write_json(output / 'case.json', {'case': args.case})
    write_json(output / 'replayed-frames.json', frames)
    receipt = {
        'result': 'FAIL', 'case': args.case, 'attempt_limit': 1,
        'binary': str(BINARY), 'binary_sha256': BINARY_SHA,
        'source_descriptor_sha256': 'fcfb57a5ae97b1bf677e164d1db5202ad10b206b5d0deb1b9d38a39aa47be71c',
        'source_records': 530, 'approval_source_sha256': 'ecd6031403e009bf1ff735b0d75413c3d4d232ad49869653044b5ebcb9cd256c',
        'frozen_inputs': identities, 'session_id': session, 'permission_id': PERMISSION_ID,
        'scope': 'actual qualified Cyril KAS projection/UI/permission wire through an owned PTY and decoded terminal; not real KAS or native CJK glyph/reflow proof',
        'safety': 'captured case exact892 command/cwd/session; controlled case separately declared; permission rawInput absent; manual RejectOnce only; no completed-tool replay, operation, model/account contact or real authentication',
        'observations': [], 'cleanup_errors': [],
    }
    tui, scratch, expected_commands, primary = None, None, {}, None
    previous_handlers = {signum: signal.getsignal(signum) for signum in (signal.SIGTERM, signal.SIGHUP)}
    for signum in previous_handlers:
        signal.signal(signum, interrupted)
    try:
        scratch = Path(tempfile.mkdtemp(prefix='cyril-xavt-delivery-owned-private-'))
        receipt['owned_scratch'] = str(scratch)
        for name in ['bin', 'home', 'config', 'data', 'ws']:
            (scratch / name).mkdir()
        (scratch / 'bin/kiro-cli').symlink_to(AUTH_FIXTURE)
        expected_commands = {
            'App': [str(BINARY), '--cwd', str(scratch / 'ws'), '--agent-engine', 'kas',
                    '--prompt', 'Display owned workflow approval fixtures; execute no operation'],
            'Node': [str(NODE), '--experimental-wasm-modules', str(scratch / 'server.js'),
                     '--transport=stdio', '--auth=acp-callback'],
            'peer': [sys.executable, str(HERE / 'harness.py'), 'agent'],
            'auth-helper': ['/bin/sh', str(scratch / 'bin/kiro-cli'), 'chat', '_', 'get-kas-token'],
        }
        write_json(output / 'owned-root.json', {'scratch': str(scratch), 'expected_commands': expected_commands,
                                               'marker': 'EJ7Y_SMOKE_OUTPUT=' + str(output)})
        # Retain partially initialized raw/master/process fields for cleanup.
        tui = ej.OwnedTui.__new__(ej.OwnedTui)
        ej.OwnedTui.__init__(tui, argparse.Namespace(binary=str(BINARY)), scratch, output)
        if args.case == 'captured':
            captured_case(tui, output, receipt, raw, frames)
        else:
            controlled_case(tui, output, receipt, raw, frames)
    except BaseException as error:
        primary = sys.exc_info()
        receipt['result'] = 'FAIL'
        receipt['primary_error'] = {'type': type(error).__name__, 'error': str(error),
                                    'traceback': traceback.format_exc()}
    finally:
        # Never read/copy private HOME, Cyril logs or token-helper output.
        try:
            close_tui(tui, receipt)
        except BaseException as error:
            receipt['cleanup_errors'].append({'stage': 'ordinary close', 'error': repr(error)})
        finally:
            try:
                if scratch is not None:
                    cleanup_owned(output, scratch, expected_commands, receipt)
                else:
                    receipt['owned_cleanup'] = {'status': 'NOT_STARTED_NO_SCRATCH'}
            except BaseException as error:
                receipt['cleanup_errors'].append({'stage': 'independent owned cleanup', 'error': repr(error)})
            finally:
                process = getattr(tui, 'process', None)
                if process is not None:
                    try:
                        receipt['observed_App_returncode'] = process.wait(timeout=5)
                    except BaseException as error:
                        receipt['observed_App_returncode'] = 'UNOBSERVED'
                        receipt['cleanup_errors'].append({'stage': 'actual App reap', 'error': repr(error)})
                else:
                    receipt['observed_App_returncode'] = 'NOT_STARTED'
                receipt['Node_peer_returncodes'] = 'UNOBSERVED; pidfd readiness is not a returncode'
                if scratch is not None and receipt.get('owned_cleanup', {}).get('status') == 'COMPLETE':
                    try:
                        shutil.rmtree(scratch)
                        receipt['scratch_disposition'] = 'REMOVED_AFTER_INDEPENDENT_OWNERSHIP_ATTESTATION'
                    except BaseException as error:
                        receipt['scratch_disposition'] = 'PRESERVED_CLEANUP_FAILED'
                        receipt['cleanup_errors'].append({'stage': 'owned scratch removal', 'error': repr(error)})
                elif scratch is not None:
                    receipt['scratch_disposition'] = 'PRESERVED_OWNERSHIP_CLEANUP_NOT_COMPLETE'
                for signum, handler in previous_handlers.items():
                    signal.signal(signum, handler)
                if (receipt.get('tui_close', {}).get('status') == 'FAIL'
                        or receipt.get('owned_cleanup', {}).get('status') == 'FAIL'
                        or receipt['cleanup_errors']):
                    receipt['result'] = 'FAIL'
                write_json(output / 'result.json', receipt)
    if primary is not None:
        raise primary[1].with_traceback(primary[2])
    if receipt['result'] != 'PASS':
        raise RuntimeError('Consumer/owned cleanup did not complete; retained result.json is authoritative')
    print(json.dumps({key: value for key, value in receipt.items() if key != 'observations'}, indent=2))


if __name__ == '__main__':
    if sys.argv[1:] == ['agent']:
        agent()
    else:
        parser = argparse.ArgumentParser(description=__doc__)
        parser.add_argument('--output', required=True)
        parser.add_argument('--case', required=True, choices=['captured', 'retained-halfwidth'])
        main(parser.parse_args())
