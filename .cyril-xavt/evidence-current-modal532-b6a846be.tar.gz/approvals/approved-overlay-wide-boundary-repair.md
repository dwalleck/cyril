# DG decision: preserve grapheme ownership when clearing overlays

Main approves this bounded repair under the user's delegated evidence-backed design authority. It restores the existing wide-grapheme rendering obligation; it does not waive acceptance or change permission/editor semantics.

## Problem and evidence

The controlled X App smoke failed before narrow controls. The retained ANSI/frozen replay shows halfwidth continuation `ﾞ` at popup left x8,y12 instead of border `│`, while `Rejecting: Deny` is already visible. A wide lead at x7 survives rectangular Clear and causes released Buffer::diff to skip x8. Actual internal-buffer branch selection remains source-derived inference until the regression executes. Original failure and raw records remain unchanged; see local://overlay-wide-boundary-diagnosis.md and local://xavt-af78-owned-runtime-handoff-b27bd94f.json.

## Approved ownership and contract

- Existing `crates/cyril-ui/src/widgets/modal.rs` owns one crate-private `clear(&mut Frame<'_>, Rect)` operation. No new module, backend, dependency, trait, cache, global repair pass or exported API.
- Clip the requested rectangle to the Buffer. For affected rows, evict whole painted grapheme spans intersecting the rectangle, including a lead left of the rectangle or trailing cells right of it. Preserve all disjoint outside cells/styles and all other rows.
- Use actual released CellWidth, arbitrary span widths and safe row-bounded arithmetic. No fixed one-cell halo, grapheme normalization, string/buffer allocation or copying in production. An allocation-free row walk from the buffer's left edge is acceptable because ownership has no backpointers.
- Migrate all twelve current rectangular Clear callers (five approval phases, six other modals, floated suggestions) to that owner; remove obsolete Clear imports. Preserve geometry, stacking, current-viewport confirmation, command/path bytes, reason/editor handling, and ordinary input behavior.
- Retain released core0.1.2/widgets0.3.2. Do not manipulate diff flags to conceal conflicting cell ownership or alter the backend.

## Verification

First add a failing actual chat-producer → approval composition → released diff → backend regression for the observed boundary, with literal producer/geometry preconditions. A present Buffer border alone is insufficient. Cover arbitrary-width crossing, right-edge eviction, disjoint-style preservation, clipped/empty bounds and restoration after overlay removal where existing test patterns support consumer-visible assertions. No incidental source-text/default/wiring tests.

Main runs the regression before production changes, then authorizes the repair. Run focused and integrated UI/App tests plus strict Clippy once afterward, retain prior unaffected evidence, review the final implementation independently, build a fresh private App, and rerun the unchanged controlled owned consumer once under a fresh Main GO. Preserve the original FAIL. No relaxed predicate, extra key, retry budget or native-glyph claim.
