# Overlay-wide-boundary caller review

## Summary

**Findings: NONE.** No provable introduced actionable bug in the assigned callers, production overlay dispatch, or documentation. All **12/12** required existing callers now use `widgets::modal::clear`; the requested rectangles and the position of clearing relative to placement, early returns, and content painting are unchanged.

This is **source-only review; qualification remains pending**. No builds, tests, lint, formatting, runtime launches, or Git state changes were performed. The modal algorithm and new render test bodies were deliberately not reviewed here; those belong to the parent reviewer. The additional final-integration MCP panel caller is deliberately absent from this worktree and is not included in this census.

## Exact comparison boundary

Worktree: `/home/dwalleck/repos/cyril-wt-fix-cyril-xavt`.

- Approval/design: [approved-overlay-wide-boundary-repair.md](local://approved-overlay-wide-boundary-repair.md).
- Qualified pre-repair source: **530-input descriptor `fcfb57a5ae97b1bf677e164d1db5202ad10b206b5d0deb1b9d38a39aa47be71c`**, as referenced by [the qualified handoff](local://xavt-af78-current-assembled-postformat-exact10-qualified-handoff.json). This descriptor is **not a Git revision**. The inventory read was `postformat-full-compile-and-runtime-inputs-by-path-mode-blob-sha256.json` under `/home/dwalleck/.claude/tmp/cyril-batch3-qualification-20261020-ipe924db/xavt-af78-current-assembled-ten-command-qualification-attempt1-20261022T171551124566Z/`.
- Actual working patch read: [overlay-wide-boundary-current-working-vs-index.patch](local://overlay-wide-boundary-current-working-vs-index.patch), exported by Main using read-only Git. This is **working tree versus held index**, not HEAD and not automatically the qualified snapshot. Its file headers enumerate the expected eleven changed files (including modal, outside this delegated review).
- Critically, approval's patch preimage `1c00302b` is **not** its qualified source. I read the retained `crates__cyril-ui__src__widgets__approval.rs.postformat-source` and [the exact qualified-to-current approval diff](local://overlay-approval-qualified-to-current.patch), whose preimage is `f696422c`. Main reports asserting that retained source's SHA-256 against the qualified pin **`ecd6031403e009bf1ff735b0d75413c3d4d232ad49869653044b5ebcb9cd256c`**. That exact diff contains **only one Clear import removal and the five clearing-call replacements**; approval geometry, guards, editor logic, and tests have no qualified-to-current delta.
- For the other scoped Rust files, the working patch's preimage blob prefixes match these qualified inventory blobs. Qualified render and traits source was additionally read directly from Main's exported blob files.

| Qualified file (`crates/cyril-ui/src/` prefix) | Inventory blob |
|---|---|
| `widgets/approval.rs` | `f696422cf40a634cedecc6dc7ed8ef6df51baa0c` |
| `render.rs` | `c8aa9d8ec648ccdf8884160e53f0ab54c14ce595` |
| `traits.rs` | `572b987b7039cca73b57799cf15921e7e50990b8` |
| `widgets/code_panel.rs` | `3c4fef183e46a3cc3f88216f1eaf8aaae520faf9` |
| `widgets/hooks_panel.rs` | `5c7be0d58164d67847c1e88446219f2d8b89dd30` |
| `widgets/picker.rs` | `2cf6cb4ae199297bb97eac6669670d3c04ad5daf` |
| `widgets/powers_panel.rs` | `421b581eaa832950a0a1d93a0aa85a9efc5c1296` |
| `widgets/review.rs` | `a78b9b5ad16ae547944303264776fca36facd7ff` |
| `widgets/usage_panel.rs` | `b9541a84b6b529b450fe0dc3cbaa73231756c3d0` |

`README.md` is outside this compile/runtime inventory; its reviewed baseline is the actual working patch's held-index preimage `da75f8e6`. No claim is made that HEAD alone represents the assembled qualified baseline. Contextual held HEAD/MERGE_HEAD are those supplied in the assignment, not independently re-resolved here.

## Complete caller census

Locations below are current worktree lines, all under `crates/cyril-ui/src/`.

| # | Caller | Clear replacement location | Preserved surrounding behavior |
|---|---|---|---|
| 1 | Approval option phase | `widgets/approval.rs:1195` | Same `OptionPage::new` result and no-room return; clear precedes preview, option rows, border hint and final Paragraph. |
| 2 | Approval reason phase | `widgets/approval.rs:1396` | Same phase check, chosen option label and `ReasonPage::new`; clear remains before the zero-inner return; reason cursor/text, notices, preview and border painting are unchanged. |
| 3 | Approval trust phase | `widgets/approval.rs:1508` | Same `trust_popup`, no-room return, selected-item window and three-row item rendering. |
| 4 | Approval scope phase | `widgets/approval.rs:1683` | Same phase check, choices, target, scope popup, selected-row window and labels. |
| 5 | Approval folder phase | `widgets/approval.rs:1890` | Same validation/status, `FolderPage::new`, zero-inner return, editor cursor/text and hint/title rendering. |
| 6 | Code panel | `widgets/code_panel.rs:142` | Same content-derived width, height, input-protected placement, no-room return, content and border. |
| 7 | Hooks panel | `widgets/hooks_panel.rs:43` | Same placed width/height, empty state, column budgets and scroll window. |
| 8 | Picker | `widgets/picker.rs:61` | Same placement, description reserve, selection-centered `option_window`, content and display-only scrollbar. |
| 9 | Powers panel | `widgets/powers_panel.rs:92` | Same shared `placement`, scroll bound/window, empty state, metadata and three-line rows. |
| 10 | Review consent form | `widgets/review.rs:45` | Same wrapped-row height, placement, consent lines, permissions wording and wrapping. |
| 11 | Usage panel | `widgets/usage_panel.rs:23` | Same row-count height, placement, refresh/title state, paging and scroll window. |
| 12 | Floated suggestions | `render.rs:207` | Same constrained-mode condition, nonzero-height guard and `Rect::new(area.x, input_area.y - overlay_height, area.width, overlay_height)`; suggestions still paint before all modal overlays. |

For rows 1–11 the replacement is exactly `super::modal::clear(frame, popup_area)`; row 12 is `crate::widgets::modal::clear(frame, overlay_area)`. No new caller-side allocation, copy, input conditional, diff flag, cache or global is introduced.

## Context and architecture evidence

Read the complete changed rendering functions, their relevant page/placement context, and the complete production `draw_inner` overlay dispatch (not the added render test bodies).

- **Approval/current viewport:** `widgets/approval.rs:999-1058` still derives confirmation from recorded terminal size, `render::input_top`, and the same Option/Reason/Trust/Scope/Folder geometry as painting. The qualified approval delta leaves this entire path unchanged. Actual command visibility, target-path checks, chosen IDs, feedback text/cursor, folder validation, scope choices and raw command/path bytes are not changed by the caller migration.
- **Paint/key stack:** `traits.rs:172-204` retains the same seven variants and `Overlay::ALL` order: Usage → Code → Powers → Hooks → Picker → Review → Approval. `render.rs:219-286` still iterates that list and passes the same `area`, `input_area.y`, state, attribution and theme into the same widgets. Nothing changes key-dispatch selection or requires modifying its implementation. Approval remains painted last; floated suggestions remain underneath the modal stack.
- **Geometry:** all changed calls consume the already-computed rectangle. No width, height, placement function, viewport arithmetic, early-return guard or rendering argument is edited in these caller functions. The intended difference is whole-span ownership cleanup, including an intersecting lead/tail outside the rectangle—not a geometry change.
- **Shared owner:** callers now defer clearing to the existing `widgets/modal.rs` owner immediately before their existing paint steps. Placement remains owned by existing page/placement helpers. Helper correctness itself is outside this delegated review.

## Narrow obsolete-Clear search

A token search for `\bClear\b` across this worktree's `crates/cyril-ui` found **no remaining ratatui Clear import or executable widget call**. All seven affected widget import lists remove `Clear`, and floated suggestions no longer names `ratatui::widgets::Clear`.

Residual tokens are not missed callers: a historical regression-test comment at `render.rs:863`, unrelated `EffortUpdate::Clear` uses at `state.rs:600,7632`, the status string at `state.rs:816`, ordinary comments at `state.rs:1311,1869`, and the helper's doc verb at `widgets/modal.rs:4`. This conclusion uses source grep and patch inspection, not negative LSP-reference results.

## Documentation and unrelated edits

- `README.md:230-236` adds only the overlay whole-painted-grapheme ownership contract at either horizontal edge, preserves bytes/disjoint styles, and retains the character-wrapping/cursor editor contract.
- `traits.rs:149-170` and `render.rs:212-218` update the clearing-owner explanation while preserving inverse paint/key-order requirements. Powers-panel comments at `widgets/powers_panel.rs:75-78,711-712` stop naming the obsolete Clear widget without changing their no-room/input-protection promise.
- No approval scope or acceptance waiver is introduced. Existing README visible-context/current-viewport and input behavior at `README.md:268-318`, and the unwaived qualification/platform/native boundaries at `README.md:375-387`, remain untouched by the patch.
- **The actual working-versus-index diff does contain incidental nonbehavioral edits:** approval test formatting (already present in the qualified postformat baseline, therefore not repair-introduced against that baseline); production import ordering at `widgets/powers_panel.rs:28`; test import ordering in code/hooks/review/usage; and assertion reflow at `widgets/usage_panel.rs:820-822`. These are disclosed rather than calling the actual diff perfectly minimal. No unrelated semantic production change was found in the delegated scope.

**Disposition:** no patch-anchored actionable finding to return. Source review does not confer runtime, regression, strict-Clippy, consumer, native-glyph or final-integration acceptance; those remain owned by Main/the parent reviewer.
