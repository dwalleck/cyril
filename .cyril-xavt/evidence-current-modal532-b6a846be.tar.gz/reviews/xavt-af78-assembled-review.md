**Findings:** None actionable.

**Overall correctness:** correct within this static source-review scope.  
**Confidence:** 0.96.

**Explanation:** Reviewed the actual assembled working source against `af78b1615bd5b97b4c702542fd3ab193151bd4c1`, not HEAD alone, including all 11 parent-relative changed files and downstream consumers. No patch-introduced defect was found in shell classification/routing, current-viewport confirmation, retained-path allocation, physical-width handling, or preservation of the incoming EJ/Un4 behavior.

### Reviewed boundaries
- **Command/path confirmation:** `approval.rs:172–214,223–247,370–387,1103–1171,1296–1368` retains the chosen identifying path fit, reserves command context ahead of chrome, and requires meaningful, fully fitting command glyphs in the **current** viewport. Both option confirmation and reason submission reach this guard through `state.rs:2536–2551`.
- **Allocation and raw bytes:** body-window accounting uses the retained fitted-path row count through O(1) `Vec::len()`, without refitting. Shell counting/visibility passes borrow sanitized graphemes and allocate no hidden rows; rendering materializes only requested rows. Command/cwd source bytes remain unchanged.
- **Physical-width substitutions:** `approval.rs:451–455,485–489` uses `CellWidth` and the shared physical scalar helper consistently, preserving LF handling, clipping checks, range-end stopping, and the capped meaningful-glyph threshold.
- **Integration:** KAS projection attaches after the ledger join; typed shell data reaches the exhaustive preview dispatcher without becoming an authorization input. Independent tree12/full600 comparison behavior, ordinary preview routing, navigation, and diff-cache consumers remain intact.
- **Tests:** new assertions inspect literal painted/outgoing cells and actual permission responses. No incidental repinning of inherited expectations was found.

### Source and qualification limits
Confirmed working-tree refs: HEAD `bc6f48a21016320cc6491356f880f37463cf8c6e`, held MERGE_HEAD `af78b1615bd5b97b4c702542fd3ab193151bd4c1`. The supplied manual-owner `approval.rs` SHA-256 pin is `667a8ff7bedb1d5aac65e12bc9a7dd145f1c10d411da56f68cafedf849cdcf88`; this review did not independently recompute it.

No edits, builds, tests, linters, formatters, diagnostics gates, or runtime checks were performed. Semantic-reference lookup timed out; explicit caller/dispatch inspection supplied coverage. This is not compiled, current-head CI, owned-consumer, native-terminal, physical-key, live-KAS, or broader Unicode-stack qualification.