# Overlay-wide-boundary repair — independent source review

## Result

**Findings: NONE.** No actionable, provable, patch-introduced bug was found in the actual eleven-file working repair or its affected producer/composition/diff/backend interactions.

**Overall correctness: correct, scoped to source review. Confidence: 0.97.** The implementation matches the approved whole-painted-span ownership contract and preserves the decisive producer-to-released-backend border fence. This is not a repaired-state qualification PASS, shipping authorization, native-glyph claim, or evidence that the unchanged controlled consumer now passes; those remain pending with Main.

## Reviewed state and comparison boundary

- Actual worktree: `/home/dwalleck/repos/cyril-wt-fix-cyril-xavt`; assignment context holds HEAD `bc6f48a21016320cc6491356f880f37463cf8c6e` plus MERGE_HEAD `af78b1615bd5b97b4c702542fd3ab193151bd4c1`. These are contextual pins, not a claim that HEAD alone contains the assembled source.
- Approved contract: [approved-overlay-wide-boundary-repair.md](local://approved-overlay-wide-boundary-repair.md).
- Implementation handoff: [overlay-wide-boundary-repair-implementation-handoff.json](local://overlay-wide-boundary-repair-implementation-handoff.json). Review conclusions derive from actual source and patch reads, not the handoff's assertion of completeness.
- Qualified pre-repair source is the **530-input descriptor `fcfb57a5ae97b1bf677e164d1db5202ad10b206b5d0deb1b9d38a39aa47be71c`**, not a Git revision. Its owning record is [xavt-af78-current-assembled-postformat-exact10-qualified-handoff.json](local://xavt-af78-current-assembled-postformat-exact10-qualified-handoff.json), with the retained `postformat-full-compile-and-runtime-inputs-by-path-mode-blob-sha256.json` inventory under the qualification root named there.
- Read the actual working-versus-index diff: README; render; traits; approval; code/hooks/picker/powers/review/usage panels; modal. The working diff is eleven files, not the whole held parent integration.
- **Approval baseline correction was explicitly checked:** the ordinary working diff starts from preformat blob `1c00302b`, not qualified approval `ecd6031403e009bf1ff735b0d75413c3d4d232ad49869653044b5ebcb9cd256c` / blob `f696422c`. A direct read-only `git diff --no-index` of retained `crates__cyril-ui__src__widgets__approval.rs.postformat-source` versus the actual file contains only the Clear import removal and five clearing-call replacements. None of its apparent working-versus-index test-format changes is new against qualified `ecd`. Exact delta retained in tool artifact `artifact://4715`.
- Modal's working preimage `68b819ff`, render's `c8aa9d8e`, and traits' `572b987b` match the qualified inventory blobs. Delegated caller review also matched the six other widget preimages to that inventory. README is not in the 530 compile/runtime roster; its reviewed preimage is the actual held-index `da75f8e6`.
- Companion read-only caller review: [overlay-wide-boundary-caller-review.md](local://overlay-wide-boundary-caller-review.md). The parent independently reviewed the modal algorithm, complete new tests, production render routing, original RED/frozen regression, and released dependency consumers.

The named source hashes are provenance recorded in the supplied/retained records, not newly computed cryptographic attestations by this reviewer. No builds, tests, lint, formatters, application/runtime launches, mutation runs, index/ref changes, or repository edits were performed. Only requested local review reports were written.

## 1. Whole-span implementation and arithmetic

Owner is exactly the existing `crates/cyril-ui/src/widgets/modal.rs:10-33`, one `pub(crate) fn clear(&mut Frame<'_>, Rect)`; there is no new module, trait, backend, exported external API, retained cache, or global repair pass.

| Required property | Source evidence and conclusion |
|---|---|
| Actual released cell widths | `modal.rs:1,22-24` imports and invokes `CellWidth` on the existing `Cell`, not scalar count, UnicodeWidthStr alone, or a forced width. Released `ratatui-core-0.1.2/src/buffer/cell.rs:309-317` honors actual CellWidth/ForcedWidth semantics; `cell_width.rs:24-74` includes FF9E/FF9F physical columns. |
| Arbitrary widths, no fixed halo | `modal.rs:19-24,30` walks from Buffer left and advances by each complete cell span. It can discover a lead arbitrarily far before the popup, including widths 3 and 8 used by tests, rather than inspecting only x-1. |
| Both rectangle edges | The loop visits leads with `x < area.right()`; the reset occurs only when `end > area.left()` (`modal.rs:20-27`). Together these are precisely span intersection `x < right && end > left`. A left-crossing lead and a right-crossing tail are reset in full, and exact-touch spans are not reset. |
| No mutation-dependent truncation | The complete `end` is computed before resetting the lead (`modal.rs:21-27`), and the next scan starts at that saved end. Resetting a wide lead cannot accidentally turn the rest of its span into separate owners during the walk. |
| Clipped/empty/offset areas | `modal.rs:11-16` intersects with actual Buffer bounds and exits on zero area. Iteration starts at Buffer left, not zero; affected y comes only from the intersection. |
| Safe u16 bounds / row isolation | `modal.rs:22-24` uses saturating addition then clamps to the Buffer's exclusive right. `Rect::new`, `right`, `bottom`, and `intersection` use saturating/clipped bounds in released `layout/rect.rs:179-225,322-332`. With `x < area.right() <= bounds.right()`, `x` is a valid in-row coordinate; every reset satisfies `x <= column < end <= bounds.right()`. No flattened index can spill into another row. |
| Zero-width progress | `.max(1)` plus saturation and the loop bound guarantee `end > x` on every executed iteration, including at high u16 coordinates. Empty buffers return before the walk. |
| Disjoint cells/styles and other rows | Spans ending at/before left are only read; leads starting at/after right are never visited; all other rows are unvisited. Only intersecting whole spans are reset. Full `Cell` comparisons in tests cover foreground/background/modifiers as well as symbols. |
| No production string/Buffer allocation or copying | Production helper only borrows the Buffer, copies its small Rect bounds, reads width, and resets cells. Released `Cell::reset` (`cell.rs:248-250`) assigns the empty constant. No String/Vec/Buffer clone, alternate text, normalization, instrumentation, flags, or backend replacement appears on the production path. Test-only snapshots/byte captures allocate under `#[cfg(test)]`, appropriately outside this restriction. |

The full affected-row walk is the approved allocation-free solution to the lack of continuation ownership backpointers. No extra broad clearing or input-specific exception was added.

## 2. All twelve callers and consuming-side routing

Current source locations, all under `crates/cyril-ui/src/`:

| # | Caller | Migrated call |
|---|---|---|
| 1 | Approval option | `widgets/approval.rs:1195` |
| 2 | Approval reason | `widgets/approval.rs:1396` |
| 3 | Approval trust | `widgets/approval.rs:1508` |
| 4 | Approval scope | `widgets/approval.rs:1683` |
| 5 | Approval folder | `widgets/approval.rs:1890` |
| 6 | Code panel | `widgets/code_panel.rs:142` |
| 7 | Hooks panel | `widgets/hooks_panel.rs:43` |
| 8 | Picker | `widgets/picker.rs:61` |
| 9 | Powers panel | `widgets/powers_panel.rs:92` |
| 10 | Review form | `widgets/review.rs:45` |
| 11 | Usage panel | `widgets/usage_panel.rs:23` |
| 12 | Floated suggestions | `render.rs:207` |

All calls receive the same already-computed rectangle at the same point between placement/early-return guards and painting. There are no remaining executable Ratatui Clear calls/imports in `crates/cyril-ui`; residual `Clear` words are historical comments or unrelated `EffortUpdate::Clear`/text, not missed callers. The additional MCP panel caller belongs to final integration and is intentionally absent from this X worktree; it is neither included in twelve nor treated as already migrated here.

Consuming paths were read, not inferred from producers alone:

- `approval.rs:15-41` explicitly dispatches every existing approval phase to its migrated renderer, including `EnterReason`.
- `render.rs:181-207,219-286` still paints chat first, floated suggestions next when constrained, then every `Overlay::ALL` branch. `traits.rs:169-201` retains the seven-variant ordering. The helper returns unit synchronously to each existing painter; there is no new queued/event value requiring a missing handler.
- The new regression uses existing `Notification::ToolCallStarted` / `ToolCallUpdated`; `state.rs:542-552` explicitly routes both through `track_tool_call`. Chat still constructs the real Execute header in `widgets/chat.rs:318-392` and paints it through the Paragraph path (`chat.rs:19-70`).
- Application drawing still invokes this renderer through `crates/cyril/src/app.rs:946-973` and the ordinary Terminal draw path.

Geometry, current-viewport confirmation, command/path bytes, option IDs, reason/editor behavior, permission/scope choices, and paint/key stack order have no behavioral delta beyond the approved span eviction. The qualified approval diff is particularly decisive: no guard, geometry, editor, or test assertion was changed there.

## 3. Permanent real-producer → released diff → Crossterm fence

The three new render tests are `render.rs:1200-1222`; their common path is `render.rs:977-1197`.

- They create a real `UiState`, install real started/updated ToolCalls, add nine real user rows, and invoke the production renderer. They do not inject a synthetic underlay lead into a Buffer.
- Literal preconditions at `render.rs:1058-1083` require the produced lead at `(7,12)`, its physical width, and either equal complete prior/current lead cells or a changed lead. Command bytes are checked in the real approval at `1109-1114`.
- `render.rs:1117-1125` asserts literal popup corners `(8,11)`, `(71,11)`, `(8,27)`, the reason label, and the intended Buffer border `(8,12)`. These do not calculate expected coordinates through the clear helper or placement implementation.
- `render.rs:1001-1023` passes the **full released** `previous.diff_iter(current)` directly into released `CrosstermBackend<Vec<u8>>::draw`; only SGR is removed afterward. Cursor commands and printed bytes remain intact. No filter manufactures a border or substitutes a custom diff/backend.
- `render.rs:1127-1138` still requires the coordinate-specific emitted-border bytes and an explicit released diff tuple for `(8,12,"│")`. A composed Buffer border alone cannot pass.
- `render.rs:1139-1155` flushes through the persistent Terminal/TestBackend, swaps buffers, repeats the actual overlay, and asserts retained border/overlay cells. `1160-1195` checks closing/restoration through the same released diff and backend path.

The released consumer was read: `ratatui-core-0.1.2/src/terminal/buffers.rs:97-123` forwards its unchanged diff iterator to Backend::draw and resets/swaps normally; `ratatui-crossterm-0.1.0/src/lib.rs:225-275` emits only the iterator's yielded cells. `buffer/diff.rs:148-174` remains responsible for wide-cell skip and VS16 trailing refresh. Thus the fence observes the actual failure boundary rather than merely a correct-looking Buffer.

## 4. Restoration-oracle correction is constrained, not weakened

Compared the frozen original RED render source with current tests.

- For **every crossing fixture** (`width > 1` at fixed lead x7/popup left x8), `render.rs:1162-1174` still unconditionally requires whole-lead restoration in both released diff and coordinate-specific Crossterm output. The decisive FF9E border expectations are unchanged.
- The width-one U3099/U309A controls end exactly at x8 and are disjoint. `render.rs:1182-1192` now requires every outside cell/style through x7 to stay identical during open, repeat and close, and requires **no** close update at x7. This corrects an impossible unconditional re-emission expectation rather than relaxing a crossing case.
- `render.rs:1175-1181,1211-1218` expects no independent x8 continuation write for ordinary wide controls, but literally expects SPACE for the VS16 case. That matches the released diff's explicit `contains_vs16` trailing-cell path (`buffer/diff.rs:158-171`), which refreshes changed trailing symbols. No production special case was introduced.
- Every common-helper assertion includes the fixture's case label, eliminating the original unlabelled-loop ambiguity on future execution.

The original no-crossing-ownership-conflict invariant remains enforced for all actual crossing cases. Neither the fixture bytes nor the emitted-border requirement was diluted.

## 5. Generic helper coverage present in source

These are coverage inspections, **not claims that the tests were executed or passed**:

| Test source | Named coverage |
|---|---|
| `modal.rs:137-166` | Simultaneous left-crossing width-three and right-crossing VS16 eviction; every disjoint cell/style and other row compared with the original Buffer. |
| `modal.rs:169-203` | U3099/U309A literal width-one leads; exact-touch spans and adjacent CJK remain unchanged. |
| `modal.rs:206-237` | Literal width-eight span, popup six cells after the lead and tail seven cells beyond its right edge; disproves fixed-halo ownership. |
| `modal.rs:240-270` | Nonzero Buffer origin, clipped top/left area, zero width/height and disjoint/right/bottom empty intersections. |
| `modal.rs:273-304` | Near-u16-limit coordinates, an overwide low-level cell and a zero-width combining cell; full row/cell isolation comparisons. Explicitly not a claim that Paragraph paints an unfitting grapheme. |
| `modal.rs:321-330` | Zero-width and zero-height Buffers unchanged. |
| `modal.rs:333-377` | Persistent actual Paragraph/Block composition through released Terminal diff/TestBackend over open, move, shrink, stack and close; literal required visible transition tuples and retained lower border. |

## 6. Original RED and causality limits preserved

Read [overlay-wide-boundary-diagnosis.md](local://overlay-wide-boundary-diagnosis.md), the complete canonical [test-only RED handoff](local://overlay-wide-boundary-test-only-RED-attempt1-handoff.json) identified by supplied SHA-256 `ef10a36476a1adb3ccca570de5de33479e857bc0835f851b930fd56a23ba038c`, its retained raw log, and the frozen original test source `render.rs.frozen-test-only-preimage` (recorded SHA `1a027da6…`).

- The one original invocation had three ordinary libtest failures: **two decisive named FF9E emitted-border failures**, unchanged and changed lead, after actual producer/width/phase/geometry/current-Buffer preconditions; and **one separate restoration-oracle failure** in the controls function. It is incorrect to count all three as border REDs.
- The raw controls panic contains no fixture label. Source order identifies the first width-one U3099 iteration as the failing control **by source-derived reasoning**, not an observed fixture label. The raw log itself does not establish that all six controls ran; no such completion claim is made here.
- The diagnosis's retained App ANSI/replay shows a left-edge border failure and a visible reason label. Exact previous/current App Buffer equality and which wide-cell diff branch ran in that App are still **[INFERENCE]**, not instrumented observations. The permanent regression does separately establish those preconditions for its own named cases when it executes.
- The two decisive REDs did not reach their later explicit diff-any, persistent/backend repeat or close assertions. The failing controls iteration did reach its earlier emitted-border/backend checks, but not the subsequent restoration output assertions. No later coverage is retrospectively attributed to that run.
- No original failure, bytes, predicate, attempt budget, timing or controlled-consumer input was altered by this review. No native terminal/fidelity conclusion follows from source or Crossterm byte inspection.

## 7. Scope and documentation

- `README.md:230-236`, `traits.rs:149-166`, `render.rs:212-218`, and `modal.rs:4-9` describe the changed clearing owner and whole-span contract. Powers-panel comments merely stop naming the obsolete Clear widget.
- Documentation preserves character wrapping/cursor behavior and inverse paint/key ordering; it introduces no permission/approval-scope waiver, risk acceptance, or broader completion claim. Existing acceptance/native boundaries remain unchanged.
- The patch does contain incidental import ordering/test assertion reflow in several widgets. These are nonbehavioral; approval test formatting was already in qualified `ecd` and is not repair-introduced against the requested baseline. No unrelated semantic production change was found.
- Current lock source still selects ratatui 0.30.0/core 0.1.2/widgets 0.3.2/crossterm adapter 0.1.0 (`Cargo.lock:2397-2468`), and no dependency/lock/backend/input file appears in the repair delta. No production AlwaysUpdate/ForcedWidth/Skip manipulation or normalization/input hack was added.

## Remaining qualification ownership

**Source review complete; repaired-state qualification pending.** Main owns the focused producer/helper GREEN checkpoint, integrated UI/App tests, strict Clippy and applicable repository checks, final assembled integration (including the additional MCP caller), a fresh private App/source binding, and the separately authorized unchanged controlled consumer. The old pre-repair qualification and original RED are preserved evidence, not a substitute for these post-repair obligations.

Tool caveat: LSP references on `modal.rs:10 clear` returned “No references found” despite twelve visible callers; this was reported through the tool issue device. Consumer discovery here instead uses the actual patch, direct routing reads and narrowly scoped source search. No caller-completeness conclusion relies on that negative LSP result.

**Final review disposition: NONE / correct / 0.97 confidence, source-only.**
