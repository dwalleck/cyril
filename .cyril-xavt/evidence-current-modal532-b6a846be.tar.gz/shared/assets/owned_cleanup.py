"""Frozen preparation: exception-safe reuse of the currentEJ/C6 cleanup paths.

Sources (read only; neither source is imported here):
* currentEJ harness.py, SHA256
  32589c8913520328cc38768c038448756762dde292c9d2b7d59014521812c90a,
  local://ej7y-private-composer-geometry-71490ce649b7/harness.py:
  274-315 (partial construction/private environment), 317-345 (drain/send),
  544-590 (final screen, Ctrl-Q, drain 0.3, wait 5, independent fd closure).
* C6 bootstrap.py, SHA256
  3aaeb7f806ddbcdf24ca6fca8db1dd84046c1e391b122a280130a593258d28e5,
  /tmp/cyril-perf-consumer-20261022/c6la-restored-owner-7d88498e-prepare/bootstrap.py:
  51-82 (pin before inspection), 85-94 (pidfd wait),
  97-132 (two TERM5/KILL5 sweeps and final ownership attestation).

Both public functions return their receipt section instead of raising. The caller
must retain its original scenario exception, run both functions independently in
finally, and make either section's FAIL an overall failure after all cleanup.
Retain a partial TUI with __new__ before calling __init__. Retain output/scratch
until cleanup_owned finishes. Only an actual Popen.wait result is a return code;
the parent may reap/wait the App after independent cleanup if still UNOBSERVED.
No Node/peer return codes are inferred from pidfd readiness.
"""

import os
from pathlib import Path
import select
import signal
import time


def _error(state, stage, error, pid=None):
    row = {"stage": stage, "type": type(error).__name__, "error": str(error)}
    if pid is not None:
        row["pid"] = pid
    state["errors"].append(row)


def close_tui(tui, receipt):
    """Try the EJ graceful close, then independently close both initialized fds.

    This function never signals a PID or process group. Independent pidfd cleanup
    must run even if rendering, decoding, Ctrl-Q, waiting, or fd closure fails.
    """
    state = {"status": "FAIL", "errors": [], "app_returncode": "UNOBSERVED",
             "final_screen": "NOT_INITIALIZED", "ctrl_q": "NOT_NEEDED",
             "drain": "NOT_NEEDED", "raw_close": "NOT_INITIALIZED",
             "master_close": "NOT_INITIALIZED"}
    receipt["tui_close"] = state
    try:
        if tui is not None:
            if hasattr(tui, "output") and hasattr(tui, "screen"):
                try:
                    (Path(tui.output) / "final-screen.txt").write_text(tui.visible())
                    state["final_screen"] = "WRITTEN"
                except BaseException as error:
                    state["final_screen"] = "FAIL"
                    _error(state, "final screen", error)
            process = getattr(tui, "process", None)
            if process is not None:
                try:
                    if process.poll() is None:
                        try:
                            tui.send(b"\x11")
                            state["ctrl_q"] = "SENT"
                        except BaseException as error:
                            state["ctrl_q"] = "FAIL"
                            _error(state, "Ctrl-Q", error)
                        try:
                            tui.drain(0.3)
                            state["drain"] = "COMPLETE"
                        except BaseException as error:
                            state["drain"] = "FAIL"
                            _error(state, "graceful drain", error)
                except BaseException as error:
                    _error(state, "App poll", error)
                finally:
                    try:
                        state["app_returncode"] = process.wait(timeout=5)
                    except BaseException as error:
                        _error(state, "App graceful wait", error)
    except BaseException as error:
        _error(state, "partial TUI close", error)
    finally:
        try:
            raw = getattr(tui, "raw", None)
            if raw is not None:
                try:
                    raw.close()
                    state["raw_close"] = "CLOSED"
                except BaseException as error:
                    state["raw_close"] = "FAIL"
                    _error(state, "raw close", error)
        except BaseException as error:
            _error(state, "partial raw close", error)
        finally:
            try:
                master = getattr(tui, "master", None)
                if master is not None:
                    os.close(master)
                    state["master_close"] = "CLOSED"
            except BaseException as error:
                state["master_close"] = "FAIL"
                _error(state, "master close", error)
    state["status"] = "FAIL" if state["errors"] else "COMPLETE"
    return state


def _owned_handles(output, scratch, commands, state, sweep):
    """C6 ownership inspection: hold the pidfd before reading the exact marker."""
    handles = []
    marker = os.fsencode("EJ7Y_SMOKE_OUTPUT=" + str(output))
    private = {"HOME": scratch / "home", "USERPROFILE": scratch / "home",
               "PATH": scratch / "bin", "XDG_CONFIG_HOME": scratch / "config",
               "XDG_DATA_HOME": scratch / "data"}
    try:
        for entry in Path("/proc").iterdir():
            if not entry.name.isdecimal():
                continue
            pid, fd, row = int(entry.name), None, None
            stage = "pidfd_open"
            try:
                fd = os.pidfd_open(pid)
                stage = "environment"
                environment = (entry / "environ").read_bytes().split(b"\0")
                if marker not in environment:
                    continue
                row = {"pid": pid, "pidfd": fd, "sweep": sweep,
                       "ownership": "marker matched but command/private environment not proven; not signaled"}
                state["observations"].append(row)
                stage = "argv"
                commandline = (entry / "cmdline").read_bytes()
                argv = commandline.removesuffix(b"\0").split(b"\0") if commandline else []
                row["argv"] = [os.fsdecode(arg) for arg in argv]
                role = next((role for role, expected in commands.items() if argv == expected), None)
                missing = [key for key, value in private.items()
                           if os.fsencode(key + "=" + str(value)) not in environment]
                if role is None or missing:
                    row["private_environment_mismatches"] = missing
                    row["exact_command_matched"] = role is not None
                    continue
                row["role"] = role
                row["ownership"] = "exact marker, full command and private environment proven"
                handles.append((pid, fd))
            except (FileNotFoundError, ProcessLookupError) as error:
                if row is not None:
                    _error(state, "marker process disappeared during " + stage, error, pid)
            except PermissionError as error:
                if row is not None:
                    _error(state, "marker ownership inspection: " + stage, error, pid)
                else:
                    # As in C6, an unreadable unknown is never claimed or signaled.
                    state["inspection_skips"].append(
                        {"pid": pid, "stage": stage, "type": type(error).__name__,
                         "ownership": "unknown; marker unreadable; not signaled"})
            except BaseException as error:
                _error(state, "ownership inspection: " + stage, error, pid)
            finally:
                # Membership, rather than a separate transfer flag, also keeps a
                # handle pinned if interrupted immediately after handles.append.
                if fd is not None and (pid, fd) not in handles:
                    try:
                        os.close(fd)
                        if row is not None:
                            row["pidfd_closed"] = True
                    except BaseException as error:
                        _error(state, "inspection pidfd close", error, pid)
    except BaseException as error:
        _error(state, "enumerate owned processes", error)
    return handles


def _wait_handles(handles, seconds, state, stage):
    pending = {fd for _, fd in handles}
    try:
        deadline = time.monotonic() + seconds
        while pending:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            ready, _, _ = select.select(list(pending), [], [], remaining)
            pending.difference_update(ready)
    except BaseException as error:
        _error(state, stage, error)
    return pending


def _close_handles(handles, state, sweep):
    for pid, fd in handles:
        row = {"pid": pid, "pidfd": fd, "sweep": sweep, "status": "UNOBSERVED"}
        state["pidfd_closures"].append(row)
        try:
            os.close(fd)
            row["status"] = "CLOSED"
        except BaseException as error:
            row["status"] = "FAIL"
            _error(state, "owned pidfd close", error, pid)


def cleanup_owned(output, scratch, expected_commands, receipt):
    """C6 bounded cleanup, using only exact-command/private-run-proven pidfds.

    expected_commands is the parent's pre-launch {role: [complete argv...]} map.
    No ownership is inferred from a PID, process name, ancestry, or executable
    alone. Unknown marker matches remain unsignaled and make the result FAIL.
    """
    state = {"status": "FAIL", "errors": [], "observations": [], "signals": [],
             "inspection_skips": [], "pidfd_closures": [],
             "surviving_proven_owned_pids": [], "unproven_marker_pids": []}
    receipt["owned_cleanup"] = state
    commands = {}
    try:
        output, scratch = Path(output), Path(scratch)
        commands = {role: [os.fsencode(arg) for arg in argv]
                    for role, argv in expected_commands.items()}
    except BaseException as error:
        _error(state, "cleanup ownership inputs", error)
        return state
    for sweep in range(2):
        handles = []
        try:
            handles = _owned_handles(output, scratch, commands, state, sweep)
            if not handles:
                break
            for pid, fd in handles:
                row = {"pid": pid, "pidfd": fd, "signal": "SIGTERM",
                       "sweep": sweep, "outcome": "UNOBSERVED"}
                state["signals"].append(row)
                try:
                    signal.pidfd_send_signal(fd, signal.SIGTERM)
                    row["outcome"] = "SENT"
                except ProcessLookupError:
                    row["outcome"] = "ALREADY_EXITED"
                except BaseException as error:
                    row["outcome"] = "ERROR; delivery not observed"
                    _error(state, "pidfd SIGTERM", error, pid)
            pending = _wait_handles(handles, 5, state, "TERM wait")
            for pid, fd in handles:
                if fd not in pending:
                    continue
                row = {"pid": pid, "pidfd": fd, "signal": "SIGKILL",
                       "sweep": sweep, "outcome": "UNOBSERVED"}
                state["signals"].append(row)
                try:
                    signal.pidfd_send_signal(fd, signal.SIGKILL)
                    row["outcome"] = "SENT"
                except ProcessLookupError:
                    row["outcome"] = "ALREADY_EXITED"
                except BaseException as error:
                    row["outcome"] = "ERROR; delivery not observed"
                    _error(state, "pidfd SIGKILL", error, pid)
            pending = _wait_handles(handles, 5, state, "KILL wait")
            if pending:
                _error(state, "bounded owned cleanup",
                       RuntimeError("Proven owned processes did not exit after TERM5/KILL5"))
        except BaseException as error:
            _error(state, "owned cleanup sweep", error)
        finally:
            _close_handles(handles, state, sweep)
    survivors = []
    try:
        survivors = _owned_handles(output, scratch, commands, state, "final")
        state["surviving_proven_owned_pids"] = [pid for pid, _ in survivors]
        state["unproven_marker_pids"] = sorted(
            {row["pid"] for row in state["observations"] if "not proven" in row["ownership"]})
        if survivors or state["unproven_marker_pids"]:
            _error(state, "final owned-process attestation",
                   RuntimeError("Owned cleanup could not attest an empty marker-owned process set"))
    except BaseException as error:
        _error(state, "final ownership inspection", error)
    finally:
        _close_handles(survivors, state, "final")
    state["status"] = "FAIL" if state["errors"] else "COMPLETE"
    return state
