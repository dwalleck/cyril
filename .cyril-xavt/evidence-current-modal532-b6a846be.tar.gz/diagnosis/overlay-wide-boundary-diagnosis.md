# Wide-grapheme overlay-boundary diagnosis

## Summary and status

The inspected current source has a concrete mechanism matching the retained controlled failure: a wide underlay grapheme whose lead is immediately outside a popup survives rectangular Clear; released Ratatui Buffer::diff then skips the popup's intended border as that lead's covered column. This is an overlay composition/occlusion defect, not reversed paint order or demonstrated failure to enter the reason phase.

Recommended existing owner: `crates/cyril-ui/src/widgets/modal.rs`. Add one crate-local clear operation there and migrate all 12 existing overlay Clear callsites. No new module, trait, framework, backend, dependency/vendor change, or normalization is justified.

This is a read-only source diagnosis and unimplemented recommendation, NOT design approval or a fix PASS. No repository edits, builds, tests, shell/runtime commands, new replay, or mutations were performed by this scout. Agent coordination messages and this requested local handoff are the only writes.

## Evidence provenance

Read the complete newly published packets, and coordinated with RefreshApprovalWidthStack:

- `local://xavt-af78-owned-runtime-handoff-b27bd94f.json`, sealed SHA-256 `4961eea3efb2e540edf48dfc8144bc0578a524e2438dd321b243ad32483675eb`.
- `local://xavt-af78-owned-runtime-failure-diagnosis-b27bd94f.json`, SHA-256 `14de20d6278c0f7b6a53ca68961a3ea76494b5a093726015d0e01fadf00f9c42`.
- `local://xavt-af78-owned-runtime-evidence-inventory-b27bd94f.json`, SHA-256 `91d52d05a76e352059c1025c00ea28bd8a85992e9d1ddfdbd22d43e3cf45b17e`.
- Independent source slice: `agent://RefreshApprovalWidthStack.InspectXReasonLayout`.

Raw root: `/tmp/cyril-xavt-af78-current-owned-retained-halfwidth-attempt1-b27bd94f`.

The packet's observed repair candidate is LEFT-EDGE ONLY. The generic span-intersection correction and 12-site migration below are this scout's recommendation, not an expansion of that packet's approval.

### Recorded raw/replay observations (not newly executed by this scout)

| Evidence | Recorded finding |
|---|---|
| `agent-wire.jsonl:4-5` | Pending Execute carries command `"ｶﾞ\n:"`, path `"界界"`; following permission stub omits rawInput. |
| `terminal.ansi` | 731,325 bytes, SHA-256 `0eb1c3db8a339b9daa31bedd1a7fb1788ced83887a6e764e1d6b01caa58acad0`. |
| Initial header pair | Byte4681 after `CSI13;3H` plus ` Run(`; decoded pair at zero-based x7..8,y12. Raw next has `CSI13;10H:)`. |
| Reason title / label | Title starts byte8304; `Rejecting: Deny` occurs once, byte11763. |
| Frozen replay | Popup top11,left8,right71; first body row12 has x8=`ﾞ` (FF9E), not `│`. |
| Exact box predicate | bottom12, raw_body=[]; reason label exists at x9,y17, but box_has remains false. |
| Prefixes | Exact frozen adapter/base replay at11763/11778/12763/full raw retains broken boundary; full visible equals original same-wait exception and final-screen exactly. |
| Emission limit | No absolute `CSI13;9H` anywhere; raw LF count0. |
| Contrast | Captured original892 prefix21316 reproduces recorded popup box and box_has=True. |
| Reach | Controlled driver1, zero observations, zero permission4 responses. All narrow/resize/width12/restoration checks were unreached. Both cleanup COMPLETE; App0 on cleanup. |

No per-read/per-key timestamps or original read-chunk boundaries were retained. Byte-prefix replay is ordering evidence, not original sampling-time evidence. Frozen replay was performed by Refresh in Eval using exact methods and adapter, not a newly written replay framework.

Pins from original result: binary `/tmp/cyril-xavt-af78-default-App-qualified-20261022T172641751658Z`, SHA `c82cc1fc28cc78635137b78542ec6ae64be8fa64948c4530c4a3a0fc566eb916`; approval source SHA `ecd6031403e009bf1ff735b0d75413c3d4d232ad49869653044b5ebcb9cd256c`; 530-input descriptor `fcfb57a5ae97b1bf677e164d1db5202ad10b206b5d0deb1b9d38a39aa47be71c`.

## Architecture and exact source proof

Repository references below are relative to `/home/dwalleck/repos/cyril-wt-fix-cyril-xavt` as inspected.

### Actual producer and paint order

- `crates/cyril-ui/src/traits.rs:508-513`: TrackedToolCall::command_text returns rawInput.command unchanged.
- `crates/cyril-ui/src/widgets/chat.rs:318-349,377-392`: Pending status supplies `⏳ `; Execute builds `Run({display})` from first50 command scalars. Actual controlled header therefore contains the halfwidth pair independently of the preserved permission title.
- `crates/cyril-ui/src/widgets/chat.rs:19-70`: real chat Paragraph construction, wrapping/scrolling and painting. Source alone does not prove y12; retained replay supplies that coordinate.
- `crates/cyril-ui/src/render.rs:181-184,212-240`: chat painted before approval overlay, using Overlay::ALL order.
- `crates/cyril-ui/src/widgets/approval.rs:1370-1478`: reason phase clears popup then paints a Paragraph with all borders. The x8 left border is intended to overwrite underlay there.
- `crates/cyril-ui/src/widgets/modal.rs:1-63`: existing centered/popup_width/place geometry owner; protects input rows without any buffer mutation responsibility yet.
- `crates/cyril-ui/src/traits.rs:149-205`: seven overlay variants, bottom-to-top usage/code/powers/hooks/picker/review/approval; render and key order are inverses.

### Locked dependency facts

`Cargo.lock:2397-2414,2433-2438,2465-2468` selects ratatui0.30.0/core0.1.2/widgets0.3.2/crossterm adapter0.1.0.

Registry base: `/home/dwalleck/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/`.

| Source | Fact read from implementation |
|---|---|
| `ratatui-core-0.1.2/src/text/span.rs:306-315` | styled_graphemes segments graphemes and filters any containing controls. Embedded LF does not create a header line break on this path. |
| `ratatui-core-0.1.2/src/buffer/cell_width.rs:24-74` | FF9E/FF9F contribute physical columns. |
| `ratatui-core-0.1.2/src/buffer/buffer.rs:970-986` | Source test explicitly stores `ｶﾞ` in one lead Cell with width2; U3099 combining counterpart width1. |
| `ratatui-widgets-0.3.2/src/paragraph.rs:407-415,459-472` | Paints Block first, then writes each grapheme at a lead cell and advances x by physical width. |
| `ratatui-widgets-0.3.2/src/clear.rs:38-48` | Clear intersects its rectangle with Buffer and resets ONLY cells inside that rectangle. It does not inspect outside leads. |
| `ratatui-widgets-0.3.2/src/block.rs:824-879` | Left border is written at area.left(). |
| `ratatui-core-0.1.2/src/buffer/diff.rs:148-174` | Both equal current multi-width leads and changed non-VS16 wide leads skip their covered columns. |
| `ratatui-core-0.1.2/src/terminal/buffers.rs:103-116` | Terminal flush sends previous.diff_iter(current) directly to Backend::draw. |
| `ratatui-crossterm-0.1.0/src/lib.rs:225-275` | Backend prints only yielded cells; omitted border cannot be recovered downstream. |

### Deterministic skip derivation

Given the source-produced lead observed at x7,y12:

```
Before overlay                 After current Clear + border painting
x7 = "ｶﾞ", width2              x7 = "ｶﾞ", width2  (outside Clear, survives)
x8 = covered column           x8 = "│"           (intended border)
```

This composed Buffer has conflicting ownership: x8 is both the wide lead's covered column and the overlay's independently written border.

The exact equal-lead diff branch is:

```rust
if matches!(current.diff_option, CellDiffOption::None) && current == previous {
    self.pos += cell_width.saturating_sub(1);
    continue;
}
```

At x7 the loop has already advanced pos once. Width2 adds1, so the next position is x9. The new x8 border is never examined. Changed non-VS16 wide leads also skip their covered columns; equality is not necessary to the broader defect.

**Evidence classification:** the skip is proven from the inspected source given these Buffer contents. It matches raw/replay facts. However the actual failed App run did not capture internal previous/current Buffers: exact x7 equality and which diff branch executed are **[INFERENCE]**, NOT instrumented App observations. No native terminal fidelity claim follows from this scout or the recorded pyte replay.

### Why the wait fails

Frozen `ej-owned-base-harness.py:424-443,513-515` extracts contiguous popup body rows only while the leftmost cell is `│`. Row12 x8 is FF9E, so extraction stops immediately and raw_body remains empty. The visible label at y17 cannot satisfy box_has. Frozen `wait` evaluates predicate then checks process/time and constructs visible exception without an intervening drain; equal exception/final screens are consistent with this. It is not demonstrated label lateness or missing reason entry. Do not relax this predicate.

## Generic smallest-correct repair recommendation

### Owner and interface

Use existing `crates/cyril-ui/src/widgets/modal.rs`, adding only one crate-local operation:

```rust
pub(crate) fn clear(frame: &mut Frame<'_>, area: Rect)
```

The module is already visible to sibling widgets and crate render (`widgets/mod.rs:1-16`). No public API, new module, trait, retained cache, or overlay framework is needed.

### Contract

For each affected row, an existing grapheme lead at a owns its full painted span `[a,b)`, clipped to that Buffer row. Clear the overlay's clipped interval `[left,right)` plus the complete owned spans that intersect it:

```
evict span iff a < right && b > left
```

Preserve EVERY outside cell whose owned grapheme is disjoint, including its style. Rows outside the clipped overlay are unchanged. Evict an intersecting whole grapheme, never normalize or preserve a scalar fragment of it.

This handles both:

1. lead outside left edge, trailing columns inside overlay;
2. lead inside overlay, trailing columns beyond right edge.

### Implementation shape

Allocation-free row walk over existing Cell ownership:

- Intersect area with Buffer first; empty intersection returns without mutation.
- Scan affected rows from Buffer's left edge through overlay.right(), advancing over visible lead spans with `CellWidth` on the Cell and `max(1)` for progress.
- Use clipped/saturating or widened arithmetic; never walk across rows.
- Determine the intersecting span bounds before resetting them, then reset that row interval, including the requested overlay interior.
- Do not inspect only x-1 or use a fixed halo. Source CellWidth tests include width3 (`あﾞ`), and longer physical spans are possible.
- Do not allocate/copy whole Buffers or strings in production.

A scan from row start is justified by absence of ownership backpointers and arbitrary span length; it avoids assuming all wide graphemes are two columns. No global post-render pass or alternative diff implementation is warranted.

This is semantic overlay occlusion BEFORE diff: the final Buffer becomes non-conflicting. Released continuation suppression remains unchanged, so this is not an application continuation-cell output workaround replacing the released dependency fix.

### Rejected alternatives

- Entire-row or indiscriminate neighboring-column clearing erases unrelated outside cells.
- AlwaysUpdate/ForcedWidth(1)/Skip manipulation lies to diff or leaves conflicting ownership.
- Normalizing/splitting `ｶﾞ`, altering header text, or content-dependent popup movement fixes the fixture rather than the class.
- Vendoring, dependency patching, backend replacement, or a global buffer repair pass changes the wrong owner.
- Weakening box_has, whole-screen label matching, extra keys/sleeps/retries/budgets, dropping controlled fixture or changing its bytes hides the failure.

## Complete affected callsite inventory

Exactly **12** current Clear calls: 5 approval phases + 6 other modals + 1 floated suggestions path.

| File | Exact line / phase |
|---|---|
| `crates/cyril-ui/src/widgets/approval.rs` |1195 option|
| same |1396 reason|
| same |1508 trust|
| same |1683 scope|
| same |1890 folder|
| `crates/cyril-ui/src/widgets/code_panel.rs` |142|
| `crates/cyril-ui/src/widgets/hooks_panel.rs` |43|
| `crates/cyril-ui/src/widgets/picker.rs` |63|
| `crates/cyril-ui/src/widgets/powers_panel.rs` |92|
| `crates/cyril-ui/src/widgets/review.rs` |45|
| `crates/cyril-ui/src/widgets/usage_panel.rs` |23|
| `crates/cyril-ui/src/render.rs` |207 floated suggestions|

Float suggestions currently use full frame width and therefore lack this interior horizontal left edge; still migrate the same clearing responsibility to avoid a second convention.

Affected docs/comments: raw-Clear responsibility at `crates/cyril-ui/src/traits.rs:149-160`, render overlay comments around212-219, modal helper docs, and physical-width user docs at `README.md:230-234`. Geometry/stack order/permission/editor semantics intentionally unchanged. Remove obsolete Clear imports as callers cut over.

## Approved width contract and scope limits

`local://approved-ratatui-release-migration.md` owns authority:

- released core0.1.2/widgets0.3.2, no vendor patch;
- physical CellWidth on borrowed graphemes, long accumulations usize;
- FF9E/FF9F physical columns and U3099/U309A combining controls;
- original bytes and existing character-wrap/character-cursor contract;
- no input-specific suppression, normalization, custom backend or continuation workaround replacing released fix;
- actual painter/diff/backend proof, not Buffer cell presence alone;
- shrink/delete/style/focus/move/geometry/close and halfwidth/combining controls retained.

`crates/cyril-ui/src/text.rs:1-29` already implements shared painted text width. Do not alter those width, sanitizer, meaningful-context, preview-navigation or confirmation policies for this repair. No ACP/core schema, permissions/grants, App event semantics or command/path bytes need change.

## Regression strategy (PROPOSED; not added or run)

### A. Decisive actual-producer -> diff -> backend fence

Put full composition coverage in `crates/cyril-ui/src/render.rs`'s existing tests (mod starts296), with real chat producer plus real approval rendering. Existing `topmost_overlay_paints_last` at871-984 supplies fixture/stack patterns but lacks wide boundary ownership.

Use persistent terminal/buffer state, not an approval-only synthetic buffer:

1. Render pending Execute message carrying actual `"ｶﾞ\n:"` raw input, with sufficient real preceding content to reproduce the observed 80x40 y12 row.
2. Assert producer precondition literally: lead Cell at(7,12) is `ｶﾞ`, physical width2. Do not derive expected x from the helper under test.
3. Enter/render actual reason page with path `界界`; assert literal popup left8/top11 and visible Deny reason label.
4. Retain previous and composed current buffers BEFORE backend application. `Terminal::get_frame`/current-buffer access are released existing seams; no new production instrumentation abstraction is necessary.
5. Require intended `│` at(8,12) in outgoing released diff AND applied backend output. Current composed Buffer cell alone is insufficient.
6. Repeat unchanged render; then move/shrink/close overlay and require valid redraw/restoration of underlay.

**Before-fix discriminator:** current composed Buffer can contain `│` at(8,12) while previous.diff_iter(current) omits it. The regression must fail on emitted border, not an incidental string/golden mismatch. Establish unchanged-lead equality as a test precondition to exercise that exact skip branch; separately retain a changed-lead variant.

These are predicted source-based failures, not executed RED claims. Main owns authorized run-before-fix and preserved failure evidence.

### B. Real backend output

Feed actual producer-composed buffers' `previous.diff_iter(current)` into released `CrosstermBackend<Vec<u8>>` via Backend::draw. Assert the border really reaches output, with target cursor/cell writes or existing frozen ANSI decoder replay. No custom backend/replacement diff model. Keep literal output coordinates independent of the clear implementation.

Actual App seam: `crates/cyril/src/app.rs:946-973` draw_frame synchronizes geometry and invokes real render. Existing `approval_draw_at` at7415-7429 creates a fresh TestBackend and flattens symbols, so it alone cannot prove this persistent transition. Extend actual draw/key tests with a persistent terminal where App integration proof is needed, without rewriting helper conventions broadly.

### C. Generic modal ownership controls

Colocate helper-level coverage in modal.rs using ordinary existing Buffer/Paragraph/Block seams:

- left and right crossing spans;
- exact-touch nonintersection (span ends at left / begins at right);
- halfwidth voiced/semi-voiced pairs, CJK, VS16;
- width>2 grapheme (verified source `あﾞ` width3), proving no x-1-only rule;
- U3099/U309A combining counterparts, which must not acquire extra columns;
- disjoint adjacent wide glyphs and outside cells with distinct styles, all preserved;
- vacated styled spans, unchanged repaint, offset Buffer origins, clipping and empty areas;
- stacked overlays, movement/shrink/close restoration;
- no independent SPACE overwrite of a surviving wide glyph's covered columns.

Preserve `topmost_overlay_paints_last`, protected-input/modal geometry, theme tests and original character-wrap oracle. Generic helper controls do not substitute for actual chat+approval producer coverage.

### D. Unchanged controlled consumer acceptance

After Main-authorized implementation/qualification, preserve and exercise frozen harness `b27bd94f`, base `32589c89...`, adapter `0ce4ddf5...`, both exact specimens and current FAIL packet. Complete all currently unreached narrow Home/End refusals, whole-pair width12 observation, restored80x40 command/path context, and one manual RejectOnce. No relaxed predicates/bytes/keys/time budget/retries. Original892 PASS remains narrowly attributed until affected proof is requalified.

## Handoff conclusion

Source owner and causal mechanism are identified. A generic correction can remain inside existing modal composition ownership with one crate-local function and twelve caller replacements. Raw observations support the left-edge failure; exact failed-run Buffer equality remains inference. No repaired-state execution or acceptance exists. Main must approve the concrete design, authorize implementation and verification, and preserve the fail-before producer/diff/backend evidence before claiming completion.
