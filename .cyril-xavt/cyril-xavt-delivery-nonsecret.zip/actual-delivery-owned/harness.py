#!/usr/bin/env -S uv run --script
# /// script
# dependencies = ["pyte"]
# ///
"""Exact safe captured-frame -> qualified actual Cyril PTY proof; RejectOnce only.
No real KAS, account, model, shell command, tool execution or completed frame.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import select
import signal
import sys
import tempfile
import time

EJ_HARNESS = Path('/tmp/cyril-ej7y-owned-smoke-20261020-a/harness.py')
SAFE_WIRE = Path('/tmp/cyril-xavt-live.ZiHasL/evidence/wire-agent-nonsecret.jsonl')
BINARY = Path('/tmp/cyril-xavt-delivery-tested-20261020')
BINARY_SHA = '33891699d8cfa71f5ce8e16fae3675b23c4e104d384a7f7d69416880ffebfb84'
DRAFT = 'D'
REASON = 'REJECT_DRAFT_NOT_SUBMITTED'
PERMISSION_ID = 4


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def journal(path, value):
    with path.open('a') as stream:
        stream.write(json.dumps(value, ensure_ascii=False) + '\n')


def fixtures():
    records = [json.loads(line) for line in SAFE_WIRE.read_text().splitlines()]
    tool = records[3]
    permission = records[4]
    assert tool['method'] == 'session/update' and tool['toolCall']['sessionUpdate'] == 'tool_call'
    assert tool['toolCall']['status'] == 'pending'
    assert permission['method'] == 'session/request_permission' and permission['id'] == PERMISSION_ID
    assert tool['sessionId'] == permission['sessionId']
    assert tool['toolCall']['toolCallId'] == permission['toolCall']['toolCallId']
    assert 'rawInput' not in permission['toolCall']
    raw = tool['toolCall']['rawInput']
    assert len(raw['command'].encode()) == 892
    assert hashlib.sha256(raw['command'].encode()).hexdigest() == '1c9636e678e54cb857c2b9e7079c45df8e0870995c1e43a51834d4902d56292c'
    # The safe wire file retained original payload fields, not transport envelopes.
    # Recreate ONLY ACP envelopes; no _meta, helper-domain fields or value changes.
    frames = [
        {'jsonrpc': '2.0', 'method': tool['method'], 'params':
         {'sessionId': tool['sessionId'], 'update': tool['toolCall']}},
        {'jsonrpc': '2.0', 'id': permission['id'], 'method': permission['method'], 'params':
         {key: permission[key] for key in ['sessionId', 'toolCall', 'options']}},
    ]
    return tool['sessionId'], raw, frames


def agent():
    output = Path(os.environ['EJ7Y_SMOKE_OUTPUT'])
    session, raw, frames = fixtures()
    prompt, emitted, decided, incoming = None, False, False, b''

    def send(frame):
        journal(output / 'agent-wire.jsonl', frame)
        print(json.dumps(frame, ensure_ascii=False), flush=True)

    def text(value):
        send({'jsonrpc': '2.0', 'method': 'session/update', 'params': {'sessionId': session,
              'update': {'sessionUpdate': 'agent_message_chunk', 'content': {'type': 'text', 'text': value}}}})

    while True:
        ready, _, _ = select.select([sys.stdin.fileno()], [], [], 0.02)
        if ready:
            chunk = os.read(sys.stdin.fileno(), 65536)
            if not chunk:
                return
            incoming += chunk
            while b'\n' in incoming:
                line, incoming = incoming.split(b'\n', 1)
                frame = json.loads(line)
                journal(output / 'client-wire.jsonl', frame)
                method, ident = frame.get('method'), frame.get('id')
                if method == 'initialize':
                    send({'jsonrpc': '2.0', 'id': ident, 'result': {'protocolVersion': 1,
                          'agentCapabilities': {'loadSession': True, '_meta': {'kiro': {}}},
                          'agentInfo': {'name': 'xavt-exact-safe-captured-peer', 'version': '0.66.43'}, 'authMethods': []}})
                elif method == 'session/new':
                    # Use the original session ID, never rewrite captured frames.
                    send({'jsonrpc': '2.0', 'id': ident, 'result': {'sessionId': session}})
                elif method == 'session/prompt':
                    assert prompt is None
                    prompt = ident
                    text('XAVT_OWNED_READY\n')
                elif method == 'session/cancel':
                    pass
                elif method and ident is not None:
                    send({'jsonrpc': '2.0', 'id': ident, 'result': {}})
                elif ident == PERMISSION_ID:
                    assert emitted and not decided
                    assert frame.get('result', {}).get('outcome') == {'outcome': 'selected', 'optionId': 'reject'}
                    assert 'rejectionReason' not in frame.get('result', {}).get('_meta', {}).get('kiro', {})
                    decided = True
                    # Deliberately no tool_call_update/completed: Reject did not execute.
                    text('\nXAVT_OWNED_REJECTED_NO_EXECUTION\n')
                    send({'jsonrpc': '2.0', 'id': prompt, 'result': {'stopReason': 'end_turn'}})
                    prompt = None
        control = output / 'control.json'
        if control.exists() and not emitted:
            assert prompt is not None
            emitted = True
            for frame in frames:
                send(frame)


def main(args):
    spec = importlib.util.spec_from_file_location('ej_owned', EJ_HARNESS)
    assert spec is not None and spec.loader is not None
    ej = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(ej)
    # The established OwnedTui launch wrapper dispatches this script's safe agent.
    ej.__file__ = str(Path(__file__).resolve())
    session, raw, frames = fixtures()
    assert digest(BINARY) == BINARY_SHA
    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=False)
    (output / 'harness.py').write_bytes(Path(__file__).read_bytes())
    (output / 'ej-owned-base-harness.py').write_bytes(EJ_HARNESS.read_bytes())
    write_json(output / 'replayed-frames.json', frames)
    receipt = {'result': 'FAIL', 'binary_sha256': BINARY_SHA, 'binary': str(BINARY),
               'safe_wire_sha256': digest(SAFE_WIRE), 'existing_ej_harness_sha256': digest(EJ_HARNESS),
               'session_id': session, 'permission_id': PERMISSION_ID,
               'scope': 'actual qualified Cyril KAS projection/UI/permission wire through an owned PTY and decoded terminal; not real KAS or native desktop glyph/reflow proof',
               'safety': 'exact pending tool and permission payloads; original command/cwd/session; rawInput absent from permission; manual RejectOnce only; no completed-frame replay, operation, account/model contact or real auth',
               'observations': []}
    with tempfile.TemporaryDirectory(prefix='cyril-xavt-delivery-owned-private-') as temp:
        scratch = Path(temp)
        for name in ['bin', 'home', 'config', 'data', 'ws']:
            (scratch / name).mkdir()
        (scratch / 'bin/kiro-cli').symlink_to(args.auth_fixture)
        tui = ej.OwnedTui(argparse.Namespace(binary=str(BINARY)), scratch, output)

        def responses():
            return [frame for frame in tui.wire('client-wire.jsonl') if frame.get('id') == PERMISSION_ID and 'method' not in frame]

        def pending():
            assert not responses(), f'unexpected permission answer: {responses()}'

        def capture(name, *, draft=True, selected=None):
            pending()
            if draft:
                assert tui.input_draft() == DRAFT, f'chat draft changed: {tui.input_draft()!r}'
            view = tui.view()
            if view is not None:
                box = view['box']
                cells = []
                for y in range(box['top'] + 1, box['bottom']):
                    interior = ''.join(tui.screen.buffer[y][x].data for x in range(box['left'] + 1, box['right']))
                    if interior.startswith('    ') and interior.strip() and not interior.lstrip().startswith('↑'):
                        cells.append(interior[4:])
                view['content_cells'] = cells
            if selected:
                assert tui.box_has('▸ ' + selected), f'selected option not drawn: {selected}'
            (output / (name + '.txt')).write_text(tui.visible())
            item = {'capture': name + '.txt', 'columns': tui.columns, 'rows': tui.rows,
                    'raw_byte_offset': tui.raw_size, 'view': view, 'chat_draft': tui.input_draft(),
                    'permission_unanswered': True}
            receipt['observations'].append(item)
            return view

        def visible_context(view):
            # OwnedTui extracts only the preview rows, not horizontally clipped title.
            assert view is not None and 'Preview unavailable' not in '\n'.join(view['body'])
            return view

        try:
            tui.wait(lambda: 'XAVT_OWNED_READY' in tui.visible(), 'owned pending prompt')
            tui.paste(DRAFT)
            tui.wait(lambda: tui.input_draft() == DRAFT, 'initial chat draft')
            tui.command(cases=[0])
            tui.wait(lambda: 'Permission Required' in tui.visible() and tui.status_start() == 1,
                     'captured shell modal with first page')
            first = visible_context(capture('01-command-first-page', selected='Allow'))
            seen = {}
            page = 1
            while True:
                view = visible_context(capture(f'02-command-page-{page:02d}', selected='Allow'))
                status = view['status']
                assert status is not None and len(view['content']) == status['visible']
                for index, row in enumerate(view['content_cells'], status['start']):
                    assert index not in seen or seen[index] == row, f'overlap mismatch at {index}'
                    seen[index] = row
                if status['end'] == status['total']:
                    break
                assert page < 10
                previous = status['start']
                tui.key('pgdn')
                tui.wait(lambda: tui.status_start() != previous, 'next command page')
                page += 1
            assert sorted(seen) == list(range(1, max(seen) + 1))
            rows = [seen[index] for index in sorted(seen)]
            cwd_index = next(index for index, value in enumerate(rows) if value.startswith('Cwd: '))
            actual_command = ''.join(rows[:cwd_index - 1]) + rows[cwd_index - 1].rstrip()
            actual_cwd = (''.join(rows[cwd_index:])[len('Cwd: '):]).rstrip()
            assert actual_command == raw['command'], f'modal command differs: {actual_command!r}'
            assert actual_cwd == raw['cwd'], f'modal cwd differs: {actual_cwd!r}'
            write_json(output / 'render-wire-reconciliation.json', {
                'result': 'PASS', 'command_bytes': len(actual_command.encode()),
                'command_sha256': hashlib.sha256(actual_command.encode()).hexdigest(),
                'full_command_equals_original_wire': True, 'cwd': actual_cwd,
                'cwd_equals_original_wire': True, 'rows': rows, 'pages': page,
                'all_24_sed_segments_present': all(actual_command.count(f'XAVT_SEG_{index:02d}') == 2 for index in range(1,25)),
                'permission_rawInput_absent': 'rawInput' not in frames[1]['params']['toolCall'],
                'title_not_used_as_command_evidence': True})
            # Inspect a reject-only reason draft and return without submitting it.
            tui.key('down')
            tui.key('down')
            tui.wait(lambda: tui.box_has('▸ Deny'), 'offered RejectOnce selected')
            tui.send(b'r')
            tui.wait(lambda: tui.box_has('Rejecting: Deny'), 'reason editor')
            tui.paste(REASON)
            tui.wait(lambda: tui.box_has(REASON + '█'), 'reason draft')
            tui.key('shift-home')
            tui.await_start(1)
            capture('03-reason-draft-command-start')
            tui.key('shift-end')
            tui.wait(lambda: tui.view() is not None and raw['cwd'] in '\n'.join(tui.view()['content']), 'reason draft command tail and cwd')
            capture('04-reason-draft-command-tail')
            assert tui.box_has(REASON + '█')
            tui.send(b'\x1b')
            tui.wait(lambda: tui.box_has('▸ Deny') and not tui.box_has('Rejecting: Deny'), 'Escape returns to RejectOnce without answering')
            capture('05-options-restored', selected='Deny')
            tui.key('up')
            tui.key('up')
            tui.wait(lambda: tui.box_has('▸ Allow'), 'Allow selected only for blocked-Enter checks')
            # Original live geometry: one preview row, then shift to cwd-only tail.
            tui.resize(80, 14)
            tui.key('shift-end')
            tui.wait(lambda: tui.view() is not None and len(tui.view()['content']) == 1
                     and tui.view()['content'][0].startswith('Cwd: '), 'cwd-only current viewport')
            capture('06-cwd-only-before-enter', selected='Allow')
            tui.send(b'\r')
            tui.drain(0.4)
            capture('07-cwd-only-after-enter', selected='Allow')
            tui.resize(12, 10)
            capture('08-tiny-before-enter', draft=False)
            tui.send(b'\r')
            tui.drain(0.4)
            capture('09-tiny-after-enter', draft=False)
            tui.resize(80, 40)
            tui.key('shift-home')
            tui.await_start(1)
            capture('10-restored-command-before-reject', selected='Allow')
            tui.key('down')
            tui.key('down')
            tui.wait(lambda: tui.box_has('▸ Deny'), 'one offered manual RejectOnce')
            capture('11-manual-reject-selected', selected='Deny')
            tui.send(b'\r')
            tui.wait(lambda: len(responses()) == 1, 'one rejection response')
            response = responses()[0]
            assert response['result']['outcome'] == {'outcome': 'selected', 'optionId': 'reject'}
            assert 'rejectionReason' not in response['result'].get('_meta', {}).get('kiro', {})
            tui.wait(lambda: 'XAVT_OWNED_REJECTED_NO_EXECUTION' in tui.visible(), 'clean owned prompt completion after rejection')
            tui.wait(lambda: tui.input_draft() == DRAFT, 'chat draft retained after rejection')
            (output / '12-rejected-clean-stop.txt').write_text(tui.visible())
            sent = tui.wire('agent-wire.jsonl')
            actual_frames = [frame for frame in sent if frame.get('method') == 'session/request_permission'
                             or (frame.get('method') == 'session/update' and frame['params']['update'].get('sessionUpdate') == 'tool_call')]
            assert actual_frames == frames, 'captured payload changed in emitted wire'
            assert not any(frame.get('method', '').startswith(('fs/', 'terminal/', '_kiro/auth/')) for frame in sent)
            assert not any(frame.get('method') == 'session/update' and frame['params']['update'].get('status') == 'completed' for frame in sent)
            assert len([frame for frame in sent if frame.get('method') == 'session/request_permission']) == 1
            receipt.update(result='PASS', command_bytes=892, command_and_cwd_exact=True,
                           pages=page, draft_retained=DRAFT, reason_draft_preserved_not_submitted=True,
                           cwd_only_enter_refused=True, tiny_enter_refused=True,
                           permission_response=response, permission_response_count=1,
                           clean_owned_prompt_end=True, completed_frame_replayed=False,
                           operation_executed=False)
        except Exception as error:
            receipt['error'] = str(error)
            raise
        finally:
            # Never read/copy private HOME, Cyril logs or token-helper output.
            if tui.process.poll() is None:
                tui.send(b'\x11')
                tui.drain(0.3)
                try:
                    tui.process.wait(timeout=5)
                except Exception:
                    os.killpg(tui.process.pid, signal.SIGTERM)
                    tui.process.wait(timeout=5)
            receipt['cyril_exit_code'] = tui.process.returncode
            tui.raw.close()
            os.close(tui.master)
            write_json(output / 'result.json', receipt)
    print(json.dumps({key: value for key, value in receipt.items() if key != 'observations'}, indent=2))


if __name__ == '__main__':
    if sys.argv[1:] == ['agent']:
        agent()
    else:
        parser = argparse.ArgumentParser(description=__doc__)
        parser.add_argument('--output', required=True)
        parser.add_argument('--auth-fixture', required=True)
        main(parser.parse_args())
