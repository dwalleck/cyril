#!/usr/bin/env -S uv run --script
# /// script
# dependencies = ["pyte"]
# ///
"""Owned ACP-peer/actual-Cyril ej7y smoke. Run only on the parent's tested binary.

No workflow operation, external account, filesystem/terminal callback, or durable
permission grant occurs. Comparison, plan Text/raw fallback, ordinary Text and
ordinary Diff are deliberately separate routes. Pyte is decoded-text/ASCII-box
proof, not native Unicode glyph fidelity. The existing App/renderer gates retain
the exhaustive size/modifier/platform obligations.
"""
import argparse
import codecs
import fcntl
import hashlib
import json
import os
from pathlib import Path
import pty
import re
import select
import shutil
import signal
import struct
import subprocess
import sys
import tempfile
import termios
import time
from typing import Any

DRAFT = "D"
PREFIX = "Compared with the replaced steps: "
# These bytes decode through crossterm0.29's parse_csi_special_key_code,
# parse_csi_modifier_key_code and parse_modifiers. UI accepts exact NONE pages
# and exact SHIFT arrows/Home/End, not Ctrl/Alt or Shift-modified page keys.
KEYS = {"pgup": b"\x1b[5~", "pgdn": b"\x1b[6~", "shift-up": b"\x1b[1;2A",
        "shift-down": b"\x1b[1;2B", "shift-home": b"\x1b[1;2H", "shift-end": b"\x1b[1;2F",
        "up": b"\x1b[A", "down": b"\x1b[B", "home": b"\x1b[H", "end": b"\x1b[F",
        "ctrl-shift-down": b"\x1b[1;6B", "alt-shift-down": b"\x1b[1;4B",
        "shift-pgdn": b"\x1b[6;2~", "ctrl-pgdn": b"\x1b[6;5~"}
STATUS = re.compile(r"↑ (\d+)–(\d+)/(\d+)")


def compact(value):
    return "".join(value.split())


def long_comparison():
    ids = lambda prefix, count: ", ".join(f"{prefix}{index:02d}" for index in range(count))
    value = f"{PREFIX}Removed: {ids('rm', 48)}; Added: {ids('add', 24)}; Changed: {ids('chg', 20)}"
    if not (len(value) > 600 and value.index("chg11") + 5 <= 600 and value.index("chg13") > 600):
        raise AssertionError("repository-derived retained/discarded ID fixture premises changed")
    return value


def plan(kind="replace", omitted=None):
    value = {"workflowId": "wf_ej7y_owned", "nodeId": "plan-editor", "kind": kind,
             "workflowRef": "generated://ej7y-owned", "keptStepIds": ["plan-editor"],
             "steps": [{"nodeId": f"{prefix}{index:02d}", "type": "step", "agentName": "reviewer",
                        "task": {"text": f"Review replacement {prefix}{index:02d}", "truncated": False}}
                       for prefix, count in [("add", 24), ("chg", 20)] for index in range(count)]}
    if omitted == "steps":
        value["keptStepIds"] = []
        value["steps"] = []
        value["omitted"] = "steps"
    elif omitted == "details":
        value["steps"] = [{"nodeId": "inspect", "type": "step", "agentName": "reviewer"}]
        value["omitted"] = "details"
    return value


def specimens() -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = [
        {"name": "queued-main", "route": "main", "comparison": long_comparison(), "path": "/tmp/ej7y-a.md"},
        {"name": "queued-next", "route": "queue", "comparison": long_comparison(), "path": "/tmp/ej7y-b.md"},
    ]
    for glyph, label in [("x", "ascii"), ("界", "wide")]:
        for length in [599, 600, 601]:
            prefix = PREFIX + "removed 'old'; added "
            comparison = prefix + glyph * (length - len(prefix) - len("TAIL_ID")) + "TAIL_ID"
            result.append({"name": f"comparison-{label}-{length}", "route": "comparison", "path": "/tmp/ej7y.md",
                           "comparison": comparison, "expected_tail": "TAIL_I..." if length > 600 else "TAIL_ID"})
    result.extend([{"name": "typed-tree-omission", "route": "tree", "path": "/tmp/ej7y.md"},
                   {"name": "typed-details-omitted", "route": "details", "path": "/tmp/ej7y.md"}])
    for source in ["text", "raw"]:
        for count in [11, 12, 13, 25]:
            result.append({"name": f"plan-{source}-fallback-{count}", "route": "fallback", "source": source,
                           "count": count, "path": "/tmp/ej7y.md"})
    result.append({"name": "malformed-plan-fallback", "route": "malformed", "source": "text", "count": 13,
                   "path": "/tmp/ej7y.md"})
    for source in ["text", "raw"]:
        result.append({"name": f"ordinary-{source}-five-plus-marker", "route": "ordinary", "source": source,
                       "count": 25, "path": "/tmp/ej7y.md"})
    result.append({"name": "ordinary-diff-twenty-plus-marker", "route": "diff", "path": "/tmp/ej7y-diff.md"})
    for glyph, phase, width in [("x", "option", 11), ("界", "reason", 12)]:
        prefix = PREFIX + "removed 'old'; added "
        comparison = prefix + glyph * (600 - len(prefix) - len("TAIL_ID")) + "TAIL_ID"
        result.append({"name": f"narrow-{phase}-{width}", "route": "narrow", "phase": phase,
                       "path": None, "comparison": comparison, "glyph": glyph, "usable_width": width})
    return result


SPECIMENS = specimens()


def wire_title(index):
    prefix = "Owned body control" if SPECIMENS[index]["route"] in ["ordinary", "diff"] else "Update Workflow"
    return f"{prefix} {index:02d}"


def permission_spec(index, workspace):
    """Synthetic safe adaptation of retained KAS workflow-plan wire shapes."""
    spec = SPECIMENS[index]
    route = spec["route"]
    raw = {"workflowId": "wf_ej7y_owned", "action": "replace_remaining",
           "workflowRef": "generated://ej7y-owned", "remainingSteps": []}
    if spec["path"] is not None:
        raw["path"] = spec["path"]
    content = []
    typed = route not in ["ordinary", "diff"]
    projection = plan(omitted="steps" if route in ["fallback", "malformed"] else
                      "details" if route == "details" else None)
    if "comparison" in spec:
        content = [{"type": "content", "content": {"type": "text", "text":
                    "Steps to add after 'plan-editor':\n\n" + spec["comparison"]}}]
    elif route in ["fallback", "malformed", "ordinary"]:
        value = "\n".join(f"fallback {row:02d}" for row in range(1, spec["count"] + 1))
        if spec["source"] == "raw":
            raw["text"] = value
        else:
            content = [{"type": "content", "content": {"type": "text", "text": value}}]
        if route == "malformed":
            projection = plan()
            del projection["steps"][0]["agentName"]
    elif route == "diff":
        raw = {"path": spec["path"]}
        content = [{"type": "diff", "path": spec["path"], "oldText": "",
                    "newText": "\n".join(f"diff row {row:02d}" for row in range(1, 22))}]
    meta = {"kiro": {"toolId": "update_workflow", "workflowPlan": projection,
                     "consent": {"capability": "workflow", "resource": "replace_remaining",
                                 "askType": "implicit", "workspaceRoot": workspace}, "consentRound": 1}}
    call = {"toolCallId": f"ej7y-owned-{index}", "title": wire_title(index),
            "kind": "other", "status": "pending", "rawInput": raw}
    request_call = {"toolCallId": call["toolCallId"], "title": call["title"], "status": "pending"}
    if content:
        request_call["content"] = content
    params = {"sessionId": "sess_ej7y_owned", "toolCall": request_call,
              "options": [{"optionId": "accept", "name": "Allow", "kind": "allow_once"},
                          {"optionId": "reject", "name": "Deny", "kind": "reject_once"}]}
    if typed:
        params["_meta"] = meta
    return call, params


def journal(path, frame):
    with path.open("a") as file:
        file.write(json.dumps(frame, ensure_ascii=False) + "\n")


def agent():
    output = Path(os.environ["EJ7Y_SMOKE_OUTPUT"])
    session, prompt, sequence, incoming = "sess_ej7y_owned", None, 0, b""
    pending, emitted = {}, set()
    workspace = os.getcwd()

    def send(value):
        frame = {"jsonrpc": "2.0", **value}
        journal(output / "agent-wire.jsonl", frame)
        print(json.dumps(frame, ensure_ascii=False), flush=True)

    def update(value):
        send({"method": "session/update", "params": {"sessionId": session, "update": value}})

    def text(value):
        update({"sessionUpdate": "agent_message_chunk", "content": {"type": "text", "text": value}})

    while True:
        ready, _, _ = select.select([sys.stdin.fileno()], [], [], 0.02)
        if ready:
            chunk = os.read(sys.stdin.fileno(), 65536)
            if not chunk:
                return
            incoming += chunk
            while b"\n" in incoming:
                line, incoming = incoming.split(b"\n", 1)
                frame = json.loads(line)
                journal(output / "client-wire.jsonl", frame)
                method, ident = frame.get("method"), frame.get("id")
                if method == "initialize":
                    send({"id": ident, "result": {"protocolVersion": 1,
                          "agentCapabilities": {"loadSession": True, "_meta": {"kiro": {}}},
                          "agentInfo": {"name": "ej7y-owned-preview-peer", "version": "0.66.43"}, "authMethods": []}})
                elif method == "session/new":
                    send({"id": ident, "result": {"sessionId": session}})
                elif method == "session/prompt":
                    if prompt is not None:
                        raise AssertionError("overlapping prompt")
                    prompt = ident
                    text("EJ7Y_PEER_READY\n")
                elif method and ident is not None:
                    send({"id": ident, "result": {}})
                elif ident in pending:
                    index = pending.pop(ident)
                    update({"sessionUpdate": "tool_call_update", "toolCallId": f"ej7y-owned-{index}",
                            "status": "completed", "content": [{"type": "content", "content": {
                                "type": "text", "text": "Owned permission exchange only; no workflow operation dispatched."}}]})
                    text(f"\nEJ7Y_DONE_{index}\n")
        control_path = output / "control.json"
        if not control_path.exists():
            continue
        command = json.loads(control_path.read_text())
        if command["sequence"] <= sequence:
            continue
        sequence = command["sequence"]
        if command.get("finish"):
            if pending or len(emitted) != len(SPECIMENS) or prompt is None:
                raise AssertionError("finish before all manual decisions")
            update({"sessionUpdate": "session_info_update", "_meta": {"kiro": {"kind": "turn_end",
                    "stopReason": "end_turn", "turnEnd": {"stopReason": "end_turn"}}}})
            text("EJ7Y_ALL_DONE\n")
            send({"id": prompt, "result": {"stopReason": "end_turn"}})
            prompt = None
            continue
        if prompt is None:
            raise AssertionError("permission command without pending prompt")
        for index in command["cases"]:
            if index in emitted:
                raise AssertionError("duplicate specimen emission")
            emitted.add(index)
            call, params = permission_spec(index, workspace)
            update({"sessionUpdate": "tool_call", **call, "status": "in_progress"})
            update({"sessionUpdate": "tool_call_update", "toolCallId": call["toolCallId"],
                    "status": "pending", "rawInput": call["rawInput"]})
            ident = 8000 + index
            pending[ident] = index
            send({"id": ident, "method": "session/request_permission", "params": params})


class OwnedTui:
    def __init__(self, args, scratch, output):
        import pyte
        self.output, self.rows, self.columns = output, 40, 80
        self.screen = pyte.Screen(self.columns, self.rows)
        self.stream = pyte.Stream(self.screen)
        self.decoder = codecs.getincrementaldecoder("utf-8")("replace")
        self.raw = (output / "terminal.ansi").open("wb")
        self.raw_size, self.control_sequence, self.capture_sequence = 0, 0, 0
        node = shutil.which("node")
        if node is None:
            raise AssertionError("Node executable required by KAS interface")
        script = Path(__file__).resolve()
        server = scratch / "server.js"
        server.write_text("const {spawn}=require('node:child_process');"
                          f"const c=spawn({json.dumps(sys.executable)},[{json.dumps(str(script))},'agent'],{{stdio:'inherit'}});"
                          "c.on('exit',n=>process.exit(n??1));process.on('SIGTERM',()=>c.kill('SIGTERM'));")
        environment = os.environ.copy()
        for key in ["KIRO_AGENT_PATH", "KIRO_KAS_SERVER_PATH", "CYRIL_AGENT_LOCATION", "CYRIL_AGENT_HOST_OS"]:
            environment.pop(key, None)
        environment.update(TERM="xterm-256color", COLORTERM="truecolor", PATH=str(scratch / "bin"), SHELL="/bin/bash",
                           HOME=str(scratch / "home"), USERPROFILE=str(scratch / "home"),
                           XDG_CONFIG_HOME=str(scratch / "config"), XDG_DATA_HOME=str(scratch / "data"),
                           KIRO_AGENT_PATH=str(Path(node).resolve()), KIRO_KAS_SERVER_PATH=str(server),
                           EJ7Y_SMOKE_OUTPUT=str(output))
        self.master, slave = pty.openpty()
        fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", self.rows, self.columns, 0, 0))
        try:
            self.process = subprocess.Popen([args.binary, "--cwd", str(scratch / "ws"), "--agent-engine", "kas",
                                            "--prompt", "Display owned workflow approval fixtures; execute no operation"],
                                           stdin=slave, stdout=slave, stderr=slave, env=environment,
                                           cwd=scratch / "ws", start_new_session=True)
        finally:
            os.close(slave)

    def drain(self, seconds=0.10):
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            ready, _, _ = select.select([self.master], [], [], max(0, deadline - time.monotonic()))
            if not ready:
                return
            try:
                chunk = os.read(self.master, 65536)
            except OSError:
                return
            if not chunk:
                return
            self.raw.write(chunk)
            self.raw.flush()
            self.raw_size += len(chunk)
            self.stream.feed(self.decoder.decode(chunk))

    def visible(self):
        return "\n".join(self.screen.display)

    def wait(self, predicate, description, timeout=30):
        deadline = time.monotonic() + timeout
        while not predicate():
            if self.process.poll() is not None or time.monotonic() > deadline:
                raise AssertionError(f"Missing {description}; exit={self.process.poll()}\n{self.visible()}")
            self.drain()

    def send(self, data):
        os.write(self.master, data)

    def paste(self, text):
        self.send(b"\x1b[200~" + text.encode() + b"\x1b[201~")

    def key(self, name):
        self.send(KEYS[name])

    def resize(self, width, height):
        before = self.raw_size
        fcntl.ioctl(self.master, termios.TIOCSWINSZ, struct.pack("HHHH", height, width, 0, 0))
        self.columns, self.rows = width, height
        self.screen.resize(lines=height, columns=width)
        os.kill(self.process.pid, signal.SIGWINCH)
        self.wait(lambda: self.raw_size > before, f"redraw at {width}x{height}")
        self.drain()

    def wire(self, name):
        path = self.output / name
        if not path.exists():
            return []
        return [json.loads(line) for line in path.read_text().splitlines(keepends=True) if line.endswith("\n")]

    def responses(self, index):
        return [frame for frame in self.wire("client-wire.jsonl")
                if frame.get("id") == 8000 + index and "method" not in frame]

    def pending(self, *indices):
        for index in indices:
            if self.responses(index):
                raise AssertionError(f"navigation answered permission {8000 + index}: {self.responses(index)}")

    def command(self, **value):
        self.control_sequence += 1
        path = self.output / "control.tmp"
        path.write_text(json.dumps({"sequence": self.control_sequence, **value}))
        path.replace(self.output / "control.json")

    def input_draft(self):
        for y in range(self.rows):
            if self.screen.buffer[y][0].data != "┌":
                continue
            if ">" not in "".join(self.screen.buffer[y][x].data for x in range(min(8, self.columns))):
                continue
            rows = []
            for row in range(y + 1, self.rows):
                if self.screen.buffer[row][0].data != "│":
                    break
                rows.append("".join(self.screen.buffer[row][x].data for x in range(1, self.columns - 1)))
            return "".join(rows).replace("█", "").strip()
        return None

    def box(self):
        boxes = []
        for y in range(self.rows):
            for left in range(1, self.columns):
                if self.screen.buffer[y][left].data != "┌":
                    continue
                right = next((x for x in range(left + 1, self.columns) if self.screen.buffer[y][x].data == "┐"), None)
                if right is None:
                    continue
                raw_body, bottom = [], y + 1
                for row in range(y + 1, self.rows):
                    bottom = row
                    if self.screen.buffer[row][left].data != "│":
                        break
                    raw_body.append("".join(self.screen.buffer[row][x].data for x in range(left + 1, right)).rstrip())
                bottom_text = "".join(self.screen.buffer[bottom][x].data for x in range(left, right + 1))
                boxes.append({"top": y, "bottom": bottom, "left": left, "right": right,
                              "width": right - left + 1, "raw_body": raw_body, "bottom_text": bottom_text})
        return boxes[-1] if boxes else None

    def view(self):
        box = self.box()
        if box is None:
            return None
        body = [row[4:] for row in box["raw_body"] if row.startswith("    ") and row.strip()]
        statuses = [STATUS.search(row) for row in body]
        statuses = [match for match in statuses if match is not None]
        status = None
        if statuses:
            if len(statuses) != 1:
                raise AssertionError(f"multiple body status rows: {body}")
            start, end, total = map(int, statuses[0].groups())
            status = {"start": start, "end": end, "total": total, "visible": end - start + 1}
        content = [row for row in body if not row.lstrip().startswith("↑")]
        return {"box": box, "body": body, "content": content, "status": status}

    def capture(self, name, index, reason=False, bound=12, pinned=True):
        self.pending(index)
        view = self.view()
        if view is None:
            raise AssertionError("approval popup missing")
        spec = SPECIMENS[index]
        raw = view["box"]["raw_body"]
        if bound is not None and len(view["body"]) > bound:
            raise AssertionError(f"body budget {bound} exceeded INCLUDING status: {view}")
        if view["status"] is not None and len(view["content"]) != view["status"]["visible"]:
            raise AssertionError(f"rendered rows disagree with visible status: {view}")
        if pinned:
            if spec["path"] is not None and not any(spec["path"] in row for row in raw):
                raise AssertionError(f"pinned path missing: {view}")
            if not any(("█" in row) if reason else ("▸ Allow" in row or "▸ Deny" in row) for row in raw):
                raise AssertionError(f"pinned choice/editor missing: {view}")
        if self.input_draft() != DRAFT:
            raise AssertionError(f"chat draft overlaid or changed: {self.input_draft()!r}")
        self.capture_sequence += 1
        filename = f"{self.capture_sequence:03d}-{name}.txt"
        (self.output / filename).write_text(self.visible())
        observation = {"capture": filename, "case": spec["name"], "permission_id": 8000 + index,
                       "columns": self.columns, "rows": self.rows, "raw_byte_offset": self.raw_size,
                       "view": view, "input_draft": self.input_draft(), "permission_unanswered": True}
        journal(self.output / "observations.jsonl", observation)
        return view

    def status_start(self):
        view = self.view()
        return None if view is None or view["status"] is None else view["status"]["start"]

    def await_start(self, start):
        def ready():
            view = self.view()
            return view is not None and view["status"] is not None and view["status"]["start"] == start and \
                len(view["content"]) == view["status"]["visible"]
        self.wait(ready, f"preview first row {start}")

    def move(self, key, index, reason=False):
        before = self.capture(f"{SPECIMENS[index]['name']}-before-{key}", index, reason)
        window = before["status"]
        if window is None:
            raise AssertionError("navigation specimen must actually overflow")
        maximum = window["total"] - window["visible"] + 1
        current = window["start"]
        expected = {"pgup": max(1, current - window["visible"]),
                    "pgdn": min(maximum, current + window["visible"]),
                    "shift-up": max(1, current - 1), "shift-down": min(maximum, current + 1),
                    "shift-home": 1, "shift-end": maximum}[key]
        self.key(key)
        self.await_start(expected)
        return self.capture(f"{SPECIMENS[index]['name']}-after-{key}", index, reason)

    def box_has(self, text):
        box = self.box()
        return box is not None and any(text in row for row in box["raw_body"])

    def enter_reason(self, index, draft):
        self.key("down")
        self.wait(lambda: self.box_has("▸ Deny"), "selected RejectOnce")
        self.send(b"r")
        self.wait(lambda: self.box_has("Rejecting: Deny"), "reason-only chrome applied")
        self.paste(draft)
        ending = draft.split("\n")[-1] + "█"
        self.wait(lambda: self.box_has(ending), "actual reason draft text")
        self.pending(index)

    def answer(self, index, reason=None):
        if reason is None:
            self.key("down")
            self.wait(lambda: self.box_has("▸ Deny"), "manual RejectOnce")
        self.pending(index)
        self.send(b"\r")
        self.wait(lambda: bool(self.responses(index)), f"permission response {8000 + index}")
        replies = self.responses(index)
        if len(replies) != 1:
            raise AssertionError(f"duplicate permission response: {replies}")
        result = replies[0].get("result", {})
        if result.get("outcome") != {"outcome": "selected", "optionId": "reject"}:
            raise AssertionError(f"unexpected manual response: {replies[0]}")
        if result.get("_meta", {}).get("kiro", {}).get("rejectionReason") != reason:
            raise AssertionError(f"reason draft changed: {replies[0]}")
        return replies[0]

    def close(self, scratch):
        (self.output / "final-screen.txt").write_text(self.visible())
        if self.process.poll() is None:
            self.send(b"\x11")
            self.drain(0.3)
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(self.process.pid, signal.SIGTERM)
                self.process.wait(timeout=5)
        self.raw.close()
        os.close(self.master)
        for source, target in [(scratch / "home/.config/cyril/cyril.log", "cyril.log"),
                               (scratch / "bin/kiro-cli-argv.txt", "kiro-cli-argv.txt")]:
            if source.exists():
                shutil.copyfile(source, self.output / target)


def traverse(tui, index, reason=False):
    tui.move("shift-home", index, reason)
    seen, pages = {}, 0
    while True:
        view = tui.capture(f"{SPECIMENS[index]['name']}-page-{pages}", index, reason)
        window = view["status"]
        if window is None:
            for number, row in enumerate(view["content"], 1):
                seen[number] = row
            break
        for number, row in enumerate(view["content"], window["start"]):
            if number in seen and seen[number] != row:
                raise AssertionError(f"overlapping viewport row changed at {number}")
            seen[number] = row
        if window["end"] == window["total"]:
            break
        tui.move("pgdn", index, reason)
        pages += 1
        if pages > 300:
            raise AssertionError("preview navigation never reached its finite endpoint")
    comparison = SPECIMENS[index]["comparison"]
    retained = comparison[:600] + ("..." if len(comparison) > 600 else "")
    actual = compact("".join(seen[number] for number in sorted(seen)))
    if compact(retained) not in actual:
        raise AssertionError(f"full retained comparison is not reachable: {SPECIMENS[index]['name']}")
    if "expected_tail" in SPECIMENS[index] and compact(SPECIMENS[index]["expected_tail"]) not in actual:
        raise AssertionError("retained comparison tail absent")
    if len(comparison) > 600 and "TAIL_ID" in comparison and "TAIL_ID" in actual:
        raise AssertionError("comparison text beyond 600-code-point cap leaked")
    if "chg11" in comparison and ("chg11" not in actual or "chg13" in actual):
        raise AssertionError("retained/removed edit comparison ID boundary changed")
    return {"pages": pages + 1, "retained_characters": len(retained), "projected_rows_seen": len(seen)}


def main_navigation(tui):
    index = 0
    tui.resize(32, 24)
    tui.await_start(1)
    first = tui.capture("main-first-tree-omission", index)
    if not first["content"] or not first["content"][0].strip().startswith("...") or "more lines" not in first["content"][0]:
        raise AssertionError("comparison must shrink nonempty tree to an explicit FIRST-row omission marker")
    coverage = traverse(tui, index)
    tui.move("pgup", index)
    tui.move("shift-home", index)
    tui.move("shift-down", index)
    tui.move("shift-up", index)
    tui.move("shift-end", index)
    tui.move("shift-home", index)
    tui.move("shift-down", index)
    # All ineligible probes point downward: a broken positive scroll cannot
    # cancel itself out. The following exact Shift+Down is the visible fence.
    for key in ["ctrl-shift-down", "alt-shift-down", "shift-pgdn", "ctrl-pgdn"]:
        tui.key(key)
    tui.key("shift-down")
    tui.await_start(3)
    tui.capture("exact-modifier-fence", index)
    for key, label in [("down", "▸ Deny"), ("up", "▸ Allow")]:
        tui.key(key)
        tui.wait(lambda: tui.box() is not None and any(label in row for row in tui.box()["raw_body"]), "ordinary option arrows")
        if tui.status_start() != 3:
            raise AssertionError("ordinary selection arrows stole preview navigation")
    # Both resize paths must move on the FIRST key after widening.
    for movement in ["shift-up", "pgup"]:
        tui.resize(32, 18)
        tui.move("shift-end", index)
        tui.resize(80, 40)
        wide = tui.capture(f"resize-render-clamp-before-{movement}", index)
        if wide["status"] is None or wide["status"]["end"] != wide["status"]["total"]:
            raise AssertionError("resize rendering did not clamp to the new endpoint")
        tui.move(movement, index)
    # A one-content-row viewport uses a border hint, not a thirteenth body row.
    tui.resize(40, 40)
    tui.move("shift-home", index)
    found = False
    for height in range(10, 20):
        tui.resize(40, height)
        view = tui.view()
        if view is not None and len(view["body"]) == 1 and "PgUp/PgDn preview" in view["box"]["bottom_text"]:
            tui.capture("single-body-row-border-affordance", index)
            before = view["content"]
            tui.key("pgdn")
            tui.wait(lambda: tui.view() is not None and tui.view()["content"] != before, "single-row page movement")
            tui.capture("single-body-row-page-advanced", index)
            found = True
            break
    if not found:
        raise AssertionError("never observed the approved one-row border navigation affordance")
    tui.resize(40, 40)
    tui.move("shift-home", index)
    for _ in range(3):
        tui.move("shift-down", index)
    before = tui.status_start()
    tui.enter_reason(index, "first\nsecond")
    if tui.status_start() != before:
        raise AssertionError("request-local preview position lost entering reason")
    tui.capture("reason-enter-retains-position-and-draft", index, True)
    for key, marker in [("home", "█second"), ("end", "second█"), ("up", "first█"),
                        ("down", "secon█d"), ("end", "second█")]:
        tui.key(key)
        tui.wait(lambda: tui.box() is not None and any(marker in row for row in tui.box()["raw_body"]), "ordinary reason editor cursor movement")
        if tui.status_start() != before:
            raise AssertionError("ordinary editor movement stole preview navigation")
    for movement in ["shift-down", "shift-up", "pgdn", "pgup", "shift-end", "shift-home"]:
        tui.move(movement, index, True)
        if "second█" not in tui.visible():
            raise AssertionError("dedicated preview keys moved or changed reason editor")
    reason_coverage = traverse(tui, index, True)
    tui.move("shift-end", index, True)
    tui.pending(0, 1)
    first_response = tui.answer(index, "first\nsecond")
    # The second request was already queued while the first was scrolled.
    tui.wait(lambda: tui.box() is not None and any(SPECIMENS[1]["path"] in row for row in tui.box()["raw_body"]), "second queued request promoted")
    tui.await_start(1)
    tui.capture("queue-promotion-position-zero", 1)
    tui.key("down")
    tui.wait(lambda: "▸ Deny" in tui.visible(), "second RejectOnce")
    tui.send(b"r")
    tui.wait(lambda: tui.box_has("Rejecting: Deny"), "promoted request reason-only chrome applied")
    raw = tui.box()["raw_body"]
    if not any(row.strip() == "█" for row in raw) or any("first" in row or "second" in row for row in raw):
        raise AssertionError("reason draft leaked into promoted request")
    if tui.status_start() != 1:
        raise AssertionError("queued request preview offset leaked")
    tui.paste("queue-only")
    tui.wait(lambda: "queue-only█" in tui.visible(), "fresh second reason draft")
    tui.capture("queue-promotion-fresh-editor", 1, True)
    second_response = tui.answer(1, "queue-only")
    return [{"case": SPECIMENS[0]["name"], "response": first_response, "option_coverage": coverage,
             "reason_coverage": reason_coverage}, {"case": SPECIMENS[1]["name"], "response": second_response}]


def narrow_navigation(tui, index):
    spec = SPECIMENS[index]
    is_reason = spec["phase"] == "reason"
    draft = "why" if is_reason else None
    if is_reason:
        tui.enter_reason(index, draft)
    for width in range(4, 11):
        tui.resize(80, 40)
        tui.move("shift-home", index, is_reason)
        tui.resize(width, 40)
        tui.key("pgdn")
        tui.key("shift-end")
        tui.drain()
        # Widening exposes any incorrectly retained hidden-width offset.
        tui.resize(80, 40)
        tui.await_start(1)
        tui.capture(f"no-text-width-{width}-offset-remains-zero", index, is_reason)
    tui.resize(spec["usable_width"], 40)
    tui.key("shift-end")
    tui.wait(lambda: tui.view() is not None and "TAIL_ID" in compact("".join(tui.view()["content"])), "tail reachable at narrow usable content width")
    narrow = tui.capture("narrow-positive-tail-and-glyph", index, is_reason, pinned=False)
    if spec["glyph"] not in compact("".join(narrow["content"])):
        raise AssertionError("retained narrow comparison glyph was clipped")
    tui.resize(80, 40)
    tui.capture("narrow-restored-before-manual-decision", index, is_reason)
    return tui.answer(index, draft)


def smoke(args):
    binary = Path(args.binary).resolve(strict=True)
    repository = Path(args.repository).resolve(strict=True)
    with binary.open("rb") as file:
        digest = hashlib.file_digest(file, "sha256").hexdigest()
    if digest != args.expected_sha256:
        raise AssertionError(f"binary identity mismatch: {digest}")
    args.binary = str(binary)
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(Path(__file__).resolve(), output / "harness.py")
    (output / "specimens.json").write_text(json.dumps(SPECIMENS, ensure_ascii=False, indent=2))
    results = []
    receipt = {"result": "FAIL", "binary": str(binary), "binary_sha256": digest,
               "engine": "kas", "peer": "owned ACP v1 workflow-plan fixture", "cases": results,
               "scope": "actual process/permission conversion/navigation/wire/decoded text; no ShellCommand",
               "limitations": "Not live KAS or native glyph fidelity. Exhaustive scalar/width/modifier/later-phase regression obligations remain with parent gates.",
               "contract": [".cyril-ej7y/design.md:C1-C5", ".cyril-ej7y/plan.md:32"],
               "fixture_provenance": ["crates/cyril-core/tests/fixtures/kas_permission/workflow-plan-2.32.0.json",
                                      "experiments/conductor-spike/audit-2.32.0/live/kas-lead-wfplan-2.32.0.jsonl:89,92,94",
                                      "crates/cyril/src/app.rs:ej7y_comparison"],
               "safety": "Synthetic safe adaptation of captured shapes; only manual RejectOnce; no operation dispatched, fs/terminal callbacks, real account or persistent grant"}
    with tempfile.TemporaryDirectory(prefix="cyril-ej7y-owned-") as name:
        scratch = Path(name)
        for child in ["bin", "home", "config", "data", "ws"]:
            (scratch / child).mkdir()
        fixture = repository / "crates/cyril-core/tests/fixtures/fake-kiro-cli.sh"
        if not fixture.is_file():
            raise AssertionError("owned auth fixture missing")
        (scratch / "bin/kiro-cli").symlink_to(fixture)
        tui = OwnedTui(args, scratch, output)
        try:
            tui.wait(lambda: "EJ7Y_PEER_READY" in tui.visible(), "pending owned prompt")
            tui.paste(DRAFT)
            tui.wait(lambda: tui.input_draft() == DRAFT, "initial chat draft")
            tui.command(cases=[0, 1])
            tui.wait(lambda: "Permission Required" in tui.visible() and tui.status_start() == 1
                     and tui.box_has(wire_title(0)), "first identifiable request rendered")
            tui.wait(lambda: sum(frame.get("method") == "session/request_permission"
                                for frame in tui.wire("agent-wire.jsonl")) == 2,
                     "both genuine permission requests emitted before navigation")
            results.extend(main_navigation(tui))
            for index, spec in enumerate(SPECIMENS[2:], 2):
                tui.resize(80, 48)
                tui.command(cases=[index])
                tui.wait(lambda: "Permission Required" in tui.visible() and tui.box_has(wire_title(index)),
                         f"identified pending request {8000 + index}: {spec['name']}")
                route = spec["route"]
                tui.capture(f"{spec['name']}-initial", index, bound=21 if route == "diff" else 12)
                if route == "comparison":
                    tui.resize(40, 40)
                    first = tui.capture(f"{spec['name']}-tree-marker", index)
                    if not first["content"] or not first["content"][0].strip().startswith("..."):
                        raise AssertionError("nonempty typed tree silently vanished before comparison")
                    coverage = traverse(tui, index)
                    response = tui.answer(index)
                    results.append({"case": spec["name"], "coverage": coverage, "response": response})
                elif route == "narrow":
                    response = narrow_navigation(tui, index)
                    results.append({"case": spec["name"], "response": response, "no_text_widths": list(range(4, 11)),
                                    "usable_width": spec["usable_width"]})
                else:
                    view = tui.view()
                    if view is None:
                        raise AssertionError("body-control popup disappeared before its decision")
                    content = view["content"]
                    if route in ["fallback", "malformed", "ordinary"]:
                        kept = min(spec["count"], 5 if route == "ordinary" else 12)
                        omitted = 0
                        if spec["count"] > kept:
                            if route != "ordinary":
                                kept -= 1
                            omitted = spec["count"] - kept
                        actual = [row.strip() for row in content if row.strip().startswith("fallback ")]
                        expected = [f"fallback {row:02d}" for row in range(1, kept + 1)]
                        if actual != expected:
                            raise AssertionError(f"wrong content row accounting: {actual} != {expected}")
                        markers = [row.strip() for row in content if row.strip().startswith("...")]
                        expected_markers = [f"...{omitted} more lines"] if omitted else []
                        if markers != expected_markers or len(content) != kept + bool(omitted):
                            raise AssertionError(f"omission marker displaced/counts wrong row: {content}")
                    elif route == "tree":
                        if len(content) != 12 or not content[-1].strip().startswith("...") or "more lines" not in content[-1]:
                            raise AssertionError(f"typed tree omission is not explicit within twelve rows: {content}")
                    elif route == "details":
                        if not any("step details left out to fit the plan" in row for row in content):
                            raise AssertionError("typed detail omission marker missing")
                    elif route == "diff":
                        actual = [row for row in content if "diff row " in row]
                        if len(actual) != 20 or "diff row 20" not in actual[-1] or any("diff row 21" in row for row in actual):
                            raise AssertionError("ordinary Diff must retain its separate twenty-line bound")
                        if len(content) != 21 or not content[-1].strip().startswith("..."):
                            raise AssertionError("ordinary Diff omission marker missing")
                    response = tui.answer(index)
                    results.append({"case": spec["name"], "body_rows": len(content), "response": response})
                tui.wait(lambda: f"EJ7Y_DONE_{index}" in tui.visible(), "owned peer consumed manual response")
                tui.wait(lambda: tui.input_draft() == DRAFT, "chat input retained after decision")
            tui.command(finish=True)
            tui.wait(lambda: "EJ7Y_ALL_DONE" in tui.visible(), "all fixture exchanges complete")
            requests = [frame for frame in tui.wire("agent-wire.jsonl") if frame.get("method") == "session/request_permission"]
            if len(requests) != len(SPECIMENS) or len(results) != len(SPECIMENS):
                raise AssertionError("missing fixture request/decision")
            forbidden = [frame for frame in tui.wire("agent-wire.jsonl")
                         if frame.get("method", "").startswith(("fs/", "terminal/", "_kiro/auth/"))]
            if forbidden:
                raise AssertionError(f"forbidden callbacks: {forbidden}")
            receipt.update(result="PASS", permission_requests=len(requests), permission_responses=len(results),
                           chat_draft_preserved=DRAFT)
        except Exception as error:
            receipt["error"] = str(error)
            raise
        finally:
            tui.close(scratch)
            (output / "result.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2))
        print(json.dumps(receipt, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    if sys.argv[1:] == ["agent"]:
        agent()
    else:
        parser = argparse.ArgumentParser(description=__doc__)
        parser.add_argument("--binary", required=True)
        parser.add_argument("--expected-sha256", required=True)
        parser.add_argument("--repository", required=True)
        parser.add_argument("--output", required=True, help="fresh owned evidence directory")
        smoke(parser.parse_args())
