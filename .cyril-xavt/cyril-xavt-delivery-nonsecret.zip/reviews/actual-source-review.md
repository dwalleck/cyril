# cyril-xavt independent source-review receipt

## Verdict

- Reviewer: ReviewShellApproval.
- Overall correctness: **correct**.
- Confidence: **0.98**.
- Actionable behavioral findings remaining: **none**.
- Review mode: source only; no files in the delivery tree were edited and no builds, tests, linters, formatters or live executions were run by this reviewer.

This is the fresh review of the actual `fix/cyril-xavt` delivery delta against published EJ base `9400e7c8ddd53776f6fd8b4d28d4c7fc69e45ab4` (PR190), not an approval inferred from the earlier combined implementation. The production and behavioral-regression scope is the following eleven repository-relative paths:

1. `crates/cyril-core/src/protocol/bridge/tests/current_runtime_contract/always_allow.rs`
2. `crates/cyril-core/src/protocol/bridge/tests/harness.rs`
3. `crates/cyril-core/src/protocol/convert/kas.rs`
4. `crates/cyril-core/src/protocol/domain_mediator/mod.rs`
5. `crates/cyril-core/src/types/mod.rs`
6. `crates/cyril-core/src/types/tool_call.rs`
7. `crates/cyril-core/tests/fixtures/kas_permission/shell-preview-2.32.0.json`
8. `crates/cyril-ui/src/traits.rs`
9. `crates/cyril-ui/src/widgets/approval.rs`
10. `crates/cyril-ui/src/widgets/workflow_plan.rs`
11. `crates/cyril/src/app.rs`

The four formatting-context-rejected approval-widget hunks reconstructed on the published EJ file were explicitly inspected: `Preview::new`, `Preview::body_window`, `Preview::into_lines`, and `OptionPage::selection_shown_with_path`. This receipt does not independently attest a whole-tree hash, a gate-time source manifest, subsequent documentation edits, or a published commit. Parent-owned final identity manifests must establish the exact final artifact linkage; the review remains applicable across formatting-only changes and the bounded F3 correction below, not arbitrary later semantic changes.

## Reviewed behavior and boundary evidence

- KAS shell classification is attached only after the existing session-aware permission-ledger join. Explicit `run_command` metadata or the absent-tool-ID execute-plus-nonblank-command shape supplies the projection; explicit other/malformed tool IDs are not rescued by execute kind.
- Commands are not guessed from titles or consent resources. Cwd is taken only from a supplied string raw `cwd`; workspace roots and terminal calls are not display fallbacks. Typed command/cwd bytes are preserved; UI sanitization does not mutate them.
- The private optional payload is `Option<Box<ShellCommand>>`; the moving builder and borrowed getter remain coherent with all consuming boundaries. Omitted raw-input updates preserve context, whereas supplied replacement raw input clears or replaces stale projection. There is no replay-message boxing workaround in this delta.
- `TrackedToolCall::preview_body` explicitly routes typed shell content before generic diff/content/raw-text fallback, and the approval widget explicitly consumes that variant. The actual approval installation path retains the supplied typed tool call rather than reconstructing it from transcript text.
- Shell command/cwd counting, wrapping, rendering and visible-command checks share safe grapheme widths. Only viewport rows are materialized. Body paging is bounded to twelve rows including scroll status, and scroll remains request-local with the inherited option/reason-editor routing.
- The reconstructed path/window/render hunks use the same inherited fitting predicate and path budget. Non-shell paths and line bodies retain the inherited behavior. The selected option or reason editor and meaningful command text must be drawn before answering; cwd-only or clipped/hidden command views do not confer authority.
- Existing approval ownership, key priority, AllowAlways, consent and grant semantics are unchanged. Existing typed workflow-plan, path, and text-only preview behavior is preserved.
- Actual App regressions render through `App::draw_frame`, route keys through `handle_key`, and inspect delivered oneshot permission responses. Whole one-character commands, multi-size confirmation, reachable pipeline stages/cwd, preserved chat/editor/selection context and cwd-only refusal are covered in source. Literal terminal-cell FE0F regressions cover command and cwd tails without deriving their expected quote location from the production wrapper.

## F3 fixture-fidelity correction

The original fresh actual-X review found no behavioral correctness issue, but separately noted one inaccurate retained fixture field. In `crates/cyril-core/tests/fixtures/kas_permission/shell-preview-2.32.0.json`, the exact corrected JSON pointer is:

`/without_cwd/permission/_meta/kiro/consent/triggeringResource`

The cited original permission capture, `experiments/conductor-spike/audit-2.32.0/live/kas-lead-interrupt-sig15-2.32.0.jsonl:56`, contains the literal **`echo SLEPT`**. The fixture had instead used `sleep 45 && echo SLEPT`. Direct source inspection established the discrepancy, and a subsequent direct read of the actual fixture confirms the field now reads `echo SLEPT`. The actual raw command, metadata command and consent resource remain `sleep 45 && echo SLEPT`.

This single-field correction restores capture fidelity and is explicitly covered by this review disposition. It does not change production code, shell preview input, test assertions, or the exercised AllowOnce response, and introduces no new permission behavior. It was not a behavioral blocker and does not invalidate the correct/confidence0.98 verdict. The historical approved patch remains historical input, not a byte-identical copy of the corrected fixture.

The bridge fixture deliberately injects both retained tool updates before permission delivery. Those tests exercise the final/repeated-approval snapshot join, not a chronological replay of every cited capture event.

## Prior combined-source repair disposition

The initial combined-source review was **incorrect** because of two accepted findings:

- **F1:** a fixed two-glyph confirmation threshold rejected fully drawn valid one-character commands such as `:` and `w`, including Allow and rejection-reason submission.
- **F2:** summing Unicode scalar widths rather than rendered grapheme widths made FE0F command/cwd closing quotes unreachable at a row boundary.

After the authorized repairs, an independent source rereview returned **correct**, confidence **0.98**, with no new findings. F1 now uses the initial count pass's meaningful-command-grapheme total capped at two: a complete one-meaningful-grapheme command can answer, while longer commands still require two actually visible unclipped meaningful graphemes. F2 now uses the shared borrowed safe-grapheme segmentation for both command and cwd. The compact optional shell payload replaced the interim replay boxing, which was retired together with its constructors and consuming dereferences. The fresh actual-delivery review confirms that these repaired behaviors and regression tests are present on the published-EJ reconstruction.

Parent-reported historical RED/GREEN and combined repository gates are supporting chronology, not actual-delivery gate receipts and not executions performed by this reviewer.

## Qualification limits

The final repository gate receipt and the source-qualified actual-delivery controlled captured-wire RejectOnce proof belong to the parent and evidence owners. This reviewer did not perform or independently validate those runtime executions. The original real-KAS execution used the historical combined binary; its complete-command-before-Allow and successful execution-wire observations must not be relabeled as a final-model-turn, rendered-stdout, or actual-delivery-binary execution proof. The actual-delivery controlled RejectOnce supplement is separate and does not execute the captured command.

This receipt records review scope, source conclusions and F1/F2/F3 dispositions only. It contains no credentials, private HOME, compiled binary, or raw session transcript.
