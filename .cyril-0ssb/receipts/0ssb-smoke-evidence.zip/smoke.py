#!/usr/bin/env python3
"""Actual current-Cyril PTY smoke, restricted to owned files and synthetic peers."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import pty
import select
import signal
import sqlite3
import struct
import subprocess
import sys
import tempfile
import termios
import time


def agent():
    out = Path(os.environ['SMOKE_RECEIPTS'])
    sid = 'sess_root_smoke'
    prompt_id = None
    callbacks = {}
    (out / 'selected-server.txt').write_text(str(Path(__file__).absolute()))

    def send(message):
        frame = {'jsonrpc': '2.0', **message}
        with (out / 'agent-to-cyril.jsonl').open('a') as log:
            log.write(json.dumps(frame) + '\n')
        print(json.dumps(frame), flush=True)

    def update(body):
        send({'method': 'session/update', 'params': {'sessionId': sid, 'update': body}})

    for line in sys.stdin:
        message = json.loads(line)
        with (out / 'cyril-to-agent.jsonl').open('a') as log:
            log.write(json.dumps(message) + '\n')
        method = message.get('method')
        ident = message.get('id')
        if method == 'initialize':
            send({'id': ident, 'result': {'protocolVersion': 1,
                 'agentCapabilities': {'_meta': {'kiro': {}}},
                 'agentInfo': {'name': 'owned-root-smoke', 'version': '0.66.8'},
                 'authMethods': []}})
        elif method == 'session/new':
            send({'id': ident, 'result': {'sessionId': sid}})
        elif method == 'session/prompt':
            prompt_id = ident
            send({'id': 'smoke-auth', 'method': '_kiro/auth/getAccessToken', 'params': {}})
            send({'id': 'smoke-hooks', 'method': '_kiro/hooks/list', 'params': {'trigger': 'agentStop'}})
        elif method is None and ident in ('smoke-auth', 'smoke-hooks'):
            callbacks[ident] = message
            (out / f'{ident}.json').write_text(json.dumps(message, indent=2))
            if len(callbacks) == 2:
                update({'sessionUpdate': 'agent_message_chunk',
                        'content': {'type': 'text', 'text': 'ROOT_SMOKE_CALLBACKS_RECEIVED'}})
                update({'sessionUpdate': 'session_info_update', '_meta': {'kiro': {
                    'kind': 'turn_end', 'stopReason': 'end_turn',
                    'turnEnd': {'stopReason': 'end_turn'}}}})
                send({'id': prompt_id, 'result': {'stopReason': 'end_turn'}})
                (out / 'protocol-complete').write_text('complete\n')
        elif method is not None and ident is not None:
            send({'id': ident, 'error': {'code': -32601, 'message': 'Outside owned smoke protocol'}})


def put(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(data)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def seed_store(path, token, label):
    path.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(path) as db:
        db.execute('CREATE TABLE auth_kv (key TEXT PRIMARY KEY, value TEXT)')
        db.execute('CREATE TABLE state (key TEXT PRIMARY KEY, value TEXT)')
        db.execute('INSERT INTO auth_kv VALUES (?, ?)', ('kirocli:odic:token', json.dumps({
            'access_token': token, 'expires_at': '2099-01-01T00:00:00Z'})))
        db.execute('INSERT INTO state VALUES (?, ?)', ('api.codewhisperer.profile',
            json.dumps({'arn': 'arn:aws:codewhisperer:us-east-1:1:profile/' + label})))


def smoke(binary, case):
    root = Path(tempfile.mkdtemp(prefix='cyril-root-binary-' + case + '-'))
    out = root / 'receipts'
    out.mkdir()
    home, workspace, profile = root / 'home', root / 'workspace', root / 'profile ü'
    for item in (home, workspace, root / 'bin', root / 'runtime', root / 'xdg-data',
                 root / 'xdg-config', root / 'xdg-cache'):
        item.mkdir(parents=True, exist_ok=True)
    put(home / '.config/cyril/config.toml',
        '[agent]\nengine = "kas"\nkas_spawn = "free"\nkas_hooks = "host"\n\n[memory]\nenabled = false\n')
    for directory, label, enabled in ((profile, 'relocated', True),
                                     (home / '.kiro', 'default', False),
                                     (root, 'ancestor', True)):
        put(directory / 'settings/cli.json', json.dumps({
            'chat.enableWorkflows': enabled, 'chat.enableThinking': not enabled}))
        put(directory / 'hooks/profile.json', json.dumps({'version': 'v1', 'hooks': [{
            'name': label, 'trigger': 'Stop',
            'action': {'type': 'command', 'command': 'printf ' + label}}]}))
    put(workspace / '.kiro/hooks/workspace.json', json.dumps({'version': 'v1', 'hooks': [{
        'name': 'workspace', 'trigger': 'Stop',
        'action': {'type': 'command', 'command': 'printf workspace'}}]}))
    helper = root / 'bin/kiro-cli'
    put(helper, '#!/bin/sh\nprintf "%s\\n" "$@" >> "${0%/*}/kiro-cli-argv.txt"\n'
        'if [ "$1" = "--version" ]; then printf "kiro-cli 2.24.0\\n"; exit 0; fi\n'
        'if [ "$1" = "chat" ] && [ "$2" = "_" ] && [ "$3" = "get-kas-token" ]; then\n' +
        ('printf "%s\\n" "error: unrecognized subcommand \'get-kas-token\'" >&2; exit 2\n'
         if case == 'stored-fallback' else
         'printf \'%s\\n\' \'{"kind":"getKasToken","data":{"accessToken":"AT-fake","expiresAt":"2099-01-01T00:00:00Z","profileArn":"arn:aws:codewhisperer:us-east-1:1:profile/FAKE","provider":"Enterprise"}}\'; exit 0\n') +
        'fi\nexit 3\n')
    helper.chmod(0o700)
    node = root / 'bin/node'
    put(node, '#!/bin/sh\nprintf "%s\\000" "$@" >> "$SMOKE_RECEIPTS/node.argv"\n'
        '[ "$1" = "--experimental-wasm-modules" ] || exit 91\nshift\n'
        'exec ' + json.dumps(sys.executable) + ' "$@" agent\n')
    node.chmod(0o700)
    launch_cwd = root / 'launch' if case == 'relative-assets-different-cwd' else workspace
    launch_cwd.mkdir(exist_ok=True)
    assets = (launch_cwd / 'relative assets' if case == 'relative-assets-different-cwd'
              else root / (' assets ' if case == 'padded-assets' else 'assets'))
    server_rel = Path('node_modules/@kiro/agent/dist/server/acp-server.js')
    version = '2.24.0-' + 'a' * 64
    code = Path(__file__).read_text()
    for bundle in (assets, root / 'xdg-data/kiro-cli', root / 'assets'):
        for v in (version, '9.0.0-' + 'b' * 64):
            put(bundle / 'kas' / v / server_rel, code)
    expected_server = assets / 'kas' / version / server_rel
    db_hashes = {}
    if case == 'stored-fallback':
        for store, token, label in ((root / 'xdg-data/kiro-cli/data.sqlite3', 'AT-native-default', 'NATIVE'),
                                    (assets / 'data.sqlite3', 'AT-wrong-asset-store', 'WRONG')):
            seed_store(store, token, label)
            db_hashes[str(store)] = digest(store)
    env = {'HOME': str(home), 'USERPROFILE': str(home), 'PATH': str(root / 'bin'),
           'SHELL': '/bin/sh', 'TERM': 'xterm-256color', 'COLORTERM': 'truecolor',
           'XDG_DATA_HOME': str(root / 'xdg-data'), 'XDG_CONFIG_HOME': str(root / 'xdg-config'),
           'XDG_CACHE_HOME': str(root / 'xdg-cache'), 'XDG_RUNTIME_DIR': str(root / 'runtime'),
           'KIRO_HOME': str(root) if case == 'invalid-ancestor' else ' \t' + str(profile) + ' \u2003',
           'KIRO_DATA_DIR': str(assets.relative_to(launch_cwd)) if case == 'relative-assets-different-cwd' else str(assets),
           'SMOKE_RECEIPTS': str(out)}
    args = [str(binary), '--cwd', str(workspace), '--agent-engine', 'kas', '--prompt', 'Owned root smoke']
    put(out / 'launch.json', json.dumps({'args': args, 'cwd': str(launch_cwd), 'env': env,
                                        'binary_sha256': digest(binary)}, indent=2))
    master, slave = pty.openpty()
    fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack('HHHH', 32, 100, 0, 0))
    process = subprocess.Popen(args, cwd=launch_cwd, env=env, stdin=slave, stdout=slave,
                               stderr=slave, start_new_session=True)
    os.close(slave)
    raw = bytearray()

    def drain(seconds):
        until = time.monotonic() + seconds
        while time.monotonic() < until:
            ready, _, _ = select.select([master], [], [], max(0, until - time.monotonic()))
            if not ready:
                return
            try:
                data = os.read(master, 65536)
            except OSError:
                return
            if not data:
                return
            raw.extend(data)

    try:
        deadline = time.monotonic() + 30
        while not (out / 'protocol-complete').is_file() and time.monotonic() < deadline:
            drain(0.1)
            if process.poll() is not None:
                break
        drain(0.8)
        assert (out / 'protocol-complete').is_file(), 'protocol did not complete: ' + str(out)
        assert b'ROOT_SMOKE_CALLBACKS_RECEIVED' in raw, 'rendered marker absent'
        wire = [json.loads(line) for line in (out / 'cyril-to-agent.jsonl').read_text().splitlines()]
        methods = {message.get('method'): message for message in wire if message.get('method')}
        assert {'initialize', 'session/new', 'session/prompt'} <= methods.keys()
        expected_enabled = case != 'invalid-ancestor'
        settings = methods['initialize']['params']['clientCapabilities']['_meta']['kiro']['settings']
        assert settings['workflows']['enabled'] is expected_enabled, settings
        assert settings['goal']['enabled'] is expected_enabled, settings
        assert settings['thinking']['enabled'] is not expected_enabled, settings
        session_settings = methods['session/new']['params']['_meta']['kiro']['settings']
        assert session_settings == settings, (settings, session_settings)
        assert (out / 'selected-server.txt').read_text() == str(expected_server)
        argv = (out / 'node.argv').read_bytes().split(b'\x00')
        assert argv[:4] == [b'--experimental-wasm-modules', os.fsencode(expected_server),
                            b'--transport=stdio', b'--auth=acp-callback'], argv
        hooks_reply = json.loads((out / 'smoke-hooks.json').read_text())
        assert 'error' not in hooks_reply, hooks_reply
        hooks = sorted(hook['id'] for hook in hooks_reply['result']['hooks'])
        assert hooks == ['profile:' + ('default' if case == 'invalid-ancestor' else 'relocated'),
                         'workspace:workspace'], hooks
        auth = json.loads((out / 'smoke-auth.json').read_text())
        assert 'error' not in auth, auth
        expected_token = 'AT-native-default' if case == 'stored-fallback' else 'AT-fake'
        assert auth['result']['accessToken'] == expected_token, auth
        helper_argv = (root / 'bin/kiro-cli-argv.txt').read_text()
        expected_calls = 1 if case == 'stored-fallback' else 2
        assert '--version\n' in helper_argv and helper_argv.count('get-kas-token\n') == expected_calls, helper_argv
        for store, before in db_hashes.items():
            assert digest(Path(store)) == before, 'owned store changed: ' + store
        if case == 'invalid-ancestor':
            log = (home / '.config/cyril/cyril.log').read_text()
            assert 'ignoring KIRO_HOME' in log and 'contains-home' in log
        receipt = {'case': case, 'result': 'PASS', 'root': str(root),
                   'binary': str(binary), 'binary_sha256': digest(binary),
                   'selected_server': str(expected_server), 'workflows': expected_enabled,
                   'hooks': hooks, 'auth_token': expected_token, 'stores_unchanged': db_hashes,
                   'limits': 'Linux PTY owned-peer smoke only; not real KAS/backend login, native Windows/macOS, trust persistence or sidecar enrichment.'}
        assert process.poll() is None, 'Cyril exited before graceful quit'
        os.write(master, b'\x11')
        drain(0.5)
        process.wait(timeout=5)
        assert process.returncode == 0, 'Cyril failed graceful quit: ' + str(process.returncode)
        receipt['exit_code'] = process.returncode
    finally:
        if process.poll() is None:
            os.write(master, b'\x11')
            drain(0.5)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGTERM)
                process.wait(timeout=5)
        drain(0.2)
        (out / 'terminal.ansi').write_bytes(raw)
        (out / 'exit-code.txt').write_text(str(process.returncode))
        os.close(master)
    put(out / 'receipt.json', json.dumps(receipt, indent=2))
    print(json.dumps(receipt), flush=True)


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[-1] == 'agent':
        agent()
    elif len(sys.argv) == 2:
        binary = Path(sys.argv[1]).resolve(strict=True)
        for case in ('trimmed-profile', 'invalid-ancestor', 'padded-assets',
                     'relative-assets-different-cwd', 'stored-fallback'):
            smoke(binary, case)
    else:
        raise SystemExit('usage: smoke.py /absolute/current/cyril')
