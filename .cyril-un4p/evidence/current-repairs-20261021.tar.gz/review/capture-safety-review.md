# PR188 current capture relocation — scoped source review

## Findings

**No provable patch-introduced bug found** in the scoped capture/global-installation mechanisms. This is a source-and-diff conclusion, not runtime qualification or proof of the earlier empty capture's cause.

Reviewed the working-tree diff against HEAD for `crates/cyril-core/src/test_support.rs` and `crates/cyril/src/app.rs`. The diff moves the existing App `AlwaysInterested` implementation unchanged into core, replaces App's private `OnceLock` installation with shared `LazyLock`, and forces that initializer before the existing capture mutex. App's first-installer-wins `Err`/DEBUG path is retained, not newly invented. App still installs its actual writer subscriber thread-locally (`crates/cyril/src/app.rs:8708-8724`); shared initialization is `crates/cyril-core/src/test_support.rs:14-46`, moved subscriber `:61-88`.

## Mechanism conclusions

- **Global conflict:** the shared initializer makes one installation attempt, does not replace an existing global, and retains the existing error path (`test_support.rs:15-19`). No competing global installer is called by the inventoried capture tests. The production logger is reachable from executable `main`, not these test paths (`crates/cyril/src/main.rs:51,280-300,314-390`). Merely enabling `test-support` does not initialize the static: the force is inside `tracing_capture_lock` (`test_support.rs:28-30`; module gate `crates/cyril-core/src/lib.rs:18-21`). No concrete new global-init conflict was found.
- **Deadlock:** initialization precedes capture-mutex acquisition; `AlwaysInterested` callbacks do not acquire that mutex, capture buffers, or call the capture helpers (`test_support.rs:28-32,63-88`). Actual capture dispatchers are constructed after locking and dropped/restored within the held guard's scope. Reviewed capture operations do not recursively acquire this lock. No source-demonstrated cycle was found. The retained error-path log would use an already-installed dispatch, but no in-tree competing global callback re-enters this initializer.
- **Delivery/isolation:** all affected actual captures use `subscriber::with_default` or `dispatcher::with_default`, never a global capture writer; see inventory below. The global's event handler is a no-op (`test_support.rs:83`). Its `enabled == false` does not itself prove that all bare events avoid dispatch, because its callsite interest is `always` (`:64-72`); no missing capture follows from that observation. No patch-introduced event drop was established.
- **Lifetime/spans:** a successful global installation retains its subscriber for process lifetime; thread-local guards restore the previous dispatch on return/unwind. JSON callers retain the returned capture mutex guard and dispatch across their observed operation (`test_support.rs:39-46`). The domain-mediator async operation is polled inside a current-thread runtime under the scoped dispatch, not returned as an unpolled future (`protocol/domain_mediator/tests/serial.rs:17-24,126-128`). The moved constant span ID and no-op span callbacks are unchanged; no affected consumer demonstrates an identity/context or lifetime regression. Tracing spans retain their originating dispatch, so replacing the thread default does not transfer an existing span to the new global.

Dependency source consulted for these semantics: locked `tracing 0.1.44` / `tracing-core 0.1.36` (`Cargo.lock:3349-3375`); local registry `tracing-0.1.44/src/subscriber.rs:20-24,38-42`, `tracing-core-0.1.36/src/dispatcher.rs:254-280,299-330,889-900`, and `tracing-0.1.44/src/span.rs:367-375,564-571,1457-1463`. Registration/cache rebuild and its dispatcher registry locking are in `tracing-core-0.1.36/src/callsite.rs:484-507,551-578`. These explain source behavior; they do not establish the earlier failure's cache causality.

## Actual capture inventory

Paths below are relative to `/home/dwalleck/repos/cyril-wt-fix-cyril-un4p`.

| Capture entry/consumer | Lock and dispatch scope |
|---|---|
| Core workflow text helper | `crates/cyril-core/src/workflow.rs:2218-2236` — shared lock, fmt writer, scoped subscriber; WARN/DEBUG wrappers drive tracker operations. |
| Turn mediator text capture | `crates/cyril-core/src/protocol/turn_mediator.rs:601-616` — shared lock, scoped subscriber around mediation. |
| Conversion text helper and permission-response capture | `crates/cyril-core/src/protocol/convert/mod.rs:891-900,1661-1684` — shared lock and scoped subscribers around conversion. |
| KAS notify text helper | `crates/cyril-core/src/protocol/convert/kas/notify.rs:123-134` — shared lock, scoped subscriber. |
| KAS workflow text helper | `crates/cyril-core/src/protocol/convert/kas/workflow.rs:5540-5550` — shared lock, scoped subscriber. |
| App text helper | `crates/cyril/src/app.rs:8708-8724` — shared lock, scoped subscriber; duplicate installer/subscriber removed in reviewed diff. |
| Latency JSON capture | `crates/cyril-core/src/usage.rs:5255-5304` — returned guard retained, `with_default` at `:5273`. |
| Powers JSON capture | `crates/cyril-core/src/protocol/convert/kas/powers.rs:384-400` — returned guard retained, `with_default` at `:385`. |
| Workflow-plan JSON captures | `crates/cyril-core/src/protocol/convert/kas/workflow_plan.rs:667-670,719-722` — two scoped parse captures. |
| Domain-mediator JSON capture | `crates/cyril-core/src/protocol/domain_mediator/tests/serial.rs:17-24,126-128` — current-thread `block_on` entirely under scoped dispatch. |
| Discovery JSON capture | `crates/cyril-core/src/protocol/kas/discovery.rs:963-1006` — guard retained across repeated, non-nested scoped calls. |
| Approval JSON capture | `crates/cyril-ui/src/widgets/approval.rs:3562-3576` — installation and both rendering phases inside scoped dispatch; capture read afterward. |
| Independent existing captures, not shared-lock callers | `crates/cyril-core/tests/win_wsl_wiring.rs:158-167` — integration-test child branch, thread-local capture; `crates/cyril-workbench/src/reviewer.rs:616-651` — separate workbench test target, thread-local capture. Neither installs a global. |

This inventories seven textual capture construction sites and seven JSON capture callsites using shared initialization, plus the two independent existing captures.

## Global installer inventory

- **Only shared capture installer:** `crates/cyril-core/src/test_support.rs:15-19` (`set_global_default`). No App duplicate remains.
- **Executable production logger:** `crates/cyril/src/main.rs:280-300` (`.init()`), called from main at `:51`; no test caller found.
- **Separate example executables:** `crates/cyril/examples/l7tw_death_probe.rs:18-23` and `crates/cyril/examples/test_bridge.rs:45-50` (`.init()`). Their entrypoints do not invoke shared capture setup.
- **Outside workspace member sources:** `experiments/bh7g-harness/src/main.rs:19-25`, `.cyril-b4y4/probes/oracle_scenario.rs:11`, `.cyril-jlxx/review-native/review-smoke-source.rs:15`, `.k1b-steering/probe.rs:80`, `.k1b-steering/probe_idle_steer.rs:50`, and stored source `.cyril-5nep/live/hook_live_probe_5nep.rs.txt:20`. These are the additional initializer text matches, not competing callers in the affected test binaries; workspace members are enumerated in `Cargo.toml:1-11`. Captured log/source quotations were excluded as non-code.

## Limitations / execution boundary

No LSP device was exposed to this reviewer; scoped text searches were used. Parent independently reports rust-analyzer `No workspaces` and no semantic references, consistent with this fallback. No semantic-reference completeness claim is made.

**No tests, builds, checks, lint, fmt, smoke, or mutation commands were executed. No repository files were changed.** Only source/search reads and read-only Git diff commands were used for review. No fresh runtime evidence is claimed, and the parent's qualification receipts are not represented as reviewer executions. First-installer failure remains a limitation of the existing design, but an actual conflicting in-tree execution path was not demonstrated. Parent retains production/App approval and final artifact ownership.
