#!/usr/bin/env -S uv run --script
# /// script
# dependencies = ["pyte"]
# ///
"""Exercise the real Cyril permission UI with an owned KAS-shaped ACP peer.

No KAS account, filesystem callback, terminal callback, command execution, or
persistent permission grant is used. Pyte supplies decoded text and ASCII box
geometry, NOT a native-terminal or exact Unicode-grapheme cell oracle.
"""
import argparse
import codecs
import fcntl
import hashlib
import json
import os
from pathlib import Path
import pty
import select
import shutil
import signal
import struct
import subprocess
import sys
import tempfile
import termios
import time

LONG_PATH = "/tmp/un4p/" + "long-owned-preview-component/" * 8 + "target.md"
DRAFT = "D"
CASES = [
    {"name": "long-option-clamped", "path": LONG_PATH, "mode": "option"},
    {"name": "long-reason-clamped", "path": LONG_PATH, "mode": "reason"},
    {"name": "long-reason-notice-clamped", "path": LONG_PATH, "mode": "notice"},
    {"name": "literal-ellipsis-option", "path": "/tmp/report…", "mode": "option"},
    {"name": "literal-ellipsis-reason", "path": "/tmp/report…", "mode": "reason"},
    {"name": "single-character-option", "path": "a", "mode": "option"},
    {"name": "single-character-reason", "path": "a", "mode": "reason"},
    {"name": "clipped-grapheme-reason", "path": "#\ufe0f#\ufe0f", "mode": "grapheme"},
    {"name": "pathless-border-option", "path": None, "mode": "border-option"},
    {"name": "pathless-border-reason", "path": None, "mode": "border-reason"},
    {"name": "priority-option", "path": "/tmp/a", "mode": "priority-option"},
    {"name": "priority-reason", "path": "/tmp/a", "mode": "priority-reason"},
    {"name": "priority-reason-notice", "path": "/tmp/a", "mode": "priority-notice"},
    {"name": "nonmonotone-option", "path": "界/ab", "mode": "nonmonotone-option"},
    {"name": "nonmonotone-reason", "path": "界/ab", "mode": "nonmonotone-reason"},
]


def journal(path, value):
    with path.open("a") as file:
        file.write(json.dumps(value, ensure_ascii=False) + "\n")


def agent():
    output = Path(os.environ["UN4P_SMOKE_OUTPUT"])
    session = "sess_un4p_owned_permission"
    prompt = None
    pending = None
    sequence = 0
    incoming = b""

    def send(value):
        frame = {"jsonrpc": "2.0", **value}
        journal(output / "agent-wire.jsonl", frame)
        print(json.dumps(frame, ensure_ascii=False), flush=True)

    def update(value):
        send({"method": "session/update", "params": {"sessionId": session, "update": value}})

    def text(value):
        update({"sessionUpdate": "agent_message_chunk", "content": {"type": "text", "text": value}})

    while True:
        ready, _, _ = select.select([sys.stdin.fileno()], [], [], 0.02)
        if ready:
            chunk = os.read(sys.stdin.fileno(), 65536)
            if not chunk:
                return
            incoming += chunk
            while b"\n" in incoming:
                line, incoming = incoming.split(b"\n", 1)
                frame = json.loads(line)
                journal(output / "client-wire.jsonl", frame)
                method, ident = frame.get("method"), frame.get("id")
                if method == "initialize":
                    send({"id": ident, "result": {"protocolVersion": 1,
                          "agentCapabilities": {"loadSession": True, "_meta": {"kiro": {}}},
                          "agentInfo": {"name": "un4p-owned-permission-peer", "version": "0.66.43"},
                          "authMethods": []}})
                elif method == "session/new":
                    send({"id": ident, "result": {"sessionId": session}})
                elif method == "session/prompt":
                    if prompt is not None:
                        raise AssertionError("overlapping prompt")
                    prompt = ident
                    text("UN4P_PEER_READY\n")
                elif method and ident is not None:
                    send({"id": ident, "result": {}})
                elif pending is not None and ident == pending["id"]:
                    case_index = pending["case"]
                    update({"sessionUpdate": "tool_call_update", "toolCallId": pending["tool"],
                            "status": "completed", "content": [{"type": "content", "content": {
                                "type": "text", "text": "Owned permission exchange only; no operation executed."}}]})
                    text(f"\nUN4P_DONE_{case_index}\n")
                    pending = None
                    if case_index == len(CASES) - 1:
                        update({"sessionUpdate": "session_info_update", "_meta": {"kiro": {
                            "kind": "turn_end", "turnEnd": {"stopReason": "end_turn"},
                            "stopReason": "end_turn"}}})
                        send({"id": prompt, "result": {"stopReason": "end_turn"}})
                        prompt = None
        control_path = output / "control.json"
        if not control_path.exists():
            continue
        control = json.loads(control_path.read_text())
        if control["sequence"] <= sequence:
            continue
        if prompt is None or pending is not None:
            raise AssertionError("permission command without an idle pending prompt")
        sequence = control["sequence"]
        index = control["case"]
        case = CASES[index]
        tool_id = f"un4p-owned-{index}"
        raw_input = {"text": "Owned preview fixture; no operation will execute."}
        if case["path"] is not None:
            raw_input["path"] = case["path"]
        update({"sessionUpdate": "tool_call", "toolCallId": tool_id,
                "title": "Owned approval fixture", "kind": "edit", "status": "pending",
                "rawInput": raw_input})
        pending = {"id": 7000 + index, "case": index, "tool": tool_id}
        # ACP v1 fields and captured KAS option IDs/kinds. Deliberately only
        # manual allow_once/reject_once; no fabricated domain capability field.
        send({"id": pending["id"], "method": "session/request_permission", "params": {
            "sessionId": session,
            "toolCall": {"toolCallId": tool_id, "status": "pending", "title": "Owned approval fixture"},
            "options": [{"optionId": "accept", "name": "Allow", "kind": "allow_once"},
                        {"optionId": "reject", "name": "Deny", "kind": "reject_once"}]}})


def smoke(args):
    import pyte

    binary = Path(args.binary).resolve(strict=True)
    repository = Path(args.repository).resolve(strict=True)
    auth_fixture = repository / "crates/cyril-core/tests/fixtures/fake-kiro-cli.sh"
    if not auth_fixture.is_file():
        raise AssertionError(f"missing owned auth fixture: {auth_fixture}")
    with binary.open("rb") as file:
        digest = hashlib.file_digest(file, "sha256").hexdigest()
    if digest != args.expected_sha256:
        raise AssertionError(f"binary identity mismatch: {digest}")
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    node = shutil.which("node")
    if node is None:
        raise AssertionError("Node executable required by the KAS launch interface")
    script = Path(__file__).resolve()
    shutil.copyfile(script, output / "harness.py")
    screen = pyte.Screen(80, 32)
    stream = pyte.Stream(screen)
    decoder = codecs.getincrementaldecoder("utf-8")("replace")
    actions = []
    results = []
    receipt = {"result": "FAIL", "binary": str(binary), "binary_sha256": digest,
               "repository": str(repository), "engine": "kas", "peer": "owned ACP v1 fixture",
               "proof": "actual Cyril process, actual permission converter/UI/manual response wire, PTY decoded text and ASCII geometry",
               "limitations": "Not live KAS backend qualification or native-terminal glyph fidelity. Exact grapheme-cell behavior belongs to the existing TestBackend regressions (parent gate artifact476).",
               "wire_provenance": [
                   "experiments/conductor-spike/kas-new-surface-turns-0668-2.24.0.jsonl:29,33",
                   "crates/cyril-core/src/protocol/convert/kas.rs:154-187",
                   "crates/cyril-core/src/protocol/domain_mediator/mod.rs:660-769"],
               "manual_grants_only": ["allow_once", "reject_once"], "cases": results}

    with tempfile.TemporaryDirectory(prefix="cyril-un4p-owned-") as scratch_name:
        scratch = Path(scratch_name)
        for name in ["bin", "home", "config", "data", "ws"]:
            (scratch / name).mkdir()
        (scratch / "bin/kiro-cli").symlink_to(auth_fixture)
        server = scratch / "server.js"
        server.write_text(
            "const {spawn}=require('node:child_process');"
            f"const child=spawn({json.dumps(sys.executable)},[{json.dumps(str(script))},'agent'],{{stdio:'inherit'}});"
            "child.on('exit',code=>process.exit(code ?? 1));"
            "process.on('SIGTERM',()=>child.kill('SIGTERM'));"
        )
        environment = os.environ.copy()
        for key in ["KIRO_AGENT_PATH", "KIRO_KAS_SERVER_PATH", "CYRIL_AGENT_LOCATION", "CYRIL_AGENT_HOST_OS"]:
            environment.pop(key, None)
        environment.update(TERM="xterm-256color", COLORTERM="truecolor", PATH=str(scratch / "bin"),
                           SHELL="/bin/bash", HOME=str(scratch / "home"), USERPROFILE=str(scratch / "home"),
                           XDG_CONFIG_HOME=str(scratch / "config"), XDG_DATA_HOME=str(scratch / "data"),
                           KIRO_AGENT_PATH=str(Path(node).resolve()), KIRO_KAS_SERVER_PATH=str(server),
                           UN4P_SMOKE_OUTPUT=str(output))
        command = [str(binary), "--cwd", str(scratch / "ws"), "--agent-engine", "kas",
                   "--prompt", "Run owned permission UI fixtures only; do not execute operations"]
        master, slave = pty.openpty()
        fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", 32, 80, 0, 0))
        try:
            process = subprocess.Popen(command, stdin=slave, stdout=slave, stderr=slave,
                                       env=environment, cwd=scratch / "ws", start_new_session=True)
        finally:
            os.close(slave)
        raw = (output / "terminal.ansi").open("wb")
        raw_size = 0

        def drain(seconds=0.12):
            nonlocal raw_size
            deadline = time.monotonic() + seconds
            while time.monotonic() < deadline:
                ready, _, _ = select.select([master], [], [], max(0, deadline - time.monotonic()))
                if not ready:
                    return
                try:
                    chunk = os.read(master, 65536)
                except OSError:
                    return
                if not chunk:
                    return
                raw.write(chunk)
                raw.flush()
                raw_size += len(chunk)
                stream.feed(decoder.decode(chunk))

        def visible():
            return "\n".join(screen.display)

        def await_observation(predicate, description, timeout=30):
            deadline = time.monotonic() + timeout
            while not predicate():
                if process.poll() is not None or time.monotonic() > deadline:
                    raise AssertionError(f"Missing {description}; exit={process.poll()}\n{visible()}")
                drain()

        def wire(name):
            path = output / name
            if not path.exists():
                return []
            return [json.loads(line) for line in path.read_text().splitlines(keepends=True)
                    if line.endswith("\n")]

        def responses(index):
            return [frame for frame in wire("client-wire.jsonl")
                    if frame.get("id") == 7000 + index and "method" not in frame]

        def popup():
            boxes = []
            for y in range(screen.lines):
                corners = [x for x in range(1, screen.columns) if screen.buffer[y][x].data == "┌"]
                for left in corners:
                    rights = [x for x in range(left + 1, screen.columns) if screen.buffer[y][x].data == "┐"]
                    if not rights:
                        continue
                    right = rights[0]
                    bodies = []
                    for row in range(y + 1, screen.lines):
                        if screen.buffer[row][left].data != "│":
                            break
                        bodies.append("".join(screen.buffer[row][x].data for x in range(left + 1, right)).strip())
                    boxes.append({"top": y, "left": left, "right": right,
                                  "width": right - left + 1, "body": bodies})
            return boxes[-1] if boxes else None

        def input_draft():
            for y in range(screen.lines):
                if screen.buffer[y][0].data != "┌":
                    continue
                title = "".join(screen.buffer[y][x].data for x in range(min(screen.columns, 8)))
                if ">" not in title:
                    continue
                rows = []
                for row in range(y + 1, screen.lines):
                    if screen.buffer[row][0].data != "│":
                        break
                    rows.append("".join(screen.buffer[row][x].data for x in range(1, screen.columns - 1)))
                return "".join(rows).replace("█", "").strip()
            return None

        def capture(name):
            text = visible()
            (output / f"{name}.txt").write_text(text)
            box = popup()
            action = {"capture": f"{name}.txt", "columns": screen.columns, "rows": screen.lines,
                      "raw_byte_offset": raw_size, "popup": box, "input_draft": input_draft()}
            actions.append(action)
            journal(output / "observations.jsonl", action)
            return box

        def send_keys(value):
            os.write(master, value)

        def paste(value):
            send_keys(b"\x1b[200~" + value.encode() + b"\x1b[201~")

        def resize(width, height):
            before = raw_size
            fcntl.ioctl(master, termios.TIOCSWINSZ, struct.pack("HHHH", height, width, 0, 0))
            screen.resize(lines=height, columns=width)
            os.kill(process.pid, signal.SIGWINCH)
            await_observation(lambda: raw_size > before, f"redraw at {width}x{height}")
            drain()

        def assert_pending(index):
            actual = responses(index)
            if actual:
                raise AssertionError(f"permission {index} answered prematurely: {actual}\n{visible()}")

        def editor_has(value=""):
            box = popup()
            return box is not None and any(value in row and "█" in row for row in box["body"])

        def reason(draft):
            send_keys(b"\x1b[Br")
            await_observation(lambda: "Reject with reason" in visible(), "real reason editor")
            paste(draft)
            await_observation(editor_has, "reason draft cursor")

        def clamp_two(width=80):
            for height in range(8, 19):
                resize(width, height)
                box = popup()
                if box is not None and len(box["body"]) == 2:
                    return box
            raise AssertionError(f"no two-inner-row popup at width {width}\n{visible()}")

        def await_response(index, option, draft=None, *, restore_geometry_after_wire=False):
            await_observation(lambda: bool(responses(index)), f"wire response {index}")
            frames = responses(index)
            if len(frames) != 1:
                raise AssertionError(f"duplicate response for permission {index}: {frames}")
            result = frames[0].get("result", {})
            if result.get("outcome") != {"outcome": "selected", "optionId": option}:
                raise AssertionError(f"wrong decision for {index}: {frames[0]}")
            actual_reason = result.get("_meta", {}).get("kiro", {}).get("rejectionReason")
            if actual_reason != draft:
                raise AssertionError(f"wrong rejection reason for {index}: {actual_reason!r} != {draft!r}")
            if restore_geometry_after_wire:
                resize(80, 32)
            await_observation(lambda: f"UN4P_DONE_{index}" in visible(), f"peer consumed response {index}")
            return frames[0]

        try:
            await_observation(lambda: "UN4P_PEER_READY" in visible(), "pending prompt ready")
            paste(DRAFT)
            await_observation(lambda: input_draft() == DRAFT, "chat draft before permission")
            capture("00-chat-draft-before-permissions")
            for index, case in enumerate(CASES):
                resize(80, 32)
                await_observation(lambda: input_draft() == DRAFT, "unchanged chat draft before next request")
                temporary = output / "control.tmp"
                temporary.write_text(json.dumps({"sequence": index + 1, "case": index}))
                temporary.replace(output / "control.json")
                await_observation(lambda: popup() is not None and "Permission Required" in visible(),
                                  f"pending permission UI for {case['name']}")
                assert_pending(index)
                capture(f"{index + 1:02d}-{case['name']}-pending")
                mode = case["mode"]
                expected_reason = None
                expected_option = "accept"
                if mode in ["reason", "notice", "grapheme", "border-reason"]:
                    expected_reason = "x" * 4096 if mode == "notice" else "why"
                    expected_option = "reject"
                    reason(expected_reason)
                    if mode == "notice":
                        paste("overflow")
                        await_observation(lambda: "Reason limit reached (4096 characters)." in visible(),
                                          "actual overflow notice while draft remains pending")
                if mode in ["priority-reason", "priority-notice", "nonmonotone-reason"]:
                    expected_reason = "why"
                    expected_option = "reject"
                    reason(expected_reason)
                    await_observation(lambda: editor_has("why"), "exact edge-case reason draft")
                    if mode == "priority-notice":
                        paste("x" * 4096)
                        await_observation(
                            lambda: "Reason limit reached (4096 characters)." in visible() and editor_has("why"),
                            "overflow insertion refused with original why draft and notice",
                        )
                        assert_pending(index)
                        capture(f"{index + 1:02d}-{case['name']}-overflow-refused")
                if mode.startswith("priority-"):
                    resize(10, 12)
                    box = capture(f"{index + 1:02d}-{case['name']}-identifying-three")
                    if (box is None or box["left"] != 2 or box["right"] != 7
                            or box["width"] != 6 or len(box["body"]) != 3):
                        raise AssertionError(f"priority fixture geometry differs from frozen App regression: {box}")
                    expected_body = ["/…", "/a", "▸ Al" if mode == "priority-option" else "why█"]
                    if box["body"] != expected_body:
                        raise AssertionError(f"identifying path/action lost priority: {box['body']} != {expected_body}")
                elif mode.startswith("nonmonotone-"):
                    reason_phase = mode == "nonmonotone-reason"
                    resize(9, 20 if reason_phase else 16)
                    box = capture(f"{index + 1:02d}-{case['name']}-identifying-smaller-fit")
                    if (box is None or box["left"] != 2 or box["right"] != 6
                            or box["width"] != 5 or len(box["body"]) != (11 if reason_phase else 7)):
                        raise AssertionError(f"nonmonotone fixture geometry differs from frozen App regression: {box}")
                    body = box["body"]
                    marker = "█" if reason_phase else "▸"
                    if not any(marker in row for row in body):
                        raise AssertionError(f"nonmonotone action/editor not drawn: {body}")
                    first = body.index("…") if "…" in body else -1
                    if (first < 0 or body[first:first + 3] != ["…", "a", "b"]
                            or any("界" in row for row in body) or "/" in body):
                        raise AssertionError(f"selected identifying smaller fit is not painted: {body}")
                elif case["name"].startswith("long-"):
                    box = clamp_two()
                    body = box["body"]
                    if not any(row.endswith("target.md") for row in body):
                        raise AssertionError(f"clamped long-path tail missing: {body}")
                    if mode == "option" and not any("▸ Allow" in row for row in body):
                        raise AssertionError(f"clamped selected action missing: {body}")
                    if mode != "option" and (not any("█" in row for row in body) or any("Limit:" in row for row in body)):
                        raise AssertionError(f"path/editor lost priority to chrome: {body}")
                    capture(f"{index + 1:02d}-{case['name']}-inner-two")
                elif mode == "grapheme":
                    box = clamp_two(10)
                    if box["width"] != 6:
                        raise AssertionError(f"unexpected narrow popup geometry: {box}")
                    capture(f"{index + 1:02d}-{case['name']}-narrow-before-enter")
                    # Keep the editor mutation within four actual text cells:
                    # why + Backspace + ! => wh!, with its cursor still drawn.
                    send_keys(b"\r\x7f!")
                    await_observation(lambda: editor_has("wh!"),
                                      "post-Enter editor mutation proves ignored narrow Enter")
                    assert_pending(index)
                    capture(f"{index + 1:02d}-{case['name']}-narrow-enter-ignored")
                    expected_reason = "wh!"
                    resize(80, 32)
                    await_observation(lambda: "wh!█" in visible(), "preserved reason after expansion")
                    assert_pending(index)
                    capture(f"{index + 1:02d}-{case['name']}-expanded")
                elif mode.startswith("border-"):
                    resize(6, 24)
                    box = popup()
                    if box is None or box["width"] != 2:
                        raise AssertionError(f"not a border-only popup: {box}")
                    capture(f"{index + 1:02d}-{case['name']}-border-before-enter")
                    if mode == "border-option":
                        # FIFO keys: if Enter answered, these cannot enter the
                        # same request's reason editor after restoring width.
                        send_keys(b"\r\x1b[Br")
                        paste("border-fence")
                        original_inner_rows = len(box["body"])
                        await_observation(
                            lambda: len((popup() or {}).get("body", [])) > original_inner_rows,
                            "reason-page border geometry after ignored narrow option Enter",
                        )
                    else:
                        send_keys(b"\r\x7f!")
                        expected_reason = "wh!"
                    resize(80, 32)
                    fence = "border-fence█" if mode == "border-option" else "wh!█"
                    await_observation(lambda: fence in visible() and "Reject with reason" in visible(),
                                      "same pending request consumed post-Enter editor keys")
                    assert_pending(index)
                    capture(f"{index + 1:02d}-{case['name']}-restored-enter-ignored")
                    if mode == "border-option":
                        send_keys(b"\x1b")
                        await_observation(lambda: "Permission Required" in visible(), "back from feedback without response")
                        send_keys(b"\x1b[A")
                        await_observation(lambda: "▸ Allow" in visible(), "restored AllowOnce selection")
                else:
                    box = popup()
                    if box is None or case["path"] not in box["body"]:
                        raise AssertionError(f"full literal target is not actually decoded in popup: {box}")
                    capture(f"{index + 1:02d}-{case['name']}-full-target")
                assert_pending(index)
                send_keys(b"\r")
                response = await_response(
                    index, expected_option, expected_reason,
                    restore_geometry_after_wire=mode.startswith(("priority-", "nonmonotone-")),
                )
                resize(80, 32)
                await_observation(lambda: input_draft() == DRAFT, "chat draft retained after decision")
                capture(f"{index + 1:02d}-{case['name']}-answered")
                results.append({"name": case["name"], "request_id": 7000 + index,
                                "tool_call_id": f"un4p-owned-{index}", "path": case["path"],
                                "response": response, "chat_draft_preserved": True})
            requests = [frame for frame in wire("agent-wire.jsonl") if frame.get("method") == "session/request_permission"]
            if len(requests) != len(CASES):
                raise AssertionError(f"wrong request count: {len(requests)}")
            forbidden = [frame for frame in wire("agent-wire.jsonl")
                         if frame.get("method", "").startswith(("fs/", "terminal/", "_kiro/auth/"))]
            if forbidden:
                raise AssertionError(f"unexpected external-operation callbacks: {forbidden}")
            receipt["result"] = "PASS"
            receipt["permission_requests"] = len(requests)
            receipt["permission_responses"] = len(results)
            receipt["chat_draft_preserved"] = DRAFT
        except Exception as error:
            receipt["error"] = str(error)
            raise
        finally:
            capture("final-screen")
            (output / "result.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2))
            if process.poll() is None:
                send_keys(b"\x11")
                drain(0.3)
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGTERM)
                    process.wait(timeout=5)
            raw.close()
            os.close(master)
            for path in [scratch / "home/.config/cyril/cyril.log", scratch / "config/cyril/cyril.log"]:
                if path.exists():
                    shutil.copyfile(path, output / "cyril.log")
            auth_log = scratch / "bin/kiro-cli-argv.txt"
            if auth_log.exists():
                shutil.copyfile(auth_log, output / "kiro-cli-argv.txt")
        print(json.dumps(receipt, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    if sys.argv[1:] == ["agent"]:
        agent()
    else:
        parser = argparse.ArgumentParser(description=__doc__)
        parser.add_argument("--binary", required=True)
        parser.add_argument("--expected-sha256", required=True)
        parser.add_argument("--repository", required=True)
        parser.add_argument("--output", required=True, help="fresh owned evidence directory")
        smoke(parser.parse_args())
