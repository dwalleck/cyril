**F1: resolved by source review.** `theme.rs:1947` now removes the exact approved `use crate::theme::{MarkdownStyle, Theme};` import before applying the existing prohibitions. Implicit resolution references remain rejected; the widget roster check, 17-file cap, and 300,000-byte cap are unchanged.

The affected seam remains correct: Markdown projects `Theme` once, hashes the complete derived `MarkdownStyle`, renders from that same value, and forwards its nested `HighlightStyle` to highlighting. The repair introduces no rendering behavior change.

**New findings:** none.

**overall_correctness:** correct  
**explanation:** The narrowly scoped allowance resolves the previously identified deterministic fence failure without weakening the implicit-theme-resolution prohibitions. This conclusion is source-derived only; no builds, tests, checks, or A/B fault injections were run by this reviewer, and parent verification remains pending.  
**confidence:** 0.99