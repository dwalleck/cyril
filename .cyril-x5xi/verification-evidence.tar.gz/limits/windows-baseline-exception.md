## Requester-approved baseline CI exception

The requester explicitly selected **Accept documented baseline exception** for the five implementation batches: keep the 13-issue scope; complete all other required verification and PRs; report the existing `cyril-u62f` Windows memory-runtime readiness failure and cancelled coverage. No blind retries, timeout increases, skipped tests, or memory-runtime changes are authorized by this exception. New or differently attributed failures remain blocking.

PR #183 / head `a5d2c4b5d5db88889ba5bc5e3f560375715977cd` failed [Test (windows-latest)](https://github.com/dwalleck/cyril/actions/runs/39369380677/job/118453541349) in three initial-readiness calls:
- `real_process_reports_ready_v3_and_exact_store_schema`
- `c3_real_runtime_restart_replay_is_exact_once_and_conflict_safe`
- `forced_kill_allows_reopen_with_same_roots`

Each timed out around 5.15 seconds with 18 connection failures and one health failure. Nextest completed 26/2696 tests (23 passed, three failed), cancelled 2,670 later tests, and skipped 13. The cancelled tests are **not** claimed to pass.

Read-only diagnosis established exact Git object identity between base and head for the failing tests, memory-runtime entrypoint, entire cyril-memory tree, checked manifests, Cargo.lock and CI workflow. These tests spawn cyril-memory-runtime and do not execute the changed UiState. [Exact-base Windows CI](https://github.com/dwalleck/cyril/actions/runs/39366546524/job/118444594493) passed identical memory source and the three named tests. Existing open issue cyril-u62f records matching prior failures; mechanism is unresolved.

All other substantive #183 jobs passed: Linux/macOS tests, Linux/Windows builds, KAS feature isolation, default-feature tests on Linux/macOS/Windows, lint, formatting, commit validation and worktree tooling. No rerun was requested. This is an accepted qualification limit, not a repaired runtime defect or a fully green CI claim.
