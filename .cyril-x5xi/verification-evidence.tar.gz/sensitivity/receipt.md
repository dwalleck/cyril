# x5xi / zj0m independent sensitivity receipts

**Result: required independent baseline RED and isolated production GREEN observed.** Six tests actually executed in each run; baseline 2 PASS / 4 intended FAIL, production 6 PASS / 0 FAIL. No compile-error RED, ignored test, zero-test success, production substitution, or source-only oracle.

## Checked source states

- Base: `8e5c325ebb5dac3a4ad89f71838fd198cc177543`.
- Independent proof checkout: `/home/dwalleck/repos/cyril-wt-test-cyril-perf-proof-20261019`, detached at that base. Initial checkout was clean before adding probes.
- RED: unchanged baseline production plus two test-only probe modules and `#[cfg(test)]` constructor-count increments immediately before **both actual baseline** `TextDiff::from_lines` calls (summary and body). There is no production fix in the RED state.
- GREEN: exact frozen completed issue patches applied to baseline, then the same probes restored. x5xi `.cyril-x5xi/production.patch` SHA256 `9ac057ccb15ee7e809330f41bb3abf39259018ea61a8066950635eb02bd93585`; zj0m `.cyril-zj0m/production.patch` SHA256 `5c0d35de8fd980228f9f595199f86014b70e6f7a376ae51c40d7ceb915a655f9`. Both hashes matched the implementation owner's frozen boundaries. They include the MarkdownStyle whitelist/import repair and `PermissionOption.is_destructive: false` fixture repair. No later live c6la migration or 1v25 source was imported.
- GREEN probe adaptation is restricted to three private highlight helper calls: `&Theme` becomes `HighlightStyle::from(theme)`. Inputs, assertions, cache ledger and expected outputs are unchanged. The unchanged chat probe counter is incremented immediately before the one actual production constructor in `tool_diff.rs`; the separate existing production counter remains intact.
- Full SHA256 manifests: [RED](local://perf-red-state.json), [GREEN](local://perf-green-state.json). The active implementation worktree was never edited.

## Exact executed command / environment

From the proof checkout, both runs used:

```sh
CARGO_TARGET_DIR=/home/dwalleck/repos/cyril/target cargo test -p cyril-ui --lib perf_sensitivity:: -- --nocapture
```

Before RED, metadata-only `touch crates/cyril-ui/src/lib.rs crates/cyril-core/src/lib.rs` forced current-checkout core/UI compilation. Before GREEN, `touch crates/cyril-ui/src/lib.rs` forced current patched UI compilation. Logs explicitly show the proof checkout in the `Compiling` paths. This avoids the parent's observed shared-target stale-sibling artifact problem without deleting dependency caches. Neither run built the binary.

Rust `1.94.0 (4a4ef493e 2026-03-02)`, host `x86_64-unknown-linux-gnu`, test profile `optimized + debuginfo`. [Environment receipt](local://perf-environment.log).

## Observed RED → GREEN

| Probe | Baseline actual observable | Production actual observable |
|---|---|---|
| `highlight::perf_sensitivity::irrelevant_role_reuses_cache_without_eviction` | FAIL: `irrelevant role evicted baseline`, retained target ledger entry `None` despite identical visible output | PASS: target/probe retained, syntax-enabled and no-syntax fallback, both call orders |
| `highlight::perf_sensitivity::relevant_syntax_and_fallback_text_isolate_visible_output` | PASS | PASS: actual uncached syntax/fallback output differences and isolated cached outputs, both call orders |
| `widgets::chat::perf_sensitivity::first_unchanged_diff_hides_later_counts` | FAIL: `✓ Edit(first.rs)  +2 -1` versus required `✓ Edit(first.rs)` | PASS |
| `widgets::chat::perf_sensitivity::changed_first_diff_has_exact_counts_and_rows` | PASS | PASS: exact first-source +2/-1 header and five body rows; later 30-line Diff does not leak |
| `widgets::chat::perf_sensitivity::first_root_draw_constructs_myers_exactly_once` | FAIL: actual cold constructor count **2**, expected 1 | PASS: **1** |
| `widgets::chat::perf_sensitivity::repeated_root_draws_reuse_myers_across_resize_theme_and_update` | FAIL: ten warm root draws **20** actual constructions, expected 0; ten warm + two width/palette changes **24**; replacement source **2** | PASS: ten warm **0**, warm + width/palette changes **0**, replacement source **1** |

RED exited **101**, `2 passed; 4 failed; 0 ignored; 788 filtered out`; GREEN exited **0**, `6 passed; 0 failed; 0 ignored; 810 filtered out`. Full output: [RED log](local://perf-red.log), [GREEN log](local://perf-green.log).

The repeated-work test deliberately does not stop at the first cold-count failure: it independently measures actual warm/redraw work and completes all visible controls before its count assertions. It drives real `UiState` start + content-empty completion notifications through `render::draw`, ten additional root draws, widths 120/80 with GruvboxDark/CyrilDark, and a same-ID source replacement. It requires visible header, removed/added rows, replacement counts/body, and absence of old deletion text. Thus a panic-catching root fallback or disconnected instrumentation cannot pass. This is actual consumer execution, not native terminal proof or a timing benchmark. Width/theme-visible text is checked; this probe does not independently assert palette cell colors.

## Preservation / final state

- Exact pre-change source+probe backup: `/tmp/cyril-perf-sensitivity-red-20261019.tar`, SHA256 `65a41df52da6e1cde5301af71ba0f8ac354944dd88ea788b3a47756867bb6fcf`. Every archived member's SHA256 was checked against the pre-run RED manifest. It preserves baseline `highlight.rs`, baseline `widgets/chat.rs`, and both independent probe modules for byte-exact restoration in a fresh baseline checkout.
- Probe files retained in proof checkout: `crates/cyril-ui/src/highlight_perf_sensitivity.rs` and `crates/cyril-ui/src/widgets/chat_perf_sensitivity.rs`.
- Final proof checkout intentionally retains the successful GREEN patched state and test-only instrumentation. No commits or PRs. No active implementation edits to restore. The first 30-second interrupted incomplete checkout was removed; only the valid proof worktree is used in these receipts.
- Shared Cargo slot explicitly released to `VerifyRootSensitivity` after GREEN; no further Cargo command was launched. Parent's existing smoke binary was not rebuilt.

These receipts discharge the assigned sensitivity obligation for the pinned x5xi/zj0m patch boundaries, not later c6la migration, whole-repository qualification, benchmark calibration, native terminal smoke, or final publication.

## Proof-only source-fence limitation

Subsequent read-only review confirmed that these temporary probe modules are **not suitable for a full-UI source-fence run as-is**. `theme::tests::widgets_only_use_the_explicit_theme` counts immediate `src/widgets/*.rs` files against 17 explicit sources; the extra proof module would cause that count assertion to fail. Its `production_source` helper also splits at the first literal `#[cfg(test)]`, so the proof-only module declaration/instrumentation truncates its source scan. Neither source fence was executed or used as evidence here. The six exercised probes depend on real output and constructor execution, not those scans; their RED/GREEN results and hashes are unchanged. Parent must perform full UI/source-fence qualification in the uninstrumented implementation checkout, not treat this isolated six-test run as a substitute. Do not copy the temporary proof scaffolding into production.
