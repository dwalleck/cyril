#!/usr/bin/env -S uv run --script
# /// script
# dependencies = ["pyte"]
# ///
"""One identical retained ACP fixture and bounded keys against one Cyril binary.

The immutable24-specimen harness is neither edited nor rerun. This probe's sole
behavioral criterion is actual drawn chg11 reachability, not status wording.
"""
import argparse
import codecs
import fcntl
import hashlib
import json
import os
from pathlib import Path
import pty
import select
import shutil
import signal
import struct
import subprocess
import sys
import tempfile
import termios
import time

WIDTH, HEIGHT, DRAFT, LATE = 32, 24, "D", "chg11"
KEYS = [("PgDn-1", b"\x1b[6~"), ("PgDn-2", b"\x1b[6~"),
        ("PgDn-3", b"\x1b[6~"), ("Shift-End", b"\x1b[1;2F")]


def journal(path, frame):
    with path.open("a") as file:
        file.write(json.dumps(frame, ensure_ascii=False) + "\n")


def peer():
    output = Path(os.environ["EJ_BOUNDED_OUTPUT"])
    fixture = json.loads((output / "fixture.json").read_text())
    session = fixture[-1]["params"]["sessionId"]
    incoming, emitted = b"", False

    def send(frame):
        frame = {"jsonrpc": "2.0", **frame}
        journal(output / "agent-wire.jsonl", frame)
        print(json.dumps(frame, ensure_ascii=False), flush=True)

    while True:
        ready, _, _ = select.select([sys.stdin.fileno()], [], [], 0.02)
        if ready:
            chunk = os.read(sys.stdin.fileno(), 65536)
            if not chunk:
                return
            incoming += chunk
            while b"\n" in incoming:
                line, incoming = incoming.split(b"\n", 1)
                frame = json.loads(line)
                journal(output / "client-wire.jsonl", frame)
                method, ident = frame.get("method"), frame.get("id")
                if method == "initialize":
                    send({"id": ident, "result": {"protocolVersion": 1,
                          "agentCapabilities": {"loadSession": True, "_meta": {"kiro": {}}},
                          "agentInfo": {"name": "bounded-ej7y-owned-peer", "version": "0.66.43"}, "authMethods": []}})
                elif method == "session/new":
                    send({"id": ident, "result": {"sessionId": session}})
                elif method == "session/prompt":
                    send({"method": "session/update", "params": {"sessionId": session, "update": {
                        "sessionUpdate": "agent_message_chunk", "content": {"type": "text", "text": "BOUNDED_EJ_READY\n"}}}})
                    # The real prompt stays pending for the whole probe.
                elif method and ident is not None:
                    send({"id": ident, "result": {}})
        if not emitted and (output / "control.json").exists():
            emitted = True
            for frame in fixture:
                send(frame)


def retained_fixture(source):
    frames = [json.loads(line) for line in source.read_text().splitlines()]
    selected = []
    for frame in frames:
        update = frame.get("params", {}).get("update", {})
        if frame.get("method") == "session/update" and update.get("toolCallId") == "ej7y-owned-0" and \
                update.get("sessionUpdate") in ["tool_call", "tool_call_update"] and \
                update.get("status") in ["in_progress", "pending"]:
            selected.append(frame)
        if frame.get("method") == "session/request_permission" and frame.get("id") == 8000:
            selected.append(frame)
            break
    if len(selected) != 3 or selected[-1].get("method") != "session/request_permission":
        raise AssertionError("source is not the successful first start/update/permission specimen")
    request = selected[-1]["params"]
    plan = request["_meta"]["kiro"]["workflowPlan"]
    if len(plan["steps"]) != 44 or [option["kind"] for option in request["options"]] != ["allow_once", "reject_once"]:
        raise AssertionError("wrong retained typed-plan fixture")
    blocks = request["toolCall"]["content"]
    text = "\n".join(block["content"]["text"] for block in blocks if block.get("type") == "content")
    comparison = next(line for line in text.splitlines() if line.startswith("Compared with the replaced steps:"))
    if not (comparison.index(LATE) + len(LATE) <= 600 and comparison.index("chg13") > 600):
        raise AssertionError("late marker is not an independently retained KAS comparison ID")
    return selected, comparison


def probe(args):
    import pyte
    binary = Path(args.binary).resolve(strict=True)
    with binary.open("rb") as file:
        binary_hash = hashlib.file_digest(file, "sha256").hexdigest()
    if binary_hash != args.expected_sha256:
        raise AssertionError(f"binary identity mismatch: {binary_hash}")
    fixture, comparison = retained_fixture(Path(args.source_wire).resolve(strict=True))
    fixture_bytes = json.dumps(fixture, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    fixture_hash = hashlib.sha256(fixture_bytes).hexdigest()
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=False)
    (output / "fixture.json").write_bytes(fixture_bytes)
    shutil.copyfile(Path(__file__).resolve(), output / "probe.py")
    receipt = {"result": "ERROR", "binary": str(binary), "binary_sha256": binary_hash,
               "source_wire": str(Path(args.source_wire).resolve()), "fixture_sha256": fixture_hash,
               "fixture_request_id": 8000, "viewport": [WIDTH, HEIGHT], "input_draft": DRAFT,
               "keys": [name for name, _ in KEYS], "late_marker": LATE,
               "late_marker_position": comparison.index(LATE), "retained_limit": 600,
               "proof": "actual pending permission body text reachability, not navigation-status availability",
               "limitations": "Owned ACP fixture, not live KAS/native glyph qualification; no operation or grant"}
    observations = []
    node = shutil.which("node")
    if node is None:
        raise AssertionError("Node executable required")
    screen = pyte.Screen(WIDTH, HEIGHT)
    stream = pyte.Stream(screen)
    decoder = codecs.getincrementaldecoder("utf-8")("replace")
    with tempfile.TemporaryDirectory(prefix="cyril-ej7y-bounded-") as scratch_name:
        scratch = Path(scratch_name)
        for child in ["bin", "home", "config", "data", "ws"]:
            (scratch / child).mkdir()
        auth = Path(args.repository).resolve(strict=True) / "crates/cyril-core/tests/fixtures/fake-kiro-cli.sh"
        (scratch / "bin/kiro-cli").symlink_to(auth)
        server = scratch / "server.js"
        server.write_text("const {spawn}=require('node:child_process');"
                          f"const c=spawn({json.dumps(sys.executable)},[{json.dumps(str(Path(__file__).resolve()))},'peer'],{{stdio:'inherit'}});"
                          "c.on('exit',n=>process.exit(n??1));process.on('SIGTERM',()=>c.kill('SIGTERM'));")
        environment = os.environ.copy()
        for key in ["KIRO_AGENT_PATH", "KIRO_KAS_SERVER_PATH", "CYRIL_AGENT_LOCATION", "CYRIL_AGENT_HOST_OS"]:
            environment.pop(key, None)
        environment.update(TERM="xterm-256color", COLORTERM="truecolor", PATH=str(scratch / "bin"), SHELL="/bin/bash",
                           HOME=str(scratch / "home"), USERPROFILE=str(scratch / "home"),
                           XDG_CONFIG_HOME=str(scratch / "config"), XDG_DATA_HOME=str(scratch / "data"),
                           KIRO_AGENT_PATH=str(Path(node).resolve()), KIRO_KAS_SERVER_PATH=str(server), EJ_BOUNDED_OUTPUT=str(output))
        master, slave = pty.openpty()
        fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", HEIGHT, WIDTH, 0, 0))
        try:
            process = subprocess.Popen([str(binary), "--cwd", str(scratch / "ws"), "--agent-engine", "kas",
                                        "--prompt", "Display the one owned pending approval fixture only"],
                                       stdin=slave, stdout=slave, stderr=slave, cwd=scratch / "ws",
                                       env=environment, start_new_session=True)
        finally:
            os.close(slave)
        raw = (output / "terminal.ansi").open("wb")
        raw_size = 0

        def visible():
            return "\n".join(screen.display)

        def drain(seconds=0.20):
            nonlocal raw_size
            deadline = time.monotonic() + seconds
            while time.monotonic() < deadline:
                ready, _, _ = select.select([master], [], [], max(0, deadline - time.monotonic()))
                if not ready:
                    return
                try:
                    chunk = os.read(master, 65536)
                except OSError:
                    return
                if not chunk:
                    return
                raw.write(chunk)
                raw.flush()
                raw_size += len(chunk)
                stream.feed(decoder.decode(chunk))

        def wait(predicate, description):
            deadline = time.monotonic() + 30
            while not predicate():
                if process.poll() is not None or time.monotonic() > deadline:
                    raise AssertionError(f"fixture/observation failure: {description}; exit={process.poll()}\n{visible()}")
                drain()

        def wire(name):
            path = output / name
            return [] if not path.exists() else [json.loads(line) for line in path.read_text().splitlines(keepends=True) if line.endswith("\n")]

        def permission_responses():
            return [frame for frame in wire("client-wire.jsonl") if frame.get("id") == 8000 and "method" not in frame]

        def popup():
            boxes = []
            for y in range(HEIGHT):
                for left in range(1, WIDTH):
                    if screen.buffer[y][left].data != "┌":
                        continue
                    right = next((x for x in range(left + 1, WIDTH) if screen.buffer[y][x].data == "┐"), None)
                    if right is None:
                        continue
                    rows = []
                    for row in range(y + 1, HEIGHT):
                        if screen.buffer[row][left].data != "│":
                            break
                        rows.append("".join(screen.buffer[row][x].data for x in range(left + 1, right)).rstrip())
                    boxes.append({"top": y, "left": left, "right": right, "rows": rows})
            return boxes[-1] if boxes else None

        def box_has(text):
            box = popup()
            return box is not None and any(text in row for row in box["rows"])

        def draft():
            for y in range(HEIGHT - 1):
                if screen.buffer[y][0].data == "┌" and ">" in "".join(screen.buffer[y][x].data for x in range(8)):
                    return "".join(screen.buffer[y + 1][x].data for x in range(1, WIDTH - 1)).replace("█", "").strip()
            return None

        def capture(name):
            box = popup()
            if box is None:
                raise AssertionError("fixture/observation failure: pending popup missing")
            if permission_responses():
                raise AssertionError(f"navigation answered permission: {permission_responses()}")
            rows = box["rows"]
            if not any("/tmp/ej7y-a.md" in row for row in rows) or not any("▸ Allow" in row for row in rows) or draft() != DRAFT:
                raise AssertionError(f"context/input not preserved: {rows}; draft={draft()!r}")
            body = [row[4:] for row in rows if row.startswith("    ") and row.strip()]
            if len(body) > 12:
                raise AssertionError(f"body exceeds twelve rows including status: {body}")
            text = "".join("".join(body).split())
            result = {"capture": name + ".txt", "raw_byte_offset": raw_size, "popup": box,
                      "body": body, "late_marker_drawn": LATE in text,
                      "permission_unanswered": True, "input_draft": draft()}
            observations.append(result)
            (output / result["capture"]).write_text(visible())
            journal(output / "observations.jsonl", result)
            return result

        try:
            wait(lambda: "BOUNDED_EJ_READY" in visible(), "owned prompt ready")
            os.write(master, b"\x1b[200~D\x1b[201~")
            wait(lambda: draft() == DRAFT, "actual chat draft before permission")
            (output / "control.json").write_text(json.dumps({"emit_exact_fixture": True}))
            wait(lambda: "Permission Required" in visible() and box_has("Update Workflow 00"),
                 "identifiable first permission rendered")
            initial = capture("00-initial")
            if initial["late_marker_drawn"]:
                raise AssertionError("fixture is not discriminating: late comparison marker already visible")
            for index, (name, key) in enumerate(KEYS, 1):
                os.write(master, key)
                drain()
                capture(f"{index:02d}-{name}")
            # FIFO selection changes visibly fence consumption of every page
            # key without answering or changing the preview phase/geometry.
            os.write(master, b"\x1b[B")
            wait(lambda: box_has("▸ Deny"), "post-navigation selection-down fence")
            os.write(master, b"\x1b[A")
            wait(lambda: box_has("▸ Allow"), "post-navigation selection-restored fence")
            capture("05-post-navigation-input-fence")
            actual_fixture = [frame for frame in wire("agent-wire.jsonl") if frame in fixture]
            if actual_fixture != fixture:
                raise AssertionError("peer did not emit the exact retained fixture")
            reached = any(row["late_marker_drawn"] for row in observations[1:])
            receipt.update(observations=observations, initially_absent=True, late_marker_reached=reached,
                           permission_responses_before_cleanup=0, context_preserved=True,
                           final_input_consumption_fence="same pending option page selected Deny then restored Allow after all probe keys")
            if not reached:
                receipt["result"] = "BEHAVIORAL_RED"
                receipt["failure_kind"] = "retained-late-comparison-unreachable"
                raise AssertionError("BEHAVIORAL_RED: retained chg11 remains absent from actual pending approval body after three PgDn and Shift-End")
            receipt["result"] = "PASS"
        except Exception as error:
            receipt["error"] = str(error)
            raise
        finally:
            if process.poll() is None:
                os.write(master, b"\x11")
                drain(0.3)
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGTERM)
                    process.wait(timeout=5)
            receipt["cyril_exit_status"] = process.returncode
            receipt["cleanup"] = "owned Cyril process stopped; private scratch removed"
            raw.close()
            os.close(master)
            log = scratch / "home/.config/cyril/cyril.log"
            if log.exists():
                shutil.copyfile(log, output / "cyril.log")
            (output / "result.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2))
        print(json.dumps(receipt, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    if sys.argv[1:] == ["peer"]:
        peer()
    else:
        parser = argparse.ArgumentParser(description=__doc__)
        parser.add_argument("--binary", required=True)
        parser.add_argument("--expected-sha256", required=True)
        parser.add_argument("--repository", required=True)
        parser.add_argument("--source-wire", required=True)
        parser.add_argument("--output", required=True)
        probe(parser.parse_args())
