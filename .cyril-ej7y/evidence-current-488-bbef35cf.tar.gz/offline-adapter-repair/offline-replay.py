"""Authorized OFFLINE retained-ANSI comparison only; never launches an App/peer/PTY."""
import codecs
import hashlib
import importlib.metadata as metadata
import importlib.util
import json
from pathlib import Path
import sys
import traceback

RUN = Path('/tmp/cyril-ej7y-current-owned-smoke-978b2605f724442ab6aec1b41e8d7794')
ADAPTER = Path('/tmp/cyril-tqr8-current-consumer-prepared-20261021/wide_overwrite.py')
SITE = Path('/home/dwalleck/.cache/uv/environments-v2/harness-88bb4079c79e84aa/lib/python3.13/site-packages')
SOURCE = Path(__file__).resolve()
RECEIPT = SOURCE.with_suffix('.json')
CONSOLE = SOURCE.with_name(SOURCE.stem + '-console.txt')
report = {'status': 'STARTED', 'scope': 'OFFLINE_BOUNDED_RETAINED_RAW_COMPARISON_ONLY',
          'App_executions': 0, 'peer_executions': 0, 'PTY_operations': 0,
          'network_operations': 0, 'runtime_retry_GO': False,
          'checks': [], 'checkpoints': []}
console = CONSOLE.open('x', encoding='utf-8')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def emit(text):
    print(text, flush=True)
    console.write(text + '\n')
    console.flush()


def check(name, condition, **details):
    report['checks'].append({'name': name, 'pass': bool(condition), **details})
    if not condition:
        raise AssertionError(name)


def projection(screen):
    return [[dict(screen.buffer[y][x]._asdict()) for x in range(screen.columns)]
            for y in range(screen.lines)]


def cursor(screen):
    return {'x': screen.cursor.x, 'y': screen.cursor.y}


def differences(left, right):
    return [{'x': x, 'y': y, 'before': left[y][x], 'after': right[y][x],
             'changed_fields': [key for key in left[y][x] if left[y][x][key] != right[y][x][key]]}
            for y in range(len(left)) for x in range(len(left[y])) if left[y][x] != right[y][x]]


def orphans(screen):
    return sorted((x, y) for y, line in list(screen.buffer.items()) for x, cell in list(line.items())
                  if 0 <= y < screen.lines and 0 <= x < screen.columns and cell.data == ''
                  and (x == 0 or not adapter.wide(line[x - 1])))


try:
    import pyte
    report['runtime'] = {'executable': sys.executable, 'version': sys.version,
                         'pyte': metadata.version('pyte'), 'wcwidth': metadata.version('wcwidth'),
                         'dont_write_bytecode': sys.dont_write_bytecode}
    report['pins'] = {
        'source': {'path': str(SOURCE), 'sha256': sha(SOURCE)},
        'adapter': {'path': str(ADAPTER), 'sha256': sha(ADAPTER)},
        'screens': {'path': str(SITE / 'pyte/screens.py'), 'sha256': sha(SITE / 'pyte/screens.py')},
        'raw': {'path': str(RUN / 'terminal.ansi'), 'sha256': sha(RUN / 'terminal.ansi')},
        'observations': {'path': str(RUN / 'observations.jsonl'), 'sha256': sha(RUN / 'observations.jsonl')},
        'failed_harness': {'path': str(RUN / 'harness.py'), 'sha256': sha(RUN / 'harness.py')},
    }
    check('existing_requested_runtime', sys.version_info[:3] == (3, 13, 9)
          and report['runtime']['pyte'] == '0.8.2' and report['runtime']['wcwidth'] == '0.9.3')
    check('exact_existing_adapter', report['pins']['adapter']['sha256'] ==
          '0ce4ddf57372fb428355dc0f02088fb0fb1a75499ccd796f27b899f34a400beb')
    check('unchanged_pyte_screens', report['pins']['screens']['sha256'] ==
          '43bcd10d5555f6a8e53a1f9c0e557a47ec801b3914533d5b51af5828a5242ecb')
    check('exact_retained_raw', report['pins']['raw']['sha256'] ==
          '6815d0637f3069e29780c35e22c9edadabb46d8835fb8b5d066dc9cabdeddb00')
    check('exact_retained_observations', report['pins']['observations']['sha256'] ==
          '03aabea05c6fed608facb60dda0e9523d71606a794bff1258beb0390169ae26b')
    check('failed_harness_unchanged', report['pins']['failed_harness']['sha256'] ==
          '0d1119a7d740d08f400f1387684a6d4e734b2adbf61f33824c8869c4ac126610')
    raw = (RUN / 'terminal.ansi').read_bytes()
    observations = [json.loads(line) for line in (RUN / 'observations.jsonl').read_text().splitlines() if line]
    check('raw_and_observation_counts', len(raw) == 221366 and len(observations) == 142)
    selected = [item for item in observations if item['permission_id'] == 8005]
    check('bounded_case_and_geometry', len(selected) == 18 and selected[0]['capture'] ==
          '125-comparison-wide-599-initial.txt' and (selected[0]['columns'], selected[0]['rows']) == (80, 48)
          and all((item['columns'], item['rows']) == (40, 40) for item in selected[1:]))
    prior = observations[observations.index(selected[0]) - 1]
    clear = b'\x1b[2J'
    start = raw.rfind(clear, prior['raw_byte_offset'], selected[0]['raw_byte_offset'])
    check('literal_clear_delimiter_in_bounded_resize_frame', start >= prior['raw_byte_offset']
          and raw[start:start + len(clear)] == clear,
          prior_offset=prior['raw_byte_offset'], first_case_offset=selected[0]['raw_byte_offset'], clear_offset=start)
    check('final_saved_boundary', selected[-1]['capture'] == '142-comparison-wide-599-before-pgdn.txt'
          and selected[-1]['raw_byte_offset'] == 220667)
    spec = importlib.util.spec_from_file_location('exact_existing_wide_overwrite_readonly', ADAPTER)
    adapter = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(adapter)
    check('adapter_imported_from_exact_path', Path(adapter.__file__).resolve() == ADAPTER.resolve())
    original, repaired = pyte.Screen(80, 48), adapter.WideOverwrite(80, 48)
    streams = pyte.Stream(original), pyte.Stream(repaired)
    decoder = codecs.getincrementaldecoder('utf-8')('replace')
    offset = start
    report['bounded_replay'] = {
        'raw_start': start, 'raw_end': len(raw), 'bytes': len(raw) - start,
        'clear_literal_hex': clear.hex(), 'clear_literal_asserted': True,
        'initial_dimensions': [80, 48],
        'resize_at_raw_offset': selected[0]['raw_byte_offset'], 'new_dimensions': [40, 40],
        'resize_source': 'Original smoke captures125 immediately before resize(40,40); capture126 and all later case8005 records use40x40.',
        'limits': 'Bounded replay begins at the retained clear delimiter, not the whole earlier multi-resize session. Read chunk boundaries and pre-clear styles were not recorded. Exact saved full-screen literals are checked at every retained case8005 checkpoint; original final in-memory style dump did not exist.'}
    for number, item in enumerate(selected):
        if number == 1:
            original.resize(lines=40, columns=40)
            repaired.resize(lines=40, columns=40)
        end = item['raw_byte_offset']
        text = decoder.decode(raw[offset:end])
        for stream in streams:
            stream.feed(text)
        before, after = projection(original), projection(repaired)
        delta = differences(before, after)
        retained = (RUN / item['capture']).read_bytes()
        original_text = '\n'.join(original.display).encode('utf-8')
        adapter_text = '\n'.join(repaired.display).encode('utf-8')
        record = {'capture': item['capture'], 'raw_offset': end,
                  'dimensions': [original.columns, original.lines],
                  'cells_compared': original.columns * original.lines,
                  'all_cell_fields': list(before[0][0]), 'cell_differences': delta,
                  'cursors': {'original': cursor(original), 'adapter': cursor(repaired)},
                  'retained_text_sha256': hashlib.sha256(retained).hexdigest(),
                  'original_text_exact': original_text == retained,
                  'adapter_text_exact': adapter_text == retained}
        report['checkpoints'].append(record)
        check(item['capture'] + '_literal_original_and_adapter_exact',
              original_text == retained and adapter_text == retained)
        check(item['capture'] + '_cells_styles_and_cursor_unchanged',
              not delta and cursor(original) == cursor(repaired), differences=delta)
        offset = end
    text = decoder.decode(raw[offset:])
    for stream in streams:
        stream.feed(text)
    before, after = projection(original), projection(repaired)
    delta = differences(before, after)
    before_cells = SOURCE.with_name(SOURCE.stem + '-original-final.cells.json')
    after_cells = SOURCE.with_name(SOURCE.stem + '-adapter-final.cells.json')
    before_cells.write_text(json.dumps({'columns': 40, 'rows': 40, 'raw_offset': len(raw),
                                      'cursor': cursor(original), 'rows_data': before}, ensure_ascii=False, indent=2) + '\n')
    after_cells.write_text(json.dumps({'columns': 40, 'rows': 40, 'raw_offset': len(raw),
                                     'cursor': cursor(repaired), 'rows_data': after}, ensure_ascii=False, indent=2) + '\n')
    try:
        original.display
        original_display = {'result': 'UNEXPECTED_SUCCESS'}
    except IndexError as error:
        original_display = {'result': 'RED', 'exception': type(error).__name__,
                            'error': str(error), 'traceback': traceback.format_exc()}
    report['final'] = {'raw_offset': len(raw), 'cells_compared': 1600,
                       'original_display': original_display,
                       'original_orphans': orphans(original), 'adapter_orphans': orphans(repaired),
                       'cursors': {'original': cursor(original), 'adapter': cursor(repaired)},
                       'exact_changed_cells': delta,
                       'original_cells': {'path': str(before_cells), 'sha256': sha(before_cells)},
                       'adapter_cells': {'path': str(after_cells), 'sha256': sha(after_cells)}}
    check('same_retained_final_display_exception_reproduced', original_display.get('exception') == 'IndexError'
          and original_display.get('error') == 'string index out of range' and bool(orphans(original)))
    adapter_display = repaired.display
    repaired_text_path = SOURCE.with_name(SOURCE.stem + '-adapter-final.txt')
    repaired_text_path.write_text('\n'.join(adapter_display), encoding='utf-8')
    report['final']['adapter_display'] = {'result': 'OFFLINE_GREEN', 'rows': len(adapter_display),
                                         'path': str(repaired_text_path), 'sha256': sha(repaired_text_path)}
    check('adapter_display_no_exception_or_orphan', len(adapter_display) == 40 and not orphans(repaired))
    check('final_cursor_unchanged', cursor(original) == cursor(repaired))
    original_orphans = set(orphans(original))
    check('only_orphan_cells_changed_to_spaces', bool(delta)
          and {(item['x'], item['y']) for item in delta} == original_orphans
          and all(item['before']['data'] == '' and item['after']['data'] == ' ' for item in delta),
          exact_differences=delta)
    legitimate = [(x, y) for y in range(40) for x in range(39)
                  if before[y][x]['data'] == '界' and before[y][x + 1]['data'] == '']
    check('legitimate_CJK_pairs_preserved', bool(legitimate)
          and all(before[y][x] == after[y][x] and before[y][x + 1] == after[y][x + 1]
                  for x, y in legitimate), pair_count=len(legitimate))
    check('literal_retained_tail_visible_not_filtered', 'TAIL_ID' in '\n'.join(adapter_display))
    report['literal_fidelity'] = {'retained_checkpoint_texts_exact': len(selected),
                                  'all_fields_compared_before_after': True,
                                  'only_invalid_empty_stub_cells_change_to_spaces': True,
                                  'legitimate_CJK_pairs_unchanged': len(legitimate),
                                  'TAIL_ID_literal_visible': True,
                                  'adapter_source_byte_exact': True,
                                  'production_or_harness_or_raw_source_writes': 0,
                                  'display_exception_to_success_fallback': False}
    report['status'] = 'OFFLINE_COMPARISON_PASS_ORIGINAL_LIVE_ATTEMPT_STILL_FAIL'
    emit('ORIGINAL_FINAL RED IndexError; raw_end=' + str(len(raw)) + '; orphans=' + repr(orphans(original)))
    emit('ADAPTER_FINAL OFFLINE_GREEN; changed_cells=' + json.dumps(delta, ensure_ascii=False, sort_keys=True))
    emit('LITERAL_FIDELITY checkpoint_texts=' + str(len(selected)) + '; CJK_pairs=' + str(len(legitimate)) + '; TAIL_ID visible; adapter exact0ce4ddf; no App/peer/PTY/runtime retry')
except BaseException as error:
    report['status'] = 'OFFLINE_UNEXPECTED_FAILURE_STOPPED'
    report['failure'] = {'type': type(error).__name__, 'error': str(error), 'traceback': traceback.format_exc()}
    emit(report['failure']['traceback'].rstrip('\n'))
finally:
    console.flush()
    report['console'] = {'path': str(CONSOLE), 'sha256': sha(CONSOLE), 'bytes': CONSOLE.stat().st_size}
    RECEIPT.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    console.close()
raise SystemExit(0 if report['status'] == 'OFFLINE_COMPARISON_PASS_ORIGINAL_LIVE_ATTEMPT_STILL_FAIL' else 1)
