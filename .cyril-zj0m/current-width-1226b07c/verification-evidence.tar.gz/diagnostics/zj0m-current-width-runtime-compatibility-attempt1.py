import hashlib, inspect, json, os, runpy, signal, sys
from pathlib import Path
import pyte, pyte.screens, wcwidth
proof = Path('/tmp/cyril-perf-consumer-20261020/zj0m-current-width-offline-completion.py')
assert hashlib.sha256(proof.read_bytes()).hexdigest() == 'e0e744c261b360693a6352ca5225b452a1099bc836636bff718d7da6ce15ffd6'
assert hasattr(os, 'pidfd_open') and hasattr(signal, 'pidfd_send_signal')
module_paths = {'pyte': pyte.__file__, 'pyte.Screen': inspect.getsourcefile(pyte.Screen), 'wcwidth': wcwidth.__file__, 'pyte.screens.wcwidth': inspect.getsourcefile(pyte.screens.wcwidth)}
assert all(path and str(Path(path).resolve()).startswith('/home/dwalleck/.cache/uv/environments-v2/smoke-dfb66bf98567089b/lib/python3.13/site-packages/') for path in module_paths.values())
print('RUNTIME_COMPATIBILITY ' + json.dumps({'python': sys.executable, 'python_resolved': str(Path(sys.executable).resolve()), 'version': sys.version, 'PYTHONPATH': os.environ['PYTHONPATH'], 'PYTHONDONTWRITEBYTECODE': os.environ['PYTHONDONTWRITEBYTECODE'], 'pidfd_open': hasattr(os, 'pidfd_open'), 'pidfd_send_signal': hasattr(signal, 'pidfd_send_signal'), 'module_paths': module_paths, 'source_sha256': {name: hashlib.sha256(Path(path).read_bytes()).hexdigest() for name, path in module_paths.items()}}, sort_keys=True), flush=True)
runpy.run_path(str(proof), run_name='__main__')
