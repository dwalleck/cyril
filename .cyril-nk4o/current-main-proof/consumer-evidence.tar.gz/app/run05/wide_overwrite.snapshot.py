import unicodedata

import pyte
from pyte import modes as mo
from pyte.screens import wcwidth


def wide(cell):return bool(cell.data) and wcwidth(cell.data[0])==2
class WideOverwrite(pyte.Screen):
    def draw(self,data):
        for ch in data:
            translated=ch.translate(self.g1_charset if self.charset else self.g0_charset)
            w=wcwidth(translated);old_x=self.cursor.x
            super().draw(ch)
            if w>0:
                start=old_x
                if old_x==self.columns:start=0 if mo.DECAWM in self.mode else old_x-w
                end=min(start+w,self.columns);line=self.buffer[self.cursor.y]
                if start>0 and wide(line[start-1]):line[start-1]=self.cursor.attrs._replace(data=' ')
                if end<self.columns and line[end].data=='' and not wide(line[end-1]):line[end]=self.cursor.attrs._replace(data=' ')
            elif w<0 or not unicodedata.combining(translated):return
