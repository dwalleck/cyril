#!/usr/bin/env -S uv run --offline --script
# /// script
# dependencies = ["pyte==0.8.2"]
# ///
"""Scratch-only actual-App owned ACP proof; never native KAS compatibility.
Reuses perf consumer PTY/pyte capture and Tqr owned KAS Node launch patterns.
No session/prompt, model operation, host callback, grant, browser or clipboard.
"""
import argparse
import codecs
import fcntl
import hashlib
import json
import os
from pathlib import Path
import pty
import select
import shutil
import signal
import struct
import subprocess
import sys
import tempfile
import termios
import time
import traceback

HERE = Path(__file__).resolve().parent
SID = 'sess_70000000-0000-4000-8000-000000000041'
BINARY = Path('/tmp/cyril-nk4o-current-main-repaired-default-App-qualified-20261022T034909219765Z')
BINARY_SHA = '704ee83b3098a1167d28e5b22a0afaf57a54b497e89a45ba4be048a6fd7f04c8'
BINARY_BYTES = 104597616
STAGE = Path('/tmp/cyril-nk4o-current-main-owned-consumer-prepare-McpLifecycle-03f68b427128')
OUTPUT = STAGE / 'run05'
SCOPE = 'nk4o-current-owned-readonly-consumer'
SOURCE_BINDING = {
    'kind': 'typed-current521-source-descriptor-not-git-tree',
    'postformat_source_descriptor': '03f68b427128d98b1d11aee19a287338cb2e54590964e2d02d6dd8fdd8bd8d63',
    'postformat_source_input_rows': 521,
    'HEAD': 'ef46c43813d12b63f45b264e427abda84d299f46',
    'held_MERGE_HEAD': '09e41ddd0306567b9430ea3216902f895fc96370',
    'original_index_sha256': 'e172cc2b54e090f7ad7f9ce1a52fbf868bfa39ebbcbf955871b6159a8099b56f',
    'final_canonical_source_receipt': '/home/dwalleck/.claude/tmp/cyril-batch3-qualification-20261020-ipe924db/nk4o-current-main-integration-repaired-green-attempt1/canonical-handoff.json',
    'final_canonical_source_receipt_sha256': 'ed0f7dc582a493951eb3257704287d88f99887a471d5c6a4b6fab6cd73f77b65',
}
FAKE_SOURCE = HERE / 'fake-kiro-cli.sh'
FAKE_SHA = '61586cd278cb555d29f84b49805a1811705112713d0b6774feec42310d0ced6d'
ADAPTER_SOURCE = HERE / 'wide_overwrite.py'
ADAPTER_SHA = '0ce4ddf57372fb428355dc0f02088fb0fb1a75499ccd796f27b899f34a400beb'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + f'.{os.getpid()}.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    os.replace(temporary, path)


def journal(path, value):
    with Path(path).open('a') as stream:
        stream.write(json.dumps(value, ensure_ascii=False) + '\n')

def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def process_identity(pid):
    """Linux start ticks disambiguate a current process from a reused PID."""
    base = Path('/proc') / str(pid)
    try:
        before = (base / 'stat').read_text().rsplit(')', 1)[1].split()
        access_errors = []
        try:
            argv = (base / 'cmdline').read_bytes().split(b'\0')
            if argv and argv[-1] == b'':
                argv.pop()
        except PermissionError as error:
            argv = []
            access_errors.append(repr(error))
        try:
            executable = os.readlink(base / 'exe')
        except FileNotFoundError:
            executable = None
        except PermissionError as error:
            executable = None
            access_errors.append(repr(error))
        after = (base / 'stat').read_text().rsplit(')', 1)[1].split()
    except (FileNotFoundError, ProcessLookupError):
        return None
    if before[19] != after[19]:
        return None
    return {'pid': pid, 'ppid': int(after[1]), 'pgid': int(after[2]),
            'session': int(after[3]), 'start_ticks': int(after[19]),
            'state': after[0], 'exe': executable,
            'argv': [os.fsdecode(value) for value in argv], 'access_errors': access_errors}


def process_table():
    result = {}
    for entry in Path('/proc').iterdir():
        if entry.name.isdecimal():
            try:
                identity = process_identity(int(entry.name))
            except PermissionError:
                # Unreadable unrelated proc entries do not suppress own PIDs.
                continue
            if identity is not None:
                result[identity['pid']] = identity
    return result


def identity_key(identity):
    return identity['pid'], identity['start_ticks']



class Consumer:
    def __init__(self, args):
        # No setup or spawn here: every resource is reachable by outer finally.
        self.args = args
        self.root = None
        self.auth = None
        self.temporary = self.scratch = None
        self.master = self.slave = self.raw = self.process = None
        self.screen = None
        self.started = time.monotonic()
        self.offset = self.sequence = 0
        self.checks, self.captures = [], []
        self.identities, self.process_observations = {}, []
        self.cyril_identity = None
        self.input_digests = {}
        self.cleanup_errors = []
        self.finished = False
        self.result = None

    def prepare(self):
        output = Path(self.args.output)
        require(output.is_absolute() and str(output) == str(OUTPUT) and output.resolve() == OUTPUT,
                'Required fresh absolute output binding is '+str(OUTPUT))
        require(HERE == STAGE and Path(__file__).resolve() == STAGE / 'harness.py',
                'Runner must be the reviewed fresh-stage harness')
        require(sys.flags.optimize == 0 and __debug__, 'Optimized Python is forbidden')
        authorization = Path(self.args.authorization)
        require(authorization.is_absolute() and authorization.is_file() and not authorization.is_symlink(),
                'Explicit absolute authorization file is required; no fallback')
        auth_bytes = authorization.read_bytes()
        self.auth = json.loads(auth_bytes)
        require(isinstance(self.auth, dict), 'Authorization must be a JSON object')
        require(self.auth.get('go') is True, 'No fresh runtime GO: authorization is missing or held')
        require(self.auth.get('authorized_by') == 'Main' and
                isinstance(self.auth.get('authorization_source'), str) and
                self.auth['authorization_source'].startswith('Main runtime GO:') and
                bool(self.auth['authorization_source'].removeprefix('Main runtime GO:').strip()),
                'Explicit fresh Main runtime GO is required')
        expected = {'scope': SCOPE, 'output': str(OUTPUT), 'binary': str(BINARY),
                    'sha256': BINARY_SHA, 'bytes': BINARY_BYTES,
                    'source_binding': SOURCE_BINDING, 'fake_cli_sha256': FAKE_SHA,
                    'adapter_sha256': ADAPTER_SHA}
        for key, value in expected.items():
            require(self.auth.get(key) == value, 'Authorization binding mismatch: '+key)
        harness_bytes = Path(__file__).read_bytes()
        harness_sha = hashlib.sha256(harness_bytes).hexdigest()
        require(self.auth.get('harness_sha256') == harness_sha,
                'Authorization must bind the final statically reviewed harness')
        fake_bytes = FAKE_SOURCE.read_bytes()
        require(hashlib.sha256(fake_bytes).hexdigest() == FAKE_SHA and not FAKE_SOURCE.is_symlink(),
                'Fake CLI must be the identical staged regular file')
        adapter_bytes = ADAPTER_SOURCE.read_bytes()
        require(hashlib.sha256(adapter_bytes).hexdigest() == ADAPTER_SHA and not ADAPTER_SOURCE.is_symlink(),
                'Adapter must be the unchanged reviewed staged regular file')
        require(BINARY.is_file() and not BINARY.is_symlink() and
                BINARY.stat().st_size == BINARY_BYTES and
                BINARY.stat().st_mode & 0o7777 == 0o755 and sha(BINARY) == BINARY_SHA,
                'Exact current binary path/hash/bytes/mode required')
        receipt_path = Path(SOURCE_BINDING['final_canonical_source_receipt'])
        receipt_bytes = receipt_path.read_bytes()
        require(hashlib.sha256(receipt_bytes).hexdigest() ==
                SOURCE_BINDING['final_canonical_source_receipt_sha256'],
                'Final canonical source receipt hash mismatch')
        receipt = json.loads(receipt_bytes)
        require(all(receipt.get(key) == SOURCE_BINDING[key] for key in [
                    'postformat_source_descriptor', 'postformat_source_input_rows',
                    'HEAD', 'held_MERGE_HEAD', 'original_index_sha256']),
                'Canonical typed current source descriptors mismatch')
        pinned = receipt.get('private_binaries', {}).get('default-App', {})
        require(all(pinned.get(key) == value for key, value in {
                    'private_path': str(BINARY), 'sha256': BINARY_SHA, 'bytes': BINARY_BYTES,
                    'mode': '0o755',
                    'source_descriptor': SOURCE_BINDING['postformat_source_descriptor'],
                    'source_input_rows': SOURCE_BINDING['postformat_source_input_rows'],
                    'HEAD': SOURCE_BINDING['HEAD'],
                    'held_MERGE_HEAD': SOURCE_BINDING['held_MERGE_HEAD']}.items()),
                'Canonical current private binary/source binding mismatch')
        totals = receipt.get('command_totals', {})
        commands = receipt.get('commands', [])
        require(all(totals.get(key) == value for key, value in {
                    'actual_commands': 40, 'all_exit0': 40,
                    'unexpected_failures': 0, 'retries': 0}.items()) and
                isinstance(commands, list) and len(commands) == 40 and
                all(isinstance(command, dict) and command.get('returncode') == 0
                    for command in commands) and
                receipt.get('source_freeze') ==
                    'RELEASED_WITH_IMMUTABLE_CANONICAL_MAIN_OWNS_SUBSEQUENT_SOURCE_OR_RUNTIME_GO' and
                receipt.get('status') ==
                    'PASS_ALL40_AUTHORIZED_LOCAL_NK_REPAIRED_GREEN_COMBINED_CARGO_GATES_NOT_FULL_NATIVE_CONSUMER_REVIEW_CI_PUBLICATION_ACCEPTANCE',
                'Canonical remaining qualification gates are not complete')
        stability = receipt.get('guards', [])
        require(isinstance(stability, list) and len(stability) == 81 and
                stability[-1].get('phase') == 'final-canonical521-source-refscope-pin' and
                all(isinstance(guard, dict) and
                    all(guard.get(key) is True for key in [
                        'all521_inputs_exact', 'HEAD_value_exact',
                        'HEAD_ref_text_exact', 'held_MERGE_HEAD_exact']) and
                    guard.get('initial_raw_index_sha256') == SOURCE_BINDING['original_index_sha256'] and
                    guard.get('observed_raw_index_sha256') == SOURCE_BINDING['original_index_sha256']
                    for guard in stability),
                'Canonical final source stability mismatch')
        output.mkdir(exist_ok=False)
        self.root = output
        import pyte
        import wide_overwrite
        adapter_module = Path(wide_overwrite.__file__).resolve(strict=True)
        require(adapter_module == ADAPTER_SOURCE, 'Imported adapter must be the exact staged module')
        self.temporary = tempfile.TemporaryDirectory(prefix='cyril-owned-mcp-isolated-')
        self.scratch = Path(self.temporary.name)
        for name in ['bin', 'home', 'config', 'data', 'cache', 'state', 'runtime', 'tmp', 'ws']:
            (self.scratch / name).mkdir()
        self.binary = self.scratch / 'cyril-qualified'
        shutil.copyfile(BINARY, self.binary)
        self.binary.chmod(0o500)
        require(self.binary.stat().st_size == BINARY_BYTES and sha(self.binary) == BINARY_SHA,
                'Frozen current binary mismatch')
        self.fake = self.scratch / 'bin/kiro-cli'
        self.fake.write_bytes(fake_bytes)
        self.fake.chmod(0o555)
        self.frozen = self.scratch / 'harness.py'
        self.frozen.write_bytes(harness_bytes)
        self.frozen.chmod(0o444)
        node = shutil.which('node')
        require(node is not None, 'Absolute Node executable is required')
        self.node = Path(node).resolve(strict=True)
        self.python = Path(sys.executable).resolve(strict=True)
        self.server = self.scratch / 'owned-server.js'
        self.server.write_text("const {spawn}=require('node:child_process');" +
                               f"const c=spawn({json.dumps(str(self.python))},[{json.dumps(str(self.frozen))},'peer'],{{stdio:'inherit'}});" +
                               "c.on('exit',n=>process.exit(n??1));process.on('SIGTERM',()=>c.kill('SIGTERM'));")
        self.server.chmod(0o444)
        self.config = self.scratch / 'home/.config/cyril/config.toml'
        self.config.parent.mkdir(parents=True)
        self.config.write_text('[agent]\nengine = "kas"\nkas_hooks = "off"\n[memory]\nenabled = false\n')
        self.config.chmod(0o444)
        self.config_sha = sha(self.config)
        self.environment = {
            'TERM': 'xterm-256color', 'COLORTERM': 'truecolor', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
            'PATH': str(self.scratch / 'bin'), 'SHELL': '/bin/bash',
            'HOME': str(self.scratch / 'home'), 'USERPROFILE': str(self.scratch / 'home'),
            'XDG_CONFIG_HOME': str(self.scratch / 'config'), 'XDG_DATA_HOME': str(self.scratch / 'data'),
            'XDG_CACHE_HOME': str(self.scratch / 'cache'), 'XDG_STATE_HOME': str(self.scratch / 'state'),
            'XDG_RUNTIME_DIR': str(self.scratch / 'runtime'), 'TMPDIR': str(self.scratch / 'tmp'),
            'KIRO_HOME': str(self.scratch / 'home/.kiro'), 'KIRO_AGENT_PATH': str(self.node),
            'KIRO_KAS_SERVER_PATH': str(self.server), 'OWNED_MCP_OUTPUT': str(self.root),
        }
        self.command = ['/usr/bin/env', '-i'] + [f'{key}={value}' for key, value in self.environment.items()] + [str(self.binary), '--cwd', str(self.scratch / 'ws'), '--agent-engine', 'kas']
        for path, data in [
                (self.root / 'authorization.snapshot.json', auth_bytes),
                (self.root / 'canonical-source.snapshot.json', receipt_bytes),
                (self.root / 'harness.snapshot.py', harness_bytes),
                (self.root / 'wide_overwrite.snapshot.py', adapter_bytes),
                (self.root / 'owned-server.snapshot.js', self.server.read_bytes()),
                (self.root / 'fake-kiro-cli.snapshot.sh', fake_bytes),
                (self.root / 'config.snapshot.toml', self.config.read_bytes())]:
            path.write_bytes(data)
            path.chmod(0o444)
            self.input_digests[path] = hashlib.sha256(data).hexdigest()
        for path in [authorization, Path(__file__), FAKE_SOURCE, adapter_module, receipt_path, BINARY,
                     self.binary, self.fake, self.frozen, self.server, self.config, self.node, self.python]:
            self.input_digests[path] = sha(path)
        require(self.input_digests[authorization] == hashlib.sha256(auth_bytes).hexdigest() and
                self.input_digests[Path(__file__)] == harness_sha and
                self.input_digests[FAKE_SOURCE] == FAKE_SHA and
                self.input_digests[ADAPTER_SOURCE] == ADAPTER_SHA and
                self.input_digests[receipt_path] == SOURCE_BINDING['final_canonical_source_receipt_sha256'] and
                self.input_digests[BINARY] == BINARY_SHA and
                self.input_digests[self.binary] == BINARY_SHA and
                self.input_digests[self.fake] == FAKE_SHA and
                self.input_digests[self.frozen] == harness_sha and
                self.input_digests[self.server] == self.input_digests[self.root / 'owned-server.snapshot.js'] and
                self.input_digests[self.config] == self.config_sha,
                'Safety input changed while freezing')
        save(self.root / 'safety.json', {
            'authorization': self.auth, 'authorization_path': str(authorization),
            'source_binding': SOURCE_BINDING, 'argv': self.command, 'environment': self.environment,
            'binary_sha256': BINARY_SHA, 'harness_sha256': harness_sha,
            'adapter_sha256': ADAPTER_SHA, 'adapter_module': str(adapter_module),
            'fake_cli_sha256': FAKE_SHA, 'fake_cli_mode': oct(self.fake.stat().st_mode & 0o777),
            'binary_mode': oct(self.binary.stat().st_mode & 0o777),
            'peer_mode': oct(self.frozen.stat().st_mode & 0o777),
            'node': str(self.node), 'node_sha256': self.input_digests[self.node],
            'python': str(self.python), 'python_sha256': self.input_digests[self.python],
            'owned_server_js_sha256': self.input_digests[self.server],
            'config_sha256': self.config_sha, 'scope': SCOPE,
            'frozen_inputs': {str(path): digest for path, digest in self.input_digests.items()},
            'evidence_layer': 'actual qualified Cyril -> PTY ANSI -> pyte/WideOverwrite decoded cells; owned protocol fixtures, not native KAS/native terminal/glyph acceptance',
        })
        (self.root / 'safety.json').chmod(0o444)
        self.input_digests[self.root / 'safety.json'] = sha(self.root / 'safety.json')
        self.columns, self.rows = 160, 48
        self.screen = wide_overwrite.WideOverwrite(self.columns, self.rows)
        self.stream = pyte.Stream(self.screen)
        self.decoder = codecs.getincrementaldecoder('utf-8')('replace')
        self.raw = (self.root / 'terminal.ansi').open('wb')
        self.master, self.slave = pty.openpty()
        os.set_blocking(self.master, False)
        fcntl.ioctl(self.slave, termios.TIOCSWINSZ, struct.pack('HHHH', self.rows, self.columns, 0, 0))

    def start(self):
        require(BINARY.stat().st_size == BINARY_BYTES and BINARY.stat().st_mode & 0o7777 == 0o755,
                'Current binary metadata changed before spawn')
        for path, mode in [(self.binary, 0o500), (self.fake, 0o555),
                           (self.frozen, 0o444), (self.server, 0o444), (self.config, 0o444)]:
            require(path.stat().st_mode & 0o7777 == mode, 'Frozen safety mode changed: '+str(path))
        for path, digest in self.input_digests.items():
            require(sha(path) == digest, 'Frozen safety input changed before spawn: '+str(path))
        pending_interrupt = False
        start_failed = False
        previous_sigint = signal.getsignal(signal.SIGINT)

        def defer_sigint(signum, frame):
            nonlocal pending_interrupt
            pending_interrupt = True

        try:
            # A caught disposition resets on exec; do not alter inherited masks.
            # Preserve an explicitly ignored disposition in both parent/child.
            if previous_sigint != signal.SIG_IGN:
                signal.signal(signal.SIGINT, defer_sigint)
            self.process = subprocess.Popen(self.command, stdin=self.slave, stdout=self.slave, stderr=self.slave,
                                            env={}, cwd=self.scratch / 'ws', start_new_session=True)
            self.cyril_identity = process_identity(self.process.pid)
            require(self.cyril_identity is not None, 'Current Cyril start identity unavailable')
            require(self.cyril_identity['pgid'] == self.process.pid and
                    self.cyril_identity['session'] == self.process.pid,
                    'Current Cyril must own its separate session/group')
            self.remember_process(self.cyril_identity, 'direct-owned-Cyril')
            save(self.root / 'cyril-start-identity.json', self.cyril_identity)
        except BaseException:
            start_failed = True
            raise
        finally:
            if start_failed:
                # Restoration failure must not replace the primary spawn error.
                self.cleanup_attempt('restore-SIGINT-after-start-failure',
                                     lambda: signal.signal(signal.SIGINT, previous_sigint))
            else:
                signal.signal(signal.SIGINT, previous_sigint)
        if pending_interrupt:
            raise KeyboardInterrupt('SIGINT deferred until owned App identity was registered')
        os.close(self.slave)
        self.slave = None
        self.observe_owned()

    def remember_process(self, identity, proof):
        key = identity_key(identity)
        previous = self.identities.get(key)
        chosen_proof = proof if proof.startswith('unique-current-scratch-owned-') else previous['proof'] if previous else proof
        record = {**identity, 'proof': chosen_proof}
        if previous != record:
            self.identities[key] = record
            self.process_observations.append({**record, 'seconds': time.monotonic()-self.started})

    def observe_owned(self):
        if self.process is None:
            return {}
        table = process_table()
        direct = table.get(self.process.pid)
        if self.cyril_identity is None and direct is not None and direct['ppid'] == os.getpid():
            # Popen succeeded but recording failed: only that still-current child.
            self.cyril_identity = direct
        if direct is not None and self.cyril_identity is not None and identity_key(direct) == identity_key(self.cyril_identity):
            self.remember_process(direct, 'direct-owned-Cyril')
        for identity in table.values():
            argv = identity['argv']
            if identity['exe'] == str(self.node) and str(self.server) in argv:
                self.remember_process(identity, 'unique-current-scratch-owned-Node')
            elif identity['exe'] == str(self.python) and argv == [str(self.python), str(self.frozen), 'peer']:
                self.remember_process(identity, 'unique-current-scratch-owned-Python')
        # Descendants are proved from live start identities, not names/old PIDs.
        changed = True
        while changed:
            changed = False
            for identity in table.values():
                if identity_key(identity) in self.identities:
                    self.remember_process(identity, self.identities[identity_key(identity)]['proof'])
                    continue
                parent = table.get(identity['ppid'])
                if (parent is not None and identity_key(parent) in self.identities and
                        identity['start_ticks'] >= parent['start_ticks']):
                    self.remember_process(identity, 'current-owned-descendant')
                    changed = True
        save(self.root / 'owned-process-identities.json', {
            'cyril_start': self.cyril_identity, 'observations': self.process_observations,
            'peer_groups': sorted({item['pgid'] for item in self.identities.values()
                                   if item['proof'].startswith('unique-current-scratch-owned-')}),
            'current_owned': [item for item in table.values() if identity_key(item) in self.identities],
            'current_ancestry': self.owned_ancestry(table),
        })
        return table

    def owned_ancestry(self, table):
        result = []
        for owned in table.values():
            if identity_key(owned) not in self.identities:
                continue
            chain, seen, current = [], set(), owned
            while current is not None and current['pid'] not in seen:
                chain.append(current)
                seen.add(current['pid'])
                if current['pid'] in (os.getpid(), 1):
                    break
                current = table.get(current['ppid'])
            result.append(chain)
        return result

    def event(self, kind, **value):
        journal(self.root / 'events.jsonl', {'seconds': time.monotonic()-self.started, 'kind': kind, **value})

    def drain(self, seconds=0.2):
        self.observe_owned()
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            ready, _, _ = select.select([self.master], [], [], max(0, end-time.monotonic()))
            if not ready:
                break
            try:
                chunk = os.read(self.master, 65536)
            except OSError:
                break
            if not chunk:
                break
            self.raw.write(chunk)
            self.raw.flush()
            self.offset += len(chunk)
            self.stream.feed(self.decoder.decode(chunk))
        self.observe_owned()

    def text(self):
        return '\n'.join(self.screen.display)

    def wait(self, predicate, label, timeout=15):
        deadline = time.monotonic()+timeout
        while not predicate():
            if self.process.poll() is not None or time.monotonic() > deadline:
                raise AssertionError(f'{label}; exit={self.process.poll()}\n{self.text()}')
            self.drain(0.1)
        self.drain(0.15)

    def visible(self, *needles):
        self.wait(lambda: all(value in self.text() for value in needles), 'Expected visible: '+repr(needles))

    def capture(self, name):
        self.drain()
        (self.root / f'{name}.txt').write_text(self.text()+'\n')
        save(self.root / f'{name}.cells.json', {'columns': self.columns, 'rows': self.rows,
             'ansi_end_offset': self.offset, 'cursor': {'x': self.screen.cursor.x, 'y': self.screen.cursor.y},
             'rows_data': [[dict(self.screen.buffer[y][x]._asdict()) for x in range(self.columns)] for y in range(self.rows)]})
        self.captures.append({'name': name, 'ansi_end_offset': self.offset})
        self.event('capture', name=name, ansi_end_offset=self.offset)

    def check(self, label, condition, **details):
        self.checks.append({'assertion': label, 'pass': bool(condition), **details})
        if not condition:
            raise AssertionError(label+': '+repr(details))

    def send(self, text):
        self.event('terminal-input', text=text)
        os.write(self.master, text.encode())
        self.drain(0.25)

    def paste(self, text):
        self.send('\x1b[200~'+text+'\x1b[201~')

    def command_input(self, text):
        self.paste(text)
        self.send('\r')

    def control(self, action):
        self.sequence += 1
        self.event('peer-control', sequence=self.sequence, action=action)
        save(self.root / f'control-{self.sequence:04d}.json', {'action': action})
        ack = self.root / f'ack-{self.sequence:04d}.json'
        self.wait(ack.exists, 'Owned peer control acknowledgement')
        assert json.loads(ack.read_text())['ok'] is True
        self.drain(0.2)

    def wire(self):
        file = self.root / 'client-wire.jsonl'
        return [json.loads(line) for line in file.read_text().splitlines()] if file.exists() else []

    def requests(self, method):
        return [frame for frame in self.wire() if frame.get('method') == method]

    def resize(self, columns, rows):
        self.event('resize', columns=columns, rows=rows)
        fcntl.ioctl(self.master, termios.TIOCSWINSZ, struct.pack('HHHH', rows, columns, 0, 0))
        self.screen.resize(lines=rows, columns=columns)
        self.columns, self.rows = columns, rows
        os.killpg(self.process.pid, signal.SIGWINCH)
        self.drain(0.5)

    def cleanup_attempt(self, step, operation):
        try:
            return operation()
        except BaseException as error:
            entry = {'step': step, 'error': repr(error)}
            if entry not in self.cleanup_errors:
                self.cleanup_errors.append(entry)
            return None

    def remaining_owned(self):
        remaining = []
        for recorded in list(self.identities.values()):
            current = process_identity(recorded['pid'])
            if current is not None and identity_key(current) == identity_key(recorded):
                remaining.append(current)
        return remaining

    def wait_owned_exit(self, seconds):
        deadline = time.monotonic()+seconds
        while True:
            if self.process is not None:
                self.cleanup_attempt('reap-poll', self.process.poll)
            self.cleanup_attempt('discover-owned-during-exit', self.observe_owned)
            remaining = self.cleanup_attempt('read-owned-during-exit', self.remaining_owned)
            if remaining == [] or time.monotonic() >= deadline:
                return
            time.sleep(min(0.05, max(0, deadline-time.monotonic())))

    def signal_pid(self, recorded, requested_signal):
        current = process_identity(recorded['pid'])
        if current is None or identity_key(current) != identity_key(recorded):
            return
        require(current['pid'] > 1 and current['pid'] != os.getpid() and
                current['pgid'] > 1 and current['pgid'] != os.getpgrp(),
                'Refusing unsafe owned PID/group')
        if current['state'] == 'Z':
            return
        try:
            os.kill(current['pid'], requested_signal)
        except ProcessLookupError:
            return
        self.signal_receipts.append({'signal': requested_signal.name, 'target': 'verified-PID',
                                     'identity': current})

    def signal_group(self, pgid, members, requested_signal):
        require(pgid > 1 and pgid != os.getpgrp(), 'Refusing zero/own/unproven group')
        require(all(identity_key(item) in self.identities for item in members),
                'Refusing group with unproven current member')
        verified = []
        for recorded in members:
            current = process_identity(recorded['pid'])
            if current is None:
                continue
            require(identity_key(current) == identity_key(recorded) and current['pgid'] == pgid,
                    'Process start/group identity changed before group signal')
            require(current['pid'] > 1 and current['pid'] != os.getpid(),
                    'Refusing group containing harness or init')
            verified.append(current)
        if not any(item['state'] != 'Z' for item in verified):
            return []
        try:
            os.killpg(pgid, requested_signal)
        except ProcessLookupError:
            return []
        self.signal_receipts.append({'signal': requested_signal.name, 'target': 'verified-group',
                                     'pgid': pgid, 'members': verified})
        return [identity_key(item) for item in verified]

    def signal_owned(self, requested_signal):
        if self.process is None:
            return
        self.cleanup_attempt('discover-before-'+requested_signal.name, self.observe_owned)
        table = self.cleanup_attempt('read-groups-before-'+requested_signal.name, process_table)
        signalled = set()
        if table is not None:
            groups = {item['pgid'] for item in table.values() if identity_key(item) in self.identities}
            for pgid in sorted(groups):
                members = [item for item in table.values() if item['pgid'] == pgid]
                keys = self.cleanup_attempt('signal-group-'+str(pgid)+'-'+requested_signal.name,
                                            lambda: self.signal_group(pgid, members, requested_signal))
                signalled.update(keys or [])
        # A failed group read/validation never prevents exact-identity fallback.
        for recorded in list(self.identities.values()):
            if identity_key(recorded) not in signalled:
                self.cleanup_attempt('signal-PID-'+str(recorded['pid'])+'-'+requested_signal.name,
                                     lambda: self.signal_pid(recorded, requested_signal))

    def graceful_exit(self):
        if self.process is None or self.master is None:
            return
        current = process_identity(self.process.pid)
        if current is None or current['state'] == 'Z':
            return
        require(self.cyril_identity is not None and
                identity_key(current) == identity_key(self.cyril_identity) and
                current['pgid'] != os.getpgrp(), 'Unverified Cyril identity before graceful exit')
        os.write(self.master, b'\x11')

    def close_descriptor(self, name):
        descriptor = getattr(self, name)
        if descriptor is not None:
            os.close(descriptor)
            setattr(self, name, None)

    def preserved_cells(self):
        return {'columns': self.columns, 'rows': self.rows, 'ansi_end_offset': self.offset,
                'cursor': {'x': self.screen.cursor.x, 'y': self.screen.cursor.y},
                'rows_data': [[dict(self.screen.buffer[y][x]._asdict())
                               for x in range(self.columns)] for y in range(self.rows)]}

    def finish(self, outcome, original_failure=None):
        if self.finished:
            return self.result
        self.finished = True
        self.signal_receipts = []
        cleanup = {'signals': self.signal_receipts, 'no_private_native_logs_read': True}
        # Every preservation step is independent of termination and later steps.
        if self.root is not None:
            if original_failure is not None:
                self.cleanup_attempt('record-original-failure',
                                     lambda: save(self.root / 'original-failure.json', original_failure))
            if self.screen is not None:
                if self.master is not None:
                    self.cleanup_attempt('capture-before-cleanup',
                                         lambda: self.capture('final' if outcome == 'PASS' else 'FAILED-preserved-screen'))
                self.cleanup_attempt('preserve-screen-without-PTY',
                                     lambda: (self.root / 'pre-cleanup-screen.txt').write_text(self.text()+'\n'))
                self.cleanup_attempt('preserve-cells-without-PTY',
                                     lambda: save(self.root / 'pre-cleanup-cells.json', self.preserved_cells()))
            if self.raw is not None:
                self.cleanup_attempt('flush-original-ANSI', self.raw.flush)
            for name in ['terminal.ansi', 'events.jsonl', 'client-wire.jsonl', 'peer-wire.jsonl', 'peer-state.json']:
                def preserve(name=name):
                    source = self.root / name
                    if source.exists():
                        shutil.copyfile(source, self.root / ('pre-cleanup.'+name))
                self.cleanup_attempt('preserve-'+name, preserve)
        # No capture, read, hash, PTY write, or record failure can skip these.
        self.cleanup_attempt('discover-owned-before-exit', self.observe_owned)
        self.cleanup_attempt('close-parent-slave', lambda: self.close_descriptor('slave'))
        self.cleanup_attempt('graceful-owned-App-exit', self.graceful_exit)
        self.cleanup_attempt('wait-graceful-App-and-peer-groups', lambda: self.wait_owned_exit(5))
        self.cleanup_attempt('TERM-owned-App-and-separate-peer-groups', lambda: self.signal_owned(signal.SIGTERM))
        self.cleanup_attempt('wait-after-TERM', lambda: self.wait_owned_exit(2))
        self.cleanup_attempt('KILL-owned-App-and-separate-peer-groups', lambda: self.signal_owned(signal.SIGKILL))
        self.cleanup_attempt('wait-after-KILL', lambda: self.wait_owned_exit(2))
        if self.process is not None:
            self.cleanup_attempt('reap-direct-child', lambda: self.process.wait(timeout=0.5))
            cleanup['owned_process_returncode'] = self.process.returncode
            if self.process.returncode is None:
                self.cleanup_errors.append({'step': 'reap-direct-child', 'error': 'Direct owned child not reaped'})
        final_table = self.cleanup_attempt('record-final-owned-identities', self.observe_owned)
        remaining = self.cleanup_attempt('final-owned-identity-absence', self.remaining_owned)
        cleanup['remaining_owned_identities'] = remaining
        peer_groups = sorted({item['pgid'] for item in self.identities.values()
                              if item['proof'].startswith('unique-current-scratch-owned-')})
        cleanup['observed_peer_groups'] = peer_groups
        cleanup['owned_peer_groups_absent'] = (final_table is not None and all(
            not any(item['pgid'] == pgid for item in final_table.values()) for pgid in peer_groups))
        cleanup['all_owned_identities_absent'] = remaining == []
        if remaining != [] or not cleanup['owned_peer_groups_absent']:
            self.cleanup_errors.append({'step': 'owned-process-absence',
                                        'error': 'Owned PID/group absence was not established'})
        if self.raw is not None:
            self.cleanup_attempt('close-original-ANSI', self.raw.close)
        self.cleanup_attempt('close-PTY-master', lambda: self.close_descriptor('master'))
        self.cleanup_attempt('close-PTY-slave-final', lambda: self.close_descriptor('slave'))
        unchanged = {}
        for path, digest in self.input_digests.items():
            def check_input(path=path, digest=digest):
                intact = sha(path) == digest
                unchanged[str(path)] = intact
                require(intact, 'Frozen safety input changed: '+str(path))
            self.cleanup_attempt('verify-frozen-'+str(path), check_input)
        cleanup['frozen_inputs_unchanged'] = unchanged
        if self.scratch is not None and self.root is not None:
            def preserve_fake_argv():
                argvlog = self.scratch / 'bin/kiro-cli-argv.txt'
                fake_args = argvlog.read_text().splitlines() if argvlog.exists() else []
                (self.root / 'fake-cli-argv.txt').write_text('\n'.join(fake_args)+'\n')
                cleanup['fake_cli_invocations'] = fake_args
            self.cleanup_attempt('preserve-fake-CLI-argv', preserve_fake_argv)
        if self.temporary is not None:
            self.cleanup_attempt('remove-only-owned-scratch', self.temporary.cleanup)
            removed = self.cleanup_attempt('record-owned-scratch-removal', lambda: not self.scratch.exists())
            cleanup['isolated_root_removed'] = removed
            if removed is not True:
                self.cleanup_errors.append({'step': 'remove-only-owned-scratch', 'error': 'Owned scratch not removed'})
        self.result = {'result': 'PASS' if outcome == 'PASS' and original_failure is None and not self.cleanup_errors else 'FAIL-STOPPED-NO-RETRY',
                       'original_failure': original_failure, 'cleanup_errors': self.cleanup_errors,
                       'first_failure': original_failure if original_failure is not None else self.cleanup_errors[0] if self.cleanup_errors else None,
                       'checks': self.checks, 'captures': self.captures, 'source_binding': SOURCE_BINDING,
                       'binary': str(BINARY), 'binary_sha256': BINARY_SHA, 'cleanup': cleanup,
                       'scope': SCOPE, 'boundary': self.auth.get('boundary') if isinstance(self.auth, dict) else None}
        if self.root is not None:
            try:
                save(self.root / 'result.json', self.result)
            except BaseException as error:
                self.cleanup_errors.append({'step': 'atomic-result-recording', 'error': repr(error)})
                self.result['result'] = 'FAIL-STOPPED-NO-RETRY'
                if self.result['first_failure'] is None:
                    self.result['first_failure'] = self.cleanup_errors[0]
                self.cleanup_attempt('atomic-fallback-result-recording',
                                     lambda: save(self.root / 'result-recording-failed.json', self.result))
        return self.result


SERVER = 'owned / server 日'
PROMPT = 'prompt / exact 日'
URI = 'canary:///exact?x=%2F'
ARGUMENTS = {
    'required key': 'e\u0301Z', 'optional key': '',
    'spacing': '\u09cb\u09cbZ', 'prepend': '\u0600\u0600Z',
    'variation': '#\ufe0fZ', 'controls': '  x\n\'y"\\\t\x00\u202e  ',
}
FIXED_PROMPT = {'description': 'Independent fixed external prompt fixture',
                'messages': [{'role': 'user', 'content': {'type': 'text', 'text': 'OWNED_PROMPT_FIXED_BEGIN\nExternal data only; no instruction is executed.\nOWNED_PROMPT_FIXED_END'}},
                             {'role': 'assistant', 'content': {'type': 'image', 'data': 'AAAA', 'mimeType': 'image/png'}},
                             {'role': 'user', 'content': {'type': 'resource_link', 'name': 'Owned linked metadata', 'uri': 'canary:///linked'}}]}
FIXED_RESOURCE = {'contents': [
    {'uri': URI, 'mimeType': 'text/plain', 'text': 'OWNED_RESOURCE_FIXED_BEGIN\n' + '\n'.join(f'OWNED_RESOURCE_LINE_{index:02d}' for index in range(50)) + '\nOWNED_RESOURCE_FIXED_END'},
    {'uri': 'canary:///blob', 'mimeType': 'application/pdf', 'blob': 'AAAA'}]}


def catalog():
    return {'name': SERVER, 'status': 'connected',
            'tools': [{'name': 'Inspection tool only', 'description': 'Never execute', 'disabled': False, 'inputSchema': {'type': 'object'}}],
            'prompts': [
                {'name': 'Display title differs', 'promptName': PROMPT,
                 'arguments': [{'name': key, 'required': key == 'required key'} for key in ARGUMENTS]},
                {'name': 'Held read', 'promptName': 'hold / canonical', 'arguments': []},
                {'name': 'Refused read', 'promptName': 'refused / canonical', 'arguments': []},
                {'name': 'Malformed read', 'promptName': 'malformed / canonical', 'arguments': []},
                {'name': 'Empty read', 'promptName': 'empty / canonical', 'arguments': []}],
            'resources': [{'name': f'Resource {index:02d}', 'title': f'Title {index:02d}',
                           'uri': URI if index == 0 else f'canary:///row/{index:02d}?opaque=%2F',
                           'mimeType': 'text/plain'} for index in range(40)],
            'resourceTemplates': [{'name': 'Inspection template only', 'uriTemplate': 'canary:///{id}'}]}


EXPECTED = [
    ('_kiro/mcp/getPrompt', {'serverName': SERVER, 'promptName': PROMPT, 'arguments': ARGUMENTS}, FIXED_PROMPT),
    ('_kiro/mcp/getResource', {'serverName': SERVER, 'uri': URI}, FIXED_RESOURCE),
    ('_kiro/mcp/getResource', {'serverName': SERVER, 'uri': 'canary:///row/39?opaque=%2F'}, {'contents': []}),
    ('_kiro/mcp/getPrompt', {'serverName': SERVER, 'promptName': 'refused / canonical', 'arguments': {}}, 'refused'),
    ('_kiro/mcp/getPrompt', {'serverName': SERVER, 'promptName': 'malformed / canonical', 'arguments': {}}, {'messages': [{'role': 'user', 'content': {'type': 'text'}}]}),
    ('_kiro/mcp/getPrompt', {'serverName': SERVER, 'promptName': 'empty / canonical', 'arguments': {}}, {'messages': []}),
] + [('_kiro/mcp/getPrompt', {'serverName': SERVER, 'promptName': 'hold / canonical', 'arguments': {}}, 'hold') for _ in range(3)]


def peer():
    output = Path(os.environ['OWNED_MCP_OUTPUT'])
    pending, sequence, counter, held = b'', 1, 0, None
    initializations, sessions = 0, 0

    def send(frame):
        message = {'jsonrpc': '2.0', **frame}
        journal(output / 'peer-wire.jsonl', message)
        print(json.dumps(message, ensure_ascii=False), flush=True)

    def snapshot(servers, **extra):
        send({'method': '_kiro/mcp/status', 'params': {'sessionId': SID, 'servers': servers, **extra}})

    def state():
        save(output / 'peer-state.json', {'validated_management_requests': counter, 'pending_response': held is not None,
                                         'fixed_expected_count': len(EXPECTED), 'peer_pid': os.getpid(), 'peer_executable': sys.executable})

    state()
    while True:
        ready, _, _ = select.select([sys.stdin.fileno()], [], [], 0.02)
        if ready:
            data = os.read(sys.stdin.fileno(), 65536)
            if not data:
                return
            pending += data
            while b'\n' in pending:
                line, pending = pending.split(b'\n', 1)
                if not line.strip():
                    continue
                frame = json.loads(line)
                journal(output / 'client-wire.jsonl', frame)
                method, ident = frame.get('method'), frame.get('id')
                try:
                    if method == 'initialize':
                        assert frame['params']['protocolVersion'] == 1
                        assert initializations == 0
                        initializations += 1
                        send({'id': ident, 'result': {'protocolVersion': 1, 'agentCapabilities': {'loadSession': False, '_meta': {'kiro': {}}},
                                                     'agentInfo': {'name': 'owned-fixed-MCP-peer-NOT-native-KAS', 'version': '1'}, 'authMethods': []}})
                    elif method == 'session/new':
                        assert sessions == 0 and initializations == 1 and counter == 0 and held is None
                        sessions += 1
                        # No early snapshot: unknown inventory must remain unknown.
                        send({'id': ident, 'result': {'sessionId': SID, 'configOptions': []}})
                    else:
                        assert ident is not None and counter < len(EXPECTED), 'Unexpected request or callback response'
                        wanted_method, wanted_params, result = EXPECTED[counter]
                        assert method == wanted_method, {'expected_method': wanted_method, 'frame': frame}
                        assert frame['params'] == wanted_params, {'expected_params': wanted_params, 'frame': frame}
                        assert held is None, 'Duplicate in-flight consumer request escaped gate'
                        counter += 1
                        journal(output / 'peer-assertions.jsonl', {'request_index': counter, 'pass': True,
                                                                 'expected_method': wanted_method, 'expected_params': wanted_params,
                                                                 'response_is_independent_fixed_fixture': True})
                        if result == 'hold':
                            held = ident
                        elif result == 'refused':
                            send({'id': ident, 'error': {'code': -32603, 'message': 'Internal error', 'data': 'OWNED_FIXED_REFUSAL: policy denied this read'}})
                        else:
                            send({'id': ident, 'result': result})
                    state()
                except BaseException as error:
                    save(output / 'peer-FAILED.json', {'error': repr(error), 'frame': frame, 'expected_index': counter})
                    raise
        command = output / f'control-{sequence:04d}.json'
        if command.exists():
            action = json.loads(command.read_text())['action']
            try:
                if action == 'catalog':
                    snapshot([catalog(),
                              {'name': 'owned-starting', 'status': 'connecting'},
                              {'name': 'owned-failed', 'status': 'failed', 'failedAuthorization': False, 'errorMessage': 'Owned transport unavailable'},
                              {'name': 'owned-disabled', 'status': 'disabled'},
                              {'name': 'owned-future', 'status': 'sleeping'}])
                elif action == 'disconnect':
                    snapshot([{'name': SERVER, 'status': 'connecting'}])
                elif action == 'entry-missing':
                    entry = catalog()
                    entry['prompts'] = []
                    snapshot([entry])
                elif action == 'server-missing':
                    snapshot([])
                elif action == 'malformed-status':
                    snapshot([{'name': SERVER, 'status': 'connected', 'tools': None}])
                elif action == 'release-held':
                    assert held is not None
                    send({'id': held, 'result': {'description': 'Late fixed success must be rejected', 'messages': [
                        {'role': 'user', 'content': {'type': 'text', 'text': 'MUST_NOT_DISPLAY_STALE_SUCCESS'}}]}})
                    held = None
                elif action == 'registry-empty':
                    snapshot([], accessMode='registry',
                             registryServers=[{'name': 'owned-registry-off', 'enabled': False, 'description': 'Owned catalog entry'}],
                             accessModeFilteredServers=['owned-policy-filtered'], unresolvedRegistryServers=['owned-unresolved'])
                elif action.startswith('policy-'):
                    send({'method': '_kiro/mcp/governance_disabled', 'params': {'sessionId': SID, 'reason': action.removeprefix('policy-')}})
                elif action == 'foreign':
                    send({'method': '_kiro/mcp/status', 'params': {'sessionId': 'sess_70000000-0000-4000-8000-000000000099',
                                                                 'servers': [{'name': 'MUST_NOT_DISPLAY_FOREIGN_SERVER', 'status': 'connecting'}]}})
                else:
                    raise AssertionError(action)
                state()
                save(output / f'ack-{sequence:04d}.json', {'ok': True, 'action': action})
            except BaseException as error:
                save(output / f'ack-{sequence:04d}.json', {'ok': False, 'error': repr(error)})
                raise
            sequence += 1


def scenario(run):
    run.visible('Session created:')
    run.wait(lambda: (run.root / 'peer-state.json').exists(), 'Owned peer process state')
    peer_state = json.loads((run.root / 'peer-state.json').read_text())
    pid = peer_state['peer_pid']
    process_chain = []
    for _ in range(4):
        status = Path(f'/proc/{pid}/status').read_text()
        ppid = int(next(line.split()[1] for line in status.splitlines() if line.startswith('PPid:')))
        process_chain.append({'pid': pid, 'exe': str(Path(f'/proc/{pid}/exe').resolve()),
                              'argv': Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\x00', b' ').decode()})
        pid = ppid
        if pid == run.process.pid:
            break
    save(run.root / 'owned-process-chain.json', process_chain)
    run.check('Launcher selects owned Python and Node, never native KAS fallback',
              process_chain[0]['exe'] == str(run.python) and any(item['exe'] == str(run.node) and str(run.server) in item['argv'] for item in process_chain))
    run.command_input('/mcp')
    run.visible('MCP inventory not reported yet (unknown, not zero configured servers).')
    run.capture('01-unknown-inventory-not-empty')
    run.check('Unknown inventory does not fabricate a zero-server snapshot', 'Known empty inventory:' not in run.text())
    run.control('catalog')
    run.visible('owned-starting', 'owned-failed', 'owned-disabled', 'owned-future', 'Reported status: sleeping')
    run.capture('02-live-named-status-and-catalog')
    run.check('Catalog has no unsolicited management or model request', len(run.wire()) == 2)
    run.control('foreign')
    run.check('Foreign session status cannot contaminate root panel', 'MUST_NOT_DISPLAY_FOREIGN_SERVER' not in run.text())
    run.send('\t')
    run.visible('TOOLS — inspection only; no tool execution control', 'Input schema (read-only)')
    run.capture('03-tools-inspection-only')
    before = len(run.wire())
    run.send('\r')
    run.check('Tools Enter does not execute any request', len(run.wire()) == before)
    run.send('\t')
    run.visible('Display title differs', 'Prompt name: '+PROMPT)
    run.capture('04-display-title-and-canonical-name')
    run.send('\r')
    run.visible('Arguments: Display title differs')
    run.send('\r')
    run.visible('Required argument required key is omitted.')
    run.check('Missing required argument is refused locally without wire', not run.requests('_kiro/mcp/getPrompt'))
    run.paste(ARGUMENTS['required key'])
    run.send('\x1b[H\x1b[C')
    run.capture('05-composed-data-independent-caret-inside')
    first_row = next(row for row in run.screen.display if '> required key' in row)
    run.check('Composed data and independent caret remain physically represented', ('é▏Z' in first_row or 'e\u0301▏Z' in first_row), row=first_row)
    run.send('\x1b[H\x1b[C\x1b[C')
    second_row = next(row for row in run.screen.display if '> required key' in row)
    run.check('Inside and existing grapheme boundary share only visual caret placement', first_row == second_row)
    run.capture('06-composed-data-existing-boundary')
    run.send('\t\x05')
    run.visible('optional key [optional; present]')
    run.send('\x15')
    run.visible('optional key [optional; omitted]')
    run.send('\x05')
    for key, movement in [('spacing', '\x1b[H'), ('prepend', '\x1b[H\x1b[C\x1b[C'), ('variation', '\x1b[H\x1b[C')]:
        run.send('\t')
        run.paste(ARGUMENTS[key])
        run.send(movement)
        run.capture('07-grapheme-'+key)
        row = next(row for row in run.screen.display if '> '+key+' ' in row)
        run.check('Independent semantic caret for '+key, '▏' in row and 'Z' in row, row=row)
    run.send('\t')
    run.paste(ARGUMENTS['controls'])
    run.capture('08-opaque-argument-controls-escaped')
    run.check('Controls and bidi are visible escapes, not terminal instructions', '\\t' in run.text() and '\\0' in run.text() and '\\u{202e}' in run.text() and '\u202e' not in run.text())
    run.send('\r')
    run.visible('OWNED_PROMPT_FIXED_BEGIN', 'OWNED_PROMPT_FIXED_END', 'Content kind: image', 'image/png', 'canary:///linked')
    run.capture('09-fixed-readonly-prompt-preview')
    run.check('Canonical prompt identity and original argument bytes reach SDK wire', run.requests('_kiro/mcp/getPrompt')[0]['params'] == EXPECTED[0][1])
    run.check('Read output is explicitly external, never executed or sent to model', 'READ-ONLY EXTERNAL DATA' in run.text() and not run.requests('session/prompt'))
    run.send('\x1b')
    run.send('\t')
    run.visible('Resource 00', URI)
    run.send('\r')
    run.visible('OWNED_RESOURCE_FIXED_BEGIN')
    run.capture('10-fixed-resource-preview-head')
    run.send('\x1b[6~\x1b[6~\x1b[6~')
    run.visible('OWNED_RESOURCE_FIXED_END', 'Content kind: blob', 'application/pdf', 'canary:///blob')
    run.capture('11-resource-preview-scroll-tail-and-nontext')
    run.send('\x1b[5~\x1b[5~\x1b[5~')
    run.visible('OWNED_RESOURCE_FIXED_BEGIN')
    run.check('Preview PageUp returns to fixed data head without refetch', len(run.requests('_kiro/mcp/getResource')) == 1)
    run.send('\x1b')
    run.send('\x1b[B' * 39)
    run.visible('> Resource 39')
    run.capture('12-resource-selection-follows-scroll')
    run.send('\x1b[5~' * 5)
    run.check('Page scroll leaves selected target offscreen', '> Resource 39' not in run.text())
    before = len(run.requests('_kiro/mcp/getResource'))
    run.send('\r')
    run.visible('> Resource 39')
    run.check('First offscreen Enter only reanchors retained selection', len(run.requests('_kiro/mcp/getResource')) == before)
    run.capture('13-offscreen-enter-reanchors-no-request')
    run.send('\r')
    run.visible('Resource returned zero content entries.')
    run.capture('14-explicit-empty-resource-not-malformed')
    run.send('\x1b')
    run.send('\t')
    run.visible('Templates are advertised metadata, not directly fetched URIs.')
    before = len(run.wire())
    run.send('\r')
    run.check('Templates Enter does not expand or fetch', len(run.wire()) == before)
    run.capture('15-template-inspection-only')
    run.send('\x1b[Z')
    run.visible('MCP · Resources')
    run.send('\x1b[Z')
    run.visible('MCP · Prompts')

    def prompt_index(index):
        # Reopening is an intentional user workflow, never a recovery retry.
        run.send('\x1b')
        run.command_input('/mcp')
        run.send('\t\t')
        run.send('\x1b[B' * index)
        run.send('\r')
        run.send('\r')

    for index, label, expected in [(2, '16-distinct-refusal', 'Operation failed (Rejected)'), (3, '17-distinct-malformed', 'Operation failed (Malformed)'), (4, '18-explicit-empty-prompt', 'Prompt returned zero messages.')]:
        prompt_index(index)
        run.visible(expected)
        run.capture(label)
        run.send('\x1b')
    for number, action, kind in [(19, 'disconnect', 'Disconnected'), (20, 'entry-missing', 'EntryMissing'), (21, 'server-missing', 'ServerMissing')]:
        run.control('catalog')
        prompt_index(1)
        run.visible('Waiting for the pinned request result.', 'PENDING [')
        run.capture(f'{number}-pending-live-before-{action}')
        count = len(run.requests('_kiro/mcp/getPrompt'))
        if action != 'server-missing':
            run.send('\x1b')
            run.send('\r')
            run.send('\r')
            run.visible('An MCP operation is pending; wait for its result.')
            run.check('Duplicate in-flight '+action+' is locally refused', len(run.requests('_kiro/mcp/getPrompt')) == count)
            run.send('\x1b')
        run.control(action)
        run.control('release-held')
        if action != 'server-missing':
            run.send('v')
        run.visible('Operation failed ('+kind+')')
        run.check('Late fixed success is not misrepresented after '+action, 'MUST_NOT_DISPLAY_STALE_SUCCESS' not in run.text())
        run.capture(f'{number}-late-result-{kind}')
        run.send('\x1b')
    run.control('catalog')
    run.control('malformed-status')
    run.visible('STATUS ERROR — last valid inventory may be stale:', 'owned-starting')
    run.capture('22-malformed-snapshot-retains-valid-state')
    run.control('registry-empty')
    run.visible('Known empty inventory: zero servers', 'Access mode: registry', 'owned-policy-filtered', 'owned-unresolved', 'owned-registry-off')
    run.capture('23-known-empty-registry-and-policy-exclusions')
    for index, reason, message in [(24, 'api_failure', 'MCP governance unavailable: policy API failed.'), (25, 'admin_disabled', 'MCP disabled by your administrator.'), (26, 'future_owned_reason', 'unrecognized reason future_owned_reason')]:
        run.control('policy-'+reason)
        run.visible(message)
        run.capture(f'{index}-governance-{reason}')
        before = len(run.wire())
        run.send('\r')
        run.check('Governed known-empty state cannot emit read '+reason, len(run.wire()) == before)
    run.send('\x1b')
    run.check('Escape closes panel after form and preview isolation', 'MCP · ' not in run.text() and 'Arguments:' not in run.text())
    run.capture('27-escape-chat-input-isolation')
    run.control('policy-admin_disabled')
    run.check('Unsolicited policy push never opens a closed MCP panel', 'MCP · ' not in run.text())
    run.check('All independent fixed management expectations exercised', len(run.requests('_kiro/mcp/getPrompt')) == 7 and len(run.requests('_kiro/mcp/getResource')) == 2)
    frames = run.wire()
    run.check('Complete fixed eleven-request sequence, with exactly one bootstrap',
              len(frames) == 11 and [frame.get('method') for frame in frames[:2]] == ['initialize', 'session/new']
              and [(frame.get('method'), frame.get('params')) for frame in frames[2:]] == [(method, params) for method, params, _ in EXPECTED])
    allowed = {'initialize', 'session/new', '_kiro/mcp/getPrompt', '_kiro/mcp/getResource'}
    run.check('No session prompt/model/reset/host/grant requests or responses', all(frame.get('method') in allowed for frame in run.wire()))
    run.check('Peer never sends any host callback request', all('id' not in frame or 'method' not in frame for frame in [json.loads(line) for line in (run.root / 'peer-wire.jsonl').read_text().splitlines()]))
    run.check('No owned protocol assertion failed', not (run.root / 'peer-FAILED.json').exists())


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'peer':
        peer()
    else:
        parser = argparse.ArgumentParser()
        parser.add_argument('--output', required=True)
        parser.add_argument('--authorization', required=True)
        arguments = parser.parse_args()
        consumer = Consumer(arguments)
        outcome, original_failure = 'FAIL-STOPPED-NO-RETRY', None
        try:
            consumer.prepare()
            consumer.start()
            scenario(consumer)
            outcome = 'PASS'
        except BaseException as failure:
            original_failure = {'type': type(failure).__name__, 'error': repr(failure),
                                'traceback': traceback.format_exc()}
            raise
        finally:
            result = consumer.finish(outcome, original_failure)
        if result['result'] != 'PASS':
            raise SystemExit(1)
