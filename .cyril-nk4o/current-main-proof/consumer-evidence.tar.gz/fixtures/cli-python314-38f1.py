#!/usr/bin/env python3
"""PREPARED FALSEGO: ordinary test_bridge stdout, four public MCP ingress sites.

A source-grounded extension of frozen finite TQR probe 41bac1cf. No product,
flag, stdin dispatcher, formatter or case mechanism is changed. Each explicitly
released case sends one early status, supported form/URL callbacks and a matching
session/new success. The ordinary example is NOT interactive: session success
would later start fixed model/prompt tests. Therefore this separate scenario uses
Main-DG-approved, observation-triggered exact-PID SIGTERM, not normal completion.
Only all four exact stdout lines plus both decline responses arm that cutoff.
Unexpected wire, an early exit, deadline, any other returncode or cleanup failure
is failure. Pending/Outcome remain independent UNIT proof, never process coverage.

Run only after frozen fixture review, Main's external current521/admin/ref/index
source guard and a separate pinned runtime-GO. This file never runs that external
guard or claims its opaque receipt schema. Canonical fields below are its actual
schema, not old receipt aliases. No Cargo/Git/native Kiro/model/account/network,
permission/grant/browser/clipboard operation is authorized. Standard library only.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import select
import selectors
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import traceback

WT = Path('/home/dwalleck/repos/cyril-wt-fix-cyril-nk4o')
SOURCE_DESCRIPTOR = '03f68b427128d98b1d11aee19a287338cb2e54590964e2d02d6dd8fdd8bd8d63'
SOURCE = WT / 'crates/cyril/examples/test_bridge.rs'
SOURCE_SHA = '8f51bc683b8587e244a3f5d2a997903ba7c5d183b81e4c2273868ad4ea36d3c5'
FROZEN = Path('/tmp/cyril-tqr8-cli-error-green-20261020/probe.py')
FROZEN_SHA = '41bac1cf68e50f401eb8953c687d5c72fec2c869677efaaabab8b7ddfbfc0e41'
RECIPE = WT / '.cyril-tqr8/current-publication-evidence/consumer/harness.py'
RECIPE_SHA = 'a9b194233c78c6970c2fd01408f7eae75d22e6e515a659c9c3b207dd4c7daa45'
FAKE = WT / 'crates/cyril-core/tests/fixtures/fake-kiro-cli.sh'
FAKE_SHA = '61586cd278cb555d29f84b49805a1811705112713d0b6774feec42310d0ced6d'
QUALIFIED = Path('/home/dwalleck/.claude/tmp/cyril-batch3-qualification-20261020-ipe924db/nk4o-current-main-integration-repaired-green-attempt1')
CANONICAL = QUALIFIED / 'canonical-handoff.json'
CANONICAL_SHA = 'ed0f7dc582a493951eb3257704287d88f99887a471d5c6a4b6fab6cd73f77b65'
MANIFEST = QUALIFIED / 'postformat-current521-inputs.json'
MANIFEST_SHA = '9d4b102d3a89ef189337f4aaecc4a33a40fb17cc5d9140b2963f1213111dc1c5'
BINARY = Path('/tmp/cyril-nk4o-current-main-repaired-default-CLI-example-qualified-20261022T035040332736Z')
BINARY_SHA = '7b0f6003b4ef146dcb935d56ce3b576a1e6b057f82b0498b395b1a171ac0d10d'
PYTHON = Path('/usr/bin/python3.14')
PYTHON_SHA = '7579d289e4d95778305acd13fc71be2a3800f7f6a202619505875234659c2c60'
NODE = Path('/usr/bin/node')
NODE_SHA = 'ed30fdcc71cd7134c5324aeedea64f1088f0dfd22bfba3834fcbee0402c28c5a'
PREFIX = b'  [McpUpdate] '
CASES = ('printable', 'snapshot-controls', 'retained-controls')
# Fail-stop bounds, not pacing, completion evidence or accepted timeout outcomes.
RUN_BOUND = 12
CLEANUP_BOUND = 3
POLL_BOUND = 0.02


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.writing')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def journal(path, frame):
    with Path(path).open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(frame, ensure_ascii=False) + '\n')


def frames(path):
    return [json.loads(line) for line in Path(path).read_text(encoding='utf-8').split('\n') if line]


def process_record(pid):
    fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
    return {'pid': pid, 'starttime': fields[19], 'state': fields[0]}


def bind_process(record, marker, workspace):
    pid = record['pid']
    fd = os.pidfd_open(pid)
    try:
        observed = process_record(pid)
        assert observed['starttime'] == record['starttime'], 'recorded PID was reused'
        assert Path(f'/proc/{pid}/cwd').resolve(strict=True) == workspace, 'owned cwd mismatch'
        assert os.fsencode(marker) in Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0'), 'owned argv marker mismatch'
        return {'pid': pid, 'starttime': record['starttime'], 'marker': marker, 'pidfd': fd}
    except BaseException:
        os.close(fd)
        raise


def live_owned(handle):
    try:
        observed = process_record(handle['pid'])
        return observed['starttime'] == handle['starttime'] and observed['state'] not in ('Z', 'X')
    except (FileNotFoundError, ProcessLookupError):
        return False


def signal_owned(handle, signum):
    if not live_owned(handle):
        return False
    # A pidfd, unlike a PID/PGID lookup followed by kill, cannot target a reused ID.
    try:
        signal.pidfd_send_signal(handle['pidfd'], signum)
        return True
    except ProcessLookupError:
        return False


def public_identity(handle):
    return {key: value for key, value in handle.items() if key != 'pidfd'}


def wire_inputs(literals, case_name):
    case = literals['cases'][case_name]
    servers = []
    for row in case['status_rows']:
        if row['fixture_shape'] == 'failed':
            servers.append({'name': row['name'], **literals['failed_status_fields']})
        elif row['fixture_shape'] == 'connected-empty':
            servers.append({'name': row['name'], 'status': 'connected', 'tools': [],
                            'prompts': [], 'resources': [], 'resourceTemplates': []})
        else:
            raise AssertionError(('unknown frozen fixture input shape', row))
    servers.extend(literals['shared_status_rows'])
    status = {'jsonrpc': '2.0', 'method': '_kiro/mcp/status',
              'params': {'sessionId': case['session_id'], 'servers': servers}}
    callbacks = []
    for mode, request_id in zip(('form', 'url'), literals['callback_request_ids'], strict=True):
        callbacks.append({'jsonrpc': '2.0', 'id': request_id, 'method': '_kiro/mcp/elicitation',
                          'params': {**case[mode + '_context'], 'elicitation': literals[mode + '_elicitation']}})
    return status, callbacks


def agent():
    output = Path(os.environ['NK_CLI_PROBE_OUTPUT']).resolve(strict=True)
    authorization = load(output / 'runtime-authorization.json')
    assert authorization['runtime_GO'] is True and authorization['approved_by'] == 'Main'
    assert sha(__file__) == authorization['fixture_sha256']
    assert sha(output / 'inputs-and-literals.json') == authorization['literals_sha256']
    case_name = os.environ['NK_CLI_PROBE_CASE']
    assert case_name == authorization['case']
    literals = load(output / 'inputs-and-literals.json')
    status, callbacks = wire_inputs(literals, case_name)
    save(output / 'agent-peer.json', process_record(os.getpid()))
    buffer, phase, initialize_id, session_id = b'', 'initialize', None, None
    deadline = time.monotonic() + RUN_BOUND

    def send(frame):
        journal(output / 'agent-wire.jsonl', frame)
        print(json.dumps(frame, ensure_ascii=False), flush=True)

    try:
        while time.monotonic() < deadline:
            readable, _, _ = select.select([sys.stdin.fileno()], [], [], POLL_BOUND)
            if readable:
                chunk = os.read(sys.stdin.fileno(), 65536)
                if not chunk:
                    assert not buffer, 'partial client frame on EOF'
                    return
                buffer += chunk
                while b'\n' in buffer:
                    line, buffer = buffer.split(b'\n', 1)
                    frame = json.loads(line)
                    journal(output / 'client-wire.jsonl', frame)
                    method, ident = frame.get('method'), frame.get('id')
                    assert frame.get('jsonrpc') == '2.0', frame
                    if method == 'initialize' and phase == 'initialize':
                        assert ident is not None, frame
                        initialize_id = ident
                        send({'jsonrpc': '2.0', 'id': ident, 'result': {
                            'protocolVersion': 1,
                            'agentCapabilities': {'loadSession': True, '_meta': {'kiro': {}}},
                            'agentInfo': {'name': 'nk-owned-cli-peer-NOT-native-KAS', 'version': '0.66.43'},
                            'authMethods': [],
                        }})
                        phase = 'new'
                    elif method == 'session/new' and phase == 'new':
                        assert ident is not None and ident != initialize_id, frame
                        assert frame['params']['cwd'] == str(Path.cwd()), frame
                        session_id = ident
                        phase = 'observer-gate'
                    elif method is None and phase in ('form-ack', 'url-ack'):
                        index = 0 if phase == 'form-ack' else 1
                        assert frame == {'jsonrpc': '2.0', 'id': callbacks[index]['id'],
                                         'result': {'action': 'decline'}}, frame
                        if index == 0:
                            send(callbacks[1])
                            phase = 'url-ack'
                        else:
                            save(output / 'decline-acks.json', {'ids': [item['id'] for item in callbacks],
                                                               'responses': [{'action': 'decline'}, {'action': 'decline'}]})
                            phase = 'success-gate'
                    else:
                        # In particular: never reply to options/model/prompt/reset,
                        # permission/grant/token/URL/host-I/O or arbitrary requests.
                        raise AssertionError(('unexpected client frame; no reply sent', phase, frame))
            control_path = output / 'control.json'
            if not control_path.exists():
                continue
            control = load(control_path)
            assert control['case'] == case_name and control['stdout_observer_bound'] is True
            assert control['owned_identities']['peer']['pid'] == os.getpid()
            assert control['owned_identities']['peer']['starttime'] == process_record(os.getpid())['starttime']
            if phase == 'observer-gate' and control['sequence'] == 1:
                assert control['action'] == 'publish-ingress'
                send(status)
                send(callbacks[0])
                phase = 'form-ack'
            elif phase == 'success-gate' and control['sequence'] == 2:
                assert control['action'] == 'publish-session-success'
                assert control['both_early_stdout_notices_and_decline_acks_observed'] is True
                send({'jsonrpc': '2.0', 'id': session_id,
                      'result': {'sessionId': literals['cases'][case_name]['session_id']}})
                phase = 'completed-held-open'
        raise AssertionError(('finite peer bound expired', phase))
    except Exception as error:
        save(output / 'peer-failure.json', {'error': repr(error), 'phase': phase})
        raise


def assert_summary(stdout, expected, literals, final=False):
    complete = stdout.split(b'\n')[:-1]
    actual = [line for line in complete if line.startswith(PREFIX)]
    assert actual == expected[:len(actual)] and len(actual) <= 4, 'unexpected/duplicate/reordered exact MCP summary line'
    text = b'\n'.join(actual).decode('utf-8')
    for marker in literals['private_canary_markers']:
        assert marker not in text, ('private canary disclosed in intended summary lines', marker)
    bidi = '\u061c\u200e\u200f\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069'
    for line in actual:
        assert not any(ord(c) < 32 or 127 <= ord(c) <= 159 or c in bidi for c in line.decode('utf-8')), 'raw control/bidi in intended summary line'
    # Other raw session-ID printers are intentionally NOT called control-free.
    for forbidden in (b'--- [2]', b'  [PERMISSION]', b'[FAIL] No SessionCreated', b'--- Shutting down ---', b'[OK] Done'):
        assert forbidden not in stdout, ('unrelated/normal example lifecycle reached', forbidden)
    if final:
        assert actual == expected, 'all four exact physical stdout lines were not printed'
        assert b'  [SessionCreated]' in stdout, 'matching session success never reached actual consumer'
    return actual


def assert_wire(output, literals, case_name, success):
    client = frames(output / 'client-wire.jsonl')
    outbound = frames(output / 'agent-wire.jsonl')
    assert [frame.get('method') for frame in client] == ['initialize', 'session/new', None, None], 'unexpected client operation'
    callbacks = wire_inputs(literals, case_name)[1]
    assert client[2:] == [{'jsonrpc': '2.0', 'id': callback['id'], 'result': {'action': 'decline'}} for callback in callbacks]
    status, callbacks = wire_inputs(literals, case_name)
    assert outbound[1:4] == [status, *callbacks], 'raw status/context/canary identity mismatch'
    assert len(outbound) == (5 if success else 4), 'unexpected peer exchange'
    assert outbound[0]['id'] == client[0]['id'] and 'result' in outbound[0]
    if success:
        assert outbound[4] == {'jsonrpc': '2.0', 'id': client[1]['id'],
                               'result': {'sessionId': literals['cases'][case_name]['session_id']}}
    raw = json.dumps(outbound, ensure_ascii=False)
    assert all(marker in raw for marker in literals['private_canary_markers']), 'a non-disclosure input canary was never supplied'
    assert load(output / 'decline-acks.json') == {'ids': literals['callback_request_ids'],
                                                'responses': [{'action': 'decline'}, {'action': 'decline'}]}
    assert not (output / 'peer-failure.json').exists(), 'strict peer reported unexpected wire'
    return {'client_frames': len(client), 'peer_frames': len(outbound),
            'only_client_requests': ['initialize', 'session/new'], 'both_exact_decline_responses': True,
            'raw_status_and_contextual_identity_equality': True, 'all_private_input_canaries_present_on_wire': True}


def immutable_inputs(probe, literals_path, authorization_path, authorization):
    pins = {FROZEN: FROZEN_SHA, RECIPE: RECIPE_SHA, FAKE: FAKE_SHA, SOURCE: SOURCE_SHA,
            CANONICAL: CANONICAL_SHA, MANIFEST: MANIFEST_SHA, BINARY: BINARY_SHA,
            PYTHON: PYTHON_SHA, NODE: NODE_SHA, probe: authorization['fixture_sha256'],
            literals_path: authorization['literals_sha256'], authorization_path: authorization['authorization_self_pin']}
    for prefix in ('main_current_source_guard_receipt', 'frozen_fixture_review'):
        pins[Path(authorization[prefix + '_path'])] = authorization[prefix + '_sha256']
    for path, digest in pins.items():
        assert sha(path) == digest, ('immutable input changed', str(path))
    canonical = load(CANONICAL)
    assert canonical['status'] == 'PASS_ALL40_AUTHORIZED_LOCAL_NK_REPAIRED_GREEN_COMBINED_CARGO_GATES_NOT_FULL_NATIVE_CONSUMER_REVIEW_CI_PUBLICATION_ACCEPTANCE'
    assert canonical['command_totals']['actual_commands'] == 40 and canonical['command_totals']['all_exit0'] == 40
    assert len(canonical['commands']) == 40 and all(row['returncode'] == 0 for row in canonical['commands'])
    binding = canonical['private_binaries']['default-CLI-example']
    assert binding['private_path'] == str(BINARY) and binding['sha256'] == BINARY_SHA
    assert binding['source_descriptor'] == SOURCE_DESCRIPTOR and binding['source_input_rows'] == 521
    assert binding['bytes'] == BINARY.stat().st_size == 78972480 and binding['mode'] == '0o755'
    assert BINARY.stat().st_mode & 0o777 == 0o755 and os.access(BINARY, os.X_OK)
    return {str(path): digest for path, digest in pins.items()}


def cleanup(process, handles, output, server, probe, workspace, receipt):
    state = {'recorded_owned_identities': {}, 'signals': [], 'errors': [],
             'remaining_live_owned_identities': None, 'direct_example_reaped': False,
             'direct_example_pid': None if process is None else process.pid,
             'scope': 'Authoritative direct Popen child plus exact recorded Node/peer pidfds/start-identities only; not a global descendant census; no PGID signals'}
    # Publish mutable progress before any fallible cleanup; never lose it because
    # a cleanup call failed before returning.
    receipt['cleanup'] = state

    def checkpoint(stage, error=None):
        state['stage'] = stage
        if error is not None:
            state['errors'].append({'stage': stage, 'error': repr(error),
                                    'traceback': ''.join(traceback.format_exception(error))})
        try:
            save(output / 'cleanup-progress.json', state)
        except BaseException as error:
            state['errors'].append({'stage': 'persist-' + stage, 'error': repr(error),
                                    'traceback': ''.join(traceback.format_exception(error))})

    # Popen is the authoritative owner even when process_record/bind_process
    # failed. Never reconstruct this child from a guessed PID or process group.
    checkpoint('direct-example-terminate')
    if process is not None:
        try:
            if process.poll() is None:
                process.terminate()
                state['signals'].append({'role': 'example', 'pid': process.pid,
                                         'ownership': 'direct Popen child', 'signal': 'SIGTERM'})
        except BaseException as error:
            checkpoint('direct-example-terminate', error)
    checkpoint('recover-recorded-descendants')
    for key, filename, marker in (('node', 'agent-node.json', str(server)), ('peer', 'agent-peer.json', str(probe))):
        try:
            if key not in handles and (output / filename).exists():
                handles[key] = bind_process(load(output / filename), marker, workspace)
        except (FileNotFoundError, ProcessLookupError):
            pass
        except BaseException as error:
            checkpoint('bind-' + key, error)
    state['recorded_owned_identities'] = {key: public_identity(value) for key, value in handles.items()}
    checkpoint('recorded-descendants-terminate')
    for key, handle in handles.items():
        if key == 'example':
            continue
        try:
            if signal_owned(handle, signal.SIGTERM):
                state['signals'].append({'role': key, **public_identity(handle), 'signal': 'SIGTERM'})
                checkpoint('terminated-' + key)
        except BaseException as error:
            checkpoint('terminate-' + key, error)
    try:
        checkpoint('term-liveness-wait')
        deadline = time.monotonic() + CLEANUP_BOUND
        while ((process is not None and process.poll() is None)
               or any(live_owned(handle) for handle in handles.values())) and time.monotonic() < deadline:
            # Bounded cleanup wait only; never a publication/cutoff delay.
            select.select([], [], [], POLL_BOUND)
    except BaseException as error:
        checkpoint('term-liveness-wait', error)
    # Escalation is bounded failure cleanup only, never qualified PASS.
    if process is not None:
        try:
            if process.poll() is None:
                checkpoint('direct-example-kill')
                process.kill()
                state['signals'].append({'role': 'example', 'pid': process.pid,
                                         'ownership': 'direct Popen child', 'signal': 'SIGKILL'})
        except BaseException as error:
            checkpoint('direct-example-kill', error)
    for key, handle in handles.items():
        if key == 'example':
            continue
        try:
            if signal_owned(handle, signal.SIGKILL):
                state['signals'].append({'role': key, **public_identity(handle), 'signal': 'SIGKILL'})
                checkpoint('killed-' + key)
        except BaseException as error:
            checkpoint('kill-' + key, error)
    if process is not None:
        try:
            checkpoint('direct-example-reap')
            state['direct_example_returncode'] = process.wait(timeout=CLEANUP_BOUND)
            state['direct_example_reaped'] = True
        except BaseException as error:
            checkpoint('direct-example-reap', error)
    try:
        checkpoint('final-liveness-wait')
        deadline = time.monotonic() + CLEANUP_BOUND
        while any(live_owned(handle) for handle in handles.values()) and time.monotonic() < deadline:
            select.select([], [], [], POLL_BOUND)
        state['remaining_live_owned_identities'] = [
            {'role': key, **public_identity(handle)} for key, handle in handles.items() if live_owned(handle)]
        assert not state['remaining_live_owned_identities'], 'exact recorded owned process survived cleanup'
    except BaseException as error:
        checkpoint('final-liveness-wait', error)
    checkpoint('complete')
    return state


def run(args):
    probe = Path(__file__).resolve(strict=True)
    literals_path = probe.with_name('literals.json')
    authorization_path = Path(args.authorization).resolve(strict=True)
    authorization = load(authorization_path)
    # Fail closed BEFORE creating output, launching anything, or mutating resources.
    assert authorization['schema'] == 'nk4o-cli-four-ingress-runtime-authorization/v1'
    assert authorization['runtime_GO'] is True and authorization['approved_by'] == 'Main'
    assert authorization['frozen_fixture_review_completed'] is True
    assert authorization['main_external_current521_admin_ref_index_guard_completed'] is True
    assert authorization['source_descriptor'] == SOURCE_DESCRIPTOR
    assert authorization['canonical_path'] == str(CANONICAL) and authorization['canonical_sha256'] == CANONICAL_SHA
    assert authorization['binary_path'] == str(BINARY) and authorization['binary_sha256'] == BINARY_SHA
    assert authorization['case'] == args.case and Path(args.binary).resolve(strict=True) == BINARY
    assert Path(sys.executable).resolve(strict=True) == PYTHON.resolve(strict=True)
    output = Path(args.output).resolve()
    assert authorization['output'] == str(output) and not output.exists(), 'output must be Main-bound and fresh'
    # This pin is derived in-memory from the supplied file, NOT a self-referential
    # JSON field or a new canonical alias. Recheck it after the run.
    authorization['authorization_self_pin'] = sha(authorization_path)
    pins = immutable_inputs(probe, literals_path, authorization_path, authorization)
    literals = load(literals_path)
    expected = [line.encode('utf-8') for line in literals['cases'][args.case]['expected_stdout_lines']]
    assert len(expected) == 4
    output.mkdir(mode=0o700, parents=True, exist_ok=False)
    (output / 'probe.py').write_bytes(probe.read_bytes())
    (output / 'inputs-and-literals.json').write_bytes(literals_path.read_bytes())
    (output / 'runtime-authorization.json').write_bytes(authorization_path.read_bytes())
    run_probe = output / 'probe.py'
    receipt = {'result': 'FAIL', 'executed': True, 'case': args.case, 'immutable_input_pins': pins,
               'scope': 'Four public-ingress summary sites, actual ordinary example stdout; expected controlled SIGTERM, NOT normal CLI completion/native KAS/physical terminal/six-site process proof',
               'external_guard_limit': 'Main separately owns fresh current521/admin/ref/index guard and its supplied opaque receipt; this finite driver checks its immutable receipt pin, not its schema or live Git state'}
    exit_code = 2
    scratch = None
    stage = 'scratch-setup'

    def record_error(kind, failed_stage, error):
        detail = {'stage': failed_stage, 'error': repr(error),
                  'traceback': ''.join(traceback.format_exception(error))}
        if kind == 'primary_error' and 'primary_error' not in receipt:
            receipt['primary_error'] = detail
            receipt['error'] = detail['error']
        else:
            receipt.setdefault('secondary_errors' if kind == 'primary_error' else kind, []).append(detail)
        # Capture the first exception BEFORE cleanup can raise or alter context.
        try:
            save(output / 'result.json', receipt)
        except BaseException as persistence_error:
            receipt.setdefault('evidence_errors', []).append({
                'stage': 'persist-' + failed_stage, 'error': repr(persistence_error),
                'traceback': ''.join(traceback.format_exception(persistence_error))})

    try:
        # Python 3.13 delete=False prevents context/finalizer deletion on FAIL.
        with tempfile.TemporaryDirectory(prefix='cyril-nk-cli-owned-', dir=output, delete=False) as temporary:
            scratch = Path(temporary)
            for name in ('bin', 'home', 'config', 'data', 'cache', 'tmp', 'ws'):
                (scratch / name).mkdir(mode=0o700)
            workspace = scratch / 'ws'
            fake_link = scratch / 'bin/kiro-cli'
            fake_link.symlink_to(FAKE)
            assert fake_link.resolve(strict=True) == FAKE.resolve(strict=True) and os.access(fake_link, os.X_OK)
            server = scratch / 'server.js'
            server.write_text(
                "const fs=require('node:fs');const {spawn}=require('node:child_process');"
                "const start=p=>fs.readFileSync('/proc/'+p+'/stat','utf8').slice(fs.readFileSync('/proc/'+p+'/stat','utf8').lastIndexOf(')')+1).trim().split(/\\s+/)[19];"
                "fs.writeFileSync(process.env.NK_CLI_PROBE_OUTPUT+'/agent-node.json.writing',JSON.stringify({pid:process.pid,starttime:start(process.pid)}));"
                "fs.renameSync(process.env.NK_CLI_PROBE_OUTPUT+'/agent-node.json.writing',process.env.NK_CLI_PROBE_OUTPUT+'/agent-node.json');"
                + 'const c=spawn(' + json.dumps(str(PYTHON)) + ',' + json.dumps([str(run_probe), 'agent']) + ",{stdio:'inherit'});"
                + "c.on('error',e=>{console.error(e);process.exit(1);});c.on('exit',(n,s)=>process.exit(n??1));\n",
                encoding='utf-8')
            environment = {
                'PATH': str(scratch / 'bin'), 'SHELL': '/bin/bash', 'LANG': 'C.UTF-8',
                'HOME': str(scratch / 'home'), 'USERPROFILE': str(scratch / 'home'),
                'XDG_CONFIG_HOME': str(scratch / 'config'), 'XDG_DATA_HOME': str(scratch / 'data'),
                'XDG_CACHE_HOME': str(scratch / 'cache'), 'TMPDIR': str(scratch / 'tmp'),
                'KIRO_HOME': str(scratch / 'home/.kiro'), 'KIRO_AGENT_PATH': str(NODE),
                'KIRO_KAS_SERVER_PATH': str(server), 'NK_CLI_PROBE_OUTPUT': str(output), 'NK_CLI_PROBE_CASE': args.case,
            }
            command = [str(BINARY), '--agent-engine', 'kas']
            receipt.update(command=command, cwd=str(workspace), environment=environment,
                           server_js_sha256=sha(server), temporary_root=str(scratch))
            process, handles, all_stdout = None, {}, bytearray()
            identities = {}
            release, cutoff = 0, False
            selector = selectors.DefaultSelector()
            read_fd, write_fd = os.pipe()
            # Register before spawn: stdout observation cannot miss the first byte.
            selector.register(read_fd, selectors.EVENT_READ)
            os.set_blocking(read_fd, False)
            try:
                with (output / 'stdout.bin').open('wb') as stdout, (output / 'stderr.bin').open('wb') as stderr:
                    stage = 'spawn-direct-example'
                    process = subprocess.Popen(command, cwd=workspace, env=environment,
                                               stdin=subprocess.DEVNULL, stdout=write_fd, stderr=stderr,
                                               start_new_session=True)
                    # Assignment retains the authoritative Popen owner before
                    # any fallible identity acquisition/binding or receipt I/O.
                    receipt['direct_child'] = {'pid': process.pid, 'ownership': 'direct Popen child',
                                               'bound_identity': None}
                    save(output / 'direct-child.json', receipt['direct_child'])
                    os.close(write_fd)
                    write_fd = None
                    stage = 'bind-direct-example'
                    handles['example'] = bind_process(process_record(process.pid), str(BINARY), workspace)
                    receipt['direct_child']['bound_identity'] = public_identity(handles['example'])
                    save(output / 'direct-child.json', receipt['direct_child'])
                    stage = 'observe-four-ingress'
                    deadline = time.monotonic() + RUN_BOUND
                    while time.monotonic() < deadline:
                        if (output / 'peer-failure.json').exists():
                            raise AssertionError(('strict peer failure', load(output / 'peer-failure.json')))
                        assert process.poll() is None, 'example exited before observation-triggered cutoff'
                        for key, _ in selector.select(POLL_BOUND):
                            chunk = os.read(key.fd, 65536)
                            assert chunk, 'example stdout EOF before controlled cutoff'
                            stdout.write(chunk)
                            stdout.flush()
                            all_stdout.extend(chunk)
                        actual = assert_summary(bytes(all_stdout), expected, literals)
                        if release == 0 and all((output / filename).exists() for filename in ('agent-node.json', 'agent-peer.json')):
                            stage = 'bind-node'
                            handles['node'] = bind_process(load(output / 'agent-node.json'), str(server), workspace)
                            stage = 'bind-peer'
                            handles['peer'] = bind_process(load(output / 'agent-peer.json'), str(run_probe), workspace)
                            stage = 'publish-observer-bound-ingress'
                            identities = {key: public_identity(value) for key, value in handles.items()}
                            save(output / 'observer-bound.json', {'stdout_observer_bound_before_session_success': True,
                                                                 'owned_identities': identities})
                            save(output / 'control.json', {'sequence': 1, 'action': 'publish-ingress', 'case': args.case,
                                                          'stdout_observer_bound': True, 'owned_identities': identities})
                            release = 1
                            stage = 'observe-four-ingress'
                        if release == 1 and actual == expected[:2] and (output / 'decline-acks.json').exists():
                            stage = 'release-session-success'
                            assert_wire(output, literals, args.case, success=False)
                            save(output / 'control.json', {'sequence': 2, 'action': 'publish-session-success', 'case': args.case,
                                                          'stdout_observer_bound': True, 'owned_identities': identities,
                                                          'both_early_stdout_notices_and_decline_acks_observed': True})
                            release = 2
                            stage = 'observe-four-ingress'
                        if release == 2 and actual == expected:
                            stage = 'qualify-cutoff-preconditions'
                            assert_summary(bytes(all_stdout), expected, literals, final=True)
                            wire = assert_wire(output, literals, args.case, success=True)
                            assert (scratch / 'bin/kiro-cli-argv.txt').read_text() == 'chat\n_\nget-kas-token\n'
                            assert all(live_owned(handle) for handle in handles.values()), 'owned identity lost before cutoff'
                            # Persist the facts BEFORE the only expected termination.
                            save(output / 'cutoff-preconditions.json', {'all_four_exact_stdout_lines': [line.decode('utf-8') for line in actual],
                                                                     'wire': wire, 'summary_only_private_canaries_absent': True,
                                                                     'summary_only_controls_escaped': True,
                                                                     'owned_identities': identities, 'expected_signal': 'SIGTERM',
                                                                     'normal_cli_completion': False})
                            stage = 'expected-owned-sigterm'
                            assert signal_owned(handles['example'], signal.SIGTERM), 'exact bound example not signalled'
                            cutoff = True
                            process.wait(timeout=CLEANUP_BOUND)
                            assert process.returncode == -signal.SIGTERM, ('not the expected controlled SIGTERM', process.returncode)
                            receipt['consumer_returncode'] = process.returncode
                            break
                    assert cutoff, 'bounded observation expired; timeout is never PASS'
            except BaseException as error:
                record_error('primary_error', stage, error)
            finally:
                # Close only our unused writer; keep the unread observation
                # pipe alive through bounded owned cleanup AND evidence drain.
                if write_fd is not None:
                    try:
                        os.close(write_fd)
                        write_fd = None
                    except BaseException as error:
                        record_error('cleanup_errors', 'close-local-writer', error)
                try:
                    cleanup(process, handles, output, server, run_probe, workspace, receipt)
                except BaseException as error:
                    record_error('cleanup_errors', 'owned-cleanup', error)
                try:
                    # Attempt raw retention even when cleanup itself failed.
                    # Exit and inherited-pipe EOF are separate obligations. Reap
                    # first; drain only after recorded Node/peer cleanup.
                    receipt['stdout_eof_after_cleanup'] = False
                    eof, deadline = False, time.monotonic() + CLEANUP_BOUND
                    with (output / 'stdout.bin').open('ab') as stdout:
                        while not eof and time.monotonic() < deadline:
                            for key, _ in selector.select(POLL_BOUND):
                                chunk = os.read(key.fd, 65536)
                                if not chunk:
                                    eof = True
                                    break
                                stdout.write(chunk)
                                all_stdout.extend(chunk)
                    assert eof, 'stdout inherited-pipe EOF not reached after owned cleanup'
                    receipt['stdout_eof_after_cleanup'] = True
                except BaseException as error:
                    record_error('cleanup_errors', 'stdout-drain', error)
                finally:
                    try:
                        selector.close()
                    except BaseException as error:
                        record_error('cleanup_errors', 'close-selector', error)
                    descriptors = [read_fd, *(handle['pidfd'] for handle in handles.values())]
                    if write_fd is not None:
                        descriptors.append(write_fd)
                    for descriptor in descriptors:
                        try:
                            os.close(descriptor)
                        except BaseException as error:
                            record_error('cleanup_errors', 'close-descriptor', error)
                    try:
                        argv_log = scratch / 'bin/kiro-cli-argv.txt'
                        if argv_log.exists():
                            (output / 'kiro-cli-argv.txt').write_bytes(argv_log.read_bytes())
                    except BaseException as error:
                        record_error('cleanup_errors', 'retain-helper-argv', error)
            stage = 'final-qualification'
            assert 'primary_error' not in receipt, 'primary run failure retained separately'
            assert not receipt.get('cleanup_errors') and not receipt.get('evidence_errors'), 'cleanup/evidence errors prevent PASS'
            assert not receipt['cleanup']['errors'], 'owned cleanup errors prevent PASS'
            assert receipt['cleanup']['direct_example_reaped'], 'direct example not reaped'
            assert receipt['cleanup']['remaining_live_owned_identities'] == [], 'owned cleanup incomplete'
            assert receipt['stdout_eof_after_cleanup'], 'stdout EOF not qualified'
            assert cutoff and receipt['consumer_returncode'] == -signal.SIGTERM
            assert_summary(bytes(all_stdout), expected, literals, final=True)
            receipt['wire'] = assert_wire(output, literals, args.case, success=True)
            assert (output / 'kiro-cli-argv.txt').read_text() == 'chat\n_\nget-kas-token\n'
            assert not any(item['signal'] == 'SIGKILL' for item in receipt['cleanup']['signals']), 'forced cleanup escalation is not qualified PASS'
        immutable_inputs(probe, literals_path, authorization_path, authorization)
        stage = 'remove-passing-scratch'
        shutil.rmtree(scratch)
        receipt['owned_temporary_root_absent'] = not scratch.exists()
        assert receipt['owned_temporary_root_absent'], 'owned temporary root remains'
        stage = 'record-qualified-pass'
        receipt.update(result='PASS_FOUR_PUBLIC_INGRESS_STDOUT_EXPECTED_CONTROLLED_SIGTERM',
                       normal_cli_completion=False, intended_summary_sites=list(literals['coverage_limits']['intended_process_sites']),
                       independent_unit_only_sites=['pendingserver', 'outcomeserver'],
                       exact_stdout_lines=[line.decode('utf-8') for line in expected])
        exit_code = 0
    except BaseException as error:
        record_error('primary_error', stage, error)
        if scratch is not None:
            receipt['owned_temporary_root_absent'] = not scratch.exists()
            receipt['failed_scratch_retained'] = scratch.exists()
    finally:
        save(output / 'result.json', receipt)
    print(json.dumps({'result': receipt['result'], 'output': str(output), 'exit_code': exit_code}, ensure_ascii=False))
    return exit_code


if __name__ == '__main__':
    if len(sys.argv) == 2 and sys.argv[1] == 'agent':
        agent()
    else:
        parser = argparse.ArgumentParser(description=__doc__)
        parser.add_argument('--binary', required=True)
        parser.add_argument('--output', required=True)
        parser.add_argument('--authorization', required=True)
        parser.add_argument('--case', required=True, choices=CASES)
        raise SystemExit(run(parser.parse_args()))
