#!/usr/bin/env python3
"""Authorized interpreter/dependency/pidfd prerequisite probe; never launches App."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import select
import signal
import sys

HERE = Path('/tmp/cyril-nk4o-two-repair-consumer-prepare-20261022')
PRECEDENT = Path('/tmp/cyril-nk4o-current-main-owned-consumer-prepare-McpLifecycle-03f68b427128')
OUTPUT = HERE / 'runtime-capability-run02.json'

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

require(not OUTPUT.exists(), 'Capability output must be fresh')
require(sys.flags.optimize == 0 and sys.flags.dont_write_bytecode == 1 and sys.flags.no_user_site == 1,
        'Unoptimized -B -s interpreter required')
executable = Path(sys.executable).resolve(strict=True)
require(executable == Path('/usr/bin/python3.14'), 'Only the authorized resolved system interpreter may run this probe')
capabilities = {'os.pidfd_open': callable(getattr(os, 'pidfd_open', None)),
                'signal.pidfd_send_signal': callable(getattr(signal, 'pidfd_send_signal', None))}
require(all(capabilities.values()), 'Both native Python pidfd APIs are required; no fallback')
fd = os.pidfd_open(os.getpid(), 0)
try:
    require(not select.select([fd], [], [], 0)[0], 'Self pidfd unexpectedly exited')
    signal.pidfd_send_signal(fd, 0)
finally:
    os.close(fd)

require(sha(PRECEDENT / 'wide_overwrite.py') == '0ce4ddf57372fb428355dc0f02088fb0fb1a75499ccd796f27b899f34a400beb',
        'Retained decoder changed')
import pyte
import pyte.screens
import wcwidth
sys.path.insert(0, str(PRECEDENT))
import wide_overwrite
require(Path(wide_overwrite.__file__).resolve(strict=True) == PRECEDENT / 'wide_overwrite.py',
        'Wrong decoder imported')
require(sha(Path(pyte.screens.__file__).resolve(strict=True)) == '43bcd10d5555f6a8e53a1f9c0e557a47ec801b3914533d5b51af5828a5242ecb',
        'Existing pyte screens bytes changed')
modules = {}
for name, module in sorted(sys.modules.items()):
    if name == 'wide_overwrite' or name == 'pyte' or name.startswith('pyte.') or name == 'wcwidth' or name.startswith('wcwidth.'):
        path = Path(module.__file__).resolve(strict=True)
        modules[name] = {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}
result = {
    'schema': 'nk4o-run02-interpreter-pidfd-dependency-prerequisite-v1',
    'status': 'PASS_PREREQUISITES_ONLY_NOT_APP_RUNTIME',
    'authorized_by': 'Main capability/import-only repair instruction',
    'requested_interpreter': '/usr/bin/python',
    'requested_interpreter_resolved': str(Path('/usr/bin/python').resolve(strict=True)),
    'executed_interpreter': sys.executable,
    'resolved_interpreter': str(executable),
    'interpreter_sha256': sha(executable),
    'interpreter_bytes': executable.stat().st_size,
    'interpreter_mode': oct(executable.stat().st_mode & 0o7777),
    'version': sys.version,
    'version_info': list(sys.version_info),
    'native_api_callable': capabilities,
    'self_pidfd_open_and_live_check': True,
    'self_pidfd_signal_zero_capability_check': True,
    'self_pidfd_closed': True,
    'actual_signal_delivered': False,
    'dependency_versions': {'pyte': importlib.metadata.version('pyte'), 'wcwidth': importlib.metadata.version('wcwidth')},
    'imported_dependency_modules': modules,
    'driver_imported': False,
    'App_or_peer_launched': False,
    'pidfd_fallback_used': False,
    'old_interpreter_failure_reexecuted': False,
    'argv': [sys.executable, *sys.argv],
    'environment_contract': {key: os.environ.get(key) for key in ['PATH', 'PYTHONPATH', 'PYTHONDONTWRITEBYTECODE', 'PYTHONNOUSERSITE', 'LC_ALL']},
}
temporary = OUTPUT.with_name(OUTPUT.name+'.'+str(os.getpid())+'.tmp')
temporary.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
os.replace(temporary, OUTPUT)
print(json.dumps(result, ensure_ascii=False, indent=2))
