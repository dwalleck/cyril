#!/bin/sh
exec /usr/bin/python3.14 /tmp/cyril-nk-two-repair-owned-w5f5oys6/harness.py peer
