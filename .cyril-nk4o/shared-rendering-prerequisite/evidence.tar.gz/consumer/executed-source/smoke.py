#!/usr/bin/env -S uv run --script
# /// script
# dependencies = ["pyte==0.8.2"]
# ///
"""Scratch actual-App smoke. Requires an explicit hash-pinned, scoped GO receipt.
No Cargo, real ACP agents, credentials, tools, filesystem callbacks, or grants.
PTY/pyte integration evidence is deliberately not native glyph qualification.
"""
import argparse
import codecs
import fcntl
import hashlib
import json
import os
from pathlib import Path
import pty
import select
import shutil
import signal
import struct
import subprocess
import sys
import termios
import time

HERE = Path(__file__).resolve().parent
COMMITTED = "COMMITTED_COLOR_CONTROL"
LIVE = "LIVE_COLOR_CONTROL"


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


class Smoke:
    def __init__(self, args):
        import pyte
        self.authorization = json.loads(Path(args.authorization).read_text())
        auth = self.authorization
        if auth.get("go") is not True or args.scope not in auth.get("scopes", []):
            raise RuntimeError("No explicit GO for the requested issue scope")
        if not auth.get("source_revision") or len(auth.get("sha256", "")) != 64:
            raise RuntimeError("GO must name the checked source revision and tested binary hash")
        binary = Path(auth["binary"]).resolve(strict=True)
        if digest(binary) != auth["sha256"]:
            raise RuntimeError("Tested binary hash differs from the GO receipt")
        self.root = Path(args.output).resolve()
        self.root.mkdir(parents=True, exist_ok=False)
        self.scope = args.scope
        self.color_mode = args.color_mode
        harness_names = ["smoke.py", "owned_peer.py"] + (["c6la_scenario.py"] if self.scope == "c6la" else [])
        self.scratch = self.root / "isolated"
        for item in ["home", "bin", "config", "data", "cache", "state", "runtime", "ws"]:
            (self.scratch / item).mkdir(parents=True)
        self.staged = self.scratch / "cyril-tested"
        shutil.copyfile(binary, self.staged)
        self.staged.chmod(0o700)
        if digest(self.staged) != auth["sha256"]:
            raise RuntimeError("Staged executable is not the tested binary")
        self.config = self.scratch / "home/.config/cyril/config.toml"
        self.config.parent.mkdir(parents=True)
        self.config.write_text('[ui]\nmax_messages = 1000\nmouse_capture = true\ntheme = "cyril-dark"\ncolor_mode = "' + self.color_mode + '"\n\n[agent]\nengine = "v2"\nkas_hooks = "off"\n\n[memory]\nenabled = false\n')
        self.columns, self.rows = 160, 48
        self.screen = pyte.Screen(self.columns, self.rows)
        self.stream = pyte.Stream(self.screen)
        self.decoder = codecs.getincrementaldecoder("utf-8")("replace")
        self.control_sequence = 0
        self.started = time.monotonic()
        self.raw_offset = 0
        self.raw = (self.root / "terminal.ansi").open("wb")
        self.cast = (self.root / "session.cast").open("w")
        self.cast.write(json.dumps({"version": 2, "width": self.columns, "height": self.rows, "timestamp": int(time.time()), "env": {"TERM": "xterm-256color", "COLORTERM": "truecolor"}, "title": "Owned Cyril actual-App smoke: " + self.scope}) + "\n")
        self.cast_decoder = codecs.getincrementaldecoder("utf-8")("replace")
        self.checks = []
        self.captures = []
        # Whitelist, rather than inherit, the process environment. No real XDG,
        # Kiro, cloud, proxy, token, OMP, or model-provider values reach Cyril.
        environment = {
            "PATH": str(self.scratch / "bin"), "SHELL": "/bin/bash",
            "HOME": str(self.scratch / "home"), "USERPROFILE": str(self.scratch / "home"),
            "XDG_CONFIG_HOME": str(self.scratch / "config"), "XDG_DATA_HOME": str(self.scratch / "data"),
            "XDG_CACHE_HOME": str(self.scratch / "cache"), "XDG_STATE_HOME": str(self.scratch / "state"),
            "XDG_RUNTIME_DIR": str(self.scratch / "runtime"),
            "TERM": "xterm-256color", "COLORTERM": "truecolor", "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8",
            "CYRIL_PERF_SMOKE_ROOT": str(self.root),
        }
        self.command = [str(self.staged), "--cwd", str(self.scratch / "ws"), "--agent-engine", "v2", "--prompt", "owned display fixture", "--agent-command", sys.executable, str(HERE / "owned_peer.py")]
        write_json(self.root / "safety.json", {
            "authorization": auth, "scope": self.scope, "original_binary": str(binary),
            "staged_binary": str(self.staged), "staged_sha256": digest(self.staged),
            "argv": self.command, "environment": environment,
            "harness_sha256": {name: digest(HERE / name) for name in harness_names},
            "real_accounts": False, "model_turns": False, "real_file_operations": False,
            "host_callback_requests": False, "permission_allow_options": False,
            "evidence_layer": "actual Cyril process -> PTY ANSI -> pyte decoded cells; not native graphical-terminal glyph proof",
            "history": {"config_default": 500, "configured_max_messages": 1000, "native_50000_claim": False},
        })
        (self.root / "harness-snapshot").mkdir()
        for name in harness_names:
            shutil.copyfile(HERE / name, self.root / "harness-snapshot" / name)
        self.master, slave = pty.openpty()
        fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", self.rows, self.columns, 0, 0))
        try:
            self.process = subprocess.Popen(self.command, stdin=slave, stdout=slave, stderr=slave, cwd=self.scratch / "ws", env=environment, start_new_session=True)
        finally:
            os.close(slave)

    def event(self, kind, **fields):
        with (self.root / "events.jsonl").open("a") as stream:
            stream.write(json.dumps({"seconds": time.monotonic() - self.started, "kind": kind, **fields}, ensure_ascii=False) + "\n")

    def drain(self, seconds=0.2):
        until = time.monotonic() + seconds
        while time.monotonic() < until:
            ready, _, _ = select.select([self.master], [], [], max(0, until - time.monotonic()))
            if not ready:
                break
            try:
                chunk = os.read(self.master, 65536)
            except OSError:
                break
            if not chunk:
                break
            self.raw.write(chunk)
            self.raw.flush()
            self.raw_offset += len(chunk)
            self.stream.feed(self.decoder.decode(chunk))
            decoded = self.cast_decoder.decode(chunk)
            if decoded:
                self.cast.write(json.dumps([time.monotonic() - self.started, "o", decoded], ensure_ascii=False) + "\n")
                self.cast.flush()

    def text(self):
        return "\n".join(self.screen.display)

    def wait(self, description, predicate, seconds=20):
        deadline = time.monotonic() + seconds
        while not predicate():
            if time.monotonic() >= deadline or self.process.poll() is not None:
                self.capture("failure")
                raise AssertionError(f"{description}; exit={self.process.poll()}\n{self.text()}")
            self.drain(0.1)
        self.drain(0.15)

    def visible(self, *needles):
        self.wait("Missing visible control " + repr(needles), lambda: all(needle in self.text() for needle in needles))

    def peer_state(self):
        state = self.root / "peer-state.json"
        return json.loads(state.read_text()) if state.exists() else {}

    def control(self, **request):
        self.control_sequence += 1
        number = self.control_sequence
        self.event("peer-control", sequence=number, request=request)
        write_json(self.root / f"control-{number:04d}.json", request)
        ack = self.root / f"ack-{number:04d}.json"
        self.wait("Peer control acknowledgement", ack.exists)
        result = json.loads(ack.read_text())
        if not result["ok"]:
            raise AssertionError(result)
        self.drain(0.3)

    def send(self, value):
        self.event("terminal-input", value=value)
        os.write(self.master, value.encode())
        self.drain(0.25)

    def command_input(self, command):
        self.send("\x1b[200~" + command + "\x1b[201~")
        self.send("\r")

    def resize(self, columns, rows):
        self.event("resize", columns=columns, rows=rows)
        fcntl.ioctl(self.master, termios.TIOCSWINSZ, struct.pack("HHHH", rows, columns, 0, 0))
        self.screen.resize(lines=rows, columns=columns)
        self.columns, self.rows = columns, rows
        os.killpg(self.process.pid, signal.SIGWINCH)
        self.cast.write(json.dumps([time.monotonic() - self.started, "r", f"{columns}x{rows}"]) + "\n")
        self.drain(0.5)

    def capture(self, name):
        self.drain()
        (self.root / f"{name}.txt").write_text(self.text())
        cells = []
        for y in range(self.rows):
            for x in range(self.columns):
                cell = self.screen.buffer[y][x]
                cells.append({"x": x, "y": y, **dict(cell._asdict())})
        write_json(self.root / f"{name}.cells.json", {"columns": self.columns, "rows": self.rows, "ansi_end_offset": self.raw_offset, "cells": cells})
        self.captures.append({"name": name, "ansi_end_offset": self.raw_offset})
        self.event("capture", name=name, ansi_end_offset=self.raw_offset)

    def style(self, marker):
        self.visible(marker)
        for y, row in enumerate(self.screen.display):
            if marker in row:
                x = row.index(marker)
                return [{key: value for key, value in self.screen.buffer[y][column]._asdict().items() if key != "data"} for column in range(x, x + len(marker))]
        raise AssertionError("No single-row style control " + marker)

    def check(self, label, condition, **details):
        self.checks.append({"check": label, "pass": bool(condition), **details})
        if not condition:
            self.capture("failure")
            raise AssertionError(label + ": " + repr(details))

    def start_prompt(self, text):
        before = self.peer_state().get("prompts", 0)
        self.command_input(text)
        self.wait("New owned prompt", lambda: self.peer_state().get("prompts", 0) == before + 1)

    def finish(self, outcome, error=None):
        self.capture("final")
        if self.process.poll() is None:
            self.send("\x11")
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(self.process.pid, signal.SIGTERM)
                try:
                    self.process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(self.process.pid, signal.SIGKILL)
                    self.process.wait(timeout=5)
        # The peer stays inside Cyril's owned session; retire it even if Cyril
        # exited before reaping it. No unrelated process/session is touched.
        try:
            os.killpg(self.process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        self.raw.close()
        self.cast.close()
        os.close(self.master)
        log = self.scratch / "home/.config/cyril/cyril.log"
        if log.exists():
            shutil.copyfile(log, self.root / "cyril.log")
        shutil.copyfile(self.config, self.root / "config-final.toml")
        frames = [json.loads(line) for line in (self.root / "wire.jsonl").read_text().splitlines()] if (self.root / "wire.jsonl").exists() else []
        forbidden = [row for row in frames if row["dir"] == "peer->cyril" and row["msg"].get("method", "").startswith(("fs/", "terminal/"))]
        result = {"result": outcome, "scope": self.scope, "authorization": self.authorization, "checks": self.checks, "captures": self.captures, "seconds": time.monotonic() - self.started, "error": error, "wire_frames": len(frames), "unexpected_host_callbacks": forbidden, "native_glyph_qualification": "NOT EXERCISED: PTY/pyte is not Ghostty/Windows Terminal", "performance_counter_proof": "NOT EXERCISED: requires parent TestBackend/work-counter checks", "native_50000_history": "NOT CLAIMED", "terminal_ansi_sha256": digest(self.root / "terminal.ansi")}
        write_json(self.root / "result.json", result)
        print(json.dumps({"result": outcome, "scope": self.scope, "color_mode": self.color_mode, "receipt": str(self.root / "result.json"), "checks": [{"check": row["check"], "pass": row["pass"]} for row in self.checks], "error": error}, indent=2))


def chunk(text, thought=False):
    return {"sessionUpdate": "agent_thought_chunk" if thought else "agent_message_chunk", "content": {"type": "text", "text": text}}


def diff(path, old, new):
    return {"type": "diff", "path": path, "oldText": old, "newText": new}


def x5xi(smoke):
    smoke.wait("Initial real prompt", lambda: smoke.peer_state().get("pending_prompt") is True)
    markdown = "# HISTORY_OLDEST_CONTROL\n\n**Bold**, *emphasis*, [link](https://example.invalid), quote and code controls.\n\n> QUOTE_CONTROL\n\n| Field | Value |\n| --- | --- |\n| Table | TABLE_CONTROL |\n\n" + "".join(f"History row {i:03}: viewport scroll marker SCROLL_{i:03}.\n\n" for i in range(70)) + "```rust\nlet committed_color_control = 42; // " + COMMITTED + "\n```\n"
    smoke.control(updates=[chunk(markdown)], complete=True)
    smoke.visible(COMMITTED)
    smoke.start_prompt("owned live Markdown control")
    smoke.control(updates=[chunk("## Live Markdown\n\n```rust\nlet live_color_control = 7; // " + LIVE + "\n```\n")])
    smoke.visible(COMMITTED, LIVE)
    smoke.capture("01-markdown-committed-and-live")
    baseline = {marker: smoke.style(marker) for marker in [COMMITTED, LIVE]}
    if smoke.color_mode == "truecolor":
        smoke.check("truecolor code controls contain nondefault foreground/background", all(any(cell["fg"] != "default" or cell["bg"] != "default" for cell in cells) for cells in baseline.values()), observed=baseline)
    else:
        smoke.check("startup no-color code cells have no foreground/background colors", all(all(cell["fg"] == "default" and cell["bg"] == "default" for cell in cells) for cells in baseline.values()), observed=baseline)
    theme_scenarios(smoke, baseline)
    smoke.resize(80, 24)
    smoke.visible(LIVE)
    smoke.capture("08-resize-narrow-live")
    smoke.resize(160, 48)
    smoke.visible(COMMITTED, LIVE)
    smoke.capture("09-resize-wide-live")
    scroll_scenarios(smoke)
    smoke.control(updates=[chunk("\nLIVE_APPEND_CONTROL\n")])
    smoke.visible("LIVE_APPEND_CONTROL")
    smoke.capture("13-live-append-after-interactions")
    smoke.control(complete=True)
    smoke.visible("LIVE_APPEND_CONTROL")
    smoke.capture("14-live-committed")


def theme_scenarios(smoke, baseline):
    # Exact baseline-source picker/command bindings are documented in plan.json.
    smoke.command_input("/theme")
    smoke.visible("┌ theme ")
    smoke.capture("02-theme-picker-open")
    smoke.send("gruvbox-dark")
    smoke.capture("03-theme-preview")
    preview = {marker: smoke.style(marker) for marker in [COMMITTED, LIVE]}
    if smoke.color_mode == "truecolor":
        smoke.check("theme preview recolors committed and live code", all(preview[marker] != baseline[marker] for marker in baseline), baseline=baseline, preview=preview)
    else:
        smoke.check("no-color preview preserves uncolored code", preview == baseline, baseline=baseline, preview=preview)
    smoke.send("\x1b")
    smoke.visible(COMMITTED, LIVE)
    cancelled = {marker: smoke.style(marker) for marker in [COMMITTED, LIVE]}
    smoke.check("theme cancel restores committed and live code colors", cancelled == baseline, restored=cancelled)
    smoke.capture("04-theme-preview-cancelled")
    smoke.command_input("/theme")
    smoke.send("gruvbox-dark")
    smoke.send("\r")
    smoke.visible(COMMITTED, LIVE)
    committed = {marker: smoke.style(marker) for marker in [COMMITTED, LIVE]}
    smoke.check("theme commit retains preview colors", committed == preview, committed=committed, preview=preview)
    smoke.capture("05-theme-preview-committed")
    smoke.command_input("/theme")
    smoke.send("cyril-dark")
    smoke.send("\r")
    smoke.visible(COMMITTED, LIVE)
    restored = {marker: smoke.style(marker) for marker in [COMMITTED, LIVE]}
    smoke.check("return palette restores original committed and live styles", restored == baseline, restored=restored)
    smoke.capture("07-return-original-palette")


def scroll_scenarios(smoke):
    smoke.send("\x1b[5~" * 40)
    smoke.visible("HISTORY_OLDEST_CONTROL")
    smoke.check("oldest browse window excludes live tail", LIVE not in smoke.text())
    smoke.capture("10-scroll-oldest")
    smoke.send("\x1b[6~" * 40)
    smoke.visible(LIVE)
    smoke.send("\x1b[5~" * 3)
    smoke.check("middle browse window differs from oldest and live tail", "HISTORY_OLDEST_CONTROL" not in smoke.text() and LIVE not in smoke.text())
    smoke.capture("11-scroll-middle")
    smoke.send("\x1b[6~" * 40)
    smoke.visible(LIVE)
    smoke.capture("12-scroll-return-to-follow")


def zj0m(smoke):
    smoke.wait("Initial real prompt", lambda: smoke.peer_state().get("pending_prompt") is True)
    old = "context-anchor\nold-first\nfooter-anchor\n"
    new = "context-anchor\nnew-first\nnew-second\nfooter-anchor\n"
    first = diff("owned_display_only.rs", old, new)
    second = diff("ignored_display_only.rs", "ignored-old\n", "IGNORED_SECOND_DIFF\n")
    smoke.control(updates=[chunk("WRITE_CHRONOLOGY_BEFORE\n"), {"sessionUpdate": "tool_call", "toolCallId": "owned-write", "title": "fs_write", "kind": "edit", "status": "pending", "rawInput": {"path": "owned_display_only.rs"}}])
    smoke.visible("owned_display_only.rs")
    smoke.capture("z01-write-start")
    smoke.control(updates=[{"sessionUpdate": "tool_call_update", "toolCallId": "owned-write", "kind": "edit", "status": "in_progress", "content": [first, second]}])
    smoke.capture("z02-write-incremental")
    smoke.control(updates=[{"sessionUpdate": "tool_call_update", "toolCallId": "owned-write", "kind": "edit", "status": "completed"}])
    smoke.visible("+2 -1", "new-first", "new-second", "old-first")
    smoke.check("first Diff owns completed counts and body", "IGNORED_SECOND_DIFF" not in smoke.text())
    smoke.capture("z03-write-completed")
    smoke.resize(100, 32)
    smoke.visible("+2 -1", "new-first")
    smoke.capture("z04-write-resized")
    smoke.resize(160, 48)
    smoke.control(updates=[{"sessionUpdate": "tool_call_update", "toolCallId": "owned-write", "kind": "edit", "status": "completed", "content": [diff("owned_display_only.rs", "stable\n", "stable\n"), second]}])
    smoke.wait(
        "App redraw applies unchanged-first-Diff replacement",
        lambda: "owned_display_only.rs" in smoke.text()
        and all(marker not in smoke.text() for marker in ["+2 -1", "new-first", "new-second", "old-first"]),
    )
    smoke.check("unchanged first Diff suppresses later Diff counts and body", "+2 -1" not in smoke.text() and "new-first" not in smoke.text() and "IGNORED_SECOND_DIFF" not in smoke.text())
    smoke.capture("z05-unchanged-first-changed-second")
    smoke.control(updates=[{"sessionUpdate": "tool_call_update", "toolCallId": "owned-write", "kind": "edit", "status": "completed", "content": [first, second]}])
    smoke.visible("+2 -1", "new-first", "new-second")
    smoke.capture("z06-replaced-diff-source")
    original_style = smoke.style("new-first")
    smoke.command_input("/theme")
    smoke.send("gruvbox-dark")
    smoke.send("\r")
    smoke.visible("+2 -1", "new-first", "new-second")
    changed_style = smoke.style("new-first")
    smoke.check("retained first-Diff styling follows committed palette", changed_style != original_style if smoke.color_mode == "truecolor" else changed_style == original_style, before=original_style, after=changed_style)
    smoke.capture("z06a-retained-diff-new-palette")
    padding = "".join(f"WRITE_HISTORY_PAD_{number:03}\n\n" for number in range(70))
    smoke.control(updates=[chunk(padding), {"sessionUpdate": "tool_call", "toolCallId": "owned-history-boundary", "title": "Owned display boundary", "kind": "read", "status": "completed", "rawInput": {"path": "HISTORY_FOLLOW_CONTROL"}}])
    smoke.visible("HISTORY_FOLLOW_CONTROL")
    smoke.check("completed Diff actually leaves the viewport", "new-first" not in smoke.text() and "+2 -1" not in smoke.text())
    smoke.capture("z06b-diff-scrolled-out")
    for _ in range(16):
        if "new-first" in smoke.text():
            break
        smoke.send("\x1b[5~")
    smoke.visible("+2 -1", "new-first", "new-second")
    smoke.check("offscreen retained Diff returns with new-palette styles", smoke.style("new-first") == changed_style)
    smoke.capture("z06c-diff-browsed-back")
    smoke.send("\x1b[6~" * 16)
    smoke.visible("HISTORY_FOLLOW_CONTROL")
    pending = {"sessionUpdate": "tool_call", "toolCallId": "owned-pending-write", "title": "fs_write", "kind": "edit", "status": "pending", "rawInput": {"path": "pending_display_only.rs"}, "content": [diff("pending_display_only.rs", "PENDING_OLD\n", "PENDING_NEW\n")]}
    smoke.control(updates=[pending])
    smoke.visible("pending_display_only.rs")
    permission = {"id": "owned-deny-only", "params": {"toolCall": {"toolCallId": "owned-pending-write", "title": "fs_write", "kind": "edit", "status": "pending"}, "options": [{"optionId": "deny", "name": "Reject", "kind": "reject_once"}]}}
    smoke.control(permission=permission)
    smoke.visible("PENDING_OLD", "PENDING_NEW")
    smoke.capture("z07-pending-comparison")
    smoke.resize(100, 32)
    smoke.visible("PENDING_OLD", "PENDING_NEW")
    smoke.capture("z08-pending-resized")
    smoke.send("\r")
    smoke.wait("Explicit rejection response", lambda: any(item.get("id") == "owned-deny-only" for item in smoke.peer_state().get("responses", [])))
    response = next(item for item in smoke.peer_state()["responses"] if item.get("id") == "owned-deny-only")
    smoke.check("only pending permission outcome is reject", response.get("result", {}).get("outcome") == {"outcome": "selected", "optionId": "deny"}, wire=response)
    smoke.resize(160, 48)
    smoke.command_input("/theme")
    smoke.send("cyril-dark")
    smoke.send("\r")
    smoke.control(updates=[chunk("WRITE_CHRONOLOGY_AFTER\n")], complete=True)
    smoke.visible("WRITE_CHRONOLOGY_AFTER")
    smoke.capture("z09-completed-and-rejected")


def c6la(smoke):
    from c6la_scenario import run
    run(smoke)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--authorization", required=True)
    parser.add_argument("--scope", choices=["x5xi", "zj0m", "c6la"], required=True)
    parser.add_argument("--color-mode", choices=["truecolor", "none"], default="truecolor")
    parser.add_argument("--output", required=True, help="Fresh, nonexisting evidence directory")
    args = parser.parse_args()
    smoke = Smoke(args)
    try:
        {"x5xi": x5xi, "zj0m": zj0m, "c6la": c6la}[args.scope](smoke)
    except BaseException as error:
        smoke.finish("FAIL", repr(error))
        raise
    else:
        smoke.finish("PASS")


if __name__ == "__main__":
    main()
