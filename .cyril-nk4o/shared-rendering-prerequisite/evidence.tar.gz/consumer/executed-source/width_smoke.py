#!/usr/bin/env -S uv run --script
# /// script
# dependencies = ["pyte==0.8.2"]
# ///
"""Prepare-only until explicitly authorized; actual owned-V2/PTy shared-width smoke.
Reuses the frozen parent Smoke/owned_peer; no product or native agent is run at import.
"""
import argparse
import json
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
import importlib
legacy = importlib.import_module("smoke")
Smoke, digest, write_json = legacy.Smoke, legacy.digest, legacy.write_json

SCOPE = "ratatui-shared-width"
CODE_BG = "282c34"


def cells_at(smoke, marker):
    return [(x, y) for y in range(smoke.rows) for x in range(smoke.columns - len(marker) + 1)
            if all(smoke.screen.buffer[y][x + i].data == char for i, char in enumerate(marker))]


def one(smoke, marker):
    smoke.wait("Exactly one physical-cell ASCII marker " + marker, lambda: len(cells_at(smoke, marker)) == 1)
    return cells_at(smoke, marker)[0]


def painted_carets(smoke):
    # These LF-free fixtures have a five-row input, no suggestions/crew/voice,
    # and one bottom status row (input.rs:19-25; render.rs:122-132).
    # Search its interior only; chat/scrollbar blocks are not input carets.
    return [(x, y) for y in range(smoke.rows - 5, smoke.rows - 2)
            for x in range(1, smoke.columns - 1)
            if "█" in smoke.screen.buffer[y][x].data]


def caret(smoke):
    smoke.wait("One structural input caret", lambda: len(painted_carets(smoke)) == 1)
    return painted_carets(smoke)[0]


def expect_caret(smoke, label, expected):
    smoke.wait(label, lambda: painted_carets(smoke) == [expected])
    smoke.check(label, painted_carets(smoke) == [expected], expected=expected, actual=painted_carets(smoke))


class WidthSmoke(Smoke):
    def capture(self, name):
        super().capture(name)
        path = self.root / (name + ".cells.json")
        snapshot = json.loads(path.read_text())
        snapshot["painted_input_carets"] = painted_carets(self)
        snapshot["transport_cursor_not_draft_oracle"] = {
            "x": self.screen.cursor.x, "y": self.screen.cursor.y,
            "hidden": getattr(self.screen.cursor, "hidden", None),
        }
        write_json(path, snapshot)

    def finish(self, outcome, error=None):
        super().finish(outcome, error)
        path = self.root / "result.json"
        receipt = json.loads(path.read_text())
        receipt["qualification_status"] = self.authorization["qualification_status"]
        receipt["acceptance_boundary"] = "Owned fake-V2 shared-width smoke only; not clearance of any blocked source gate, native acceptance, C6 or MCP qualification."
        write_json(path, receipt)

    def record_extras(self):
        snapshot = self.root / "harness-snapshot/shared-width-prepare"
        snapshot.mkdir()
        safety_path = self.root / "safety.json"
        safety = json.loads(safety_path.read_text())
        safety["qualification_status"] = self.authorization["qualification_status"]
        safety["known_parent_gate"] = self.authorization.get("known_parent_gate")
        safety["acceptance_boundary"] = "No snapshot waiver; passing an owned smoke does not clear a blocked UI crate or authorize native acceptance."
        for name in ["width_smoke.py", "fixtures.json"]:
            shutil.copyfile(HERE / name, snapshot / name)
            safety["harness_sha256"]["shared-width-prepare/" + name] = digest(HERE / name)
        safety["release_contract"] = "ratatui-core0.1.2/widgets0.3.2; CellWidth physical symbols; scalar input wrapping unchanged"
        safety["engine_binding"] = "explicit v2; no _meta.kiro; bare UUID sessions; direct owned Python peer; no KAS/native auth"
        safety["failure_policy"] = "First new failure STOP, retain original bytes; no automatic retry, normalization or fallback engine"
        safety["excluded_claims"] = ["native graphical-terminal glyphs", "TestBackend/work-counter proof", "50k history", "C6 history/gutters", "MCP painter", "separate /code intelligence panel"]
        write_json(safety_path, safety)

    def payload(self, name, text):
        path = self.root / (name + ".utf8.bin")
        path.write_bytes(text.encode("utf-8"))
        write_json(self.root / (name + ".payload.json"), {
            "text": text, "scalars": [f"U+{ord(char):04X}" for char in text],
            "utf8_hex": text.encode("utf-8").hex(), "sha256": digest(path), "normalization": "NONE",
        })


def check_markdown(smoke, fixture, name):
    positions = [one(smoke, marker) for marker in fixture["table_sentinels"]]
    smoke.check(name + " table second-column physical alignment", {x for x, _ in positions} == {5}, positions=positions)
    for marker, expected in zip(fixture["table_sentinels"][:4], ["ｶﾞ", "ｶﾟ", "A゙", "B゚"]):
        _, y = one(smoke, marker)
        actual = "".join(smoke.screen.buffer[y][x].data for x in range(2)).strip()
        smoke.check(name + " original table cluster " + marker, actual == expected, actual=actual, expected=expected)
    hx, hy = one(smoke, "lang")
    smoke.check(name + " code-label physical origin", hx == 5, actual=(hx, hy))
    smoke.check(name + " code-label mark and following Z columns",
                [smoke.screen.buffer[hy][x].data for x in [9, 10, 11]] == ["ｶ", "ﾞ", "Z"])
    for row in fixture["code_rows"]:
        x, y = one(smoke, row["prefix"])
        sx, sy = one(smoke, row["suffix"])
        smoke.check(name + " code inline sentinel " + row["prefix"],
                    (x, sx, sy) == (2, 2 + len(row["prefix"]) + row["cells"], y), actual=(x, y, sx, sy))
        smoke.check(name + " complete code background " + row["prefix"],
                    all(smoke.screen.buffer[y][column].bg == CODE_BG for column in range(smoke.columns)))
    smoke.check(name + " complete header background", all(smoke.screen.buffer[hy][x].bg == CODE_BG for x in range(smoke.columns)))
    fx, fy = one(smoke, "CODE_FOLLOW_ASCII_SENTINEL")
    smoke.check(name + " following paragraph origin/style", fx == 0 and smoke.screen.buffer[fy][fx].bg == "default", actual=(fx, fy), bg=smoke.screen.buffer[fy][fx].bg)
    smoke.capture(name)


def paste(smoke, text):
    smoke.send("\x1b[200~" + text + "\x1b[201~")


def submit_exact(smoke, text, name):
    before = smoke.peer_state().get("prompts", 0)
    smoke.send("\r")
    smoke.wait("New real session/prompt for " + name, lambda: smoke.peer_state().get("prompts", 0) == before + 1)
    frames = [json.loads(line) for line in (smoke.root / "wire.jsonl").read_text().splitlines()]
    outgoing = [row["msg"] for row in frames if row["dir"] == "cyril->peer" and row["msg"].get("method") == "session/prompt"][-1]
    blocks = outgoing["params"]["prompt"]
    actual = [block["text"] for block in blocks if block.get("type") == "text"]
    smoke.check(name + " exact outgoing UTF-8 and scalars", len(actual) == 1 and actual[0].encode("utf-8") == text.encode("utf-8"), actual=actual, expected=text)
    wait_busy(smoke)
    smoke.control(complete=True)
    smoke.wait("Owned prompt completed", lambda: smoke.peer_state().get("pending_prompt") is False)
    wait_idle(smoke)


def toolbar_session_at(smoke, x):
    session = smoke.peer_state().get("session_id", "")
    return bool(session) and all(smoke.screen.buffer[0][x + i].data == char for i, char in enumerate(session))


def wait_busy(smoke):
    smoke.wait("Actual UI busy spinner and UUID at x2",
               lambda: toolbar_session_at(smoke, 2) and smoke.screen.buffer[0][0].data in "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏")


def wait_idle(smoke):
    smoke.wait("Actual UI processed end_turn: UUID at x0 without spinner",
               lambda: smoke.peer_state().get("pending_prompt") is False and toolbar_session_at(smoke, 0))


def check_short_data(smoke, case, x, y, label):
    cluster = [case["cluster"]] if case["combining"] else list(case["cluster"])
    expected = cluster + ["Z", "█"]
    start = x + len(case["prefix"])
    actual = [smoke.screen.buffer[y][start + i].data for i in range(len(expected))]
    smoke.check(label + " visible original cluster + ASCII sentinel + caret", actual == expected, actual=actual, expected=expected)


def check_short_input(smoke, case):
    name = "i-" + case["id"]
    text = case["prefix"] + case["cluster"] + "Z"
    smoke.payload(name, text)
    paste(smoke, text)
    x, y = one(smoke, case["prefix"])
    end = (x + len(case["prefix"]) + case["cells"] + 1, y)
    expect_caret(smoke, name + " end scalar caret", end)
    check_short_data(smoke, case, x, y, name + " initial")
    smoke.capture(name + "-end")
    smoke.send("\x1b[D")
    expect_caret(smoke, name + " before ASCII sentinel", (end[0] - 1, y))
    smoke.send("\x1b[D")
    middle = (end[0] - (1 if case["combining"] else 2), y)
    expect_caret(smoke, name + " between scalars, not grapheme jump", middle)
    smoke.capture(name + "-between-scalars")
    smoke.send("\x1b[3~")
    expect_caret(smoke, name + " Delete removes next scalar without moving caret", middle)
    if not case["combining"]:
        smoke.check(name + " deleted halfwidth mark vacates old following column", smoke.screen.buffer[y][end[0]].data == " ")
    smoke.send(case["cluster"][-1])
    expect_caret(smoke, name + " original mark reinserted without normalization", (end[0] - 1, y))
    smoke.send("\x1b[C")
    expect_caret(smoke, name + " restored End", end)
    check_short_data(smoke, case, x, y, name + " mark restored")
    smoke.send("\x7f")
    expect_caret(smoke, name + " Backspace shrinks one ASCII scalar", (end[0] - 1, y))
    smoke.send("Z")
    expect_caret(smoke, name + " replacement preserves physical end", end)
    check_short_data(smoke, case, x, y, name + " ASCII restored")
    smoke.send("\x1b[H")
    expect_caret(smoke, name + " Home whole draft", (x, y))
    smoke.send("\x1b[F")
    expect_caret(smoke, name + " End whole draft", end)
    check_short_data(smoke, case, x, y, name + " Home/End restored")
    submit_exact(smoke, text, name)


def check_wrap_input(smoke, case, index):
    name = "b-" + case["id"]
    prefix = "BOUND" + str(index) + "="
    width = smoke.columns - 2
    text = prefix + "x" * (width - 1 - len(prefix)) + case["cluster"] + "Z"
    smoke.payload(name, text)
    paste(smoke, text)
    x, y = one(smoke, prefix)
    smoke.check(name + " source inner geometry", x == 1, inner_width=width, origin=(x, y))
    first = smoke.screen.buffer[y][x + width - 1].data
    expected_first = case["cluster"] if case["combining"] else case["cluster"][0]
    smoke.check(name + " exact-fit first scalar at last physical column", first == expected_first, actual=first, expected=expected_first)
    following = [smoke.screen.buffer[y + 1][x + i].data for i in range(3)]
    expected = ["Z", "█"] if case["combining"] else [case["cluster"][1], "Z", "█"]
    smoke.check(name + " scalar wrap not grapheme wrap", following[:len(expected)] == expected, actual=following, expected=expected)
    expect_caret(smoke, name + " structural caret after wrapped sentinel", (x + len(expected) - 1, y + 1))
    smoke.capture(name + "-char-wrap")
    submit_exact(smoke, text, name)


def check_approval_cells(smoke, name):
    _, title_y = one(smoke, "Permission Required")
    option_rows = [y for _, y in cells_at(smoke, "Reject") if y > title_y]
    smoke.wait("Approval reject option below title", lambda: bool(option_rows))
    candidates = [(x, y) for x, y in cells_at(smoke, "DISPLAY_ONLY_") if title_y < y < min(option_rows)]
    smoke.check(name + " actual preview inside overlay", len(candidates) == 1, positions=candidates)
    x, y = candidates[0]
    expected = ["ｶ", "ﾞ", "Z", "_", "ｶ", "ﾟ", "Z", "_", "A゙", "Z", "_", "B゚", "Z"]
    actual = [smoke.screen.buffer[y][x + len("DISPLAY_ONLY_") + i].data for i in range(len(expected))]
    smoke.check(name + " preview halfwidth physical cells and combining controls", actual == expected, actual=actual, expected=expected)


def check_approval(smoke, fixture):
    smoke.start_prompt("APPROVAL_DISPLAY_ONLY")
    wait_busy(smoke)
    prompt_count = smoke.peer_state()["prompts"]
    draft = "DRAFT_ONLY:ｶﾞZ"
    paste(smoke, draft)
    before = caret(smoke)
    smoke.payload("approval-inert-command", fixture["pending_command"])
    tool = {"sessionUpdate": "tool_call", "toolCallId": fixture["pending_tool_id"], "title": fixture["pending_tool_title"], "kind": "execute", "status": "pending", "rawInput": {"command": fixture["pending_command"], "text": fixture["pending_command"]}}
    permission = {"id": "owned-width-deny-only", "params": {"toolCall": {key: tool[key] for key in ["toolCallId", "title", "kind", "status"]}, "options": [{"optionId": "deny", "name": "Reject", "kind": "reject_once"}]}}
    smoke.control(updates=[tool], permission=permission)
    smoke.visible("Permission Required", "DISPLAY_ONLY_", "Reject")
    smoke.check("approval real text preview, not unavailable fallback", "Preview unavailable" not in smoke.text())
    check_approval_cells(smoke, "a01")
    smoke.capture("a01-pending-reject-only")
    smoke.resize(80, 32)
    smoke.visible("Permission Required", "DISPLAY_ONLY_", "Reject")
    check_approval_cells(smoke, "a02")
    smoke.capture("a02-pending-geometry")
    smoke.send("\r")
    smoke.wait("Actual reject-only permission reply", lambda: any(row.get("id") == "owned-width-deny-only" for row in smoke.peer_state().get("responses", [])))
    response = next(row for row in smoke.peer_state()["responses"] if row.get("id") == "owned-width-deny-only")
    smoke.check("approval selected reject, no grant", response.get("result", {}).get("outcome") == {"outcome": "selected", "optionId": "deny"}, wire=response)
    smoke.wait("Actual approval popup closed", lambda: "Permission Required" not in smoke.text())
    smoke.check("approval Enter did not submit underlying draft", smoke.peer_state()["prompts"] == prompt_count)
    smoke.resize(52, 32)
    smoke.visible(draft)
    expect_caret(smoke, "approval close restores existing draft caret", before)
    smoke.capture("a03-closed-draft-preserved")
    smoke.send("\x1b[F" + "\x7f" * len(draft))
    smoke.wait("Draft cleared by scalar Backspace, not submission", lambda: not cells_at(smoke, "DRAFT_ONLY:"))
    wait_busy(smoke)
    smoke.control(complete=True)
    smoke.wait("Owned approval prompt completed", lambda: smoke.peer_state().get("pending_prompt") is False)
    wait_idle(smoke)


def run(smoke, fixture):
    smoke.record_extras()
    for control in fixture["scalar_controls"]:
        smoke.check("fixture original scalars " + control["id"], [f"U+{ord(char):04X}" for char in control["text"]] == control["scalars"])
    smoke.wait("Initial owned actual prompt", lambda: smoke.peer_state().get("pending_prompt") is True)
    wait_busy(smoke)
    smoke.payload("markdown-original", fixture["markdown"])
    smoke.control(updates=[{"sessionUpdate": "agent_message_chunk", "content": {"type": "text", "text": fixture["markdown"]}}])
    check_markdown(smoke, fixture, "m01-live-160")
    wait_busy(smoke)
    smoke.control(complete=True)
    smoke.wait("Initial peer completion", lambda: smoke.peer_state().get("pending_prompt") is False)
    wait_idle(smoke)
    check_markdown(smoke, fixture, "m02-committed-160")
    smoke.resize(80, 40)
    check_markdown(smoke, fixture, "m03-committed-80")
    smoke.resize(52, 32)
    check_markdown(smoke, fixture, "m04-committed-52")
    for case in fixture["input_cases"]:
        check_short_input(smoke, case)
    for index, case in enumerate(fixture["input_cases"]):
        check_wrap_input(smoke, case, index)
    check_approval(smoke, fixture)
    frames = [json.loads(line) for line in (smoke.root / "wire.jsonl").read_text().splitlines()]
    forbidden = [row for row in frames if row["dir"] == "peer->cyril" and row["msg"].get("method", "").startswith(("fs/", "terminal/"))]
    smoke.check("no filesystem/terminal host callbacks", not forbidden, frames=forbidden)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--authorization", required=True)
    parser.add_argument("--output", required=True, help="Fresh nonexistent evidence directory; never reuse an old run")
    args = parser.parse_args()
    auth = json.loads(Path(args.authorization).read_text())
    if auth.get("go") is not True or SCOPE not in auth.get("scopes", []):
        parser.error("PREPARE ONLY: exact binary/hash and explicit ratatui-shared-width GO required")
    if auth.get("engine") != "v2":
        parser.error("Only explicit valid owned V2 is supported; no native/KAS fallback")
    if len(auth.get("actual_qualified_tree") or "") != 40:
        parser.error("GO must bind the actual qualified source tree")
    if auth.get("qualification_status") not in ("PARTIAL_UI_CRATE_BLOCKED", "QUALIFIED"):
        parser.error("GO must explicitly label PARTIAL_UI_CRATE_BLOCKED or QUALIFIED; no inferred source-gate clearance")
    fixture = json.loads((HERE / "fixtures.json").read_text())
    args.scope, args.color_mode = SCOPE, "truecolor"
    smoke = WidthSmoke(args)
    try:
        run(smoke, fixture)
    except BaseException as error:
        smoke.finish("FAIL", repr(error))
        raise
    else:
        smoke.finish("PASS")


if __name__ == "__main__":
    main()
