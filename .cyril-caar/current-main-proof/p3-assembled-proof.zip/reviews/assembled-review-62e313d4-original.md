## Finding

### [P3] Avoid marking the active root noncurrent during a same-ID reload

**File:** `/home/dwalleck/repos/cyril-wt-fix-cyril-caar-final/crates/cyril-ui/src/state.rs`  
**Lines:** 1436–1437  
**Confidence:** 0.98

When root `A` is active and `session/load A` is pending, scoped MCP progress for `A` receives `BoundRequestedLoad` at `domain_mediator/startup.rs:164–167` and is intercepted before ordinary main routing at `app.rs:1481–1495`. This new formatter therefore durably displays `Session 'A' (requested load; not yet current root)`, although `A` remains the established current root throughout the wait and after a recoverable load failure. Same-ID reload is explicitly supported by the inherited/current cases at `domain_mediator/tests/mcp.rs:607–624`. Describe the pending request instead—for example, “requested load; response pending”—without asserting that its session is noncurrent. This is a presentation/provenance defect, not a demonstrated registry or session-authority failure.

## Verdict

**Overall correctness:** incorrect  
**Explanation:** One low-severity, patch-introduced provenance defect remains in same-ID Load presentation. Otherwise, the assembled Caar implementation follows the approved ownership and behavior decisions; no additional actionable source defect was found.  
**Confidence:** 0.95

This is an **ordinary assembled design/source review**, not an isolated reconstruction or an acceptance/merge-readiness verdict.

## Reviewed state and governing scope

Reviewed `62e313d4d27c5c76348ce7e6a58f794e56ff839b` against NK parent `89ef8075c9972d5c2489485041adcdd962ed5f54`, including affected inherited Tqr/NK consumers and lifecycle owners.

Read the Caar design identified by recorded SHA256 `1bb82ba2e8c3598fc90633243ade95985d9f6b170dbeaef9ed011bfe923b4df8`, its specification and approved replacement-root amendment, plus inherited NK/Tqr designs. The current Gilfoyle contract makes ordinary substantive independent review the default; no universal isolated-reconstruction requirement was imposed.

## Assembled source/design conclusions

Paths below are relative to the reviewed worktree.

| Concern | Evidence and conclusion |
|---|---|
| **Admitted diagnostic generations** | `crates/cyril-core/src/protocol/domain_mediator/startup.rs:320–336` consumes `begin_mcp_session` before allocating an attempt. Inherited `domain_mediator/mcp.rs:29–49` remains the sole admission policy. No duplicate busy guard or remotely-created-success discard substitutes for admission. |
| **New/Load/control/prompt distinction** | `domain_mediator/commands/mod.rs:18–48` retains separate 90/30/10-second budgets. `commands/session.rs:138–170` classifies New’s actual timeout before ACP error conversion. Load retains its recoverable error path at `session.rs:208–240`; prompt remains an unbounded `sent.block_task().await` at `session.rs:540`. |
| **Session provenance** | `protocol/convert/kiro.rs:1119–1178` preserves actual optional v2 session IDs; `domain_mediator/inbound.rs:213–235` routes them with that scope. `startup.rs:97–170` separates diagnostic scopes and qualifies New versus explicitly targeted Load without inferring the new root’s identity. |
| **Timeout categories and inventory limits** | `startup.rs:210–317` distinguishes reported outcomes, explicit OAuth waits and announced-unsettled connecting rows. Received KAS snapshots replace facts only within their actual scope. Candidate pools never become unanswered-New root inventory; the final diagnostic explicitly states the pending root’s complete inventory is unknown. No config resolver, polling, premature startup-status parser or first-candidate binding was introduced. |
| **Cross-boundary outcome consumption** | `CommandOutcome::RootStartFinished` is explicitly dispatched at `domain_mediator/mod.rs:534–535`. `startup.rs:173–200` checks generation before consuming an attempt, and `startup.rs:338–377` applies success/fatal/recoverable/stale decisions serially. Nonterminal progress passes through the existing turn-mediator catch-all without losing its envelope metadata. |
| **Publication and failure lifecycle** | `commands/session.rs:254–285` preserves `UsageSessionStarted → SessionCreated → initial config → matching staged MCP state`. Inherited `mcp.rs:55–113` keeps exact-ID replay separate from still-active-root authority. Fatal fingerprint preflight precedes admission at `session.rs:189–202`; shutdown still aborts waiters and delegates owned runtime/process cleanup. |
| **Progress retention and consumers** | `app.rs:1475–1554` consumes qualified progress as display-only history and avoids replay duplication. `cyril-ui/src/state.rs:1412–1446` uses the established durable notice/reveal owner; `subagent_ui.rs:106–110` retains scoped chronology. Main OAuth and CLI ready/failure/OAuth have concrete consumers at `app.rs:1670–1675` and `cyril/examples/test_bridge.rs:622–658`. |
| **Protected owners and inherited behavior** | App adds typed routing/presentation wiring, not timers, inventory calculation or a correlation ledger. Startup joining/diagnostics live in the cohesive private startup owner. Engine and generic host lifecycle receive no Caar responsibility body. Tqr global URL delivery, canonical scoped errors/main presentation copies, adoption behavior and NK admission/staging remain intact in the affected paths. |

The added deadline, scope, fingerprint, generation, owned-process and App replacement-history tests were inspected as source, including the twelve parameterized replacement cases. **They were not executed.**

## Retained earlier reviews

The earlier bounded Core 0.94 and consumer 0.95 reports remain useful only within their original scopes. I compared the current committed **25 Caar feature-path blob identities** against `current-main-proof/feature-files.json`; all match the recorded postformat rows, including the ten formatter-affected paths.

That supports retaining their unchanged conclusions alongside this fresh review. It does **not** upgrade their original confidence, historical line anchors or runtime claims, nor make their earlier “no findings” statements cover the newly identified same-ID qualifier defect. The existing Tqr ordinary review remains applicable to unaffected production responsibilities; affected shared consumers were inspected here.

## Limits

No edits, builds, tests, linters, formatters, applications, native execution, authentication probes or Git mutations were performed. LSP reference searches returned empty results despite visible callers; those results were discarded, and dispatch tracing used source inspection.

Native529 remains blocked by the reported fresh-login prerequisite. Native startup/inventory and held-response acceptance, OAuth completion, CI/platform qualification and merge readiness are **not established by this source verdict**.