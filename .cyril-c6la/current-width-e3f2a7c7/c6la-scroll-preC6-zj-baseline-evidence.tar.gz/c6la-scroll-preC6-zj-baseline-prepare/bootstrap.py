"""Prepared only. A new explicit Main GO is required before invoking this file."""

import argparse
import hashlib
import importlib.metadata
import inspect
import json
import os
from pathlib import Path
import runpy
import select
import signal
import sys
import time

import pyte

from wide_overwrite import WideOverwrite

HERE = Path(__file__).resolve().parent
HARNESS = HERE / "smoke.py"
PEER = HARNESS.with_name("owned_peer.py")
PROOF = HERE / "decoder-proof.py"
BINARY = Path("/tmp/cyril-zj0m-current-width-tested-20261021")
OUTPUT = HERE.parent / "c6la-scroll-preC6-zj-original400-truecolor-01"
PINS = {
    HARNESS: "c9ce883004155aef05e5a1dd68723be16e3507cc2873aff977e3cb554f34ec2a",
    PEER: "6c5b5b64f1e5d4ec306b6028e299a96340891961dfaf0cdb046dc2b1240f9cfe",
    PROOF: "e0e744c261b360693a6352ca5225b452a1099bc836636bff718d7da6ce15ffd6",
    BINARY: "b9c988540861e4a9d8e3379d6a2833225bbe417e7ff1ec0aea40321677e687e1",
    HERE / "c6la_scenario.py": "d41cf6718f65fd2d2299b7ae5c4a2b8ded96a0a9cde310cc0c0e567f70431b55",
    HERE / "v2_failed_validation_2_11_0.jsonl": "4b9ee48758874a98a4eb275e35632aa32f782550d2dfdc0f285c3ec6f576da0d",
    HERE / "wide_overwrite.py": "0ce4ddf57372fb428355dc0f02088fb0fb1a75499ccd796f27b899f34a400beb",
    HERE / "canonical-handoff.json": "9ffea80c46ce8b703f0ae6d9795290b7d80affdea0667d21cda1325218cf8dcd",
    HERE / "private-binary-provenance.json": "def4c5a63ab5ef18dba5933d968154d98d23c32a516f0d45afe59506e875fcb2",
    HERE / "final-actual-assembled-after-all-requested-gates.source-manifest.json": "2d4e94560cc1b83a2ae6299113ea7d24f7d91264effa063388fe9bc92daa03ec",
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def owned_handles(output, observations):
    """Pin process identities before inspecting their exact private-run marker."""
    handles = []
    marker = ("CYRIL_PERF_SMOKE_ROOT=" + str(output)).encode()
    app = str(output / "isolated/cyril-tested").encode()
    peer_argv = [os.fsencode(sys.executable), os.fsencode(PEER)]
    for entry in Path("/proc").iterdir():
        if not entry.name.isdecimal():
            continue
        pid = int(entry.name)
        fd = None
        try:
            fd = os.pidfd_open(pid)
            environment = (entry / "environ").read_bytes().split(b"\0")
            if marker not in environment:
                continue
            argv = [arg for arg in (entry / "cmdline").read_bytes().split(b"\0") if arg]
            expected_home = ("HOME=" + str(output / "isolated/home")).encode()
            expected_path = ("PATH=" + str(output / "isolated/bin")).encode()
            command_matches = bool(argv) and (argv[0] == app or argv == peer_argv)
            if not command_matches or expected_home not in environment or expected_path not in environment:
                observations.append({"pid": pid, "ownership": "marker matched but command/private environment not proven; not signaled"})
                continue
            observations.append({"pid": pid, "ownership": "exact marker, command and private environment proven", "argv": [os.fsdecode(arg) for arg in argv], "pgid": os.getpgid(pid), "sid": os.getsid(pid)})
            handles.append((pid, fd))
            fd = None
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
        finally:
            if fd is not None:
                os.close(fd)
    return handles


def wait_handles(handles, seconds):
    pending = {fd for _, fd in handles}
    deadline = time.monotonic() + seconds
    while pending:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        ready, _, _ = select.select(list(pending), [], [], remaining)
        pending.difference_update(ready)
    return pending


def cleanup_owned(output, receipt):
    """Never signal a PID by number: pidfds retain only proven owned identities."""
    for sweep in range(2):
        handles = owned_handles(output, receipt["observations"])
        if not handles:
            break
        try:
            for pid, fd in handles:
                try:
                    signal.pidfd_send_signal(fd, signal.SIGTERM)
                    receipt["signals"].append({"pid": pid, "signal": "SIGTERM", "sweep": sweep})
                except ProcessLookupError:
                    pass
            pending = wait_handles(handles, 5)
            for pid, fd in handles:
                if fd in pending:
                    try:
                        signal.pidfd_send_signal(fd, signal.SIGKILL)
                        receipt["signals"].append({"pid": pid, "signal": "SIGKILL", "sweep": sweep})
                    except ProcessLookupError:
                        pass
            if wait_handles(handles, 5):
                raise RuntimeError("Proven marker-owned process did not exit after bounded cleanup")
        finally:
            for _, fd in handles:
                os.close(fd)
    survivors = owned_handles(output, receipt["observations"])
    try:
        receipt["surviving_proven_owned_pids"] = [pid for pid, _ in survivors]
        receipt["unproven_marker_pids"] = sorted({row["pid"] for row in receipt["observations"] if "not proven" in row["ownership"]})
        if survivors or receipt["unproven_marker_pids"]:
            raise RuntimeError("Owned cleanup could not attest an empty marker-owned process set")
        receipt["status"] = "COMPLETE — no proven-owned survivors or unproven marker matches"
    finally:
        for _, fd in survivors:
            os.close(fd)


def interrupted(signum, _frame):
    raise SystemExit(128 + signum)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--authorization", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    if output != OUTPUT or output.exists():
        raise RuntimeError("Only the fresh exact c6la pre-C6 Zj baseline output directory is permitted")
    authorization = json.loads(args.authorization.read_text())
    if authorization.get("go") is not True or authorization.get("scopes") != ["c6la"]:
        raise RuntimeError("A new explicit Main GO limited to c6la is required")
    if Path(authorization.get("binary", "")).resolve() != BINARY or authorization.get("sha256") != PINS[BINARY]:
        raise RuntimeError("GO does not identify the same qualified App binary")
    if authorization.get("actual_checkout_tree") != "1226b07c56bf010c8595c9309dcc175d4546850e":
        raise RuntimeError("GO does not identify the qualified assembled source")
    for path, expected in PINS.items():
        if digest(path) != expected:
            raise RuntimeError("Pinned input changed: " + str(path))
    if importlib.metadata.version("pyte") != "0.8.2" or importlib.metadata.version("wcwidth") != "0.9.2":
        raise RuntimeError("Recorded decoder environment changed")
    decoder_file = inspect.getsourcefile(pyte.Screen)
    if decoder_file is None:
        raise RuntimeError("Installed decoder source cannot be identified")
    decoder_source = Path(decoder_file)
    if digest(decoder_source) != "43bcd10d5555f6a8e53a1f9c0e557a47ec801b3914533d5b51af5828a5242ecb":
        raise RuntimeError("Installed decoder source changed")
    adapter_source = (HERE / "wide_overwrite.py").read_text()
    exact_adapter = PROOF.read_text().split("def wide(cell):", 1)[1].split("# Independent installed terminal semantics", 1)[0]
    if adapter_source.split("def wide(cell):", 1)[1] != exact_adapter:
        raise RuntimeError("Adapter differs from the exact executed offline proof")
    if not hasattr(os, "pidfd_open") or not hasattr(signal, "pidfd_send_signal"):
        raise RuntimeError("Linux pidfd cleanup APIs are required before starting the consumer")
    cleanup_path = HERE / "baseline-original400-cleanup.json"
    if cleanup_path.exists():
        raise RuntimeError("Cleanup receipt already exists; this bootstrap is single-use")
    receipt = {"output": str(output), "observations": [], "signals": [], "status": "STARTED", "adapter_sha256": digest(HERE / "wide_overwrite.py"), "bootstrap_sha256": digest(Path(__file__)), "original_harness_sha256": PINS[HARNESS], "proof_sha256": PINS[PROOF]}
    previous_screen = pyte.Screen
    previous_argv = sys.argv
    previous_handlers = {signum: signal.getsignal(signum) for signum in (signal.SIGTERM, signal.SIGHUP)}
    for signum in previous_handlers:
        signal.signal(signum, interrupted)
    try:
        pyte.Screen = WideOverwrite
        sys.argv = [str(HARNESS), "--authorization", str(args.authorization.resolve()), "--scope", "c6la", "--color-mode", "truecolor", "--output", str(output)]
        runpy.run_path(str(HARNESS), run_name="__main__")
    finally:
        pyte.Screen = previous_screen
        sys.argv = previous_argv
        try:
            cleanup_owned(output, receipt)
        except BaseException as error:
            receipt["status"] = "FAIL — cleanup exception"
            receipt["error"] = repr(error)
            raise
        finally:
            for signum, handler in previous_handlers.items():
                signal.signal(signum, handler)
            with cleanup_path.open("x") as stream:
                json.dump(receipt, stream, indent=2)
                stream.write("\n")


if __name__ == "__main__":
    main()
