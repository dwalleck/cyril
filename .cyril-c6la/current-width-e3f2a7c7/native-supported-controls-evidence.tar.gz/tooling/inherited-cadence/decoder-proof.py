import codecs,ctypes as C,hashlib,importlib.metadata as M,inspect,json,unicodedata
from pathlib import Path
import pyte
from pyte import modes as mo
from pyte.screens import wcwidth
R=Path('/tmp/cyril-perf-consumer-20261020/zj0m-current-width-truecolor-01')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(R/'terminal.ansi')=='97a84dcbfa81b96da9d431911fbbaa393885b91e714405bbd03ed87edb5ce80f'
assert sha(R/'session.cast')=='62837415cfd34ea5584921b503c4cdc95a4a9baf78b467b8f82455aff1ceb8e4'
assert sha(R/'harness-snapshot/smoke.py')=='c9ce883004155aef05e5a1dd68723be16e3507cc2873aff977e3cb554f34ec2a'
assert sha(inspect.getsourcefile(pyte.Screen))=='43bcd10d5555f6a8e53a1f9c0e557a47ec801b3914533d5b51af5828a5242ecb'
assert M.version('pyte')=='0.8.2' and M.version('wcwidth')=='0.9.2'
raw=(R/'terminal.ansi').read_bytes();cast=[json.loads(x) for x in (R/'session.cast').read_text().splitlines()]
assert ''.join(e[2] for e in cast[1:] if e[1]=='o').encode()==raw
print('PINS_OK',len(raw),'cast/raw exact byte identity; pyte0.8.2 wcwidth0.9.2; frozen harness/source SHA matched',flush=True)
print('SEMANTIC_SOURCE xtermjs/xterm.js commit9ba6c00a195c95fcf8292a2b9084d91450e5daae InputHandler.print left520-522 right641-643; not pyte upstream current display-only change',flush=True)
print('LIBVTERM',str(Path('/usr/lib/libvterm.so').resolve()),sha('/usr/lib/libvterm.so'),flush=True)
# Smallest API-preserving candidate: inherit Screen/Stream/control/resize/cells.
# Delegate every actual draw to installed pyte; repair only its touched glyph boundaries.
def wide(cell):return bool(cell.data) and wcwidth(cell.data[0])==2
class WideOverwrite(pyte.Screen):
    def draw(self,data):
        for ch in data:
            translated=ch.translate(self.g1_charset if self.charset else self.g0_charset)
            w=wcwidth(translated);old_x=self.cursor.x
            super().draw(ch)
            if w>0:
                start=old_x
                if old_x==self.columns:start=0 if mo.DECAWM in self.mode else old_x-w
                end=min(start+w,self.columns);line=self.buffer[self.cursor.y]
                if start>0 and wide(line[start-1]):line[start-1]=self.cursor.attrs._replace(data=' ')
                if end<self.columns and line[end].data=='' and not wide(line[end-1]):line[end]=self.cursor.attrs._replace(data=' ')
            elif w<0 or not unicodedata.combining(translated):return
# Independent installed terminal semantics, no process, parser or custom width oracle.
class Rect(C.Structure):_fields_=[('start_row',C.c_int),('end_row',C.c_int),('start_col',C.c_int),('end_col',C.c_int)]
class Pos(C.Structure):_fields_=[('row',C.c_int),('col',C.c_int)]
class Color(C.Union):_fields_=[('raw',C.c_ubyte*4)]
class Cell(C.Structure):_fields_=[('chars',C.c_uint32*6),('width',C.c_char),('attrs',C.c_uint),('fg',Color),('bg',Color)]
L=C.CDLL('/usr/lib/libvterm.so')
def api(n,a,r):f=getattr(L,n);f.argtypes=a;f.restype=r;return f
new=api('vterm_new',[C.c_int,C.c_int],C.c_void_p);free=api('vterm_free',[C.c_void_p],None)
utf8=api('vterm_set_utf8',[C.c_void_p,C.c_int],None);obtain=api('vterm_obtain_screen',[C.c_void_p],C.c_void_p)
alt=api('vterm_screen_enable_altscreen',[C.c_void_p,C.c_int],None);reset=api('vterm_screen_reset',[C.c_void_p,C.c_int],None)
size=api('vterm_set_size',[C.c_void_p,C.c_int,C.c_int],None);feed=api('vterm_input_write',[C.c_void_p,C.c_char_p,C.c_size_t],C.c_size_t)
getcell=api('vterm_screen_get_cell',[C.c_void_p,Pos,C.POINTER(Cell)],C.c_int)
gettext=api('vterm_screen_get_text',[C.c_void_p,C.c_void_p,C.c_size_t,Rect],C.c_size_t)
class VT:
    def __init__(self):
        self.v=new(48,160);assert self.v;utf8(self.v,1);self.s=obtain(self.v);alt(self.s,1);reset(self.s,1)
    def feed(self,b):assert feed(self.v,b,len(b))==len(b)
    def resize(self,c,r):size(self.v,r,c)
    def cell(self,r,c):
        z=Cell();assert getcell(self.s,Pos(r,c),C.byref(z));return {'chars':list(z.chars),'width':z.width[0],'attrs':z.attrs,'fg':list(z.fg.raw),'bg':list(z.bg.raw)}
    def blank(self,r,c):
        z=self.cell(r,c)
        if z['chars'][0] in (0,32):return True
        if z['chars'][0]!=0xffffffff or c==0:return False
        p=self.cell(r,c-1)
        return p['chars'][0] in (0,32) and p['width']==2
    def text(self,r,c=0,n=160):
        b=C.create_string_buffer(8192);k=gettext(self.s,b,len(b),Rect(r,r+1,c,c+n));return b.raw[:k].decode()
    def close(self):free(self.v)
def verdict(s):
    try:s.display;return 'OK'
    except IndexError:return 'IndexError'
def orphans(s):
    return sorted((x,y) for y,line in list(s.buffer.items()) for x,z in list(line.items()) if 0<=y<s.lines and 0<=x<s.columns and z.data=='' and (x==0 or not wide(line[x-1])))
def allcells(s):return [[s.buffer[y][x] for x in range(s.columns)] for y in range(s.lines)]
# Preserve ordinary CJK, combining, style/control, scrolling/autowrap, and resize behavior.
fixtures=[('ascii-style-controls','\x1b[31;44;1mASCII\x1b[0m\r\x1b[4C!\b?\nnext\tX'),('cjk-combining','界字 e\u0301\x1b[2;5H語\x1b[3;1H\x1b[32mkeep\x1b[0m'),('erase-whole-wide','界\x1b[1;1H\x1b[2X\x1b[2;1H語\x1b[2;1H\x1b[K'),('wrap-controls','\x1b[1;159Habcd\x1b[3;1H\x1b[?7lxyz\x1b[?7h'),('combining-after-wide','界\u0301x')]
for name,text in fixtures:
    a=pyte.Screen(160,48);b=WideOverwrite(160,48);pyte.Stream(a).feed(text);pyte.Stream(b).feed(text)
    assert allcells(a)==allcells(b) and a.cursor.x==b.cursor.x and a.cursor.y==b.cursor.y,(name,'changed inherited semantics')
    assert a.display==b.display
    print('UNCHANGED',name,flush=True)
a=pyte.Screen(160,48);b=WideOverwrite(160,48);sa=pyte.Stream(a);sb=pyte.Stream(b)
for c,r,text in [(160,48,'\x1b[20;5H界 e\u0301'),(100,32,'\x1b[10;5H語'),(160,48,'\x1b[40;1Htail')]:
    a.resize(lines=r,columns=c);b.resize(lines=r,columns=c);sa.feed(text);sb.feed(text)
    assert allcells(a)==allcells(b) and a.display==b.display
print('UNCHANGED resize160x48->100x32->160x48 all cells/styles',flush=True)
# Source-backed boundary tests; independent libvterm representations are observed, not mis-normalized.
for name,text,expected in [('lead-space','\x1b[38;1H⏳\x1b[38;1H ',[' ',' ']),('lead-A','\x1b[38;1H界\x1b[38;1HA',['A',' ']),('tail-B','\x1b[38;1H界\x1b[38;2HB',[' ','B']),('both-boundaries','\x1b[38;1H界界\x1b[38;2H語',[' ','語','',' '])]:
    a=pyte.Screen(160,48);b=WideOverwrite(160,48);pyte.Stream(a).feed(text);pyte.Stream(b).feed(text)
    assert verdict(b)=='OK' and not orphans(b)
    assert [b.buffer[37][x].data for x in range(len(expected))]==expected
    v=VT();v.feed(text.encode());obs=[v.cell(37,x) for x in range(len(expected))]
    print('BOUNDARY',name,'original=',verdict(a),'adapter=',[b.buffer[37][x].data for x in range(len(expected))],'libvterm=',obs,flush=True)
    if name=='lead-space':
        assert verdict(a)=='IndexError' and orphans(a)==[(1,37)]
        assert v.blank(37,0) and v.blank(37,1)
    v.close()
v=VT();v.feed('\x1b[38;1H⏳'.encode());assert not v.blank(37,0) and not v.blank(37,1);assert v.cell(37,0)['width']==2;v.close()
print('BLANK_PREDICATE rejects nonblank hourglass AND its continuation',flush=True)
# Replay frozen captured bytes with recorded resize events; no live process or checkpoint fabrication.
class Trace(pyte.Screen):
    def draw(self,data):
        for ch in data:
            x,y=self.cursor.x,self.cursor.y
            before=[self.buffer[y][i].data for i in range(max(0,x-1),min(x+3,self.columns))]
            super().draw(ch)
            for i in range(max(0,x-1),min(x+3,self.columns)):
                if self.buffer[y][i].data=='' and (i==0 or not wide(self.buffer[y][i-1])) and not hasattr(self,'first_bad'):
                    self.first_bad=(offset,event_index,(x,y),repr(ch),before,[self.buffer[y][j].data for j in range(max(0,x-1),min(x+3,self.columns))])
                    print('FIRST_ORPHAN raw_end_offset,cast_line,zero_based_cursor,ch,before,after',self.first_bad,flush=True)
                    print('RAW_CONTEXT',repr(raw[max(0,offset-100):offset+100]),flush=True)
a=pyte.Screen(160,48);b=WideOverwrite(160,48);t=Trace(160,48)
sa=pyte.Stream(a);sb=pyte.Stream(b);st=pyte.Stream(t);dec=codecs.getincrementaldecoder('utf-8')('replace');v=VT();offset=0
captures={e['ansi_end_offset']:e['name'] for e in map(json.loads,(R/'events.jsonl').read_text().splitlines()) if e['kind']=='capture'}
seen=set();resizes=[]
for event_index,event in enumerate(cast[1:],2):
    if event[1]=='r':
        c,r=map(int,event[2].split('x'));resizes.append((c,r))
        for s in (a,b,t):s.resize(lines=r,columns=c)
        v.resize(c,r)
    elif event[1]=='o':
        data=event[2].encode();sa.feed(event[2]);sb.feed(event[2]);v.feed(data)
        for byte in data:
            offset+=1;st.feed(dec.decode(bytes([byte])))
        if offset in captures:
            name=captures[offset];z=json.loads((R/(name+'.cells.json')).read_text())
            assert verdict(a)=='OK' and verdict(b)=='OK' and verdict(t)=='OK'
            assert b.columns==z['columns'] and b.lines==z['rows']
            for cell in z['cells']:
                x,y=cell['x'],cell['y'];expected={k:w for k,w in cell.items() if k not in ('x','y')}
                assert a.buffer[y][x]._asdict()==expected,(name,'original',x,y)
                assert b.buffer[y][x]._asdict()==expected,(name,'adapter',x,y)
                assert t.buffer[y][x]._asdict()==expected,(name,'bytewise',x,y)
            seen.add(name);print('CAPTURE_UNCHANGED cells+all_styles',name,offset,flush=True)
assert len(seen)==11 and offset==len(raw)
assert verdict(a)=='IndexError' and verdict(t)=='IndexError' and orphans(a)==orphans(t)==[(1,37)]
assert verdict(b)=='OK' and not orphans(b)
assert b.buffer[36][0].data=='⏳' and b.buffer[36][1].data==''
assert v.cell(36,0)['chars'][0]==ord('⏳') and v.cell(36,0)['width']==2
assert all(b.buffer[37][x].data==' ' and v.blank(37,x) for x in range(40))
assert 'WRITE_CHRONOLOGY_AFTER' in b.display[39] and 'WRITE_CHRONOLOGY_AFTER' in v.text(39)
for y in [36,37,39]:print('FINAL_ROW',y+1,'adapter=',repr(b.display[y]),'libvterm=',repr(v.text(y)),flush=True)
print('RESIZES',resizes,flush=True)
print('OFFLINE_GREEN exact captured bytes: original RED IndexError/orphan(1,37); adapter GREEN original display and cells API; eleven existing checkpoints data+styles unchanged; libvterm agrees visually blank row38 and marker row40. No z09/final/live13-checkpoint/consumer PASS claim.',flush=True)
v.close()
