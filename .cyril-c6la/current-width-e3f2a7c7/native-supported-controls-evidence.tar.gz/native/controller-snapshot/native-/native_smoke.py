#!/usr/bin/python3
"""Local C6 native adapter. No operation, including setup, is allowed without exact Main GO.
Reuses nativeq Ghostty export/input/PNG/grid/process ownership; never emulates a terminal.
A completed run is capture-complete, NOT accepted: every named PNG obligation needs review.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
FIXTURE = Path('/tmp/cyril-perf-consumer-20261021/c6la-input-cadence-prepare')
NATIVEQ = Path('/home/dwalleck/.claude/tmp/janet-followups/integration/tools/native-qualification')
BINARY = Path('/tmp/cyril-c6la-current-width-tested-20261021')
BINARY_SHA = '3efb0b67f240a55236d8fbabdaa45a0cbd8acfd2ad59f5071a7f936f81c1fd72'
SOURCE_SHA = 'e3f2a7c73e2de8dfb1895be825305a572dd203a94743633490f8de8f91165f94'
EXPECTED_OUTPUT = Path('/tmp/cyril-perf-consumer-20261021/c6la-native-supported-controls-01')
SOURCE_ROOT = Path('/home/dwalleck/repos/cyril-wt-perf-cyril-c6la')
SOURCE_MANIFEST = Path('/home/dwalleck/.claude/tmp/cyril-batch3-qualification-20261020-ipe924db/c6la-current-width-integration-attempt1/checked-post-initial-format.bounded-workspace-inputs.json')
SOURCE_MANIFEST_SHA = '19bbbc77ad4ddd548512d780dc6a662a3101f3096c49a57c5394bbed4f9b4098'
sys.dont_write_bytecode = True
sys.path.insert(0, str(NATIVEQ))
from nativeq import lease
from nativeq.evidence import EvidenceStore, sha256_file, write_new_json
from nativeq.ghostty import installed_ghostty
from nativeq.linux import GhosttySession, app_pids, ghostty_config
from nativeq.procs import descendants, identity
from native_fixture import chunk


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def pins(paths):
    return {str(path): sha256_file(path) for path in paths}

def verify_source():
    require(sha256_file(SOURCE_MANIFEST) == SOURCE_MANIFEST_SHA, 'Authoritative source manifest changed')
    rows = json.loads(SOURCE_MANIFEST.read_text())
    require(len(rows) == 505 and len({row['path'] for row in rows}) == 505, 'Expected 505 unique bounded inputs')
    for row in rows:
        path = SOURCE_ROOT / row['path']
        require(path.resolve().is_relative_to(SOURCE_ROOT), 'Source manifest path escapes qualified worktree')
        status = path.stat()
        require(status.st_size == row['bytes'] and bool(status.st_mode & 0o111) == row['executable']
                and sha256_file(path) == row['sha256'], 'Qualified source input changed: ' + row['path'])
    return {'checked_paths': 505, 'bytes_hash_executable_modes': 'MATCH', 'manifest_sha256': SOURCE_MANIFEST_SHA}



class CyrilSession(GhosttySession):
    """Only launch/lifecycle differ from nativeq; no .NET diagnostics or real HOME."""
    def __init__(self, out, mode, authorization):
        self.authorization = authorization
        self.mode = mode
        self.scratch = out / 'isolated'
        self.staged = self.scratch / 'cyril-tested'
        self.app_environment = {
            'PATH': str(self.scratch / 'bin'), 'SHELL': '/bin/bash',
            'HOME': str(self.scratch / 'home'), 'USERPROFILE': str(self.scratch / 'home'),
            **{'XDG_' + name.upper() + '_HOME': str(self.scratch / name)
               for name in ('config', 'data', 'cache', 'state')},
            'XDG_RUNTIME_DIR': str(self.scratch / 'runtime'),
            'TERM': 'xterm-256color', 'COLORTERM': 'truecolor',
            'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'CYRIL_PERF_SMOKE_ROOT': str(out),
        }
        argv = [str(self.staged), '--cwd', str(self.scratch / 'ws'), '--agent-engine', 'v2',
                '--prompt', 'owned display fixture', '--agent-command', '/usr/bin/python3', str(FIXTURE / 'owned_peer.py')]
        super().__init__(out, argv, app_match=str(self.staged), dotnet='/nonexistent-not-dotnet')
        self.evidence = EvidenceStore(out, run=out.name)
        self.result = {'status': 'FAILED', 'native_acceptance': 'PENDING independent PNG review',
                       'color_mode': mode, 'argv': argv, 'source_descriptor': SOURCE_SHA,
                       'binary_sha256': BINARY_SHA, 'authorization': authorization,
                       'app_environment': self.app_environment, 'native_50000_history': 'NOT CLAIMED',
                       'work_counters': 'Separate existing source-bound proof, not measured here',
                       'focus_back': 'Separate approved existing state/render proof; no entry control invented'}
        self.app_identity = None

    def app_command(self):
        return ['/usr/bin/env', '-i', *[k + '=' + v for k, v in self.app_environment.items()], *self.argv]

    def persist_owned(self):
        path = self.out / 'owned-processes.json'
        temporary = path.with_suffix('.tmp')
        temporary.write_text(json.dumps([item.to_json() for item in self.owned.owned], indent=2) + '\n')
        temporary.replace(path)

    def _spawn(self, argv, **kwargs):
        proc = super()._spawn(argv, **kwargs)
        self.persist_owned()
        return proc

    def adopt_tree(self):
        # Roots must still have their recorded identity before discovering descendants.
        for proc in self.popen:
            owned = next((item for item in self.owned.owned if item.pid == proc.pid), None)
            if owned is not None and self.owned.alive(owned):
                self.owned.adopt_descendants(proc.pid)
        self.persist_owned()

    def assert_app(self):
        if self.app_identity is not None:
            require(identity(self.app_pid) == self.app_identity, 'Owned App exited or identity changed')
        self.adopt_tree()

    def grid(self):
        self.assert_app()
        return super().grid()

    def start(self):
        lease.require('linux', 'Cyril on owned Ghostty/Xvfb :216')
        require(not Path('/tmp/.X11-unix/X216').exists() and not Path('/tmp/.X216-lock').exists(),
                'Display :216 is occupied; do not reclaim it')
        self.result['ghostty'] = installed_ghostty('/usr/bin/ghostty')
        for name in ('home', 'bin', 'config', 'data', 'cache', 'state', 'runtime', 'ws'):
            (self.scratch / name).mkdir(parents=True)
        (self.scratch / 'runtime').chmod(0o700)
        shutil.copyfile(BINARY, self.staged)
        self.staged.chmod(0o700)
        require(sha256_file(self.staged) == BINARY_SHA, 'Staged binary hash mismatch')
        config = self.scratch / 'home/.config/cyril/config.toml'
        config.parent.mkdir(parents=True)
        config.write_text('[ui]\nmax_messages = 1000\nmouse_capture = true\ntheme = "cyril-dark"\ncolor_mode = "' + self.mode + '"\n\n[agent]\nengine = "v2"\nkas_hooks = "off"\n\n[memory]\nenabled = false\n')
        for name in ('exports', '.private'):
            (self.out / name).mkdir()
        (self.out / '.private').chmod(0o700)
        auth = self.out / '.private/xauth'
        host_env = {
            'PATH': '/usr/bin:/bin', 'HOME': str(self.scratch / 'home'),
            **{'XDG_' + name.upper() + '_HOME': str(self.scratch / name)
               for name in ('config', 'data', 'cache', 'state')},
            'XDG_RUNTIME_DIR': str(self.scratch / 'runtime'), 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
            'DISPLAY': self.display, 'XAUTHORITY': str(auth), 'GDK_BACKEND': 'x11',
            'TMPDIR': str(self.out / 'exports'),
        }
        self.env = host_env
        cookie = subprocess.check_output(['/usr/bin/mcookie'], env=host_env, text=True, timeout=15).strip()
        subprocess.run(['/usr/bin/xauth', '-q', '-f', str(auth), 'add', self.display, '.', cookie],
                       env=host_env, check=True, timeout=15)
        ghost_config = self.out / 'ghostty.conf'
        ghost_config.write_text(ghostty_config(self.font_size))
        self._spawn(['/usr/bin/Xvfb', self.display, '-screen', '0', '2560x1600x24',
                     '-nolisten', 'tcp', '-noreset', '-auth', str(auth)], env=host_env,
                    stdout=subprocess.DEVNULL, stderr=(self.out / 'xvfb.log').open('x'))
        time.sleep(.7)
        command = ['/usr/bin/dbus-run-session', '--', '/usr/bin/ghostty', '--config-default-files=false',
                   '--config-file=' + str(ghost_config), '-e', *self.app_command()]
        self.result['host_environment'] = host_env
        self.result['host_command'] = command
        self.launcher = self._spawn(command, env=host_env, cwd=self.scratch / 'ws',
                                    stdout=(self.out / 'ghostty.log').open('x'), stderr=subprocess.STDOUT,
                                    start_new_session=True)
        end = time.monotonic() + 20
        while time.monotonic() < end:
            self.adopt_tree()
            try:
                windows = self.x('/usr/bin/xdotool', 'search', '--onlyvisible', '--class', '[Gg]hostty').splitlines()
            except subprocess.CalledProcessError:
                windows = []
            candidates = {pid: ident.argv for pid in descendants(self.launcher.pid) if (ident := identity(pid))}
            found = app_pids(candidates, self.argv, str(self.staged))
            if len(windows) == 1 and len(found) == 1:
                self.window, self.app_pid = windows[0], found[0]
                break
            time.sleep(.1)
        require(self.window is not None and self.app_pid is not None, 'One owned Ghostty window/App not found')
        window_pid = int(self.x('/usr/bin/xdotool', 'getwindowpid', self.window))
        self.ghostty_pids = [pid for pid in descendants(self.launcher.pid)
                             if (ident := identity(pid)) and ident.argv and Path(ident.argv[0]).name == 'ghostty']
        require(window_pid in self.ghostty_pids, 'Window is not in owned Ghostty descendant tree')
        self.app_identity = self.owned.adopt(self.app_pid)
        self.result['app'] = self.app_identity.to_json()
        self.x('/usr/bin/xdotool', 'windowfocus', '--sync', self.window)
        self.resize(160, 48)

    def natural_exit(self):
        self.assert_app()
        self.key('ctrl+q')
        deadline = time.monotonic() + 5
        while identity(self.app_pid) == self.app_identity and time.monotonic() < deadline:
            self.adopt_tree()
            time.sleep(.05)
        self.result['natural_exit'] = identity(self.app_pid) is None
        require(self.result['natural_exit'], 'App did not exit naturally after Ctrl+Q')

    def close(self):
        self.adopt_tree()
        self.result['owned_processes'] = [item.to_json() for item in self.owned.owned]
        self.result['cleanup'] = self.owned.cleanup(grace=2)
        for proc in self.popen:
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                pass
        # Retain failed evidence too; only remove this run's private Xauthority cookie.
        auth = self.out / '.private/xauth'
        if auth.exists():
            auth.unlink()
        self.result['cleanup_complete'] = all(row['gone'] for row in self.result['cleanup'])
        if not self.result['cleanup_complete']:
            self.result['status'] = 'FAILED'
        write_new_json(self.out / 'result.json', self.result)


class NativeFixture:
    """Small existing-scenario input/observation adapter. PNGs own all glyph/style claims."""
    def __init__(self, session):
        self.session = session
        self.root = session.out
        self.color_mode = session.mode
        self.control_sequence = 0
        self.started = time.monotonic()
        self.checks = []
        self.visual = []
        self.latest = ''

    def event(self, kind, **fields):
        self.session.assert_app()
        self.session.evidence.put_json(kind, {'seconds': time.monotonic() - self.started,
                                           'kind': kind, 'app': self.session.app_identity.to_json(), **fields}, kind='event')

    def drain(self, seconds=.2):
        time.sleep(seconds)
        self.session.assert_app()

    def text(self):
        self.session.assert_app()
        # Cyril owns the alternate screen; require no host scrollback. Do not infer
        # physical rows, colors, or glyph widths from these unwrapped native strings.
        capture = self.session.capture_split('observation')
        require(not capture['history'].strip(), 'Unexpected host history makes active-area oracle ambiguous')
        self.latest = capture['active']
        return self.latest

    def wait(self, description, predicate, seconds=20):
        deadline = time.monotonic() + seconds
        while True:
            self.session.assert_app()
            if predicate():
                self.drain(.15)
                return
            if time.monotonic() >= deadline:
                self.capture('failure')
                raise AssertionError(description)
            self.drain(.1)

    def visible(self, *needles):
        self.wait('Missing native active-area controls ' + repr(needles),
                  lambda: all(needle in self.text() for needle in needles))

    def peer_state(self):
        path = self.root / 'peer-state.json'
        return json.loads(path.read_text()) if path.exists() else {}

    def control(self, **request):
        self.control_sequence += 1
        number = self.control_sequence
        self.event('peer-control', sequence=number, request=request)
        # Atomic publication prevents the reused peer from reading a partial JSON file.
        temporary = self.root / f'control-{number:04d}.tmp'
        write_new_json(temporary, request)
        temporary.rename(self.root / f'control-{number:04d}.json')
        ack = self.root / f'ack-{number:04d}.json'
        self.wait('Peer control acknowledgement', ack.exists)
        result = json.loads(ack.read_text())
        require(result.get('ok') is True and result.get('sequence') == number, 'Peer acknowledgement failed')
        self.drain(.3)

    def send(self, value):
        self.event('terminal-input', value=value)
        sequences = {'\x1b[5~': 'Prior', '\x1b[6~': 'Next', '\r': 'Return', '\x1b': 'Escape'}
        for sequence, key in sequences.items():
            if value and value == sequence * (len(value) // len(sequence)):
                count = len(value) // len(sequence)
                self.session.key(*([key] * count))
                self.event('native-key-delivery', key=key, count=count,
                           cadence='one existing ordinary send, no burst merge')
                self.drain(.25)
                return
        require('\x1b' not in value and '\r' not in value and '\n' not in value,
                'Unsupported terminal control; do not invent an App input')
        self.session.text(value)
        self.drain(.25)

    def command_input(self, command):
        # Existing command text and Enter, using private-display native key input.
        self.session.text(command)
        self.session.key('Return')
        self.drain(.25)

    def start_prompt(self, text):
        before = self.peer_state().get('prompts', 0)
        self.command_input(text)
        self.wait('New owned prompt', lambda: self.peer_state().get('prompts', 0) == before + 1)

    def resize(self, columns, rows):
        pending = self.peer_state().get('pending_prompt') is True
        before = list(self.session.grid())
        self.session.resize(columns, rows)
        after = list(self.session.grid())
        self.event('native-grid-resize', before=before, after=after, pending_prompt=pending)
        self.drain(.5)

    def capture(self, name):
        self.drain()
        exported = self.session.capture_split(name)
        require(not exported['history'].strip(), 'Cyril unexpectedly acquired host scrollback')
        png = self.session.screenshot(name)
        record = {'name': name, 'png': png['id'], 'grid': list(self.session.grid()),
                  'app': self.session.app_identity.to_json(), 'export_semantics': 'native history+active, unwrapped'}
        self.session.evidence.put_json(name + '-scene', record, kind='native-scene')
        return record

    def style(self, marker):
        self.visible(marker)
        return {'marker': marker, 'native_scene': self.capture('style-' + marker),
                'oracle': 'PNG visual inspection required; native exports contain no style cells'}

    def require_visual(self, label, **details):
        obligation = {'claim': label, 'status': 'PENDING independent PNG review', **details}
        self.visual.append(obligation)
        self.session.evidence.put_json('visual-obligation', obligation, kind='visual-obligation')

    def check(self, label, condition, **details):
        row = {'check': label, 'pass': bool(condition), **details}
        self.checks.append(row)
        self.session.evidence.put_json('assertion', row, kind='assertion')
        if not condition:
            self.capture('failure')
            raise AssertionError(label)


def streaming_resize_scenes(fixture):
    """Separate epoch: never append native diagnostic text to inherited fixtures."""
    fixture.command_input('/clear')
    fixture.start_prompt('owned dedicated native streaming resize fixture')
    for index, (columns, rows) in enumerate(((160, 48), (80, 24), (160, 48), (160, 12), (160, 48))):
        before = f'C6N{index:02d}_BEFORE'
        after = f'C6N{index:02d}_AFTER'
        fixture.control(updates=[chunk(before + '\n')])
        fixture.visible(before)
        fixture.resize(columns, rows)
        fixture.control(updates=[chunk(after + '\n')])
        fixture.visible(before, after)
        scene = fixture.capture(f'dedicated-stream-resize-{index:02d}')
        fixture.require_visual('Same App continues streamed source across actual host geometry transition',
                               scene=scene, before=before, after=after,
                               geometry=[columns, rows], pending_prompt=True)
    fixture.control(complete=True)


def edge_scenes(fixture):
    """Separate display-only epochs, using existing user/system input routes."""
    edge = json.loads((HERE / 'edge-fixtures.json').read_text())
    fixture.command_input('/clear')
    before = fixture.peer_state().get('prompts', 0)
    # A private-display clipboard owner supplies one actual multiline UserText prompt.
    # No controller/emulator inserts a synthetic history message.
    fixture.session.paste(edge['user_width']['text'], following=('Return',))
    fixture.wait('Exact multiline user prompt', lambda: fixture.peer_state().get('prompts', 0) == before + 1)
    fixture.control(complete=True)
    for width in (160, 80, 160):
        fixture.resize(width, 48)
        fixture.visible(*edge['user_width']['positive_markers'])
        scene = fixture.capture('user-width-' + str(width))
        fixture.require_visual('Original halfwidth/combining clusters own their physical following-Z columns',
                               scene=scene, normative=edge['user_width'])

    for case in edge['wide_edges']:
        fixture.command_input('/clear')
        fixture.resize(case['columns'], 48)
        fixture.start_prompt('owned native wide right-edge fixture')
        fixture.control(frames=[{'method': '_kiro/system/notify',
                                 'params': {'level': 'info', 'message': '\n' + case['text']}}], complete=True)
        fixture.visible('WIDE_NATIVE_EDGE_END')
        scene = fixture.capture(case['id'])
        fixture.require_visual('Full-frame wide/combining safe starts, conservation and reserved right edge',
                               scene=scene, normative=case)

    for case in edge['opaque_urls']:
        fixture.command_input('/clear')
        fixture.resize(140, 40)
        fixture.start_prompt('owned native opaque URL fixture')
        fixture.control(updates=[chunk(f"**GUTTER_HISTORY_HEAD_{case['length']}**")])
        fixture.control(frames=[{'method': '_kiro/system/notify',
                                 'params': {'level': 'info', 'message': '\n' + case['text']}}], complete=True)

        def capture_url(label):
            text = fixture.text()
            # ASCII conservation only, not physical-cell/row/style proof. The PNG
            # obligation below checks actual 139-column chunks and the gutter.
            flattened = ''.join(line.rstrip(' ▲▼║█') for line in text.splitlines())
            fixture.check('Complete native-export opaque URL including tail ' + label,
                          case['url'] in flattened, length=case['length'], expected=case['url'])
            scene = fixture.capture('url-' + str(case['length']) + '-' + label)
            fixture.require_visual('Every opaque URL byte and final Z, blank tail, system styling and separate gutter',
                                   scene=scene, source=case, content_columns=fixture.session.grid()[0] - 1,
                                   expected_gutter='▲ top, ▼ bottom, ║/█ between; no indicator in content')

        fixture.visible('gutter_tail_019')
        capture_url('follow')
        fixture.send('\x1b[5~')
        capture_url('page-up-20')
        fixture.send('\x1b[6~')
        capture_url('return-follow')
        fixture.resize(160, 48)
        capture_url('resize-wide')
        fixture.resize(140, 40)
        capture_url('resize-restored')
        for palette in ('gruvbox-dark', 'cyril-dark'):
            fixture.command_input('/theme')
            fixture.send(palette)
            fixture.send('\r')
            fixture.visible('gutter_tail_019')
            capture_url('palette-' + palette)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--authorization', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    auth = json.loads(Path(args.authorization).read_text())
    require(auth.get('go') is True and auth.get('scope') == 'c6la-native-supported-controls',
            'Fresh native Main GO required; PTY receipts are not authorization')
    require(auth.get('binary') == str(BINARY) and auth.get('sha256') == BINARY_SHA
            and auth.get('checked_source_descriptor') == SOURCE_SHA and auth.get('bounded_inputs') == 505,
            'Qualified binary/source identity differs')
    require(auth.get('color_modes') == ['truecolor', 'none'], 'Both separate startup modes required')
    require(Path(args.output).resolve() == EXPECTED_OUTPUT and auth.get('output') == str(EXPECTED_OUTPUT),
            'Output is not the explicitly owned authorized root')
    preparation = json.loads((HERE / 'preparation.json').read_text())
    require(auth.get('preparation_sha256') == sha256_file(HERE / 'preparation.json'), 'Preparation pin differs')
    require(auth.get('review_status') == 'PASS', 'Independent controller review required before execution')
    require(sha256_file(BINARY) == BINARY_SHA, 'Qualified original binary hash changed')
    expected_pins = preparation['file_sha256']
    require(pins(map(Path, expected_pins)) == expected_pins, 'Controller/fixture/nativeq/runtime pins changed')
    source_before = verify_source()
    lease.require('linux', 'the entire Cyril native two-mode session')
    signal.signal(signal.SIGALRM, lambda signum, frame: (_ for _ in ()).throw(TimeoutError('2400-second native bound')))
    signal.alarm(2400)
    # No writes, process calls, setup, or desktop operations occur above this line.
    EXPECTED_OUTPUT.mkdir(exist_ok=False)
    write_new_json(EXPECTED_OUTPUT / 'source-before.json', source_before)
    snapshot = EXPECTED_OUTPUT / 'controller-snapshot'
    snapshot.mkdir()
    for path in [HERE / 'preparation.json', *map(Path, expected_pins)]:
        if path.parent in (HERE, FIXTURE):
            destination = snapshot / ('original-' if path.parent == FIXTURE else 'native-') / path.name
            destination.parent.mkdir(exist_ok=True)
            shutil.copyfile(path, destination)
    failures = []
    sessions = []
    for mode in ('truecolor', 'none'):
        session = CyrilSession(EXPECTED_OUTPUT / mode, mode, auth)
        fixture = NativeFixture(session)
        sessions.append(session)
        try:
            session.start()
            from native_scenario import run
            run(fixture)
            streaming_resize_scenes(fixture)
            edge_scenes(fixture)
            fixture.capture('final')
            session.natural_exit()
            session.result['status'] = 'CAPTURE_COMPLETE_PENDING_VISUAL_REVIEW'
        except BaseException as error:
            session.result['error'] = repr(error)
            failures.append(mode)
        finally:
            session.result['content_checks'] = fixture.checks
            session.result['visual_obligations'] = fixture.visual
            session.close()
        if failures or not session.result['cleanup_complete']:
            break  # First unexpected STOP: no retry, edit, second-mode continuation, or setup repair.
    unchanged = pins(map(Path, expected_pins)) == expected_pins and sha256_file(BINARY) == BINARY_SHA
    source_after = verify_source()
    write_new_json(EXPECTED_OUTPUT / 'source-after.json', source_after)
    cleaned = all(session.result['cleanup_complete'] for session in sessions)
    receipt = {'status': 'FAILED' if failures or not unchanged or not cleaned or len(sessions) != 2 else 'CAPTURE_COMPLETE_PENDING_VISUAL_REVIEW',
               'failures': failures, 'pins_unchanged': unchanged,
               'native_acceptance': 'NOT PASS until independent PNG obligations are discharged',
               'modes': [{'mode': s.mode, 'status': s.result['status'], 'cleanup_complete': s.result['cleanup_complete']}
                         for s in sessions]}
    write_new_json(EXPECTED_OUTPUT / 'result.json', receipt)
    print(json.dumps(receipt, indent=2))
    return 1 if receipt['status'] == 'FAILED' else 0


if __name__ == '__main__':
    def interrupted(signum, frame):
        raise KeyboardInterrupt(f'interrupted by signal {signum}')
    for sig in (signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, interrupted)
    raise SystemExit(main())
