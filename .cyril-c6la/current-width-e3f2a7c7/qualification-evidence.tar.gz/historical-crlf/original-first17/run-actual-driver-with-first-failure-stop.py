"""Execute the unchanged approved driver; stop before its next Cargo call on an unexpected named one-test result."""
import argparse
import hashlib
import json
import re
import runpy
import subprocess
import sys
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument('--driver', type=Path, required=True)
parser.add_argument('--driver-sha256', required=True)
parser.add_argument('--source-root', type=Path, required=True)
parser.add_argument('--target-dir', type=Path, required=True)
parser.add_argument('--evidence-dir', type=Path, required=True)
parser.add_argument('--guard-receipts', type=Path, required=True)
args = parser.parse_args()
if hashlib.sha256(args.driver.read_bytes()).hexdigest() != args.driver_sha256:
    raise SystemExit('Actual driver drifted before execution')
expected = {
    'clean-lf': ('PASS', 'PASS'),
    'clean-crlf': ('FAIL', 'PASS'),
    'clean-mixed-lf-crlf': ('FAIL', 'PASS'),
    'clean-mixed-crlf-lf': ('PASS', 'PASS'),
    'crlf-production-violation': ('FAIL', 'FAIL'),
    'mixed-production-violation': ('FAIL', 'FAIL'),
}
gates = {
    'theme::tests::widgets_only_use_the_explicit_theme',
    'widgets::markdown::tests::production_exposes_only_the_explicit_theme_entry_point',
}
real_run = subprocess.run
observed = []

def guarded_run(command, *positional, **kwargs):
    # This driver has precisely one subprocess.run site: its named Cargo fence.
    fixture = Path(kwargs['cwd']).resolve()
    relative = fixture.relative_to(args.evidence_dir.resolve())
    if len(relative.parts) != 2:
        raise RuntimeError(f'Unexpected case path {relative}')
    case, side = relative.parts
    gate = command[command.index('--lib') + 1]
    if case not in expected or side not in ('before', 'after') or gate not in gates:
        raise RuntimeError(f'Unexpected named driver command: {command!r}')
    if Path(command[command.index('--target-dir') + 1]).resolve() != args.target_dir.resolve():
        raise RuntimeError('Driver escaped the exclusive shared target')
    result = real_run(command, *positional, **kwargs)
    text = result.stdout
    want = expected[case][0 if side == 'before' else 1]
    named_one = '\nrunning 1 test\n' in text and f'test {gate} ... ' in text
    compiler_error = 'could not compile' in text or re.search(r'error\[E\d+\]', text) is not None
    if want == 'PASS':
        matches = result.returncode == 0 and named_one and 'test result: ok. 1 passed; 0 failed' in text
    else:
        matches = (result.returncode == 101 and named_one and 'panicked at ' in text
                   and 'test result: FAILED. 0 passed; 1 failed' in text)
        if case.endswith('production-violation'):
            matches = matches and 'crate::theme::resolve' in text
    matches = bool(matches and not compiler_error)
    row = {
        'ordinal': len(observed) + 1, 'case': case, 'side': side,
        'gate': gate, 'expected': want, 'exit_code': result.returncode,
        'named_one_test_executed': named_one, 'compiler_error': compiler_error,
        'matches_expectation': matches, 'command': command, 'cwd': str(fixture),
        'driver_environment_CARGO_TARGET_DIR': kwargs.get('env', {}).get('CARGO_TARGET_DIR'),
        'explicit_target_dir': str(args.target_dir.resolve()),
        'stdout_sha256': hashlib.sha256(text.encode()).hexdigest(),
    }
    observed.append(row)
    with args.guard_receipts.open('a') as stream:
        stream.write(json.dumps(row) + '\n')
    if not matches:
        unexpected = args.guard_receipts.with_name(f'unexpected-named-receipt-{row["ordinal"]}.log')
        unexpected.write_text(text)
        print(text, flush=True)
        raise RuntimeError(f'STOP first unexpected named receipt: {row}; full log={unexpected}')
    return result

original_argv = sys.argv
try:
    subprocess.run = guarded_run
    sys.argv = [str(args.driver), '--source-root', str(args.source_root),
                '--target-dir', str(args.target_dir), '--evidence-dir', str(args.evidence_dir)]
    runpy.run_path(str(args.driver), run_name='__main__')
finally:
    subprocess.run = real_run
    sys.argv = original_argv
# The unchanged driver prints its raw24 receipts. This line records execution
# count only; interpretation remains separately retained per named receipt.
print(json.dumps({'guard_observed_named_commands': len(observed),
                  'guard_receipts': str(args.guard_receipts)}), flush=True)
