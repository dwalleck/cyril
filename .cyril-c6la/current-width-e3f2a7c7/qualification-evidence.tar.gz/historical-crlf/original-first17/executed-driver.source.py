"""Run both actual source fences BEFORE/AFTER over fresh identical case trees.

Main-owned execution only. Implementation workers do not run this harness.
BEFORE is the frozen reviewed checker source; AFTER is frozen from --source-root
when the harness starts, so a later parent formatter cannot silently stale it.
Each side differs only in its two checker source files. All runtime widget input,
line-ending transformation and the production-violation marker are identical.

Expected pairs, for EACH named actual fence:
  clean-lf                  BEFORE PASS / AFTER PASS
  clean-crlf                BEFORE FAIL / AFTER PASS
  clean-mixed-lf-crlf        BEFORE FAIL / AFTER PASS
  clean-mixed-crlf-lf        BEFORE PASS / AFTER PASS
  crlf-production-violation  BEFORE FAIL / AFTER FAIL
  mixed-production-violation BEFORE FAIL / AFTER FAIL

This harness prints complete commands, source identities and transcripts. It does
not assert an aggregate verdict. A compiler failure or zero executed tests is NOT
an intended checker RED. Main must inspect each named one-test receipt.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess


CHECKERS = (
    "crates/cyril-ui/src/theme.rs",
    "crates/cyril-ui/src/widgets/markdown.rs",
)
GATES = (
    "theme::tests::widgets_only_use_the_explicit_theme",
    "widgets::markdown::tests::production_exposes_only_the_explicit_theme_entry_point",
)
BEFORE_SHA256 = {
    CHECKERS[0]: "7e5e4bc045037149aa2c1e86ef3f83c58043c753b3966a47da7cba73a4d9c248",
    CHECKERS[1]: "5cb487e6f4e35c1392fc372410319f0f6e7eaaedef9d27e6fa6f56983f9f8742",
}
ANCHOR = b"    let mut hasher = DefaultHasher::new();"
VIOLATION = b"    // CRLF production violation after instrumentation: crate::theme::resolve"
CASES = (
    ("clean-lf", b"\n", b"\n", False),
    ("clean-crlf", b"\r\n", b"\r\n", False),
    ("clean-mixed-lf-crlf", b"\n", b"\r\n", False),
    ("clean-mixed-crlf-lf", b"\r\n", b"\n", False),
    ("crlf-production-violation", b"\r\n", b"\r\n", True),
    ("mixed-production-violation", b"\n", b"\r\n", True),
)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument("--target-dir", type=Path, required=True)
    parser.add_argument("--evidence-dir", type=Path, required=True)
    args = parser.parse_args()
    root = args.source_root.resolve()
    target = args.target_dir.resolve()
    evidence = args.evidence_dir.resolve()
    if evidence.exists():
        raise SystemExit("Use a new --evidence-dir; never reuse a prior case tree")
    if evidence.is_relative_to(root) or target == root:
        raise SystemExit("Evidence must be outside source; target must not be the source root")
    evidence.mkdir(parents=True)
    inputs = Path(__file__).resolve().parent / "crlf-repair" / "inputs"
    before = {}
    after = {}
    for relative in CHECKERS:
        data = (inputs / "before" / (relative + ".source")).read_bytes()
        if digest(data) != BEFORE_SHA256[relative]:
            raise SystemExit(f"Frozen BEFORE source changed: {relative} {digest(data)}")
        before[relative] = data
        after[relative] = (root / relative).read_bytes()
    frozen = {"BEFORE": before, "AFTER": after}
    source_record = {
        "source_root": str(root),
        "target_dir": str(target),
        "checker_inputs": {
            side: {relative: {"bytes": len(data), "sha256": digest(data)} for relative, data in sources.items()}
            for side, sources in frozen.items()
        },
        "expected_pairs": {
            "clean-lf": ["PASS", "PASS"],
            "clean-crlf": ["FAIL", "PASS"],
            "clean-mixed-lf-crlf": ["FAIL", "PASS"],
            "clean-mixed-crlf-lf": ["PASS", "PASS"],
            "crlf-production-violation": ["FAIL", "FAIL"],
            "mixed-production-violation": ["FAIL", "FAIL"],
        },
        "gate_names": GATES,
    }
    (evidence / "source.json").write_text(json.dumps(source_record, indent=2) + "\n")
    print(json.dumps(source_record, indent=2), flush=True)
    for side, sources in frozen.items():
        for relative, data in sources.items():
            path = evidence / "frozen" / side.lower() / (relative + ".source")
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)

    def ignore(directory, names):
        return [
            name for name in names
            if name in {".git", "target", "node_modules"}
            or (Path(directory) / name).resolve() in {target, evidence}
        ]

    pristine = evidence / "pristine"
    shutil.copytree(root, pristine, symlinks=True, ignore=ignore)
    environment = os.environ.copy()
    environment.pop("CARGO_TARGET_DIR", None)
    for case, newline, module_newline, inject in CASES:
        for side, sources in frozen.items():
            fixture = evidence / case / side.lower()
            shutil.copytree(pristine, fixture, symlinks=True)
            for relative, data in sources.items():
                (fixture / relative).write_bytes(data)
            widget_paths = sorted((fixture / "crates/cyril-ui/src/widgets").rglob("*.rs"))
            newline_paths = [fixture / CHECKERS[0], *widget_paths]
            for path in newline_paths:
                data = path.read_bytes().replace(b"\r\n", b"\n").replace(b"\n", newline)
                # Independently vary the first ordinary-module boundary's second line ending.
                # Runtime instrumentation and all production bytes keep the case's base ending.
                boundary = newline + b"#[cfg(test)]" + newline + b"mod tests {"
                mixed_boundary = newline + b"#[cfg(test)]" + module_newline + b"mod tests {"
                path.write_bytes(data.replace(boundary, mixed_boundary, 1))
            markdown = fixture / CHECKERS[1]
            if inject:
                data = markdown.read_bytes()
                if data.count(ANCHOR) != 1:
                    raise SystemExit(f"Production mutation anchor changed: {markdown}")
                data = data.replace(ANCHOR, VIOLATION + newline + ANCHOR, 1)
                markdown.write_bytes(data)
            print(
                f"CASE {case} SIDE {side} widgets={len(widget_paths)} "
                f"markdown_sha256={digest(markdown.read_bytes())} "
                f"injected={VIOLATION.decode() if inject else 'none'}",
                flush=True,
            )
            # Rebuild package entrypoints when switching a shared Cargo target.
            for relative in (
                "crates/cyril-core/src/lib.rs",
                "crates/cyril-ui/src/lib.rs",
                "crates/cyril/src/main.rs",
                "crates/cyril-workbench/src/lib.rs",
            ):
                (fixture / relative).touch()
            for gate in GATES:
                command = [
                    "cargo", "test", "--manifest-path", str(fixture / "Cargo.toml"),
                    "--target-dir", str(target), "-p", "cyril-ui", "--lib", gate,
                    "--", "--exact", "--nocapture", "--test-threads=1",
                ]
                print(f"RUN {case} {side} {gate}: {json.dumps(command)}", flush=True)
                result = subprocess.run(command, cwd=fixture, env=environment,
                                        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                log = fixture / (gate.replace("::", "-") + ".log")
                log.write_text(result.stdout)
                print(f"EXIT {result.returncode} LOG {log}", flush=True)
                print(result.stdout, end="" if result.stdout.endswith("\n") else "\n", flush=True)
    print("Inspect all24 named one-test receipts; compiler/zero-test failures are not checker RED.", flush=True)


if __name__ == "__main__":
    main()
