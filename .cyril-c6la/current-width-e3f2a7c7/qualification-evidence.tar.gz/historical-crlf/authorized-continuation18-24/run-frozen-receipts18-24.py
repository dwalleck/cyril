"""External continuation only: preserve original driver bytes and receipts1-17; run7 unrun commands with its exact fixture/command semantics."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import shutil
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--prior', type=Path, required=True)
parser.add_argument('--evidence', type=Path, required=True)
parser.add_argument('--target-dir', type=Path, required=True)
args = parser.parse_args()
prior = args.prior.resolve()
evidence = args.evidence.resolve()
target = args.target_dir.resolve()
evidence.mkdir(exist_ok=False)
driver = prior / 'executed-driver.source.py'
digest = lambda data: hashlib.sha256(data).hexdigest()
if digest(driver.read_bytes()) != '989608c6da3481c2415464043febff3829ee4a111b6e14ddec8728ed2ce578a4':
    raise SystemExit('Frozen original driver changed')
d = runpy.run_path(str(driver), run_name='frozen_approved_driver_import_only')
original = prior / 'actual-driver-24-case-evidence'
record = json.loads((original / 'source.json').read_text())
pristine = original / 'pristine'
frozen = {}
for side in ('BEFORE', 'AFTER'):
    frozen[side] = {}
    for relative in d['CHECKERS']:
        data = (original / 'frozen' / side.lower() / (relative + '.source')).read_bytes()
        if digest(data) != record['checker_inputs'][side][relative]['sha256']:
            raise SystemExit(f'Frozen checker drift: {side} {relative}')
        frozen[side][relative] = data
metadata = {'prior_source_record': str(original / 'source.json'),
            'prior_handoff': str(prior / 'canonical-handoff.json'),
            'prior_handoff_sha256': digest((prior / 'canonical-handoff.json').read_bytes()),
            'frozen_pristine': str(pristine), 'frozen_driver': str(driver),
            'driver_sha256': digest(driver.read_bytes()),
            'source_record': record, 'executed_ordinals': [],
            'guard_change': 'Injection diagnostic required only for AFTER negatives. BEFORE remains exactly1 named checker assertion failure; old CRLF raw-byte cap can mask seam diagnostics.',
            'first17_reexecuted': False,
            'fixture_semantics': 'Same pristine copy, frozen2 checker override, widget/theme line-ending and first module-boundary transform, identical single production marker, same gate commands. Boundary touches include app.rs in addition to approved4 roots.'}
(evidence / 'continuation-source.json').write_text(json.dumps(metadata, indent=2) + '\n')
environment = os.environ.copy()
environment.pop('CARGO_TARGET_DIR', None)
rows = []
ordinal = 0
for case, newline, module_newline, inject in d['CASES']:
    for side, sources in frozen.items():
        first_ordinal = ordinal + 1
        ordinal += len(d['GATES'])
        if ordinal <= 17:
            continue
        fixture = evidence / case / side.lower()
        shutil.copytree(pristine, fixture, symlinks=True)
        for relative, data in sources.items():
            (fixture / relative).write_bytes(data)
        widget_paths = sorted((fixture / 'crates/cyril-ui/src/widgets').rglob('*.rs'))
        newline_paths = [fixture / d['CHECKERS'][0], *widget_paths]
        for path in newline_paths:
            data = path.read_bytes().replace(b'\r\n', b'\n').replace(b'\n', newline)
            boundary = newline + b'#[cfg(test)]' + newline + b'mod tests {'
            mixed_boundary = newline + b'#[cfg(test)]' + module_newline + b'mod tests {'
            path.write_bytes(data.replace(boundary, mixed_boundary, 1))
        markdown = fixture / d['CHECKERS'][1]
        if inject:
            data = markdown.read_bytes()
            if data.count(d['ANCHOR']) != 1:
                raise SystemExit(f'Production mutation anchor changed: {markdown}')
            data = data.replace(d['ANCHOR'], d['VIOLATION'] + newline + d['ANCHOR'], 1)
            markdown.write_bytes(data)
        # For continuation receipt18, require exact source equivalence to the
        # already-frozen receipt17 fixture, without executing receipt17 again.
        same_as_prior17 = None
        if first_ordinal == 17:
            old = original / case / side.lower()
            same_as_prior17 = all((old / p.relative_to(fixture)).read_bytes() == p.read_bytes()
                                 for p in (fixture / 'crates/cyril-ui/src').rglob('*.rs'))
            if not same_as_prior17:
                raise SystemExit('Receipt18 fixture differs from frozen receipt17 UI source')
        touches = []
        for relative in ('crates/cyril-core/src/lib.rs', 'crates/cyril-ui/src/lib.rs',
                         'crates/cyril/src/main.rs', 'crates/cyril/src/app.rs',
                         'crates/cyril-workbench/src/lib.rs'):
            path = fixture / relative
            before = digest(path.read_bytes())
            path.touch()
            if digest(path.read_bytes()) != before:
                raise SystemExit('Boundary touch changed source bytes')
            touches.append({'path': relative, 'sha256': before, 'mtime_ns': path.stat().st_mtime_ns})
        print(f'CASE {case} SIDE {side} widgets={len(widget_paths)} markdown_sha256={digest(markdown.read_bytes())}', flush=True)
        for offset, gate in enumerate(d['GATES']):
            current = first_ordinal + offset
            if current <= 17:
                continue
            command = ['cargo', 'test', '--manifest-path', str(fixture / 'Cargo.toml'),
                       '--target-dir', str(target), '-p', 'cyril-ui', '--lib', gate,
                       '--', '--exact', '--nocapture', '--test-threads=1']
            print(f'RUN ordinal={current} {case} {side} {gate}: {json.dumps(command)}', flush=True)
            result = subprocess.run(command, cwd=fixture, env=environment,
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            log = fixture / (gate.replace('::', '-') + '.log')
            log.write_text(result.stdout)
            print(f'EXIT {result.returncode} LOG {log}', flush=True)
            print(result.stdout, end='' if result.stdout.endswith('\n') else '\n', flush=True)
            text = result.stdout
            named_one = '\nrunning 1 test\n' in text and f'test {gate} ... ' in text
            compiler_error = 'could not compile' in text or re.search(r'error\[E\d+\]', text) is not None
            expected_after_diagnostic = (
                'markdown.rs: widget imports the theme module outside an allowed seam'
                if gate == d['GATES'][0]
                else 'assertion failed: !production.contains("crate::theme::resolve")'
            )
            attributed_after_diagnostic = expected_after_diagnostic in text
            checker_assertion = 'panicked at ' in text and (
                'assertion failed:' in text or 'assertion `' in text or attributed_after_diagnostic
            )
            marker = 'crate::theme::resolve' in text
            valid = (result.returncode == 101 and named_one and checker_assertion
                     and 'test result: FAILED. 0 passed; 1 failed' in text and not compiler_error
                     and (side == 'BEFORE' or attributed_after_diagnostic))
            row = {'ordinal': current, 'case': case, 'side': side.lower(), 'gate': gate,
                   'expected': 'FAIL', 'exit_code': result.returncode, 'named_one_test_executed': named_one,
                   'compiler_error': compiler_error, 'checker_assertion': checker_assertion,
                   'injected_marker_in_diagnostic': marker, 'matches_expectation': valid,
                   'expected_after_diagnostic': expected_after_diagnostic,
                   'injection_specific_after_diagnostic_observed': attributed_after_diagnostic,
                   'before_cap_mask_possible': side == 'BEFORE', 'command': command, 'cwd': str(fixture),
                   'explicit_target_dir': str(target), 'environment_CARGO_TARGET_DIR': None,
                   'log': str(log), 'log_sha256': digest(log.read_bytes()), 'boundary_touches': touches,
                   'same_UI_source_as_prior_receipt17': same_as_prior17}
            rows.append(row)
            with (evidence / 'named-receipts.jsonl').open('a') as stream:
                stream.write(json.dumps(row) + '\n')
            if not valid:
                raise SystemExit(f'STOP first unexpected receipt{current}; source not repaired/retried')
print(json.dumps({'executed_ordinals': [r['ordinal'] for r in rows], 'named_command_count': len(rows)}), flush=True)
