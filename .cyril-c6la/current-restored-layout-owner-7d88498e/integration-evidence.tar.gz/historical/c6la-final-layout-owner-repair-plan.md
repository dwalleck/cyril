# C6 final layout-owner repair plan — D1, D2, D3

## Status and decision

**Plan only. No production/workflow edits, Git mutations, builds, tests, linters, formatters, benchmarks, or native runs performed. Main GO is required before implementation; Main owns all Cargo and assembled qualification.**

Inspected the supplied linked worktree `/home/dwalleck/repos/cyril-wt-perf-cyril-c6la`, identified by the assignment as HEAD `c0846f994994575683dd9d1568ed08f003859886`. Paths below are worktree-relative; `UI/` means `crates/cyril-ui/src/`. The approved design available in this worktree is `.cyril-c6la/design.md`; no separate `approveddesign.md` was found.

**D1 is verified by source inspection and should be repaired, not waived.** Restore the existing approved ownership at `design.md:71-81,103-110,221`: chat specifies presentation and resolves its sources; layout prepares/owns physical rows and aggregates/indexes/seeks/traverses/paints them. The current misplaced bodies are explicitly identified below. This is one atomic source/caller migration, not a new top-level design.

**No new unapproved responsibility/interface tradeoff is required.** A single opaque payload type parameter on layout-owned block/aggregate data is justified by the actual ownership constraint: selectors/generated/shared backing must stay chat-defined, but each selector payload and its rows must be retained/replaced/dropped together. Layout never interprets that payload. There is one production specialization, `Layout<Presentation>`, no provider/backend trait, dynamic dispatch, registry, configurable renderer family, payload clone requirement, or parallel selector deque. This is an intrinsic ownership seam, not hypothetical adapter generality. The existing borrowed source callback remains a closure at the physical painting seam.

D2 and D3 are independently verified ledger omissions/inconsistencies. Their proposed changes below only document already-approved contracts. Do not edit the design or findings before Main GO.

## 1. Exact source ownership repair

### Move into `UI/widgets/chat_layout/mod.rs`

| Existing source | New ownership / concrete change |
|---|---|
| `chat/presentation.rs:45-50`, only `rows: Vec<WrappedRow>` | Layout owns private immutable `PreparedRows` storage and a `PreparedBlock<P>` combining those rows with an opaque payload. The payload is owned in the same block, not in a sidecar collection. |
| `chat/presentation.rs:150-154` `LogicalLine` | Move this source-neutral logical specification unchanged: span token/style pairs, line style, alignment. Chat constructs these inputs; layout interprets them physically. |
| `chat/presentation.rs:736-757` `Preparation::finish` body | Move logical-specification → borrowed `SourceLine`/`SourceSpan` construction and the single `wrap_lines` call behind `chat_layout::prepare`. Presentation's `finish` becomes only borrow-source adaptation and payload handoff; it no longer imports/calls `wrap_lines` or stores rows. |
| `chat/retained.rs:52-54,58-63` physical storage | One layout aggregate owns the indexed block deque, `RowHeights`, one leading block, and the four existing trailing blocks. Retained keeps one nested `Layout<Presentation>` field, never a second physical/source-owner deque. |
| `chat/retained.rs:108-115` `total_rows` | Move exact leading + indexed total + trailing total arithmetic into layout. |
| `chat/retained.rs:125-156` paired deque/index operations | Move append, point replacement, and prefix removal/shrink operations into atomic layout methods. Chat still decides which retained-relative indices change from domain revisions; it never updates a height separately. |
| `chat/retained.rs:237-304` `ChatRenderState::paint` | Move skip handling, indexed seek, visible block iteration, leading/trailing order, and continuation row/y arithmetic into layout's `paint`. Supply only an immutable Buffer/Rect/start and the chat source callback. |
| `chat/retained.rs:325-350` `paint_block` | Move into layout as a private implementation helper; retain direct row slicing, viewport `take`, zero overscan, and calls to the existing row painter. |
| `chat/presentation.rs:132-142`, only run counting; `retained.rs:71-105`, only physical traversal/counting | Layout counts indexed blocks/rows/runs and traverses payloads through an inspection callback outside drawing. Chat retains source-slot/generated/shared Markdown byte accounting and Arc-pointer deduplication. Public metric names and meaning do not change. |
| `chat/retained.rs:258-259,341-345` actual physical-operation instrumentation | Move index-step/painted-row/resolved-run counters with the actual operations. Preserve the existing chat-facing aggregate `work_counts()` fields by composing snapshots, not by adding decorative caller-side counters. |

`chat_layout/mod.rs` remains cohesive: physical prepared data, aggregate operations and painting. Reuse the existing file; do not add a sixth widget Rust source.

### Retain in `UI/widgets/chat/presentation.rs`

- Rename the current row-bearing `PreparedBlock` to `Presentation`, containing **only** `sources: Vec<SourceSlot>` and `markdown: Vec<Arc<[Line<'static>]>>`.
- Keep `Source`, `SourceSlot`, `Sources`, `Sources::message`, `Sources::external`, `Presentation::source_text`, and shared-Markdown/source-ownership accounting here (`:18-43,52-130,134-147`). No `ChatMessage`, `ToolTextSource`, `DiffSource`, `TuiState`, or source-selector matching moves into layout.
- `Preparation` holds that presentation payload and `Vec<chat_layout::LogicalLine>`. All message/tool/plan/thought/steer/generated-affix/Markdown/activity policy remains here. Crossing-grapheme derivation and all existing source ranges remain unchanged.
- Preserve `Preparation::into_lines` for existing presentation-shape tests. It remains a test adapter, not another preparation/wrapping engine.
- `finish(sources, width)` borrows the payload to invoke `chat_layout::prepare(&lines, width, |slot| payload.source_text(slot, sources))`, then moves the payload plus returned physical storage into layout's `PreparedBlock::new`. Temporary source borrows end before the payload move. No retained borrowed strings or self-reference is introduced.

### Retain in `UI/widgets/chat/retained.rs`

- `ChatRenderState`, its crate-visible outward interface, reset behavior, geometry/theme identity, history revision/range, child-name ownership, independent text/thought revision keys, live-nonempty flag, and activity key.
- History source identity/reset detection, chronological append versus changed-existing-position classification, between-frame prune calculation, and assignment of the new history revision/range (`:117-160`). These are transcript/source invalidation decisions, not physical indexing.
- `prepare_message` and all domain `Preparation` calls in `synchronize_live` / `synchronize_activity` (`:163-235,307-323`), redirected to layout block replacement methods.
- `activity_key`, focused main/child selection, name selection, guarded main/child live-text access, follow/rows-back/clamp policy, and **F12's sole content/gutter geometry and scrollbar owner** (`:352-451`). Layout receives the already-final content Rect and `usize` start. It neither subtracts a gutter nor chooses scroll policy.
- Source adaptation for a visible block: indexed blocks map `retained.start + relative_index` to one current `MessageHistory::get`; prefix/label/activity use default `Sources`; live/thought use the existing thought context. Resolve this context **once per intersecting block**, then return the existing per-slot borrowed `source_text` closure. Do not perform a new history lookup for every styled run.
- Existing `WorkCounts` outward shape and actual preparation counters. The physical counter snapshot is supplied by layout.

### `chat_layout/wrap.rs` and `index.rs`

- Preserve `wrap_lines`, the corrected F11 carry body, span/run boundaries, physical widths, alignment, attribution/license, and test-only original-reference classification unchanged.
- Preserve all `RowHeights` algorithms: append-node construction, point update, retired-prefix accounting, binary-lifting locate, metadata-only compaction and capacity thresholds. Only narrow visibility/imports if needed so production chat no longer imports index/wrapper internals.
- Existing layout test helpers remain accessible to presentation's F11 differential/golden fixtures under `cfg(test)`; no fidelity fixture removal or expected-output repinning.

## 2. Bounded private interface

Names are proposed implementation spellings, not new public UI interfaces:

```text
LogicalLine { spans: Vec<(usize, Style)>, style, alignment }
PreparedRows { private rows: Vec<WrappedRow> }
prepare(lines: &[LogicalLine], width: u16,
        source_text: impl FnMut(usize) -> &str) -> PreparedRows

PreparedBlock<P> { private payload: P, private physical: PreparedRows }
PreparedBlock::new(payload, physical)
PreparedBlock::payload() -> &P

Layout<P> {
    private leading: PreparedBlock<P>,
    private indexed: VecDeque<PreparedBlock<P>>,
    private heights: RowHeights,
    private trailing: [PreparedBlock<P>; 4],
}
Layout::{len, push, replace, discard_prefix, replace_leading, replace_trailing,
         total_rows, paint, metrics}
BlockLocation::{Leading, Indexed(usize), Trailing(usize)}
```

`prepare`'s real Rust declaration uses a normal output lifetime tied to its borrowed-source callback. `PreparedRows` is a zero-extra-allocation storage wrapper: it lets preparation borrow chat-owned/generated payload bytes, then move that payload into its block after wrapping. It does not expose the raw row vector to production chat.

The four inline trailing slots are exactly the four existing allocations/blocks, ordered label/live/thought/activity. Their numeric-to-domain mapping is private to chat; layout only knows ordered trailing slots. Keep them inline, not in a new heap Vec or a runtime-configurable slot registry. Layout must not name or inspect their transcript meaning. No const-generic renderer topology is needed.

`push`/`replace` compute the block height and update deque/index together. `discard_prefix` performs the existing deque retirement, index discard and capacity-ratio shrink together. Invalid caller indices retain invariant failure behavior; do not add input-validation/retry/fallback policy.

`paint` owns all physical iteration. Its source callback is created once per visible block and yields a per-slot borrowed accessor; an ordinary `F: FnMut(usize) -> &'a str` plus `make_source: impl FnMut(BlockLocation, &'a P) -> F` suffices. The lifetime is the common immutable borrow of layout and selected sources, not `'static`; no boxed closure, clone, source-provider trait, or stored callback. `paint_row` stays the unchanged leaf painter.

`metrics` returns physical block/row/run counts and invokes an immutable payload inspection callback. Chat uses that callback for source slots, generated bytes and shared Markdown deduplication, then constructs the unchanged `render::LayoutMetrics`. No all-history inspection is added to timed/warm painting.

`ChatRenderState::invalidate` continues replacing the **whole** chat state, including its nested layout and all revision keys. No separate invalidation ordering protocol is introduced.

## 3. Necessary callers and obsolete code

### Source files expected to change

1. `UI/widgets/chat/presentation.rs`: payload/physical split; imported logical specification; thin finish handoff; local test access adaptation.
2. `UI/widgets/chat/retained.rs`: nested owner and atomic update calls; chat policy and source callback; counter snapshot composition; local test adaptation.
3. `UI/widgets/chat_layout/mod.rs`: actual prepared/aggregate owner and moved physical bodies, plus focused tests through that interface.
4. `UI/widgets/chat_layout/wrap.rs`: at most visibility/test-access adjustments. Do not rewrite its algorithm.
5. `UI/widgets/chat_layout/index.rs`: at most narrower visibility. Do not rewrite its algorithm.

The last two can remain byte-identical if their current visibility suffices. `UI/widgets/chat.rs` should remain unchanged: its `ChatRenderState`, `render`, `work_counts`, and `wrap_count` seams remain valid; `Preparation`/`into_lines` test adapters at `:78-122` continue to work. Only a necessary internal import adjustment is in scope if encountered.

### Explicitly unchanged consumers

- `UI/render.rs:8-40,220`: public `LayoutMetrics`, private chat field, draw/reset wiring.
- `crates/cyril/src/app.rs:30,77,466,968`: separate long-lived `RenderState` and root draw.
- `UI/traits.rs`, `message_history.rs`, `state.rs`, `subagent_ui.rs`, Core parser types: **no production change** for D1–D3.
- `UI/conversation_performance_tests.rs`, `chrome_theme_tests.rs`, and `benches/conversation_render.rs`: preserve the public-root/counter/metrics contract and all assertions/workloads; no filename/snapshot/TSV fixture migration is justified.
- `UI/widgets/approval.rs:580-584` and `chat::render_diff_lines`: real independent approval consumers, not obsolete aliases; leave them intact.
- Source inventory registrations: the same widget file set remains.

### Delete obsolete ownership, not add compatibility layering

- Remove chat's physical row field, direct `WrappedRow`/`wrap_lines`/`RowHeights` production imports, deque/index fields and paired mutation bodies, physical `total_rows`, physical traversal/`paint_block`, and redundant run-count logic after their move.
- Do not leave forwarding aliases for old row-bearing chat `PreparedBlock`, a second prepared deque, duplicated index state, a shadow copy of physical counters, or fallback traversal.
- Replace direct private representation accesses in tests with the new owner/test access, not production row-vector getters. Test-only borrowing of physical rows/pointers can remain where required by existing F11/ownership assertions; it is not a new public consumer seam.

## 4. Algorithm, body, memory and contract preservation

- SourceLine construction and wrapping remain preparation-only and occur exactly once for each existing `finish`, including empty/zero-width cases. Same temporary line/span collections; same final `Vec<WrappedRow>` allocation moved, not rebuilt/copied.
- Existing owned source-slot and Arc vectors move into the same block payload. No deep Arc-line copy, plain/diff body copy, extra per-block box, per-frame owning string, stored UiState pointer, or new all-history source view.
- Existing prefix/suffix allocations stay inline. VecDeque removal/shrink and RowHeights tombstone compaction preserve row allocation identity; only existing metadata moves. Retain ratio4/shrink-to2 behavior and index compaction thresholds.
- Same seek and visible-row loop bodies: `O(log N + R + S_v)`, zero physical-row overscan, direct deep seek in a giant message, no u16 scroll narrowing. Same changed-block derivation + `O(K log N)` metadata and explicit cold width/theme/focus transitions.
- Width/height zero, empty history, zero-height blocks, boundary skips, history-to-tail crossing, total/oversized back, prefix pruning beyond the old range, and reset-before-live behavior must remain identical. Height-only geometry continues selecting a window without wrapping.
- No F11 expansion, upstream2680 semantics, clipping, unsafe-reference blanket skip, source-policy exception, scrollbar relocation, history cap, allocation workaround or new dependency.
- Recursive widget inventory remains22 here /23 only with the already-approved MCP widget. Keep raw production cap300000 and all five explicit-theme prohibitions, including broad `resolve(`. Keep `source_text` spelling. Palette/highlight coverage remains independent and unchanged.

## 5. Existing tests: precise adaptation, no replacement of consumer proof

| Existing test surface | Disposition |
|---|---|
| `chat/retained.rs:464-533` zero/one-column/F12 | Keep geometry/gutter/actual Buffer/work assertions in retained; adapt only physical pointer inspection via test-only layout access. |
| `retained.rs:537-611` revision order, coalescing, append/prune/overtake | Keep domain invalidation/preparation-count and authoritative-source checks; obtain payloads through owner test access. Preserve untouched row allocation identity checks. |
| `retained.rs:615-640` child-name/live independence | Keep chat policy test, unchanged live-preparation/Markdown count and row-allocation assertions; adapt header/label payload inspection. |
| `retained.rs:644-665` compaction | Physical deque/index/locate assertions move with the layout aggregate into `chat_layout/mod.rs` tests using literal source-neutral blocks. Keep the domain integration's zero-reprepare/zero-rewrap and pointer-preservation assertions rather than replacing them with a new model/oracle. |
| `presentation.rs:806-885` `assert_reference`, `:887-1288` affix/F11/halfwidth fixtures | Keep original normative rows/cells/styles, safe real Paragraph comparisons, unsafe classification and every selected window. Adapt layout row access/painting only through cfg-test borrowing or the layout interface. |
| `presentation.rs:1292-1339` selectors/body ownership | Keep with presentation: zero retained plain bytes, nonzero source ranges, current authoritative pointer identity, and drop/move source lifetime controls. Inspect `PreparedBlock::payload`, not relocated physical internals. |
| `chat_layout/index.rs` and `wrap.rs` tests | Already correctly owned. Preserve index/F11/fidelity expectations and classifier meaning. |
| Public root tests in `conversation_performance_tests.rs` | Retain all C1–C5, F11/F12, >u16/giant source, receipt/diff, child/focus/adoption, geometry/theme and work assertions unchanged. These remain the cross-seam proof. |

For the moved aggregate interface, cover the newly centralized integration directly using existing literal blocks/Buffer expectations: empty/zero rows; prefix/body/tail and partial-block transitions; first/middle/last and out-of-range starts; append and changed height; prefix discard/compaction preserving payload/row allocation identity; exactly-once source-context acquisition only for visible blocks. Extend/relocate the relevant current assertions; do not introduce another renderer, parser, checker or shadow expected index.

## 6. Main-owned verification and evidence applicability

No check below has been run by this worker. Perform once after the complete atomic implementation; no sibling Cargo runs.

### Refresh because the changed producer path/counter ownership is directly affected

- Focused aggregate/retained/presentation/wrap/index tests and all public-root conversation performance tests, preserving named positive controls and original workloads.
- Existing explicit-theme recursive inventory/raw-byte guard and palette/highlight guard; do not change inventory limits or checker semantics to make the move fit.
- UI tests, affected binary/App tests, workspace tests, compiler/feature matrices, lint and format gates from the current canonical handoff. Public and crate-visible interfaces remain unchanged but their new source state must qualify.
- Existing actual-root `completed-write` and `long-history` benchmarks, with original100 warmups,30×100 draws, history sizes through50000, giant/deep cases and outside-timer metrics. Historical timings are not observations of the restored source.
- Fresh actual-App consumer plus the approved supported-control native truecolor/none pair for the moved aggregate/paint path, under the existing capture protocol: scroll/resize/palette and separate launches. Do not claim new all-four-mode native or native child-focus coverage. Existing deterministic state/root tests continue owning main↔child focus/back. Preserve the layered exact-test/export/PNG judgment and its visual-only literal-exactness limits.
- Independent repair review after qualification, followed by the required fresh isolated production reconstruction → approved-design comparison for D1 and exact ledger coverage for D2/D3. The old comparison is an honest pre-repair FAIL, not a result to relabel.

Recorded command forms for Main to reuse with its existing source-bound target/environment handling:

```sh
cargo test -p cyril-ui --lib widgets::chat_layout:: -- --test-threads=1 --nocapture
cargo test -p cyril-ui --lib widgets::chat::retained::tests:: -- --test-threads=1 --nocapture
cargo test -p cyril-ui --lib presentation::tests:: -- --test-threads=1 --nocapture
cargo test -p cyril-ui --lib conversation_performance_tests:: -- --test-threads=1 --nocapture
cargo test -p cyril-ui --lib theme::tests::widgets_only_use_the_explicit_theme -- --exact
cargo test -p cyril-ui --test widget_theme_sources
cargo bench -p cyril-ui --bench conversation_render -- completed-write
cargo bench -p cyril-ui --bench conversation_render -- long-history
cargo test --workspace
cargo clippy --workspace --all-targets -- -D warnings
cargo build -p cyril --bins
cargo fmt --all -- --check
```

The first combined layout and retained filters include new aggregate tests; these two are proposed commands, not prior receipts. The wider required feature/no-default/KAS matrices and native invocation remain owned by the current canonical receipt/protocol, not replaced by this list.

### Retain as historical/reference evidence, without rebinding old binaries

- Original portable baseline RED and F11/F12/released-width sensitivity failures: preserve source pins/log bytes; do not rerun reported failures merely to confirm them.
- Literal expected rows/cells/styles, original Paragraph/reference provenance, captured fixtures/TSVs/snapshots, upstream attribution, and external host/reference premises remain unchanged. No expected output is regenerated from the restoration.
- Unchanged checker sensitivity history remains applicable to unchanged checker semantics; actual checker PASS must refresh on the new source. Existing mutation RED can be retained when the mutated algorithm/assertions are unchanged; update moved path/recipe applicability, not its historical execution identity.
- Original benchmark/native archives and visual reviews retain their original source identity and observed limits. They remain historical/reference evidence beside, not substitutes for, the new source-bound runs above.
- Unaffected domain/parser/tracked-tool implementation review can retain its scoped applicability because D1 does not edit those owners. Current assembled compiler/tests still run as required.

Relevant existing owners: `current-main038-b5d45fe2/integration-evidence.tar.gz:qualification/canonical-handoff.json`; `current-width-e3f2a7c7/qualification-evidence.tar.gz:current/running-command-receipts.json`; `current-width-e3f2a7c7/native-supported-controls-evidence.json`; current actual-App consumer `current-main038-b5d45fe2/c6la-main038-consumer-result.json`. Preserve their source labels; none is this worker's executed verification.

## 7. D2 and D3 documentation-only proposals, after Main GO

Change only the Module shape / ownership ledger in `.cyril-c6la/design.md`, preserving approvals and citing the existing amendment. Do not alter behavior, responsibility ownership, interface semantics, risk, fidelity, limits or acceptance.

### D2 — replace existing Core row (`design.md:108`)

| Module | Disposition and owned responsibility | Forbidden responsibilities / interface discipline | Verification |
|---|---|---|---|
| `cyril-core` | Retain typed source domain; existing approved receipt-transform exception returns `HarvestedReceipts` with ordered receipts and conservative earliest-removal splice metadata, consumed via `into_parts` (Post-RED approved owner repairs: Receipt transform metadata). | No history display revisions, Theme, ratatui or rendering dependency; preserve recognition, surviving bytes, receipt order and UI-owned interpretation of metadata. | Existing parser metadata/receipt tests, dependency/compiler checks and review. |

This reconciles the ledger with the already-approved `design.md:257` and implemented `types/steer_receipt.rs:77-93,164-200`; it is not new permission to change Core.

### D3 — add one `traits.rs` row, without forcing it under history/chat

| Module | Disposition and owned responsibility | Forbidden responsibilities / interface discipline | Verification |
|---|---|---|---|
| `traits.rs` | Retain read-only `TuiState` history/live contract and authoritative tracked-tool borrowed/derived text projections, public Cow adaptations, direct recorded-source resolution and indexed first-Diff/cached preview views; implement only existing interface amendments at design217,225,255. | No physical prepared-row/index/wrap algorithms, retained transcript layout owner, event routing, mutable history escape, generic source-provider service or new diff-derivation path. | Existing history/live/tool-text/diff projection tests, public-root caller/compiler checks and independent review. |

This covers the existing production owner (`traits.rs:48-56,374-414,423-495,576-738`) without migrating its implementation. Keep its established history/traits concrete type dependency explicit; do not manufacture a new one-way dependency claim.

After implementation and checks, Main's artifact owners record one bounded approved-contract D1 repair plus documentation-only D2/D3 dispositions in the existing decision surface, and replace only invalidated qualification conclusions. No wholesale redesign, risk waiver, new tracker deferral, or retrospective relabeling of D1 is needed.

## Research limitations

Production reads and a read-only caller/proof census support this plan. LSP status reported rust-analyzer ready, but a `PreparedBlock` references query at the actual declaration returned false-empty despite its implementation and retained callers. Reported via `xd://report_issue`; no absence-of-caller conclusion relies on it. Scoped repository searches found no external physical primitive consumers beyond the five target files; `chat.rs` additionally consumes `Preparation` only in existing test adapters. No executable result or post-repair conformance is claimed.
