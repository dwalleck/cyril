#!/usr/bin/python3
"""GUI-lease drain: only exact identities already recorded by this authorized run."""
import argparse
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, '/home/dwalleck/.claude/tmp/janet-followups/integration/tools/native-qualification')
from nativeq import lease
from nativeq.evidence import sha256_file, write_new_json
from nativeq.procs import Identity, OwnedProcesses


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--authorization', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    auth = json.loads(Path(args.authorization).read_text())
    root = Path(args.output).resolve()
    if not (auth.get('go') is True and auth.get('scope') == 'c6la-native-supported-controls'
            and auth.get('output') == str(root)
            and root == Path('/tmp/cyril-perf-consumer-20261022/c6la-native-restored-layout-owner-506-supported-controls-01')
            and auth.get('preparation_sha256') == sha256_file(HERE / 'preparation.json')):
        raise RuntimeError('Drain requires this run exact Main GO/output/preparation')
    preparation = json.loads((HERE / 'preparation.json').read_text())
    if any(sha256_file(Path(path)) != expected for path, expected in preparation['file_sha256'].items()):
        raise RuntimeError('Drain inputs changed; retain GUI lease for Main')
    lease.require('linux', 'owned Cyril native lease drain')
    registry = OwnedProcesses()
    for mode in ('truecolor', 'none'):
        path = root / mode / 'owned-processes.json'
        if path.exists():
            for item in json.loads(path.read_text()):
                ident = Identity(int(item['pid']), int(item['start']), tuple(item['argv']))
                if ident not in registry.owned:
                    registry.owned.append(ident)
    report = registry.cleanup(grace=1)
    good = all(row['gone'] for row in report)
    if root.exists():
        write_new_json(root / 'lease-drain.json', {'ok': good, 'cleanup': report,
                                                  'no_process_name_or_group_kills': True})
    # Nonzero deliberately keeps the existing GUI lease for Main; no stale lease reclamation.
    return 0 if good else 1


if __name__ == '__main__':
    raise SystemExit(main())
