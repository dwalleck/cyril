"""Prepared actual-App c6la scenario; the parent owns hash-pinned GO and execution."""


def run(smoke):
    # The parent imports this module while defining its reusable fixtures.
    from native_fixture import chunk, diff, x5xi, zj0m
    import hashlib
    import json
    from pathlib import Path
    import re

    def ordered(label, *markers):
        smoke.visible(*markers)
        text = smoke.text()
        positions = [text.index(marker) for marker in markers]
        counts = {marker: text.count(marker) for marker in markers}
        smoke.check(
            label,
            positions == sorted(positions)
            and len(set(positions)) == len(positions)
            and all(count == 1 for count in counts.values()),
            markers=list(markers),
            positions=positions,
            visible_counts=counts,
            evidence_window="current Ghostty active-area export, not the entire transcript",
        )

    def read_boundary(ident, path):
        return {
            "sessionUpdate": "tool_call",
            "toolCallId": ident,
            "title": "fs_read",
            "kind": "read",
            "status": "in_progress",
            "rawInput": {"path": path},
        }

    def complete_tool(ident, kind="read"):
        return {
            "sessionUpdate": "tool_call_update",
            "toolCallId": ident,
            "kind": kind,
            "status": "completed",
        }

    def write_boundary(ident, path, old, new):
        return {
            "sessionUpdate": "tool_call",
            "toolCallId": ident,
            "title": "fs_write",
            "kind": "edit",
            "status": "pending",
            "rawInput": {"path": path},
            "content": [diff(path, old, new)],
        }

    def replace_diff(ident, path, old, new):
        return {
            "sessionUpdate": "tool_call_update",
            "toolCallId": ident,
            "kind": "edit",
            "status": "completed",
            "content": [diff(path, old, new)],
        }

    def pages(direction, count):
        smoke.send(("\x1b[5~" if direction == "older" else "\x1b[6~") * count)

    def source_indices():
        return [int(value) for value in re.findall(r"C6LA_SOURCE_(\d{3})", smoke.text())]

    smoke.event(
        "c6la-scenario-boundaries",
        scenario_path=str(Path(__file__).resolve()),
        scenario_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        source_design=".cyril-c6la/design.md",
        source_plan=".cyril-c6la/plan.md",
        execution_authorization="native controller requires separate exact hash-pinned Main GO",
        evidence_layer="actual App -> Ghostty 1.3.1 on owned Xvfb; native exports + PNG review",
        unique_markdown_sources=270,
        configured_max_messages=1000,
        product_default_max_messages=500,
        product_fixed_upper_clamp=False,
        native_50000_history="NOT CLAIMED",
        benchmark_50000="separate parent qualification; no benchmark result imported",
        work_counters_and_latency="NOT MEASURED by this scenario",
        runtime_color_mode_transition="UNEXERCISED: startup-only; parent launches each mode separately",
    )
    smoke.event(
        "unexercised-boundary",
        boundary="focused child transcript and main/child/back selection",
        status="UNEXERCISED",
        reason="production App has no key/command entering child focus; do not fabricate entry",
        exercised_instead="source-backed crew list lifecycle and non-main stream routing only",
    )

    # Both fixtures consume an actual pending session/prompt and complete it.
    # x5xi supplies Markdown/table/code, palette there/back, scroll and width changes.
    x5xi(smoke)
    smoke.start_prompt("owned c6la inherited write and deny-only preview fixture")
    zj0m(smoke)

    smoke.start_prompt("owned c6la thought text tool and clear lifecycle")
    smoke.command_input("/clear")
    smoke.wait(
        "Initial c6la clear removes the inherited committed fixture",
        lambda: "WRITE_CHRONOLOGY_AFTER" not in smoke.text(),
    )
    smoke.control(updates=[chunk("C6LA_THOUGHT_BEGIN ", thought=True)])
    smoke.visible("C6LA_THOUGHT_BEGIN")
    smoke.control(updates=[chunk("C6LA_THOUGHT_APPEND\n", thought=True)])
    ordered("live thought deltas accumulate in order", "C6LA_THOUGHT_BEGIN", "C6LA_THOUGHT_APPEND")
    smoke.capture("c01-live-thought-append")

    smoke.control(updates=[chunk("## C6LA_LIVE_BEGIN\n\n**Markdown** live text.\n\n")])
    smoke.control(updates=[chunk("C6LA_LIVE_APPEND\n")])
    ordered(
        "response commits preceding thought without duplicating text deltas",
        "C6LA_THOUGHT_BEGIN", "C6LA_THOUGHT_APPEND", "C6LA_LIVE_BEGIN", "C6LA_LIVE_APPEND",
    )
    smoke.capture("c02-live-text-append")
    smoke.control(updates=[chunk("C6LA_TOOL_THOUGHT\n", thought=True)])
    smoke.visible("C6LA_TOOL_THOUGHT", "C6LA_LIVE_APPEND")

    live_tool = "c6la-live-tool"
    live_path = "c6la-live-visible.rs"
    live_old = "stable\nC6LA_LIVE_TOOL_BASE\n"
    smoke.control(updates=[
        write_boundary(live_tool, live_path, live_old, "stable\nC6LA_LIVE_TOOL_NEW\n"),
        complete_tool(live_tool, kind="edit"),
    ])
    ordered(
        "tool boundary commits text and thought before its completed diff",
        "C6LA_THOUGHT_BEGIN", "C6LA_LIVE_BEGIN", "C6LA_LIVE_APPEND",
        "C6LA_TOOL_THOUGHT", live_path, "C6LA_LIVE_TOOL_NEW",
    )
    smoke.capture("c03-tool-boundary-chronology")
    smoke.control(updates=[replace_diff(
        live_tool, live_path, live_old, "stable\nC6LA_LIVE_TOOL_REPLACED\n",
    )])
    smoke.visible("C6LA_LIVE_TOOL_REPLACED", "C6LA_LIVE_APPEND")
    smoke.check(
        "visible completed tool replaces its old diff source",
        "C6LA_LIVE_TOOL_NEW" not in smoke.text(),
        replacement="C6LA_LIVE_TOOL_REPLACED",
    )
    smoke.capture("c04-visible-tool-source-update")

    smoke.control(updates=[
        chunk("C6LA_CLEAR_KEEP_TEXT\n"),
        chunk("C6LA_CLEAR_KEEP_THOUGHT\n", thought=True),
    ])
    smoke.visible("C6LA_CLEAR_KEEP_TEXT", "C6LA_CLEAR_KEEP_THOUGHT")
    smoke.command_input("/clear")
    smoke.wait(
        "Clear drops committed history but preserves live text and thought",
        lambda: all(marker in smoke.text() for marker in ["C6LA_CLEAR_KEEP_TEXT", "C6LA_CLEAR_KEEP_THOUGHT"])
        and all(marker not in smoke.text() for marker in ["C6LA_LIVE_BEGIN", "C6LA_LIVE_TOOL_REPLACED", live_path]),
    )
    smoke.check(
        "clear preserves both live blocks while dropping old committed rows",
        all(marker in smoke.text() for marker in ["C6LA_CLEAR_KEEP_TEXT", "C6LA_CLEAR_KEEP_THOUGHT"])
        and "C6LA_THOUGHT_BEGIN" not in smoke.text(),
        policy="clear is not a live-stream reset",
    )
    smoke.capture("c05-clear-during-live-text-and-thought")
    reused_path = "c6la-reused-visible.rs"
    smoke.control(updates=[
        write_boundary(live_tool, reused_path, "C6LA_REUSED_BASE\n", "C6LA_REUSED_TOOL_NEW\n"),
        complete_tool(live_tool, kind="edit"),
        chunk("C6LA_AFTER_CLEAR\n"),
    ], complete=True)
    ordered(
        "reused tool ID after clear owns a new correctly ordered row",
        "C6LA_CLEAR_KEEP_TEXT", "C6LA_CLEAR_KEEP_THOUGHT", reused_path,
        "C6LA_REUSED_TOOL_NEW", "C6LA_AFTER_CLEAR",
    )
    smoke.check("clear does not resurrect the prior tool source", live_path not in smoke.text())
    smoke.capture("c06-clear-reused-tool-and-turn-complete")

    smoke.start_prompt("owned c6la bounded cache-pressure history")
    smoke.command_input("/clear")
    smoke.wait("Fresh cache-pressure history epoch", lambda: "C6LA_AFTER_CLEAR" not in smoke.text())
    sources = [
        f"## C6LA_SOURCE_{index:03d}\n\n"
        f"Unique source {index:03d}: **bold**, *emphasis*, [link](https://example.invalid/c6la/{index}).\n\n"
        f"```rust\nlet c6la_source_{index:03d} = {index};\n```\n\n"
        f"C6LA_COMMIT_{index:03d}\n"
        for index in range(270)
    ]
    old_tool = "c6la-seed-000"
    old_path = "c6la-old-visible.rs"
    old_base = "stable\nC6LA_TOOL_BASE\n"
    confirmed_batches = []
    # Thirty notification frames per batch, well below the 256-frame queues.
    # A real tool start commits each Markdown block; chunks alone would concatenate.
    for first in range(0, len(sources), 10):
        updates = []
        for index in range(first, first + 10):
            ident = f"c6la-seed-{index:03d}"
            boundary = (
                write_boundary(ident, old_path, old_base, "stable\nC6LA_TOOL_ORIGINAL\n")
                if index == 0
                else read_boundary(ident, f"c6la-boundary-{index:03d}.txt")
            )
            updates.extend([
                chunk(sources[index]),
                boundary,
                complete_tool(ident, kind="edit" if index == 0 else "read"),
            ])
        smoke.control(updates=updates)
        last = first + 9
        ordered(
            f"cache-pressure batch ending {last:03d} reaches the actual viewport",
            f"C6LA_COMMIT_{last:03d}", f"c6la-boundary-{last:03d}.txt",
        )
        confirmed_batches.append(last)
    smoke.check(
        "270 unique committed Markdown inputs exceed the 256-entry global cache",
        len(set(sources)) == 270 and len(confirmed_batches) == 27 and 2 * len(sources) < 1000,
        unique_input_sources=len(set(sources)),
        tool_commit_boundaries=len(sources),
        batch_size=10,
        visible_batch_endpoints=confirmed_batches,
        fixture_committed_rows=2 * len(sources),
        retained_count="not introspected; endpoint content and batch ordering are observed",
        cache_eviction_and_work_counts="not instrumented by PTY smoke",
    )
    smoke.control(updates=[chunk("C6LA_HISTORY_LIVE_TAIL\n")])
    ordered("cache-pressure newest suffix remains in order", "C6LA_COMMIT_269", "C6LA_HISTORY_LIVE_TAIL")
    smoke.capture("c07-cache-pressure-newest-and-live")

    for _ in range(10):
        pages("older", 40)
    ordered("cache-pressure oldest source and original tool remain visible", "C6LA_SOURCE_000", old_path, "C6LA_TOOL_ORIGINAL")
    smoke.check("oldest browse window is distinct from the live tail", "C6LA_HISTORY_LIVE_TAIL" not in smoke.text())
    smoke.capture("c08-cache-pressure-oldest")
    smoke.control(updates=[replace_diff(
        old_tool, old_path, old_base, "stable\nC6LA_TOOL_UPDATED_OLD_VISIBLE\n",
    )])
    ordered(
        "old retained visible tool updates after cache-size-exceeding history",
        "C6LA_SOURCE_000", old_path, "C6LA_TOOL_UPDATED_OLD_VISIBLE",
    )
    smoke.check("old tool edit removes the prior visible body", "C6LA_TOOL_ORIGINAL" not in smoke.text())
    smoke.capture("c09-old-visible-tool-updated")

    # Return from the deliberately oversized rows-back value before seeking middle.
    for _ in range(10):
        pages("newer", 40)
    smoke.visible("C6LA_HISTORY_LIVE_TAIL", "C6LA_COMMIT_269")
    middle = []
    for _ in range(80):
        pages("older", 4)
        middle = [index for index in source_indices() if 100 <= index <= 169]
        if middle:
            break
    smoke.check(
        "cache-pressure middle browse has positive interior source content",
        bool(middle) and "C6LA_SOURCE_000" not in smoke.text() and "C6LA_HISTORY_LIVE_TAIL" not in smoke.text(),
        visible_interior_sources=middle,
        navigation="bounded PageUp search for source indices 100..169, not a fixed top anchor",
    )
    smoke.capture("c10-cache-pressure-middle")
    for _ in range(10):
        pages("newer", 40)
    ordered("cache-pressure browse returns to main follow", "C6LA_COMMIT_269", "C6LA_HISTORY_LIVE_TAIL")
    smoke.capture("c11-cache-pressure-return-to-follow")

    smoke.resize(80, 24)
    smoke.visible("C6LA_HISTORY_LIVE_TAIL")
    smoke.capture("c12-cache-pressure-narrow")
    smoke.resize(160, 48)
    smoke.visible("C6LA_COMMIT_269", "C6LA_HISTORY_LIVE_TAIL")
    smoke.capture("c13-cache-pressure-wide")
    smoke.resize(160, 12)
    smoke.visible("C6LA_HISTORY_LIVE_TAIL")
    smoke.capture("c14-cache-pressure-height-only-short")
    smoke.resize(160, 48)
    ordered("height-only restoration preserves newest source and live tail", "C6LA_COMMIT_269", "C6LA_HISTORY_LIVE_TAIL")
    smoke.capture("c15-cache-pressure-height-only-restored")
    palette_baseline = smoke.style("C6LA_COMMIT_269")
    for palette, capture in [
        ("gruvbox-dark", "c16-cache-pressure-palette-changed"),
        ("cyril-dark", "c17-cache-pressure-palette-restored"),
    ]:
        smoke.command_input("/theme")
        smoke.visible("theme")
        smoke.send(palette)  # Picker filtering consumes ordinary keys, not paste.
        smoke.send("\r")
        smoke.visible("C6LA_COMMIT_269", "C6LA_HISTORY_LIVE_TAIL")
        palette_observed = smoke.style("C6LA_COMMIT_269")
        smoke.require_visual(
            "cache-pressure retained suffix follows palette " + palette,
            original=palette_baseline,
            observed=palette_observed,
            color_mode=smoke.color_mode,
            expected="changed in truecolor for gruvbox-dark; otherwise identical marker styling",
        )
        smoke.capture(capture)

    child_id = "70000000-0000-4000-8000-000000000002"
    child_name = "c6la-owned-child"
    smoke.check(
        "owned child identity is distinct from the actual main session",
        bool(smoke.peer_state().get("session_id")) and child_id != smoke.peer_state()["session_id"],
        child_session_id=child_id,
        main_session_id=smoke.peer_state().get("session_id"),
    )

    def crew_frame(status):
        return {
            "method": "_kiro.dev/subagent/list_update",
            "params": {
                "subagents": [{
                    "sessionId": child_id,
                    "sessionName": child_name,
                    "agentName": "owned-performance-display-peer",
                    "initialQuery": "owned display-only rendering fixture",
                    "group": "c6la-owned",
                    "status": status,
                }],
                "pendingStages": [],
            },
        }

    def child_frame(update):
        return {"method": "session/update", "params": {"sessionId": child_id, "update": update}}

    def main_frame(text):
        # Only $MAIN is replaced by the peer; child UUIDs must remain untouched.
        return {"method": "session/update", "params": {"sessionId": "$MAIN", "update": chunk(text)}}

    child_markers = ["C6LA_CHILD_TRANSCRIPT_ONLY", "C6LA_CHILD_LIVE_ONLY", "C6LA_CHILD_APPEND_ONLY"]
    smoke.control(frames=[
        crew_frame({"type": "working", "message": "C6LA_CHILD_WORKING"}),
        child_frame(chunk("C6LA_CHILD_TRANSCRIPT_ONLY\n")),
        child_frame(read_boundary("c6la-child-tool-1", "c6la-child-only-1.txt")),
        child_frame(complete_tool("c6la-child-tool-1")),
        child_frame(chunk("C6LA_CHILD_LIVE_ONLY\n")),
        main_frame("\nC6LA_CREW_CREATED_MAIN\n"),
    ])
    smoke.visible(child_name, "C6LA_CHILD_WORKING", "C6LA_CREW_CREATED_MAIN")
    smoke.check(
        "crew creation preserves the main transcript rather than selecting child text",
        "C6LA_HISTORY_LIVE_TAIL" in smoke.text() and all(marker not in smoke.text() for marker in child_markers),
        focused_transcript="UNEXERCISED: no production input enters child focus",
    )
    smoke.capture("c18-crew-child-created-main-stays-selected")
    smoke.control(frames=[
        crew_frame({"type": "working", "message": "C6LA_CHILD_UPDATED"}),
        child_frame(chunk("C6LA_CHILD_APPEND_ONLY\n")),
        child_frame(read_boundary("c6la-child-tool-2", "c6la-child-only-2.txt")),
        child_frame(complete_tool("c6la-child-tool-2")),
        child_frame({
            "sessionUpdate": "tool_call_update",
            "toolCallId": "c6la-child-tool-1",
            "kind": "read",
            "title": "Owned child display updated",
            "status": "completed",
        }),
        main_frame("C6LA_CREW_UPDATED_MAIN\n"),
    ])
    smoke.visible(child_name, "C6LA_CHILD_UPDATED", "C6LA_CREW_UPDATED_MAIN")
    smoke.check(
        "replacement crew list updates visible status without child transcript leakage",
        "C6LA_CHILD_WORKING" not in smoke.text() and all(marker not in smoke.text() for marker in child_markers),
        child_history_visibility="UNEXERCISED; tool boundaries and updates are source-backed wire inputs only",
    )
    smoke.capture("c19-crew-child-status-and-stream-updated")
    smoke.control(frames=[
        crew_frame({"type": "terminated"}),
        main_frame("C6LA_CREW_TERMINATED_MAIN\n"),
    ])
    smoke.visible(child_name, "Terminated", "C6LA_CREW_TERMINATED_MAIN")
    smoke.check("terminated crew status replaces working status", "C6LA_CHILD_UPDATED" not in smoke.text())
    smoke.capture("c20-crew-child-terminated")
    smoke.control(frames=[
        {"method": "_kiro.dev/subagent/list_update", "params": {"subagents": [], "pendingStages": []}},
        main_frame("C6LA_CREW_REMOVED_MAIN\n"),
    ])
    smoke.wait(
        "Empty replacement list removes the crew entry while main content advances",
        lambda: "C6LA_CREW_REMOVED_MAIN" in smoke.text() and child_name not in smoke.text(),
    )
    ordered(
        "crew lifecycle leaves main content in chronological follow mode",
        "C6LA_HISTORY_LIVE_TAIL", "C6LA_CREW_CREATED_MAIN", "C6LA_CREW_UPDATED_MAIN",
        "C6LA_CREW_TERMINATED_MAIN", "C6LA_CREW_REMOVED_MAIN",
    )
    smoke.check(
        "crew removal does not expose the stored child transcript",
        all(marker not in smoke.text() for marker in child_markers) and "crew: c6la-owned" not in smoke.text(),
        focused_transcript="UNEXERCISED: no authentic production focus-entry input",
        removal_semantics="entry absent; child storage is retained, not deleted",
        child_activity_ready="source-backed consequence of absence, not introspected by this smoke",
    )
    smoke.capture("c21-crew-child-removed")

    failure_fixture = Path(__file__).with_name("v2_failed_validation_2_11_0.jsonl")
    failure_frames = [json.loads(line)["msg"] for line in failure_fixture.read_text().splitlines() if line]
    captured_sessions = sorted({frame["params"]["sessionId"] for frame in failure_frames})
    # Rebind only the captured routing identity. Every update/content/rawInput value is retained.
    for frame in failure_frames:
        frame["params"]["sessionId"] = "$MAIN"
    failure_error = "The tool arguments failed validation: '/home/dwalleck/repos/rivets/CONTEXT.md' does not exist"
    smoke.event(
        "captured-failed-validation-input",
        fixture_path=str(failure_fixture),
        fixture_sha256=hashlib.sha256(failure_fixture.read_bytes()).hexdigest(),
        captured_session_ids=captured_sessions,
        routing_rebind_only=True,
        captured_tool_call_id="tooluse_s3x9l2sZ9aE7Sazt0allDj",
        raw_output="absent in the genuine captured failed update",
        oracle="existing v2_failed_validation root chronology/one-failure/content-error contract",
    )
    smoke.control(frames=failure_frames)
    ordered(
        "captured failed update preserves before/error/after chronology",
        "there's an existing CONTEXT.md",
        failure_error,
        "No existing domain model.",
    )
    failure_screen = smoke.text()
    smoke.check(
        "one genuine failed update renders its single content-backed error",
        failure_screen.count("✗ ") == 1 and failure_screen.count(failure_error) == 1,
        expected_error=failure_error,
        expected_tool_call_id="tooluse_s3x9l2sZ9aE7Sazt0allDj",
        failure_scope="tool failure only; no main-turn cancellation or transport-error claim",
    )
    smoke.capture("c21a-captured-failed-validation")

    smoke.control(updates=[chunk("C6LA_DONE\n")], complete=True)
    smoke.wait("Actual c6la prompt completed", lambda: smoke.peer_state().get("pending_prompt") is False)
    ordered("final main turn commits the visible lifecycle tail", "C6LA_CREW_REMOVED_MAIN", "C6LA_DONE")
    smoke.capture("c22-final-main-turn-committed")
    smoke.event(
        "c6la-scenario-complete",
        input_unique_markdown_sources=270,
        bounded_batch_visible_checkpoints=len(confirmed_batches),
        native_50000_history="NOT CLAIMED",
        native_glyph_qualification="PENDING: independent retained native PNG review",
        focused_transcript="UNEXERCISED: no production focus-entry key/command",
        performance_work_counters="separate parent TestBackend/benchmark evidence required",
    )
