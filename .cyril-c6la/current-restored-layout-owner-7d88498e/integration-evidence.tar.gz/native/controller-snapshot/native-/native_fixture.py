"""Native-only copy of the immutable inherited payload functions; color assertions require PNG review."""
COMMITTED = "COMMITTED_COLOR_CONTROL"
LIVE = "LIVE_COLOR_CONTROL"


def chunk(text, thought=False):
    return {"sessionUpdate": "agent_thought_chunk" if thought else "agent_message_chunk", "content": {"type": "text", "text": text}}


def diff(path, old, new):
    return {"type": "diff", "path": path, "oldText": old, "newText": new}


def x5xi(smoke):
    smoke.wait("Initial real prompt", lambda: smoke.peer_state().get("pending_prompt") is True)
    markdown = "# HISTORY_OLDEST_CONTROL\n\n**Bold**, *emphasis*, [link](https://example.invalid), quote and code controls.\n\n> QUOTE_CONTROL\n\n| Field | Value |\n| --- | --- |\n| Table | TABLE_CONTROL |\n\n" + "".join(f"History row {i:03}: viewport scroll marker SCROLL_{i:03}.\n\n" for i in range(70)) + "```rust\nlet committed_color_control = 42; // " + COMMITTED + "\n```\n"
    smoke.control(updates=[chunk(markdown)], complete=True)
    smoke.visible(COMMITTED)
    smoke.start_prompt("owned live Markdown control")
    smoke.control(updates=[chunk("## Live Markdown\n\n```rust\nlet live_color_control = 7; // " + LIVE + "\n```\n")])
    smoke.visible(COMMITTED, LIVE)
    smoke.capture("01-markdown-committed-and-live")
    baseline = {marker: smoke.style(marker) for marker in [COMMITTED, LIVE]}
    if smoke.color_mode == "truecolor":
        smoke.require_visual("truecolor code controls contain nondefault foreground/background", observed=baseline)
    else:
        smoke.require_visual("startup no-color code cells have no foreground/background colors", observed=baseline)
    theme_scenarios(smoke, baseline)
    smoke.resize(80, 24)
    smoke.visible(LIVE)
    smoke.capture("08-resize-narrow-live")
    smoke.resize(160, 48)
    smoke.visible(COMMITTED, LIVE)
    smoke.capture("09-resize-wide-live")
    scroll_scenarios(smoke)
    smoke.control(updates=[chunk("\nLIVE_APPEND_CONTROL\n")])
    smoke.visible("LIVE_APPEND_CONTROL")
    smoke.capture("13-live-append-after-interactions")
    smoke.control(complete=True)
    smoke.visible("LIVE_APPEND_CONTROL")
    smoke.capture("14-live-committed")


def theme_scenarios(smoke, baseline):
    # Exact baseline-source picker/command bindings are documented in plan.json.
    smoke.command_input("/theme")
    smoke.visible("┌ theme ")
    smoke.capture("02-theme-picker-open")
    smoke.send("gruvbox-dark")
    smoke.capture("03-theme-preview")
    preview = {marker: smoke.style(marker) for marker in [COMMITTED, LIVE]}
    if smoke.color_mode == "truecolor":
        smoke.require_visual("theme preview recolors committed and live code", baseline=baseline, preview=preview)
    else:
        smoke.require_visual("no-color preview preserves uncolored code", baseline=baseline, preview=preview)
    smoke.send("\x1b")
    smoke.visible(COMMITTED, LIVE)
    cancelled = {marker: smoke.style(marker) for marker in [COMMITTED, LIVE]}
    smoke.require_visual("theme cancel restores committed and live code colors", baseline=baseline, restored=cancelled)
    smoke.capture("04-theme-preview-cancelled")
    smoke.command_input("/theme")
    smoke.send("gruvbox-dark")
    smoke.send("\r")
    smoke.visible(COMMITTED, LIVE)
    committed = {marker: smoke.style(marker) for marker in [COMMITTED, LIVE]}
    smoke.require_visual("theme commit retains preview colors", committed=committed, preview=preview)
    smoke.capture("05-theme-preview-committed")
    smoke.command_input("/theme")
    smoke.send("cyril-dark")
    smoke.send("\r")
    smoke.visible(COMMITTED, LIVE)
    restored = {marker: smoke.style(marker) for marker in [COMMITTED, LIVE]}
    smoke.require_visual("return palette restores original committed and live styles", baseline=baseline, restored=restored)
    smoke.capture("07-return-original-palette")


def scroll_scenarios(smoke):
    smoke.send("\x1b[5~" * 40)
    smoke.visible("HISTORY_OLDEST_CONTROL")
    smoke.check("oldest browse window excludes live tail", LIVE not in smoke.text())
    smoke.capture("10-scroll-oldest")
    smoke.send("\x1b[6~" * 40)
    smoke.visible(LIVE)
    smoke.send("\x1b[5~" * 3)
    smoke.check("middle browse window differs from oldest and live tail", "HISTORY_OLDEST_CONTROL" not in smoke.text() and LIVE not in smoke.text())
    smoke.capture("11-scroll-middle")
    smoke.send("\x1b[6~" * 40)
    smoke.visible(LIVE)
    smoke.capture("12-scroll-return-to-follow")


def zj0m(smoke):
    smoke.wait("Initial real prompt", lambda: smoke.peer_state().get("pending_prompt") is True)
    old = "context-anchor\nold-first\nfooter-anchor\n"
    new = "context-anchor\nnew-first\nnew-second\nfooter-anchor\n"
    first = diff("owned_display_only.rs", old, new)
    second = diff("ignored_display_only.rs", "ignored-old\n", "IGNORED_SECOND_DIFF\n")
    smoke.control(updates=[chunk("WRITE_CHRONOLOGY_BEFORE\n"), {"sessionUpdate": "tool_call", "toolCallId": "owned-write", "title": "fs_write", "kind": "edit", "status": "pending", "rawInput": {"path": "owned_display_only.rs"}}])
    smoke.visible("owned_display_only.rs")
    smoke.capture("z01-write-start")
    smoke.control(updates=[{"sessionUpdate": "tool_call_update", "toolCallId": "owned-write", "kind": "edit", "status": "in_progress", "content": [first, second]}])
    smoke.capture("z02-write-incremental")
    smoke.control(updates=[{"sessionUpdate": "tool_call_update", "toolCallId": "owned-write", "kind": "edit", "status": "completed"}])
    smoke.visible("+2 -1", "new-first", "new-second", "old-first")
    smoke.check("first Diff owns completed counts and body", "IGNORED_SECOND_DIFF" not in smoke.text())
    smoke.capture("z03-write-completed")
    smoke.resize(100, 32)
    smoke.visible("+2 -1", "new-first")
    smoke.capture("z04-write-resized")
    smoke.resize(160, 48)
    smoke.control(updates=[{"sessionUpdate": "tool_call_update", "toolCallId": "owned-write", "kind": "edit", "status": "completed", "content": [diff("owned_display_only.rs", "stable\n", "stable\n"), second]}])
    smoke.wait(
        "App redraw applies unchanged-first-Diff replacement",
        lambda: "owned_display_only.rs" in smoke.text()
        and all(marker not in smoke.text() for marker in ["+2 -1", "new-first", "new-second", "old-first"]),
    )
    smoke.check("unchanged first Diff suppresses later Diff counts and body", "+2 -1" not in smoke.text() and "new-first" not in smoke.text() and "IGNORED_SECOND_DIFF" not in smoke.text())
    smoke.capture("z05-unchanged-first-changed-second")
    smoke.control(updates=[{"sessionUpdate": "tool_call_update", "toolCallId": "owned-write", "kind": "edit", "status": "completed", "content": [first, second]}])
    smoke.visible("+2 -1", "new-first", "new-second")
    smoke.capture("z06-replaced-diff-source")
    original_style = smoke.style("new-first")
    smoke.command_input("/theme")
    smoke.send("gruvbox-dark")
    smoke.send("\r")
    smoke.visible("+2 -1", "new-first", "new-second")
    changed_style = smoke.style("new-first")
    smoke.require_visual("retained first-Diff styling follows committed palette", before=original_style, after=changed_style, color_mode=smoke.color_mode)
    smoke.capture("z06a-retained-diff-new-palette")
    padding = "".join(f"WRITE_HISTORY_PAD_{number:03}\n\n" for number in range(70))
    smoke.control(updates=[chunk(padding), {"sessionUpdate": "tool_call", "toolCallId": "owned-history-boundary", "title": "Owned display boundary", "kind": "read", "status": "completed", "rawInput": {"path": "HISTORY_FOLLOW_CONTROL"}}])
    smoke.visible("HISTORY_FOLLOW_CONTROL")
    smoke.check("completed Diff actually leaves the viewport", "new-first" not in smoke.text() and "+2 -1" not in smoke.text())
    smoke.capture("z06b-diff-scrolled-out")
    for _ in range(16):
        if "new-first" in smoke.text():
            break
        smoke.send("\x1b[5~")
    smoke.visible("+2 -1", "new-first", "new-second")
    smoke.require_visual("offscreen retained Diff returns with new-palette styles", baseline=changed_style, observed=smoke.style("new-first"))
    smoke.capture("z06c-diff-browsed-back")
    smoke.send("\x1b[6~" * 16)
    smoke.visible("HISTORY_FOLLOW_CONTROL")
    pending = {"sessionUpdate": "tool_call", "toolCallId": "owned-pending-write", "title": "fs_write", "kind": "edit", "status": "pending", "rawInput": {"path": "pending_display_only.rs"}, "content": [diff("pending_display_only.rs", "PENDING_OLD\n", "PENDING_NEW\n")]}
    smoke.control(updates=[pending])
    smoke.visible("pending_display_only.rs")
    permission = {"id": "owned-deny-only", "params": {"toolCall": {"toolCallId": "owned-pending-write", "title": "fs_write", "kind": "edit", "status": "pending"}, "options": [{"optionId": "deny", "name": "Reject", "kind": "reject_once"}]}}
    smoke.control(permission=permission)
    smoke.visible("PENDING_OLD", "PENDING_NEW")
    smoke.capture("z07-pending-comparison")
    smoke.resize(100, 32)
    smoke.visible("PENDING_OLD", "PENDING_NEW")
    smoke.capture("z08-pending-resized")
    smoke.send("\r")
    smoke.wait("Explicit rejection response", lambda: any(item.get("id") == "owned-deny-only" for item in smoke.peer_state().get("responses", [])))
    response = next(item for item in smoke.peer_state()["responses"] if item.get("id") == "owned-deny-only")
    smoke.check("only pending permission outcome is reject", response.get("result", {}).get("outcome") == {"outcome": "selected", "optionId": "deny"}, wire=response)
    smoke.resize(160, 48)
    smoke.command_input("/theme")
    smoke.send("cyril-dark")
    smoke.send("\r")
    smoke.control(updates=[chunk("WRITE_CHRONOLOGY_AFTER\n")], complete=True)
    smoke.visible("WRITE_CHRONOLOGY_AFTER")
    smoke.capture("z09-completed-and-rejected")

