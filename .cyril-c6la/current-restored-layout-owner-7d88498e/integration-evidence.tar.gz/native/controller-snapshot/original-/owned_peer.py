#!/usr/bin/env python3
"""Throwaway display-only ACP peer. Never invokes a model, tool, or host callback.
Reuses .cyril-1v25/smoke.py's V2 handshake and lki9's numbered control/ack pattern.
"""
import json
import os
from pathlib import Path
import select
import sys
import time

ROOT = Path(os.environ["CYRIL_PERF_SMOKE_ROOT"])
SID = "70000000-0000-4000-8000-000000000001"
sequence = 1
sessions = 0
prompt = None
pending = bytearray()
state = {"sessions": 0, "prompts": 0, "pending_prompt": False, "responses": []}


def record(direction, message):
    with (ROOT / "wire.jsonl").open("a") as stream:
        stream.write(json.dumps({"monotonic": time.monotonic(), "dir": direction, "msg": message}, ensure_ascii=False) + "\n")


def save_state():
    temporary = ROOT / "peer-state.tmp"
    temporary.write_text(json.dumps(state, indent=2))
    temporary.replace(ROOT / "peer-state.json")


def send(message):
    frame = {"jsonrpc": "2.0", **message}
    record("peer->cyril", frame)
    print(json.dumps(frame, ensure_ascii=False), flush=True)


def receive(frame):
    global SID, sessions, prompt
    record("cyril->peer", frame)
    method, ident = frame.get("method"), frame.get("id")
    if method == "initialize":
        send({"id": ident, "result": {"protocolVersion": 1, "agentCapabilities": {"loadSession": False}, "agentInfo": {"name": "owned-performance-display-peer", "version": "1"}, "authMethods": []}})
    elif method == "session/new":
        sessions += 1
        SID = f"70000000-0000-4000-8000-{sessions:012d}"
        state.update(sessions=sessions, session_id=SID)
        send({"id": ident, "result": {"sessionId": SID}})
    elif method == "session/prompt":
        if prompt is not None:
            raise RuntimeError("Concurrent prompt is not part of the smoke protocol")
        prompt = ident
        state.update(prompts=state["prompts"] + 1, pending_prompt=True)
    elif method == "session/cancel":
        if prompt is not None:
            send({"id": prompt, "result": {"stopReason": "cancelled"}})
            prompt = None
            state["pending_prompt"] = False
        if ident is not None:
            send({"id": ident, "result": {}})
    elif method and ident is not None:
        send({"id": ident, "error": {"code": -32601, "message": "Owned display fixture does not implement " + method}})
    elif ident is not None:
        state["responses"].append(frame)
    save_state()


def control(request):
    global prompt
    for update in request.get("updates", []):
        send({"method": "session/update", "params": {"sessionId": SID, "update": update}})
    for frame in request.get("frames", []):
        frame = json.loads(json.dumps(frame))
        if isinstance(frame.get("params"), dict) and frame["params"].get("sessionId") == "$MAIN":
            frame["params"]["sessionId"] = SID
        send(frame)
    if "permission" in request:
        send({"id": request["permission"]["id"], "method": "session/request_permission", "params": {"sessionId": SID, **request["permission"]["params"]}})
    if request.get("complete"):
        if prompt is None:
            raise RuntimeError("Completion requested without an actual Cyril session/prompt")
        send({"id": prompt, "result": {"stopReason": "end_turn"}})
        prompt = None
        state["pending_prompt"] = False
    save_state()


save_state()
while True:
    ready, _, _ = select.select([sys.stdin], [], [], 0.02)
    if ready:
        chunk = os.read(sys.stdin.fileno(), 65536)
        if not chunk:
            break
        pending.extend(chunk)
        while b"\n" in pending:
            line, _, rest = pending.partition(b"\n")
            pending = bytearray(rest)
            if line.strip():
                receive(json.loads(line))
    command = ROOT / f"control-{sequence:04d}.json"
    if sessions and command.exists():
        request = json.loads(command.read_text())
        try:
            control(request)
            acknowledgement = {"sequence": sequence, "ok": True, "monotonic": time.monotonic()}
        except Exception as error:
            acknowledgement = {"sequence": sequence, "ok": False, "error": repr(error)}
        (ROOT / f"ack-{sequence:04d}.json").write_text(json.dumps(acknowledgement))
        sequence += 1
