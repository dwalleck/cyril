"""Curate run evidence into a ticket: gzip every selected file, hash raw and gzip bytes,
write a manifest, then validate the destination against it.

The destination directory must not exist (a curation is never re-run in place;
make a new one). Runtime trees, home/config caches and credential-shaped files
are never selected. Gzip uses mtime=0 so the same input gives the same bytes.
"""
from __future__ import annotations

import datetime
import fnmatch
import gzip
from pathlib import Path, PurePosixPath

from .evidence import sha256_bytes, write_new, write_new_json
from .manifest import validate_manifest

SCHEMA = 'nativeq.curated/1'
# Directory names never curated: staged runtimes, private home/config, build output.
EXCLUDED_DIRS = frozenset({'app', 'tools', 'mcp', 'tool-bundle', 'mcp-bundle', 'home', 'config',
                           '__pycache__', 'bin', 'obj', 'scratch'})
# File names that can hold credentials or session secrets.
CREDENTIAL_GLOBS = ('xauth', '.Xauthority', '*.pem', '*.key', '*.pfx', '*.p12', 'id_rsa*', 'id_ed25519*',
                    'id_ecdsa*', '.netrc', '*credential*', '*secret*', '*.kdbx', 'known_hosts')


def is_credential(name: str) -> bool:
    lowered = name.lower()
    return any(fnmatch.fnmatchcase(lowered, pattern.lower()) for pattern in CREDENTIAL_GLOBS)


def select(sources: dict[str, Path]) -> tuple[dict[str, Path], list[dict]]:
    """Expand `label -> file or directory` into `relative name -> file`, recording what was skipped."""
    selected, skipped = {}, []
    for label, source in sources.items():
        source = Path(source)
        if source.is_file():
            candidates = [(PurePosixPath(label), source, ())]
        elif source.is_dir():
            candidates = [(PurePosixPath(label) / p.relative_to(source).as_posix(), p, p.relative_to(source).parts)
                          for p in sorted(source.rglob('*'))]
        else:
            raise FileNotFoundError(source)
        for rel, path, parts in candidates:
            if path.is_symlink():
                skipped.append({'path': rel.as_posix(), 'reason': 'symlink'})
            elif not path.is_file():
                continue
            elif any(part in EXCLUDED_DIRS for part in parts[:-1]):
                continue
            elif is_credential(path.name):
                skipped.append({'path': rel.as_posix(), 'reason': 'credential-shaped name'})
            else:
                selected[rel.as_posix()] = path
    return selected, skipped


def curate(sources: dict[str, Path], destination: Path, *, note: str | None = None) -> dict:
    selected, skipped = select(sources)
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=False)
    rows = []
    for rel, path in sorted(selected.items()):
        raw = path.read_bytes()
        packed = gzip.compress(raw, compresslevel=9, mtime=0)
        target = destination / 'files' / (rel + '.gz')
        target.parent.mkdir(parents=True, exist_ok=True)
        write_new(target, packed)
        if gzip.decompress(target.read_bytes()) != raw:
            raise RuntimeError(f'Curated copy does not reconstruct: {rel}')
        rows.append({'source': str(path), 'path': target.relative_to(destination).as_posix(),
                     'encoding': 'gzip', 'bytes': len(packed), 'sha256': sha256_bytes(packed),
                     'rawBytes': len(raw), 'rawSha256': sha256_bytes(raw)})
    manifest = {'schema': SCHEMA, 'created': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'note': note, 'sources': {k: str(v) for k, v in sources.items()},
                'excludedDirectories': sorted(EXCLUDED_DIRS), 'credentialGlobs': list(CREDENTIAL_GLOBS),
                'skipped': skipped, 'files': rows,
                'rawBytes': sum(r['rawBytes'] for r in rows), 'gzipBytes': sum(r['bytes'] for r in rows)}
    write_new_json(destination / 'manifest.json', manifest)
    report = validate_manifest(destination, destination / 'manifest.json', strict=True)
    if not report['ok']:
        raise RuntimeError(f'Curated destination failed validation: {report}')
    return {'destination': str(destination), 'files': len(rows), 'skipped': len(skipped),
            'rawBytes': manifest['rawBytes'], 'gzipBytes': manifest['gzipBytes']}
