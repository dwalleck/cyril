"""App environment rules shared by both hosts.

A run may set HEX1B_*/JANET_* variables and one .NET variable, DOTNET_PROCESSOR_COUNT (a positive integer up to
4 digits, no leading zero). .NET sizes Environment.ProcessorCount, and with it the thread pool, from that variable,
so a run can emulate a small machine (for example a 2-CPU thread pool on the 8-CPU VM). No other DOTNET_* variable
is allowed. `windows/NativeSession.ps1` (ConvertTo-NqLaunchEnvironment) applies the Windows rules on the host.

Values: on Windows each variable becomes a `set "NAME=VALUE"` line of `launch.cmd`, so a value may not contain a
character cmd.exe would act on there (`"`, `&`, `|`, `<`, `>`, `%`, `^`, a line break). On Linux the variables reach
the app through `env NAME=VALUE` arguments, with no shell in between, so any value is passed as given (only NUL,
which no argument can carry, is refused); ticket 16's JSON-array `JANET_EDITOR_ARGUMENTS` works there.
"""
from __future__ import annotations

import re

from .refusal import CallRefused

PROCESSOR_COUNT = 'DOTNET_PROCESSOR_COUNT'
NAME = re.compile(r'^(HEX1B_|JANET_)[A-Z0-9_]+$')
UNSAFE_VALUE = {'windows': re.compile(r'[\r\n"&|<>%^]'), 'linux': re.compile(r'\x00')}
COUNT = re.compile(r'^[1-9][0-9]{0,3}$')
# Set by the runner on both hosts; from the app env it would move the Flow log the fault check reads.
RESERVED = ('HEX1B_FLOW_COMMIT_EVENTS',)
# Follow-up 05: the console opens its Hex1b diagnostics socket only under JANET_DIAGNOSTICS=1, and every run's CLI calls
# (app frames, terminal geometry, resize) need it. The runner sets it on both hosts (`launch`, and
# ConvertTo-NqLaunchEnvironment on Windows); the app env may repeat that value but not change it.
DIAGNOSTICS, DIAGNOSTICS_ON = 'JANET_DIAGNOSTICS', '1'


class EnvRefused(CallRefused):
    """An app environment variable a run may not set; the message names it."""


def check(env: dict[str, str], host: str = 'windows') -> dict[str, str]:
    """Return `env` unchanged, or raise EnvRefused naming the first variable that is not allowed on `host`
    ('windows' or 'linux')."""
    unsafe = UNSAFE_VALUE[host]
    for name, value in env.items():
        value = str(value)
        if name == PROCESSOR_COUNT:
            if not COUNT.fullmatch(value):
                raise EnvRefused(f'{PROCESSOR_COUNT} must be a positive integer of at most 4 digits: {value!r}')
        elif name in RESERVED:
            raise EnvRefused(f'App environment variable {name} is set by the runner (the Flow log the fault check reads); '
                             'a run may not set it')
        elif name == DIAGNOSTICS and value != DIAGNOSTICS_ON:
            raise EnvRefused(f'App environment variable {DIAGNOSTICS} is set to {DIAGNOSTICS_ON} by the runner (its CLI '
                             f'calls need the app\'s diagnostics socket); a run may not set it to {value!r}')
        elif not NAME.fullmatch(name):
            raise EnvRefused(f'App environment variable {name!r}: names must start with JANET_ (or HEX1B_) and use '
                             f'only A-Z, 0-9 and _; the one .NET variable allowed is {PROCESSOR_COUNT}')
        elif found := unsafe.search(value):
            where = ('launch.cmd (cmd.exe `set`) cannot carry it; pass such a value through a file the app reads'
                     if host == 'windows' else 'no argument can carry it')
            raise EnvRefused(f'App environment variable {name}: its value contains {found.group()!r}, and {where}')
    return env


def launch(env: dict[str, str]) -> dict[str, str]:
    """The variables the app is launched with: the runner's diagnostics switch, then the checked app env."""
    return {DIAGNOSTICS: DIAGNOSTICS_ON, **{name: value for name, value in env.items() if name != DIAGNOSTICS}}


def processors(env: dict[str, str], host_count: int | None) -> dict:
    """What the app's Environment.ProcessorCount is, as far as the controller knows: the override when set,
    else the host's count. The app does not report it itself (`appReported` false)."""
    override = int(env[PROCESSOR_COUNT]) if PROCESSOR_COUNT in env else None
    return {'hostProcessorCount': host_count, 'dotnetProcessorCount': override,
            'effective': override if override is not None else host_count,
            'effectiveSource': PROCESSOR_COUNT if override is not None else 'host', 'appReported': False}
