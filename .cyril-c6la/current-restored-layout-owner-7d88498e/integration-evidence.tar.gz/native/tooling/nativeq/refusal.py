"""Refusals at the call: a mistake in the arguments is refused before any run directory, display or host connection
exists. The command line prints `nativeq: refused: <message>` on stderr and exits 2 (`nativeq/__main__.py`)."""
from __future__ import annotations

from pathlib import Path


class CallRefused(ValueError):
    """An argument the call cannot use; the message names the argument."""


def existing(path, what: str, *, kind: str = 'any') -> Path:
    """`path` made absolute (against the current directory), or refused when nothing of `kind` ('file', 'dir' or
    'any') is there. The message gives the resolved path, so a path resolved under the wrong directory shows."""
    resolved = Path(path).expanduser().absolute()
    present = {'file': resolved.is_file, 'dir': resolved.is_dir, 'any': resolved.exists}[kind]()
    if not present:
        noun = {'file': 'file', 'dir': 'directory', 'any': 'path'}[kind]
        raise CallRefused(f'{what}: no {noun} at {resolved}' + (f' (given as {path})' if str(path) != str(resolved)
                                                                 else ''))
    return resolved


def fresh(path, what: str) -> Path:
    """An output path made absolute, refused when something is already there (each run directory is used once)."""
    resolved = Path(path).expanduser().absolute()
    if resolved.exists():
        raise CallRefused(f'{what}: {resolved} already exists; each run directory is used once')
    if not resolved.parent.is_dir():
        raise CallRefused(f'{what}: the parent directory {resolved.parent} does not exist')
    return resolved
