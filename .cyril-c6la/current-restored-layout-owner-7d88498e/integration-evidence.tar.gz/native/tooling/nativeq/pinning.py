"""Pin a native run's runtime components and compare a destination against the pin.

A pinned manifest names every component a run stages (by default `app`, `tools`
and `mcp`, plus the `control` files: runner, module, scenario, app environment)
and the SHA-256 of every file in each one. `compare` checks a destination
listing against that pin. A component with no files at the destination,
a missing file, an unexpected file or a hash mismatch all fail it; there is no
"reused, so assume it is there" path.
"""
from __future__ import annotations

import fnmatch
import json
from pathlib import Path, PurePosixPath

from .evidence import sha256_file

SCHEMA = 'nativeq.pinned/1'
REQUIRED = ('app', 'tools', 'mcp')
# Runtime identifiers each platform loads from `runtimes/<rid>/`; other RIDs are not staged.
PLATFORM_RIDS = {
    'win-x64': ('win', 'win-x64'),
    'linux-x64': ('unix', 'linux', 'linux-x64'),
}
# Native symbol files are never loaded and are 100+ MB per RID (SkiaSharp).
DEFAULT_EXCLUDES = ('runtimes/*/native/*.pdb',)
SHARED_LIBRARY = 'Hex1b.dll'


class PinError(ValueError):
    pass


def select_files(root: Path, platform: str, excludes=DEFAULT_EXCLUDES) -> dict[str, Path]:
    """Files a component stages: everything except foreign-RID runtime assets and excluded globs."""
    root = Path(root)
    if platform not in PLATFORM_RIDS:
        raise PinError(f'Unknown platform {platform!r}')
    if not root.is_dir():
        raise PinError(f'Component directory missing: {root}')
    rids = PLATFORM_RIDS[platform]
    selected = {}
    for path in sorted(root.rglob('*')):
        rel = path.relative_to(root).as_posix()
        if path.is_symlink():
            raise PinError(f'Symlink in component (stage real files only): {path}')
        if not path.is_file():
            continue
        parts = PurePosixPath(rel).parts
        if len(parts) > 2 and parts[0] == 'runtimes' and parts[1] not in rids:
            continue
        if any(fnmatch.fnmatchcase(rel, pattern) for pattern in excludes):
            continue
        selected[rel] = path
    return selected


def pin(components: dict[str, Path], platform: str, *, required=REQUIRED, excludes=DEFAULT_EXCLUDES,
        control: dict[str, Path] | None = None, shared_library: str | None = SHARED_LIBRARY,
        app_name: str | None = None) -> dict:
    """Return a pinned manifest. Raises PinError when a required component is absent or empty,
    or when components carry different copies of the shared framework library."""
    for name in required:
        if name not in components or components[name] is None:
            raise PinError(f'Required component not supplied: {name}')
    pinned = {'schema': SCHEMA, 'platform': platform, 'excludes': list(excludes), 'components': {}}
    for name, root in components.items():
        if root is None:
            continue
        files = select_files(Path(root), platform, excludes)
        if not files:
            raise PinError(f'Component {name} has no files to stage: {root}')
        pinned['components'][name] = {
            'source': str(Path(root).resolve()),
            'files': {rel: {'sha256': sha256_file(p), 'bytes': p.stat().st_size} for rel, p in files.items()},
        }
    if control:
        files = {}
        for rel, path in control.items():
            path = Path(path)
            if not path.is_file():
                raise PinError(f'Control file missing: {path}')
            files[rel] = {'sha256': sha256_file(path), 'bytes': path.stat().st_size, 'source': str(path.resolve())}
        pinned['components']['control'] = {'source': None, 'files': files}
    if app_name:
        if app_name not in pinned['components'].get('app', {}).get('files', {}):
            raise PinError(f'App entry point {app_name} is not in the app component')
        pinned['appName'] = app_name
    if shared_library:
        hashes = {name: c['files'][shared_library]['sha256'] for name, c in pinned['components'].items()
                  if shared_library in c['files']}
        if 'app' in pinned['components'] and 'app' not in hashes:
            raise PinError(f'App component has no {shared_library}')
        if len(set(hashes.values())) > 1:
            raise PinError(f'Components load different {shared_library}: {hashes}')
        pinned['sharedLibrary'] = {'name': shared_library, 'sha256': next(iter(hashes.values()), None),
                                   'components': sorted(hashes)}
    return pinned


def flatten(pinned: dict) -> dict[str, str]:
    """`component/relative/path` -> sha256 for every pinned file."""
    return {f'{name}/{rel}': meta['sha256'] for name, component in pinned['components'].items()
            for rel, meta in component['files'].items()}


def bundle_sources(pinned: dict) -> dict[str, Path]:
    """`component/relative/path` -> local source path, for building an upload bundle."""
    out = {}
    for name, component in pinned['components'].items():
        for rel, meta in component['files'].items():
            out[f'{name}/{rel}'] = Path(meta['source']) if 'source' in meta else Path(component['source']) / rel
    return out


def verify_sources(pinned: dict) -> dict:
    """Re-hash the local sources; a source changed since pinning must not be staged."""
    expected = flatten(pinned)
    observed = {}
    for key, path in bundle_sources(pinned).items():
        observed[key] = sha256_file(path) if path.is_file() else None
    return compare(pinned, {k: v for k, v in observed.items() if v is not None})


def compare(pinned: dict, observed: dict[str, str], *, ignore=()) -> dict:
    """Compare a destination listing (`component/rel` -> sha256) with the pin."""
    expected = flatten(pinned)
    observed = {k.replace('\\', '/'): v.lower() for k, v in observed.items()
                if not any(fnmatch.fnmatchcase(k, pattern) for pattern in ignore)}
    missing = sorted(set(expected) - set(observed))
    unexpected = sorted(set(observed) - set(expected))
    mismatched = sorted(k for k in set(expected) & set(observed) if expected[k] != observed[k])
    counts = {}
    for name, component in pinned['components'].items():
        counts[name] = {'expected': len(component['files']),
                        'observed': sum(1 for k in observed if k.startswith(name + '/'))}
    missing_components = sorted(name for name, c in counts.items() if c['expected'] and not c['observed'])
    ok = not (missing or unexpected or mismatched)
    return {'ok': ok, 'missingComponents': missing_components, 'missing': missing,
            'unexpected': unexpected, 'mismatched': mismatched, 'componentCounts': counts}


def from_build_stage(stage: Path) -> dict[str, Path]:
    """Use a `tools/hex1b-diagnostics/build-stage.py` output as the tools/mcp source.

    Re-hashes every file that stage's manifest lists and returns `{'tools': cli, 'mcp': mcp}`.
    """
    stage = Path(stage)
    manifest = json.loads((stage / 'manifest.json').read_text())
    changed = [rel for rel, sha in manifest['files'].items()
               if not (stage / rel).is_file() or sha256_file(stage / rel) != sha]
    if changed:
        raise PinError(f'Build stage {stage} differs from its manifest: {changed[:5]}')
    return {'tools': stage / 'cli', 'mcp': stage / 'mcp'}
