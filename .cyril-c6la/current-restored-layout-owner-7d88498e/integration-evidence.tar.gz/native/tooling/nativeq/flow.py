"""Flow event health: the fault-word check every run applies to `flow.jsonl`, and the opt-in expected fault.

A line is a fault line when it contains one of FAULT_WORDS (case-insensitive) outside a commit unit's
record key. The framework logs each committed unit as `commit N unit M key=<unit key> rows=...`, and the
key is an application-chosen record name (`restored/answer-…/context/cancelled`), not an event, so the
value of every `key=` token is replaced by `<unit-key>` before the word match. Real fault forms keep their
word outside the key (`commit N fault after unit M: ...`, `suspended IOException: ...`,
`recovery-reanchor reason=fault`, `drain-timeout`). Without an expectation, any fault line fails the run,
as before. With an expected-fault regex:

- fault lines the regex matches (`re.search`) are recorded as expected evidence;
- the run fails unless at least one such line exists (an injection that never fired cannot pass);
- any other fault line still fails the run.

A line the regex matches but that carries no fault word (outside a unit key) is not a fault and is never
counted as one, expected or unexpected. The regex itself still searches the whole, unmodified line.

One fault line is recovered rather than a fault: Flow delivery recovery. When the native presentation refuses a
history batch because its geometry changed, Flow restores its checkpoint, logs `commit C delivery-refused unit=U
attempt=N expected=WxH` and recomposes the same unit (hex1b docs/terminal.md:468-469, FlowCommitCoordinator.cs:612-633;
its fence ContinuousHistoryRetentionFenceTests.RefusedBatch_IsRecomposedAndEveryPayloadKeySurvivesExactlyOnce requires
that line and no failure). Such a line (nothing else in its detail, attempt below the framework's limit of 8, which
throws an IOException instead of logging) counts as recovered only when commit C has exactly one `start units=K` line
before it and a later `commit C emission-ack units=K` line: the commit then delivered every unit. The unit's
`commit C unit U key=` line is no proof, because it is logged at composition, before submission. A refusal without
that ack (the commit never finished, or the app exited) is a fault as before, and so is every other fault line.
Recovered lines are reported (`recovered`), never dropped. A line the expected-fault regex matches is expected
evidence first, recovered or not.
Windows applies the same rules in `windows/NativeSession.ps1` (`Test-NqFlowEvents`), with .NET regex
semantics, so keep expected-fault patterns to the subset both engines share.
"""
from __future__ import annotations

import json
import re

from .refusal import CallRefused

FAULT_WORDS = ('suspend', 'fault', 'exception', 'failed', 'cancelled', 'stopped-commit', 'drain-timeout',
               'delivery-refused')
EXPECTATION_SCHEMA = 'nativeq.flow-expectation/1'
# The value of a `key=` token. Unit keys may contain spaces (`key=SESSION beta TARGET main rows=1 ...`),
# so the value runs up to the ` rows=<n>` that follows it in the unit line, without leaving the JSON
# `detail` string; with no such marker, up to whitespace or the closing quote. Every `key=` line in the
# 486 distinct Flow logs on hand (137,336 lines) is `commit N unit M key=<key> rows=N at=N width=N`.
# NativeSession.ps1 uses the same pattern and placeholder.
UNIT_KEY = re.compile(r'\bkey=(?:[^"]*?(?= rows=\d)|[^\s"]+)')
UNIT_KEY_PLACEHOLDER = 'key=<unit-key>'
# Flow delivery recovery (see the module docstring); NativeSession.ps1 uses the same three patterns. Each is anchored on
# the framework's own record prefix (Hex1bFlowRunner writes every Flow event as kind commit, source hex1b), so a line of
# another kind or source is never recovered. ASCII digits only, and counts of at most 9 digits, so both hosts parse the
# same numbers (PowerShell's [long] cast would throw on a Unicode digit or an overlong count; such lines do not match).
_RECORD = r'"kind":"commit","source":"hex1b","detail":"commit ([0-9]+) '
REFUSAL = re.compile(_RECORD + r'delivery-refused unit=[0-9]+ attempt=([0-9]{1,9}) expected=[0-9]+x[0-9]+"')
START = re.compile(_RECORD + r'start units=([0-9]{1,9}) ')
ACK = re.compile(_RECORD + r'emission-ack units=([0-9]{1,9}) ')
# FlowCommitCoordinator.MaxDeliveryRejectionsPerUnit is 8, and the 8th refusal throws before it is logged.
MAX_RECOVERED_ATTEMPT = 7


def check_pattern(pattern: str | None) -> str | None:
    """None (no expectation) or a non-empty, compilable regex."""
    if pattern is None:
        return None
    if not isinstance(pattern, str) or not pattern or '\n' in pattern or '\r' in pattern:
        raise CallRefused(f'--expect-flow-fault must be a non-empty single-line regex: {pattern!r}')
    try:
        re.compile(pattern)
    except re.error as error:
        raise CallRefused(f'--expect-flow-fault {pattern!r} does not compile: {error}') from error
    return pattern


def expectation_document(pattern: str | None) -> dict:
    """The staged control value (`control/flow-expectation.json` on Windows)."""
    return {'schema': EXPECTATION_SCHEMA, 'expectedFault': check_pattern(pattern)}


def expectation_bytes(pattern: str | None) -> bytes:
    return (json.dumps(expectation_document(pattern), indent=2, sort_keys=True) + '\n').encode()


def fault_text(line: str) -> str:
    """The line as the fault-word match sees it: every unit-key value replaced by a placeholder."""
    return UNIT_KEY.sub(UNIT_KEY_PLACEHOLDER, line)


def is_fault(line: str) -> bool:
    lowered = fault_text(line).lower()
    return any(word in lowered for word in FAULT_WORDS)


def recovered_refusals(lines: list[str]) -> set[int]:
    """Indexes of the `delivery-refused` lines whose commit later acknowledged all its units."""
    starts, acks = {}, {}
    for index, line in enumerate(lines):
        for regex, table in ((START, starts), (ACK, acks)):
            match = regex.search(line)
            if match:
                table.setdefault(match.group(1), []).append((index, int(match.group(2))))
    recovered = set()
    for index, line in enumerate(lines):
        match = REFUSAL.search(line)
        if not match or int(match.group(2)) > MAX_RECOVERED_ATTEMPT:
            continue
        commit_starts = starts.get(match.group(1), [])
        if len(commit_starts) != 1 or commit_starts[0][0] > index:
            continue
        units = commit_starts[0][1]
        if any(at > index and acked == units for at, acked in acks.get(match.group(1), [])):
            recovered.add(index)
    return recovered


def classify(lines, pattern: str | None) -> dict:
    """Report on flow lines: expected, recovered and unexpected fault lines, and whether the run is healthy."""
    checked = check_pattern(pattern)
    regex = re.compile(checked) if checked is not None else None
    lines = [line.rstrip('\r\n') for line in lines]
    recoveries = recovered_refusals(lines)
    expected, recovered, unexpected = [], [], []
    for index, line in enumerate(lines):
        if not line.strip() or not is_fault(line):
            continue
        if regex and regex.search(line):
            expected.append(line)
        elif index in recoveries:
            recovered.append(line)
        else:
            unexpected.append(line)
    missing = regex is not None and not expected
    return {'expectedFault': pattern, 'expected': expected, 'recovered': recovered, 'unexpected': unexpected,
            'expectedMissing': missing, 'ok': not unexpected and not missing}


def failure_message(report: dict) -> str:
    if report['unexpected']:
        return 'Unexpected Flow suspension/fault'
    return 'Expected Flow fault did not occur: ' + repr(report['expectedFault'])
