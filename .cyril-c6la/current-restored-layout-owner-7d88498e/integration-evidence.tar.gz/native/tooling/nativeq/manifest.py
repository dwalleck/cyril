"""Validate a manifest against retained artifacts: path, size and hash for every entry, plus orphans.

Accepts an evidence ledger (`evidence.jsonl`, one entry per line) or a JSON
manifest whose `files` list holds entries. Each entry needs `path` (relative to
the root) and `sha256` of the stored file; `bytes`, and for gzip entries
`rawSha256`/`rawBytes`, are checked when present. The result fails on any
missing file, mismatch, duplicated path or invalid entry. Orphans (files under
the root that no entry names) are always reported and fail only with `strict`.
"""
from __future__ import annotations

import fnmatch
import gzip
import hashlib
import json
import os
from pathlib import Path, PurePosixPath

from .evidence import read_ledger, sha256_file


def _legacy(entry):
    """Pre-nativeq Windows export ledgers (`native-export-manifest.jsonl`) name the file `gzip`."""
    if isinstance(entry, dict) and 'path' not in entry and 'gzip' in entry and 'gzipSha256' in entry:
        return dict(entry, path=entry['gzip'], sha256=entry['gzipSha256'], encoding='gzip')
    return entry


def load_entries(manifest: Path) -> list[dict]:
    manifest = Path(manifest)
    if manifest.suffix == '.jsonl':
        return [_legacy(entry) for entry in read_ledger(manifest)]
    value = json.loads(manifest.read_text(encoding='utf-8'))
    if isinstance(value, dict) and isinstance(value.get('files'), list):
        return value['files']
    if isinstance(value, list):
        return value
    raise ValueError(f'{manifest}: expected a ledger, a list, or an object with a files list')


def _relative(path: str) -> str | None:
    pure = PurePosixPath(path.replace('\\', '/'))
    if pure.is_absolute() or not pure.parts or '..' in pure.parts:
        return None
    return pure.as_posix()


def _ignored(rel: str, patterns) -> bool:
    # fnmatch's `*` also crosses `/`, so `scratch/*` covers the whole scratch tree.
    return any(fnmatch.fnmatchcase(rel, pattern) for pattern in patterns)


def _files(root: Path):
    for directory, dirs, files in os.walk(root, followlinks=False):
        here = Path(directory)
        for name in files + [d for d in dirs if (here / d).is_symlink()]:
            yield (here / name).relative_to(root).as_posix()


def validate(root: Path, entries: list[dict], *, ignore=(), exclude_paths=(), strict: bool = False) -> dict:
    root = Path(root)
    missing, mismatched, invalid, duplicates, matched = [], [], [], [], []
    seen: dict[str, int] = {}
    for index, entry in enumerate(entries):
        rel = _relative(str(entry.get('path', ''))) if isinstance(entry, dict) else None
        if rel is None or not isinstance(entry.get('sha256'), str):
            invalid.append({'index': index, 'entry': entry})
            continue
        if rel in seen:
            duplicates.append({'index': index, 'path': rel, 'firstIndex': seen[rel]})
            continue
        seen[rel] = index
        target = root / rel
        if target.is_symlink():
            mismatched.append({'index': index, 'path': rel, 'reason': 'symlink'})
            continue
        if not target.is_file():
            missing.append({'index': index, 'path': rel, 'id': entry.get('id')})
            continue
        problems = {}
        actual = sha256_file(target)
        if actual != entry['sha256'].lower():
            problems['sha256'] = {'expected': entry['sha256'], 'actual': actual}
        size = target.stat().st_size
        if 'bytes' in entry and entry['bytes'] != size:
            problems['bytes'] = {'expected': entry['bytes'], 'actual': size}
        if not problems and entry.get('encoding') == 'gzip':
            try:
                raw = gzip.decompress(target.read_bytes())
            except (OSError, EOFError) as error:
                problems['gzip'] = repr(error)
            else:
                if entry.get('rawSha256') and hashlib.sha256(raw).hexdigest() != entry['rawSha256']:
                    problems['rawSha256'] = {'expected': entry['rawSha256'], 'actual': hashlib.sha256(raw).hexdigest()}
                if 'rawBytes' in entry and entry['rawBytes'] != len(raw):
                    problems['rawBytes'] = {'expected': entry['rawBytes'], 'actual': len(raw)}
        if problems:
            mismatched.append({'index': index, 'path': rel, 'id': entry.get('id'), **problems})
        else:
            matched.append(index)
    excluded = {Path(p).as_posix() for p in exclude_paths}
    orphans = sorted(rel for rel in _files(root)
                     if rel not in seen and rel not in excluded and not _ignored(rel, ignore))
    ok = not (missing or mismatched or invalid or duplicates) and (not strict or not orphans)
    return {'ok': ok, 'root': str(root), 'entries': len(entries), 'matched': len(matched),
            'missing': missing, 'mismatched': mismatched, 'duplicates': duplicates,
            'invalid': invalid, 'orphans': orphans, 'strict': strict, 'ignore': list(ignore)}


def validate_manifest(root: Path, manifest: Path | None = None, **options) -> dict:
    root = Path(root)
    manifest = Path(manifest) if manifest else root / 'evidence.jsonl'
    exclude = list(options.pop('exclude_paths', ()))
    try:
        exclude.append(manifest.resolve().relative_to(root.resolve()).as_posix())
    except ValueError:
        pass
    report = validate(root, load_entries(manifest), exclude_paths=exclude, **options)
    report['manifest'] = str(manifest)
    return report
