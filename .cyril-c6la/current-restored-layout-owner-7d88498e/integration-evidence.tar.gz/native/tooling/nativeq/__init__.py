"""Shared native-qualification tooling: evidence, manifests, pinning, host runs."""
