"""Evidence that is written exactly once.

Every capture, AppFrame export or record gets a run-unique ID (`<seq>-<label>`)
and is written with exclusive create (O_CREAT|O_EXCL), so a reused name fails
loudly instead of replacing an earlier file. Each write appends one line to the
run's ledger (`evidence.jsonl`) with the stored file's SHA-256 and, for gzip
entries, the raw bytes' SHA-256. `nativeq.manifest` validates a ledger against
the retained files. The Windows module (`windows/NativeSession.ps1`) writes the
same ledger schema with `FileMode.CreateNew`.
"""
from __future__ import annotations

import datetime
import gzip
import hashlib
import json
import os
import re
import threading
from pathlib import Path

LEDGER = 'evidence.jsonl'
SCHEMA = 'nativeq.evidence/1'
_UNSAFE = re.compile(r'[^A-Za-z0-9._-]+')


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, 'rb') as handle:
        for block in iter(lambda: handle.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def write_new(path: Path, data: bytes) -> None:
    """Create `path` and write `data`; raise FileExistsError if anything is already there."""
    with open(path, 'xb') as handle:  # 'x' = O_CREAT|O_EXCL; a dangling symlink also refuses.
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())


def write_new_json(path: Path, value) -> None:
    write_new(Path(path), (json.dumps(value, indent=2, sort_keys=True) + '\n').encode())


def clean_label(label: str) -> str:
    text = _UNSAFE.sub('-', label).strip('-.')
    if not text:
        raise ValueError('Empty evidence label')
    return text[:80]


def read_ledger(path: Path) -> list[dict]:
    rows = []
    for number, line in enumerate(Path(path).read_text(encoding='utf-8').splitlines(), 1):
        if line.strip():
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as error:
                raise ValueError(f'{path}:{number}: invalid ledger line') from error
    return rows


class EvidenceStore:
    """Allocates unique IDs and writes evidence files exclusively under one run directory."""

    def __init__(self, root: Path, run: str | None = None):
        self.root = Path(root)
        if not self.root.is_dir():
            raise FileNotFoundError(self.root)
        self.run = run
        self.ledger = self.root / LEDGER
        existing = read_ledger(self.ledger) if self.ledger.exists() else []
        self._seq = max((int(row.get('seq', 0)) for row in existing), default=0)
        self._lock = threading.Lock()

    def _allocate(self, label: str, suffix: str) -> tuple[str, int, Path]:
        with self._lock:
            self._seq += 1
            seq = self._seq
        ident = f'{seq:05d}-{clean_label(label)}'
        return ident, seq, self.root / (ident + suffix)

    def _record(self, entry: dict) -> dict:
        line = json.dumps(entry, sort_keys=True, separators=(',', ':')) + '\n'
        with self._lock, open(self.ledger, 'a', encoding='utf-8') as handle:
            handle.write(line)
            handle.flush()
            os.fsync(handle.fileno())
        return entry

    def _entry(self, ident, seq, label, kind, path, stored: bytes, raw: bytes, encoding):
        entry = {
            'schema': SCHEMA, 'seq': seq, 'id': ident, 'label': label, 'kind': kind,
            'path': path.relative_to(self.root).as_posix(), 'bytes': len(stored),
            'sha256': sha256_bytes(stored), 'encoding': encoding,
            'rawBytes': len(raw), 'rawSha256': sha256_bytes(raw),
            'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        }
        if self.run:
            entry['run'] = self.run
        return entry

    def put_bytes(self, label: str, raw: bytes, *, kind: str, suffix: str, compress: bool = False,
                  meta: dict | None = None) -> dict:
        """`meta` adds descriptive keys to the ledger entry (for example a capture's `export` region); it may not
        replace any of the entry's own keys."""
        clash = set(meta or ()) & {'schema', 'seq', 'id', 'label', 'kind', 'path', 'bytes', 'sha256', 'encoding',
                                   'rawBytes', 'rawSha256', 'utc', 'run'}
        if clash:
            raise ValueError(f'Evidence metadata may not replace {sorted(clash)}')
        if compress:
            suffix += '.gz'
        ident, seq, path = self._allocate(label, suffix)
        stored = gzip.compress(raw, compresslevel=9, mtime=0) if compress else raw
        write_new(path, stored)
        entry = self._entry(ident, seq, label, kind, path, stored, raw, 'gzip' if compress else 'identity')
        entry.update(meta or {})
        return self._record(entry)

    def put_text(self, label: str, text: str, *, kind: str = 'capture', compress: bool = True) -> dict:
        return self.put_bytes(label, text.encode('utf-8'), kind=kind, suffix='.txt', compress=compress)

    def put_json(self, label: str, value, *, kind: str = 'app-frame') -> dict:
        raw = value if isinstance(value, (bytes, str)) else json.dumps(value, indent=2, sort_keys=True) + '\n'
        return self.put_bytes(label, raw.encode('utf-8') if isinstance(raw, str) else raw,
                              kind=kind, suffix='.json')

    def entries(self) -> list[dict]:
        return read_ledger(self.ledger) if self.ledger.exists() else []
