"""Ghostty text exports: one request, one uniquely identified fresh file, no ambiguity.

Pinned to Ghostty 1.3.1 (`src/Surface.zig` `writeScreenFile`, `src/terminal/formatter.zig`):

- Each `write_*_file` action creates a new temporary directory under `TMPDIR` and writes one file named after its
  region, `screen.txt` (`write_screen_file`) or `history.txt` (`write_scrollback_file`), then copies the path.
- `screen.txt` is **not** the visible screen. It is the whole scrollback followed by the active area (the bottom
  grid rows): Ghostty's `.screen` point region. `history.txt` is the scrollback alone (`.history`, the rows above
  the active area). Ghostty 1.3.1 has no action that exports the visible rows alone.
- Both are formatted with `unwrap = true` (a soft-wrapped row and its continuation are one line) and trailing blank
  rows always trimmed, so export lines are not grid rows.
- When there is no scrollback (or the alternate screen is active) `write_scrollback_file` writes nothing at all.
- A surface handles key bindings one at a time and writes the file before it handles the next key, so a file
  produced by a later key in the same request proves every earlier key's file has already been written (or never
  will be). `GhosttyExports` uses a `screen.txt` export, which always writes, as that barrier.

`GhosttyExports.request` presses the keys exactly once (no retry: a retried key whose first press is merely slow
writes a second file later, which a later capture would then read as its own), waits for the barrier file, and
claims only files that are new, named for a requested region, created after the request, complete, and alone in
their own new directory. Anything else (an unclaimed file left from earlier, a duplicate, an unrequested region, a
file older than the request) refuses the capture instead of guessing.
"""
from __future__ import annotations

import os
import re
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

# Ghostty version whose export semantics (above) nativeq was checked against. A different version refuses to run
# until those semantics are re-checked and this pin is moved.
GHOSTTY_EXPORT_VERSION = '1.3.1'

REGIONS = {
    'screen': {'action': 'write_screen_file', 'key': 'ctrl+alt+s', 'file': 'screen.txt', 'region': 'history+active'},
    'history': {'action': 'write_scrollback_file', 'key': 'ctrl+alt+e', 'file': 'history.txt', 'region': 'history'},
}
EXPORT_SEMANTICS = {'unwrapped': True, 'trailingBlankRowsTrimmed': True, 'visibleScreenOnly': False,
                    'emptyHistoryWritesNoFile': True}
# Every file name a Ghostty 1.3.1 write_*_file action can produce. `exports/` is also the app's TMPDIR, so other
# entries there (the runtime's clr-debug-pipe FIFOs, for example) are not exports and are ignored.
EXPORT_NAMES = frozenset(f'{loc}.{ext}' for loc in ('screen', 'history', 'selection') for ext in ('txt', 'html'))
# Filesystem timestamps come from a coarse clock that may trail time.time_ns() by a tick.
MTIME_TOLERANCE_NS = 50_000_000


class ExportRefused(RuntimeError):
    """The export could not be identified as exactly one fresh file for this request."""


class ExportTimeout(ExportRefused):
    """No barrier file arrived: the key was lost or Ghostty is very slow. A new request is safe, because a late file
    from this one can only show up as a leftover or a second file, which refuses that request."""


def ghostty_version(text: str) -> str:
    """`Ghostty 1.3.1-arch2.1` (first line of `ghostty --version`) -> `1.3.1`."""
    match = re.match(r'\s*Ghostty\s+(\d+\.\d+\.\d+)', text)
    if not match:
        raise ExportRefused(f'Unrecognised ghostty --version output: {text.splitlines()[:1]}')
    return match.group(1)


def check_ghostty_version(text: str) -> dict:
    version = ghostty_version(text)
    if version != GHOSTTY_EXPORT_VERSION:
        raise ExportRefused(f'Ghostty {version} is not the pinned {GHOSTTY_EXPORT_VERSION}: re-check its export '
                            'semantics (nativeq/ghostty.py) before moving GHOSTTY_EXPORT_VERSION')
    return {'version': version, 'reported': text.splitlines()[0].strip(), 'exportPin': GHOSTTY_EXPORT_VERSION}


def installed_ghostty(binary: str = 'ghostty') -> dict:
    return check_ghostty_version(subprocess.check_output([binary, '--version'], text=True, timeout=15))


@dataclass
class Export:
    region: str
    raw: bytes
    path: str  # relative to the exports directory, for the record only (the file is removed once claimed)
    requested_ns: int
    mtime_ns: int

    def meta(self) -> dict:
        spec = REGIONS[self.region]
        return {'ghosttyAction': spec['action'], 'file': spec['file'], 'region': spec['region'],
                'ghostty': GHOSTTY_EXPORT_VERSION, **EXPORT_SEMANTICS, 'present': True,
                'tmpPath': self.path, 'requestedNs': self.requested_ns, 'mtimeNs': self.mtime_ns}


@dataclass
class ExportSet:
    requested: tuple[str, ...]
    requested_ns: int
    exports: dict[str, Export] = field(default_factory=dict)

    def get(self, region: str) -> Export | None:
        return self.exports.get(region)


def absent_meta(region: str, requested_ns: int) -> dict:
    spec = REGIONS[region]
    return {'ghosttyAction': spec['action'], 'file': None, 'region': spec['region'], 'ghostty': GHOSTTY_EXPORT_VERSION,
            **EXPORT_SEMANTICS, 'present': False, 'requestedNs': requested_ns}


class GhosttyExports:
    """Claims Ghostty export files from `directory` (Ghostty's TMPDIR)."""

    def __init__(self, directory: Path, press: Callable[[list[str]], None], *, timeout: float = 15.0,
                 settle: float = .3, open_paths: Callable[[], set[str]] | None = None,
                 clock: Callable[[], float] = time.monotonic, sleep: Callable[[float], None] = time.sleep):
        self.directory = Path(directory)
        self.press = press
        self.timeout, self.settle = timeout, settle
        self.open_paths = open_paths  # paths the Ghostty process still holds open (None: rely on settle only)
        self.clock, self.sleep = clock, sleep

    def _files(self) -> dict[Path, os.stat_result]:
        found = {}
        for path in self.directory.rglob('*'):
            if path.name in EXPORT_NAMES and (path.is_file() or path.is_symlink()):
                found[path] = path.lstat()
        return found

    def request(self, regions: tuple[str, ...]) -> ExportSet:
        """Press each region's key once, in order, in one native invocation. The last region must be `screen` (the
        barrier). Returns the claimed exports; a non-barrier region may be absent (Ghostty wrote nothing)."""
        regions = tuple(regions)
        if not regions or regions[-1] != 'screen' or len(set(regions)) != len(regions) \
                or any(r not in REGIONS for r in regions):
            raise ValueError(f'Export request must be distinct regions ending with screen: {regions}')
        leftovers = self._files()
        if leftovers:
            raise ExportRefused('Unclaimed export files before the request (an earlier export wrote more than one '
                                f'file): {sorted(str(p.relative_to(self.directory)) for p in leftovers)}')
        before_dirs = {p for p in self.directory.rglob('*') if p.is_dir()}
        requested_ns = time.time_ns()
        self.press([REGIONS[r]['key'] for r in regions])
        barrier = REGIONS['screen']['file']
        end = self.clock() + self.timeout
        while True:
            files = self._files()
            if any(p.name == barrier for p in files):
                break
            self._refuse_unexpected(files, regions)
            if self.clock() >= end:
                raise ExportTimeout(f'No {barrier} within {self.timeout:.0f} s of one request for {list(regions)} '
                                    f'(new files: {sorted(p.name for p in files)}); the key is not re-sent')
            self.sleep(.03)
        files = self._complete()
        self._refuse_unexpected(files, regions)
        claimed = ExportSet(regions, requested_ns)
        for path, stat in files.items():
            region = next(r for r in regions if REGIONS[r]['file'] == path.name)
            if region in claimed.exports:
                raise ExportRefused(f'More than one {path.name} for one request: '
                                    f'{sorted(str(p.relative_to(self.directory)) for p in files)}')
            if path.is_symlink() or not path.is_file():
                raise ExportRefused(f'Export is not a regular file: {path}')
            if path.parent == self.directory or path.parent in before_dirs \
                    or [c.name for c in path.parent.iterdir()] != [path.name]:
                raise ExportRefused(f'Export is not alone in a directory created for this request: {path}')
            if stat.st_mtime_ns < requested_ns - MTIME_TOLERANCE_NS:
                raise ExportRefused(f'Export predates the request ({stat.st_mtime_ns} < {requested_ns}): {path}')
            claimed.exports[region] = Export(region, path.read_bytes(), str(path.relative_to(self.directory)),
                                             requested_ns, stat.st_mtime_ns)
        if 'screen' not in claimed.exports:
            raise ExportRefused('Barrier export vanished')
        for path in files:
            path.unlink()
            path.parent.rmdir()
        return claimed

    def _refuse_unexpected(self, files, regions):
        wanted = {REGIONS[r]['file'] for r in regions}
        stray = sorted(str(p.relative_to(self.directory)) for p in files if p.name not in wanted)
        if stray:
            raise ExportRefused(f'Unrequested export files for {list(regions)}: {stray}')

    def _complete(self) -> dict[Path, os.stat_result]:
        """Files whose size and mtime held still for `settle` and that Ghostty no longer holds open."""
        end = self.clock() + self.timeout
        previous = None
        while True:
            files = self._files()
            snapshot = {p: (s.st_size, s.st_mtime_ns) for p, s in files.items()}
            busy = self.open_paths() & {str(p) for p in files} if self.open_paths else set()
            if snapshot == previous and not busy:
                return files
            if self.clock() >= end:
                raise ExportRefused(f'Export files still changing or open after {self.timeout:.0f} s: '
                                    f'{sorted(str(p) for p in files)}')
            previous = snapshot
            self.sleep(self.settle)


def split_screen(history: str | None, screen: str) -> dict:
    """Split a `screen.txt` export (scrollback + active area) with the `history.txt` taken just before it.

    `history` is None when Ghostty wrote no history file (no scrollback). The scrollback is the text prefix; the
    formatter separates the last history row from the next non-blank row with one newline, unless that row
    soft-wraps into the active area (unwrapped: no newline). Trailing blank history rows are trimmed from
    `history.txt`, so blank lines right after the separator may be scrollback or active rows: they are counted in
    `ambiguousBlankLines` and left at the start of `active`. `historyLines` is the screen line index where the
    active area's first line can begin; it begins at most `ambiguousBlankLines` later.
    """
    history_text = history or ''
    if not screen.startswith(history_text):
        raise ExportRefused('screen.txt does not begin with the history.txt taken before it')
    rest = screen[len(history_text):]
    if history is None:
        boundary, active = 'none', rest
    elif history_text == '':
        boundary, active = 'blank-history', rest
    elif rest.startswith('\n') or rest == '':
        boundary, active = 'newline', rest[1:]
    else:
        boundary, active = 'soft-wrap', rest
    history_lines = 0 if history_text == '' else history_text.count('\n') + 1
    if boundary == 'soft-wrap':
        history_lines -= 1  # the last history line continues as the active area's first line
    # With no scrollback every leading blank line is an active row; otherwise trimmed blank history rows may lead.
    blank = len(active) - len(active.lstrip('\n')) if history is not None else 0
    return {'boundary': boundary, 'historyChars': len(history_text), 'historyLines': history_lines,
            'ambiguousBlankLines': blank, 'activeChars': len(active), 'active': active,
            'historyPresent': history is not None}
