"""Run a command and parse its JSON, failing loudly.

Every place nativeq reads JSON from a command (the Hex1b CLI in a Linux session, PowerShell over ssh) goes through
`parse_json`, and local commands through `run_json`/`run_text`. A non-zero exit, a command that does not finish in
time, empty output (unless the caller allows it) and output that is not JSON all raise CommandFailed, whose message
names the command, the exit code and the tail of its stderr. Both output streams are drained, so a command that writes
a lot to stderr cannot block. `windows/NativeSession.ps1` has the PowerShell counterpart (Invoke-NqProcess,
ConvertFrom-NqCliJson) for the host runner.
"""
from __future__ import annotations

import json
import subprocess
from typing import Any

TAIL = 1500


class CommandFailed(RuntimeError):
    def __init__(self, message: str, *, exit: int | None = None, stdout: str = '', stderr: str = ''):
        super().__init__(message)
        self.exit, self.stdout, self.stderr = exit, stdout, stderr


def _tail(text: str | None) -> str:
    text = (text or '').strip()
    return text if len(text) <= TAIL else '...' + text[-TAIL:]


def _describe(what: str, exit: int | None, stderr: str) -> str:
    parts = [what] + ([f'exit {exit}'] if exit is not None else [])
    tail = _tail(stderr)
    return ', '.join(parts) + (f'; stderr: {tail}' if tail else '; no stderr')


def parse_json(text: str | None, *, what: str, exit: int | None = 0, stderr: str = '', allow_empty: bool = False) -> Any:
    """The JSON value in `text`. Raises CommandFailed for empty output (unless `allow_empty`, which returns None) or
    output that is not JSON."""
    body = (text or '').strip().lstrip('﻿').strip()
    if not body:
        if allow_empty:
            return None
        raise CommandFailed(f'{_describe(what, exit, stderr)}: empty output where JSON was expected', exit=exit,
                            stdout=text or '', stderr=stderr)
    try:
        return json.loads(body)
    except ValueError as error:
        head = body[:300] + ('...' if len(body) > 300 else '')
        raise CommandFailed(f'{_describe(what, exit, stderr)}: output is not JSON ({error}): {head}', exit=exit,
                            stdout=text or '', stderr=stderr) from None


def _run(argv: list[str], what: str, timeout: float, env) -> subprocess.CompletedProcess:
    try:
        done = subprocess.run(list(map(str, argv)), capture_output=True, text=True, timeout=timeout, env=env,
                              encoding='utf-8', errors='replace')
    except subprocess.TimeoutExpired as expired:
        stderr = expired.stderr.decode('utf-8', 'replace') if isinstance(expired.stderr, bytes) else expired.stderr
        raise CommandFailed(f'{_describe(what, None, stderr or "")}: did not finish within {timeout:g} s (stopped)',
                            stderr=stderr or '') from None
    if done.returncode:
        raise CommandFailed(_describe(what, done.returncode, done.stderr), exit=done.returncode, stdout=done.stdout,
                            stderr=done.stderr)
    return done


def run_text(argv: list[str], *, what: str | None = None, timeout: float = 60, env=None) -> str:
    """stdout of `argv`; a non-zero exit or a command still running after `timeout` seconds raises CommandFailed."""
    return _run(argv, what or ' '.join(map(str, argv)), timeout, env).stdout


def run_json(argv: list[str], *, what: str | None = None, timeout: float = 60, env=None,
             allow_empty: bool = False) -> Any:
    """The JSON value `argv` prints (see run_text and parse_json)."""
    what = what or ' '.join(map(str, argv))
    done = _run(argv, what, timeout, env)
    return parse_json(done.stdout, what=what, exit=done.returncode, stderr=done.stderr, allow_empty=allow_empty)
