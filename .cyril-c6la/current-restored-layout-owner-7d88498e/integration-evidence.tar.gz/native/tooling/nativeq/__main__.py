"""nativeq command line. Run from anywhere with PYTHONPATH=<janet>/tools/native-qualification."""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

from . import appenv
from . import curate as curate_mod
from . import flow as flow_check
from . import lease, pinning
from .command import CommandFailed
from .evidence import write_new_json
from .manifest import validate_manifest
from .refusal import CallRefused, existing, fresh


def _print(value):
    print(json.dumps(value, indent=2, sort_keys=True))


def _pairs(values, what):
    out = {}
    for value in values or ():
        if '=' not in value:
            raise CallRefused(f'{what} must be NAME=VALUE: {value}')
        name, rest = value.split('=', 1)
        out[name] = rest
    return out


def _app_env_file(path) -> dict[str, str]:
    """`windows stage --app-env`: a JSON object of names to string values."""
    try:
        env = json.loads(Path(path).read_text(encoding='utf-8'))
    except (OSError, ValueError) as error:
        raise CallRefused(f'--app-env {path}: {error}') from None
    if not isinstance(env, dict) or not all(isinstance(v, (str, int)) and not isinstance(v, bool) for v in env.values()):
        raise CallRefused(f'--app-env {path}: must be a JSON object of NAME: "value" pairs')
    return {name: str(value) for name, value in env.items()}


def _positive(text):
    value = int(text)
    if value < 1:
        raise argparse.ArgumentTypeError('must be a positive integer')
    return value


def _components(a) -> dict[str, Path]:
    """Component directories, absolute; a missing one is refused at the call."""
    components = {'app': existing(a.app_dir, '--app-dir', kind='dir')} if a.app_dir else {}
    if a.build_stage:
        components.update(pinning.from_build_stage(existing(a.build_stage, '--build-stage', kind='dir')))
    if a.tool_dir:
        components['tools'] = existing(a.tool_dir, '--tool-dir', kind='dir')
    if a.mcp_dir:
        components['mcp'] = existing(a.mcp_dir, '--mcp-dir', kind='dir')
    return components


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog='nativeq')
    sub = parser.add_subparsers(dest='area', required=True)

    m = sub.add_parser('manifest', help='validate retained artifacts against a manifest or ledger')
    m.add_argument('action', choices=['validate'])
    m.add_argument('root', type=Path)
    m.add_argument('--manifest', type=Path, help='default: ROOT/evidence.jsonl')
    m.add_argument('--ignore', action='append', default=[], help='glob of files not expected in the manifest')
    m.add_argument('--strict', action='store_true', help='orphans fail too')
    m.add_argument('--report', type=Path, help='write the report here (exclusive create)')

    c = sub.add_parser('curate', help='gzip+sha256 evidence into a new directory with a validated manifest')
    c.add_argument('--dest', type=Path, required=True)
    c.add_argument('--source', action='append', required=True, help='LABEL=PATH (file or directory)')
    c.add_argument('--note')

    p = sub.add_parser('pin', help='write a pinned component manifest')
    for flag in ('--app-dir', '--tool-dir', '--mcp-dir', '--build-stage'):
        p.add_argument(flag)
    p.add_argument('--platform', default='win-x64', choices=sorted(pinning.PLATFORM_RIDS))
    p.add_argument('--app-name')
    p.add_argument('--out', type=Path, required=True)

    w = sub.add_parser('windows', help='Windows host run lifecycle')
    w.add_argument('--store', type=Path, default=os.environ.get('NATIVEQ_STORE'),
                   help='local run records (default $NATIVEQ_STORE)')
    w.add_argument('--host', default=None, help='ssh host alias (default resourcefs-win11)')
    ws = w.add_subparsers(dest='action', required=True)
    pf = ws.add_parser('preflight', help='host state before a run: OK/WARN/FAIL findings (exit 2 on FAIL)')
    pf.add_argument('--json', action='store_true', help='print the full report (findings and host facts)')
    pf.add_argument('--no-window-probe', action='store_true',
                    help='skip the user-session window probe (it uses the bridge; run preflight under the GUI lease)')
    pf.add_argument('--run', help='the run about to start (its own staging is expected)')
    pf.add_argument('--strict', action='store_true', help='a visible focus stealer fails instead of warning')
    pf.add_argument('--min-cpus', type=_positive, default=4, help='fail below this ProcessorCount (default 4)')
    sw = ws.add_parser('sweep', help="stop what a run started and unstage it; anything not provably the run's is "
                                     'reported as foreign and left alone')
    which = sw.add_mutually_exclusive_group(required=True)
    which.add_argument('--run', action='append', help='a run of this store (repeatable)')
    which.add_argument('--mine', metavar='PREFIX', help="this store's runs whose ID starts with PREFIX")
    sw.add_argument('--dry-run', action='store_true', help='report the plan; change nothing on the host')
    st = ws.add_parser('stage')
    st.add_argument('--run', required=True)
    for flag in ('--app-dir', '--tool-dir', '--mcp-dir', '--build-stage'):
        st.add_argument(flag)
    st.add_argument('--app-name', required=True)
    st.add_argument('--scenario', type=Path)
    st.add_argument('--app-env', type=Path, help='JSON object of HEX1B_/JANET_ variables; {RUN} expands')
    st.add_argument('--reuse-from', help='earlier run whose identical components are junctioned after verification')
    st.add_argument('--minimum-free-bytes', type=int, default=50_000_000)
    st.add_argument('--runtime-sha256', help='refuse unless the host dotnet.exe has this hash')
    st.add_argument('--expect-flow-fault', metavar='REGEX',
                    help='opt-in: staged as control/flow-expectation.json and pinned; fault lines in flow.jsonl '
                         'matching REGEX are expected evidence, the run fails unless one appears, and any other '
                         'fault line still fails it')
    for name in ('verify', 'monitor', 'retain', 'unstage'):
        ws.add_parser(name).add_argument('--run', required=True)
    mon = ws.choices['monitor']
    mon.add_argument('--wait', type=float, metavar='SECONDS',
                     help='poll until result.json is present and the task is Ready again, or SECONDS pass (exit 3)')
    mon.add_argument('--poll', type=float, default=30, metavar='SECONDS', help='interval for --wait (default 30)')
    sr = ws.add_parser('start')
    sr.add_argument('--run', required=True)
    sr.add_argument('--mode', choices=['Scenario', 'Smoke'], default='Scenario')
    sr.add_argument('--app-args', default='')
    sr.add_argument('--ready', default='Ready')
    sr.add_argument('--verify-only', action='store_true', help='run every launch gate, then stop')
    sr.add_argument('--skip-preflight', action='store_true', help='launch without the host preflight (recorded)')
    sr.add_argument('--strict', action='store_true', help='preflight: a visible focus stealer fails')
    sr.add_argument('--min-cpus', type=_positive, default=4, help='preflight: fail below this ProcessorCount (default 4)')

    li = sub.add_parser('lint', help='pyright and PSScriptAnalyzer (bug rules only) on scripts; exit 1 on findings')
    li.add_argument('paths', nargs='+', help='files or directories (searched recursively for .py, .ps1, .psm1, .ps1.inc)')
    li.add_argument('--json', action='store_true', help='print the full report')

    lx = sub.add_parser('linux', help='Ghostty run on a private Xvfb display')
    lx.add_argument('action', choices=['run'])
    lx.add_argument('out', type=Path)
    lx.add_argument('--app', type=Path, required=True, help='app dll (run with $DOTNET_ROOT/dotnet)')
    lx.add_argument('--scenario', type=Path, required=True, help='Python file defining exercise(session)')
    lx.add_argument('--tool-dir', type=Path)
    lx.add_argument('--mcp-dir', type=Path)
    lx.add_argument('--app-env', action='append', default=[])
    lx.add_argument('--app-arg', action='append', default=[])
    lx.add_argument('--ready', default='Ready')
    lx.add_argument('--exit-key', default='ctrl+q')
    lx.add_argument('--expect-flow-fault', metavar='REGEX',
                    help='opt-in: fault lines in flow.jsonl matching REGEX are expected evidence; the run fails '
                         'unless one appears, and any other fault line still fails it')

    a = parser.parse_args(argv)
    try:
        return _dispatch(a)
    except CallRefused as refused:
        print(f'nativeq: refused: {refused}', file=sys.stderr)
        return 2
    except CommandFailed as failed:
        print(f'nativeq: command failed: {failed}', file=sys.stderr)
        return 1


def _dispatch(a) -> int:
    if a.area == 'manifest':
        root = existing(a.root, 'ROOT', kind='dir')
        manifest = existing(a.manifest, '--manifest', kind='file') if a.manifest else None
        out = fresh(a.report, '--report') if a.report else None
        report = validate_manifest(root, manifest, ignore=a.ignore, strict=a.strict)
        if out:
            write_new_json(out, report)
        _print(report)
        return 0 if report['ok'] else 1
    if a.area == 'curate':
        sources = {k: existing(v, f'--source {k}') for k, v in _pairs(a.source, '--source').items()}
        _print(curate_mod.curate(sources, fresh(a.dest, '--dest'), note=a.note))
        return 0
    if a.area == 'pin':
        out = fresh(a.out, '--out')
        pinned = pinning.pin(_components(a), a.platform, app_name=a.app_name)
        write_new_json(out, pinned)
        _print({k: len(v['files']) for k, v in pinned['components'].items()})
        return 0
    if a.area == 'lint':
        from . import lint
        report = lint.lint(a.paths)
        _print(report) if a.json else print(lint.summary(report))
        return 0 if report['ok'] else 1
    if a.area == 'linux':
        lease.require('linux', 'nativeq linux run')
        from .linux import run
        # Everything is checked before the run directory, the display or any process exists.
        app_env = appenv.check(_pairs(a.app_env, '--app-env'), host='linux')
        flow_check.check_pattern(a.expect_flow_fault)
        out = fresh(a.out, 'OUT')
        app = existing(a.app, '--app', kind='file').resolve()
        scenario = existing(a.scenario, '--scenario', kind='file')
        components = {'app': app.parent}
        tool_dir = existing(a.tool_dir, '--tool-dir', kind='dir') if a.tool_dir else None
        if tool_dir:
            components['tools'] = tool_dir
        if a.mcp_dir:
            components['mcp'] = existing(a.mcp_dir, '--mcp-dir', kind='dir')
        if not os.environ.get('DOTNET_ROOT'):
            raise CallRefused('DOTNET_ROOT is not set (source tools/hex1b-diagnostics/env.sh)')
        dotnet = str(existing(os.environ['DOTNET_ROOT'] + '/dotnet', 'DOTNET_ROOT', kind='file'))
        result = run(out, [dotnet, str(app), *a.app_arg], scenario, ready=a.ready, exit_key=a.exit_key,
                     app_match=str(app), components=components, app_env=app_env,
                     tool_dir=tool_dir, dotnet=dotnet, expect_flow_fault=a.expect_flow_fault)
        return 0 if result['ok'] else 1

    lease.require('windows', f'nativeq windows {a.action}')
    from .windows import HOST, LaunchRefused, SshTransport, WindowsRuns
    if not a.store:
        raise SystemExit('--store or NATIVEQ_STORE is required')
    runs = WindowsRuns(Path(a.store).expanduser().absolute(), SshTransport(a.host or HOST))
    try:
        if a.action == 'preflight':
            from .hoststate import FAIL, summary
            report = runs.preflight(min_cpus=a.min_cpus, strict=a.strict, probe=not a.no_window_probe, run=a.run)
            _print(report) if a.json else print(summary(report))
            return 2 if report['status'] == FAIL else 0
        elif a.action == 'sweep':
            report = runs.sweep(runs=a.run or (), mine=a.mine, dry_run=a.dry_run)
            _print(report)
            return 1 if report.get('failed') else 0
        elif a.action == 'stage':
            env = _app_env_file(existing(a.app_env, '--app-env', kind='file')) if a.app_env else {}
            scenario = existing(a.scenario, '--scenario', kind='file') if a.scenario else None
            _print(runs.stage(a.run, components=_components(a), app_name=a.app_name, scenario=scenario,
                              app_env=env, reuse_from=a.reuse_from, minimum_free_bytes=a.minimum_free_bytes,
                              runtime_sha256=a.runtime_sha256, expect_flow_fault=a.expect_flow_fault))
        elif a.action == 'verify':
            report = runs.verify(a.run)
            _print(report)
            return 0 if report['ok'] else 1
        elif a.action == 'start':
            _print(runs.start(a.run, mode=a.mode, app_args=a.app_args, ready=a.ready, verify_only=a.verify_only,
                              skip_preflight=a.skip_preflight, strict=a.strict, min_cpus=a.min_cpus))
        elif a.action == 'monitor':
            snapshot = runs.monitor(a.run, wait=a.wait, poll=a.poll)
            _print(snapshot)
            if snapshot.get('waited', {}).get('timedOut'):
                return 3
        elif a.action == 'retain':
            report = runs.retain(a.run)
            _print(report)
            return 0 if report['ok'] else 1
        elif a.action == 'unstage':
            _print(runs.unstage(a.run))
    except LaunchRefused as refused:
        report = refused.report
        if isinstance(report, dict) and report.get('schema') == 'nativeq.preflight/1':
            report = {k: v for k, v in report.items() if k != 'facts'}  # findings only; facts are in the run evidence
        _print({'refused': str(refused), 'report': report})
        return 2
    return 0


if __name__ == '__main__':
    sys.exit(main())
