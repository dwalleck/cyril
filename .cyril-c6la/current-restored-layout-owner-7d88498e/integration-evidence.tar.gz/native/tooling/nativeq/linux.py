"""Ghostty on a private Xvfb display: one owned app, exclusive evidence, exact-PID cleanup.

A scenario is a Python file defining `exercise(session) -> dict`. The session
gives it `key`, `text`, `capture`, `capture_split`, `wait_native`, `screenshot`,
`app_frame`, `wait_editor`, `grid`, `resize` and `paste`. A `capture` is a
Ghostty export: the scrollback plus the active area, not the visible screen
alone (`nativeq/ghostty.py`); `capture_split` separates the two. Every capture
and AppFrame goes through the run's EvidenceStore (unique ID, exclusive create,
ledger). The app, tools and mcp directories are pinned before launch and re-verified after
the run, and the dotnet host is hashed. Nothing outside `out` is written.
"""
from __future__ import annotations

import fcntl
import json
import os
import runpy
import select
import shutil
import struct
import subprocess
import termios
import time
from collections.abc import Sequence
from pathlib import Path

from . import appenv
from . import command
from . import flow as flow_check
from . import lease
from . import pinning
from .evidence import EvidenceStore, sha256_bytes, sha256_file, write_new, write_new_json
from .ghostty import GHOSTTY_EXPORT_VERSION, REGIONS, ExportRefused, ExportTimeout, GhosttyExports, absent_meta, installed_ghostty, \
    split_screen
from .manifest import validate_manifest
from .procs import OwnedProcesses, descendants, identity

GHOSTTY_CONFIG = """scrollback-limit = 64000000
gtk-single-instance = false
font-size = {font_size}
shell-integration = none
confirm-close-surface = false
keybind = {history_key}=write_scrollback_file:copy
keybind = {screen_key}=write_screen_file:copy
keybind = ctrl+alt+h=scroll_to_top
keybind = ctrl+alt+b=scroll_to_bottom
keybind = ctrl+alt+a=select_all
keybind = ctrl+alt+c=copy_to_clipboard
"""


def ghostty_config(font_size: int) -> str:
    return GHOSTTY_CONFIG.format(font_size=font_size, history_key=REGIONS['history']['key'],
                                 screen_key=REGIONS['screen']['key'])


# Files the runner writes outside the evidence ledger.
RUN_FILE_GLOBS = ('result.json', 'pinned-manifest.json', 'controller/*', 'ghostty.conf', 'ghostty.log', 'xvfb.log',
                  'flow.jsonl', 'exports/*', 'home/*', 'config/*', 'post-run-pin.json')
_CLIPBOARD_OWNER = ("import gi,sys;gi.require_version('Gtk','3.0');from gi.repository import Gtk,Gdk;Gtk.init([]);"
                    "c=Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD);c.set_text(sys.stdin.read(),-1);print('ready',flush=True);Gtk.main()")
_CLIPBOARD_READ = ("import gi,json,hashlib;gi.require_version('Gtk','3.0');from gi.repository import Gtk,Gdk;Gtk.init([]);"
                   "s=Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD).wait_for_text() or '';print(json.dumps({'text':s}))")


def app_pids(candidates: dict[int, Sequence[str]], argv: list[str], app_match: str) -> list[int]:
    """The launched app: its argv begins with the launch argv. Ghostty (and any wrapper) also carries the app path in
    its own argv after `-e`, so mere membership would also select the terminal itself."""
    return [pid for pid, args in candidates.items() if list(args[:len(argv)]) == list(argv) and app_match in args]


# Not inherited from the controller's environment. DOTNET_PROCESSOR_COUNT reaches the app only from --app-env, so
# the recorded `processors` is what the app was given.
DROPPED_ENV = ('WAYLAND_DISPLAY', 'LD_PRELOAD', 'XDG_SESSION_TYPE', 'GDK_BACKEND', appenv.PROCESSOR_COUNT)


class GhosttySession:
    def __init__(self, out: Path, argv: list[str], *, app_match: str, components: dict[str, Path] | None = None,
                 app_env: dict[str, str] | None = None, tool_dir: Path | None = None, display: str = ':216',
                 canvas=(2560, 1600), font_size: int = 11, dotnet: str | None = None,
                 expect_flow_fault: str | None = None):
        self.expect_flow_fault = flow_check.check_pattern(expect_flow_fault)
        self.app_env = appenv.check(dict(app_env or {}), host='linux')
        self.out = Path(out).resolve()
        self.out.mkdir(parents=True, exist_ok=False)
        self.argv, self.app_match = list(argv), app_match
        self.tool_dir = Path(tool_dir) if tool_dir else None
        self.display, self.canvas, self.font_size = display, canvas, font_size
        self.dotnet = dotnet or (os.environ.get('DOTNET_ROOT', '') + '/dotnet')
        self.evidence = EvidenceStore(self.out)
        self.owned = OwnedProcesses()
        self.popen: list[subprocess.Popen] = []
        self.window = None
        self.app_pid = None
        self.components = components
        self.pinned = None
        self.ghostty_pids: list[int] = []
        self.exports = GhosttyExports(self.out / 'exports', self._press_exports, open_paths=self._ghostty_open_paths)
        self.result = {'ok': False, 'privateCanvas': {'width': canvas[0], 'height': canvas[1]}, 'argv': self.argv,
                       'flowExpectation': flow_check.expectation_document(self.expect_flow_fault),
                       'processors': appenv.processors(self.app_env, len(os.sched_getaffinity(0)))}
        if self.expect_flow_fault is not None:
            self.evidence.put_json('flow-expectation', self.result['flowExpectation'], kind='flow-expectation')

    def app_command(self) -> list[str]:
        """What Ghostty runs: the app argv under `env`, with the controller's HOME, the runner's diagnostics switch
        and the app env (nativeq/appenv.py `launch`)."""
        return ['env', 'HOME=' + os.environ['HOME'], *[k + '=' + v for k, v in appenv.launch(self.app_env).items()],
                *self.argv]

    # -- process / X helpers --------------------------------------------------------------
    def x(self, *cmd, timeout=15) -> str:
        return subprocess.check_output(cmd, env=self.env, text=True, stderr=subprocess.DEVNULL, timeout=timeout).strip()

    def _spawn(self, argv, **kwargs) -> subprocess.Popen:
        proc = subprocess.Popen(argv, **kwargs)
        self.popen.append(proc)
        self.owned.adopt(proc.pid)
        return proc

    def key(self, *keys):
        self.x('xdotool', 'key', '--clearmodifiers', '--window', self.window, *keys)

    def text(self, value: str):
        self.x('xdotool', 'type', '--clearmodifiers', '--window', self.window, '--delay', '1', '--', value)

    # -- evidence -----------------------------------------------------------------------------
    def _press_exports(self, keys: list[str]):
        self.key(*keys)  # one native invocation: Ghostty handles the keys in order

    def _ghostty_open_paths(self) -> set[str]:
        """Files under `exports/` that a Ghostty process still holds open (an export still being written)."""
        held = set()
        for pid in self.ghostty_pids:
            try:
                fds = os.listdir(f'/proc/{pid}/fd')
            except OSError:
                continue
            for fd in fds:
                try:
                    target = os.readlink(f'/proc/{pid}/fd/{fd}')
                except OSError:
                    continue
                if target.startswith(str(self.out / 'exports') + '/'):
                    held.add(target)
        return held

    def capture(self, label: str, history: bool = False) -> str:
        """Ghostty text export. `history=False` (`write_screen_file`) is the scrollback **plus** the active area, not
        the visible screen alone; `history=True` (`write_scrollback_file`) is the scrollback alone, '' when there is
        none (Ghostty then writes no file; the `screen.txt` barrier proves it). Soft wraps are unwrapped and trailing
        blank rows trimmed. Each export is one key press, claimed as the one fresh file of that request
        (nativeq/ghostty.py); use `capture_split` to separate scrollback from the active area."""
        if history:
            claimed = self._request(label, ('history', 'screen'))
            found = claimed.get('history')
            barrier = claimed.get('screen')
            meta = found.meta() if found else absent_meta('history', claimed.requested_ns)
            meta['barrier'] = {'file': 'screen.txt', 'rawSha256': sha256_bytes(barrier.raw)}
            raw = found.raw if found else b''
            self.evidence.put_bytes(label, raw, kind='capture-history', suffix='.txt', compress=True,
                                    meta={'export': meta})
            return raw.decode('utf-8', errors='replace')
        screen = self._request(label, ('screen',)).get('screen')
        self.evidence.put_bytes(label, screen.raw, kind='capture', suffix='.txt', compress=True,
                                meta={'export': screen.meta()})
        return screen.raw.decode('utf-8', errors='replace')

    def capture_split(self, label: str, attempts: int = 3) -> dict:
        """Scrollback and active area of one moment. Ghostty 1.3.1 cannot export the visible rows alone, so this takes
        history.txt then screen.txt (one request, ordered by Ghostty) and repeats the pair; the split is accepted only
        when the scrollback is the same in both pairs (it did not grow during the screen export) and screen.txt begins
        with it. Records the pair and a `capture-split` entry (`boundary`, `historyLines`, `ambiguousBlankLines`, the
        grid) so an audit can separate history from the active area. Returns those fields plus `screen`, `history`
        and `active` text. See `nativeq.ghostty.split_screen` for the boundary rules."""
        hashes = []
        for attempt in range(1, attempts + 1):
            first = self._request(f'{label}-split', ('history', 'screen'))
            second = self._request(f'{label}-split', ('history', 'screen'))
            pair = [x.raw if (x := claimed.get('history')) else None for claimed in (first, second)]
            hashes.append([sha256_bytes(raw) if raw is not None else None for raw in pair])
            if pair[0] == pair[1]:
                break
        else:
            raise ExportRefused(f'Scrollback changed during each of {attempts} split captures of {label}')
        history, screen = first.get('history'), first.get('screen')
        history_text = history.raw.decode('utf-8', errors='replace') if history else None
        screen_text = screen.raw.decode('utf-8', errors='replace')
        split = split_screen(history_text, screen_text)
        history_entry = self.evidence.put_bytes(
            f'{label}-history', history.raw if history else b'', kind='capture-history', suffix='.txt', compress=True,
            meta={'export': history.meta() if history else absent_meta('history', first.requested_ns)})
        screen_entry = self.evidence.put_bytes(f'{label}-screen', screen.raw, kind='capture', suffix='.txt',
                                               compress=True, meta={'export': screen.meta()})
        record = {k: v for k, v in split.items() if k != 'active'}
        record.update(history=history_entry['id'], screen=screen_entry['id'], attempts=attempt,
                      historyPairSha256=hashes, ghostty=GHOSTTY_EXPORT_VERSION,
                      grid=list(self.grid()) if self.app_pid else None)
        self.evidence.put_json(label, record, kind='capture-split')
        return {**split, 'screen': screen_text, 'history': history_text or '', 'grid': record['grid']}

    def _request(self, label: str, regions: tuple[str, ...]):
        try:
            return self.exports.request(regions)
        except ExportRefused:
            try:
                self.screenshot('failed-' + label)
            except Exception:  # the refusal is the evidence that matters; a failed screenshot must not mask it
                pass
            raise

    def wait_native(self, needle: str, tag: str, exact: bool = False, timeout: float = 20) -> str:
        """Waits for `needle` anywhere in the screen export (scrollback + active area, not only the visible rows)."""
        end, index = time.monotonic() + timeout, 0
        while time.monotonic() < end:
            try:
                value = self.capture(f'{tag}-{index}')
            except ExportTimeout:  # a lost key (for example before the surface is ready): ask again
                index += 1
                continue
            index += 1
            if (needle in [line.strip() for line in value.splitlines()]) if exact else (needle in value):
                return value
            time.sleep(.15)
        raise AssertionError('Native screen export (scrollback + active area) did not contain ' + repr(needle))

    def screenshot(self, label: str) -> dict:
        if not self.window:
            raise RuntimeError('No Ghostty window to screenshot')
        png = subprocess.check_output(['import', '-window', self.window, 'png:-'], env=self.env,
                                      stderr=subprocess.DEVNULL, timeout=15)
        return self.evidence.put_bytes(label, png, kind='screenshot', suffix='.png')

    def _tool_argv(self, args) -> list[str]:
        if not self.tool_dir:
            raise RuntimeError('tool_dir required')
        return [self.dotnet, str(self.tool_dir / 'Hex1b.Tool.dll'), *map(str, args)]

    def tool(self, *args, timeout: float = 60) -> str:
        """stdout of the staged Hex1b CLI; a non-zero exit or a call past `timeout` raises CommandFailed with the
        CLI's stderr (nativeq/command.py)."""
        return command.run_text(self._tool_argv(args), what='Hex1b CLI ' + ' '.join(map(str, args)), timeout=timeout)

    def cli_json(self, *args, timeout: float = 60, allow_empty: bool = False):
        """The JSON the Hex1b CLI prints. Fails loudly (CommandFailed, with stderr) on a non-zero exit, empty
        output or output that is not JSON, so a scenario never parses an empty answer."""
        return command.run_json(self._tool_argv(args), what='Hex1b CLI ' + ' '.join(map(str, args)), timeout=timeout,
                                allow_empty=allow_empty)

    def app_frame(self, label: str) -> dict:
        listing = self.cli_json('terminal', 'list', '--json')
        matches = [t['id'] for t in listing if int(t['pid']) == self.app_pid]
        if len(matches) != 1:
            raise RuntimeError('Exact app PID not discovered')
        args = ('app', 'tree', matches[0], '--authorize', 'editor-text', '--json')
        raw = self.tool(*args)
        frame = command.parse_json(raw, what='Hex1b CLI ' + ' '.join(args))
        self.evidence.put_json(label, raw, kind='app-frame')
        return frame

    def wait_editor(self, label: str, predicate, timeout: float = 20) -> dict:
        end, index = time.monotonic() + timeout, 0
        while time.monotonic() < end:
            frame = self.app_frame(f'{label}-{index}')
            index += 1
            if predicate(frame['frame']['focusedEditor']):
                return frame
            time.sleep(.05)
        raise AssertionError('Editor state did not reach ' + label)

    # -- geometry / clipboard -----------------------------------------------------------------
    def grid(self):
        fd = os.open(f'/proc/{self.app_pid}/fd/1', os.O_RDWR | os.O_NOCTTY)
        try:
            rows, cols, xp, yp = struct.unpack('HHHH', fcntl.ioctl(fd, termios.TIOCGWINSZ, b'\0' * 8))
            return cols, rows, xp, yp
        finally:
            os.close(fd)

    def _geometry(self) -> dict:
        return dict(line.split('=') for line in self.x('xdotool', 'getwindowgeometry', '--shell', self.window).splitlines())

    def resize(self, cols: int, rows: int):
        for _ in range(8):
            c, r, xp, yp = self.grid()
            if (c, r) == (cols, rows):
                g = self._geometry()
                if int(g['X']) < 0 or int(g['Y']) < 0 or int(g['X']) + int(g['WIDTH']) > self.canvas[0] \
                        or int(g['Y']) + int(g['HEIGHT']) > self.canvas[1]:
                    raise AssertionError(('Window outside private canvas', g))
                return
            g = self._geometry()
            self.x('xdotool', 'windowsize', self.window, str(round(int(g['WIDTH']) + (cols - c) * xp / c)),
                   str(round(int(g['HEIGHT']) + (rows - r) * yp / r)))
            time.sleep(.25)
        if self.grid()[:2] != (cols, rows):
            raise AssertionError(self.grid())

    def clipboard(self) -> str:
        return json.loads(self.x('python3', '-c', _CLIPBOARD_READ))['text']

    def paste(self, value: str, following=(), owner_timeout: float = 15):
        owner = self._spawn(['python3', '-c', _CLIPBOARD_OWNER], env=self.env, stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
        owner.stdin.write(value)
        owner.stdin.close()
        # Bounded: a Gtk owner that never starts would otherwise block readline() for good.
        ready, _, _ = select.select([owner.stdout], [], [], owner_timeout)
        if not ready:
            raise RuntimeError(f'Clipboard owner did not start within {owner_timeout:g} s')
        if owner.stdout.readline().strip() != 'ready':
            raise RuntimeError('Clipboard owner did not start')
        if self.clipboard() != value:
            raise AssertionError('Clipboard roundtrip mismatch')
        # Paste and following keys share one native invocation, with no observation barrier.
        self.key('ctrl+shift+v', *following)

    # -- lifecycle --------------------------------------------------------------------------------
    def start(self, ready: str = 'Ready'):
        lease.require('linux', f'a Ghostty session on display {self.display}')
        if Path(f'/tmp/.X11-unix/X{self.display.lstrip(":")}').exists():
            raise RuntimeError(f'Display {self.display} is in use')
        self.result['ghostty'] = installed_ghostty()  # refuses a Ghostty whose export semantics were not checked
        if self.components:
            self.pinned = pinning.pin(self.components, 'linux-x64', required=tuple(self.components), excludes=())
            write_new_json(self.out / 'pinned-manifest.json', self.pinned)
        if Path(self.dotnet).is_file():
            self.result['dotnet'] = {'path': self.dotnet, 'sha256': sha256_file(Path(self.dotnet))}
        for name in ('home', 'config', 'exports', '.private'):
            (self.out / name).mkdir()
        os.chmod(self.out / '.private', 0o700)
        auth = self.out / '.private' / 'xauth'
        config = self.out / 'ghostty.conf'
        write_new(config, ghostty_config(self.font_size).encode())
        cookie = subprocess.check_output(['mcookie'], text=True, timeout=15).strip()
        subprocess.run(['xauth', '-q', '-f', str(auth), 'add', self.display, '.', cookie], check=True, timeout=15)
        self.env = {k: v for k, v in os.environ.items() if k not in DROPPED_ENV}
        self.env.update(DISPLAY=self.display, XAUTHORITY=str(auth), GDK_BACKEND='x11', LANG='C.UTF-8', LC_ALL='C.UTF-8')
        self._spawn(['Xvfb', self.display, '-screen', '0', f'{self.canvas[0]}x{self.canvas[1]}x24', '-nolisten', 'tcp',
                     '-noreset', '-auth', str(auth)], stdout=subprocess.DEVNULL, stderr=(self.out / 'xvfb.log').open('w'))
        time.sleep(.7)
        launch_env = dict(self.env, HOME=str(self.out / 'home'), XDG_CONFIG_HOME=str(self.out / 'config'),
                          TMPDIR=str(self.out / 'exports'), HEX1B_FLOW_COMMIT_EVENTS=str(self.out / 'flow.jsonl'))
        command = ['dbus-run-session', '--', 'ghostty', '--config-default-files=false', '--config-file=' + str(config),
                   '-e', *self.app_command()]
        self.launcher = self._spawn(command, env=launch_env, stdout=(self.out / 'ghostty.log').open('w'),
                                    stderr=subprocess.STDOUT, start_new_session=True)
        end = time.monotonic() + 15
        while time.monotonic() < end and not self.window:
            try:
                self.window = self.x('xdotool', 'search', '--onlyvisible', '--class', '[Gg]hostty').splitlines()[0]
            except (subprocess.CalledProcessError, IndexError):
                time.sleep(.1)
        if not self.window:
            raise RuntimeError('Ghostty window did not appear')
        self.ghostty_pids = [pid for pid in descendants(self.launcher.pid)
                             if (ident := identity(pid)) and ident.argv and Path(ident.argv[0]).name == 'ghostty']
        self.x('xdotool', 'windowfocus', '--sync', self.window)
        self.wait_native(ready, 'ready')
        pids = app_pids({pid: ident.argv for pid in descendants(self.launcher.pid) if (ident := identity(pid))},
                        self.argv, self.app_match)
        if len(pids) != 1:
            raise RuntimeError(f'Expected one owned app process, found {pids}')
        self.app_pid = pids[0]
        self.result['app'] = self.owned.adopt(self.app_pid).to_json()

    def exit_naturally(self, exit_key: str = 'ctrl+q', timeout: float = 5):
        if self.app_pid is None:
            raise RuntimeError('No owned app process to exit')
        app = self.app_pid
        if not self.result.get('scenarioExited'):
            self.key(exit_key)
        deadline = time.monotonic() + timeout
        while identity(app) and time.monotonic() < deadline:
            time.sleep(.05)
        self.result['naturalExit'] = identity(app) is None
        if not self.result['naturalExit']:
            raise AssertionError('Application did not naturally exit')
        self.check_flow()

    def check_flow(self):
        """Fault lines in flow.jsonl fail the run, except those the declared expected-fault regex matches and
        recovered Flow delivery refusals; a declared expectation with no matching fault line fails too
        (see nativeq/flow.py)."""
        flow = self.out / 'flow.jsonl'
        report = flow_check.classify(flow.read_text().splitlines() if flow.exists() else [], self.expect_flow_fault)
        self.result['flow'] = report
        if report['expected']:
            self.evidence.put_text('expected-flow-faults', '\n'.join(report['expected']) + '\n', kind='flow',
                                   compress=False)
        if report['recovered']:
            self.evidence.put_text('recovered-flow-events', '\n'.join(report['recovered']) + '\n', kind='flow',
                                   compress=False)
        if report['unexpected']:
            self.evidence.put_text('unexpected-flow-events', '\n'.join(report['unexpected']) + '\n', kind='flow',
                                   compress=False)
        if not report['ok']:
            raise AssertionError(flow_check.failure_message(report))
        self.result['flowHealthy'] = True

    def close(self):
        if hasattr(self, 'launcher'):
            for pid in descendants(self.launcher.pid):
                if identity(pid):
                    self.owned.adopt(pid)
        self.result['cleanup'] = self.owned.cleanup()
        for proc in self.popen:
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                pass
        shutil.rmtree(self.out / '.private', ignore_errors=True)
        if self.pinned:
            after = pinning.verify_sources(self.pinned)
            write_new_json(self.out / 'post-run-pin.json', after)
            self.result['componentsUnchanged'] = after['ok']
            if not after['ok']:
                self.result['ok'] = False
        if (self.out / 'evidence.jsonl').is_file():
            report = validate_manifest(self.out, ignore=RUN_FILE_GLOBS)
            self.result['evidence'] = {k: report[k] for k in ('ok', 'entries', 'matched', 'missing', 'mismatched',
                                                              'duplicates', 'orphans')}
        else:
            # The run failed before its first evidence write (for example in start); the result still records why.
            report = {'ok': False}
            self.result['evidence'] = {'ok': False, 'error': 'no evidence.jsonl: the run wrote no evidence'}
        if not report['ok']:
            self.result['ok'] = False
        write_new_json(self.out / 'result.json', self.result)


def run(out: Path, argv: list[str], scenario: Path, *, ready='Ready', exit_key='ctrl+q', **options) -> dict:
    session = GhosttySession(out, argv, **options)
    (session.out / 'controller').mkdir()
    shutil.copy2(scenario, session.out / 'controller' / Path(scenario).name)
    try:
        session.start(ready)
        session.result['scenario'] = runpy.run_path(str(scenario))['exercise'](session)
        session.exit_naturally(exit_key)
        session.result['ok'] = True
    except BaseException as error:
        session.result['ok'] = False
        session.result['error'] = repr(error)
        raise
    finally:
        session.close()
    return session.result
