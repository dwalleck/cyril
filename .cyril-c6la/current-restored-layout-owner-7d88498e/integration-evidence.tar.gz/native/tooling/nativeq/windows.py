"""Stage, verify, launch, monitor, retain and unstage a native run on the Windows host.

Every stage ends with a full destination verification against the pinned
manifest (all components, including `mcp` and `tools`, whether uploaded or
reused through a junction), and `start` repeats it immediately before writing
the user-session bridge. Any mismatch refuses the launch. The host runner
(`windows/run.ps1`) verifies the same pin again on the host before it changes
anything. The transport is injectable so the gate logic is testable without
the host.
"""
from __future__ import annotations

import base64
import json
import os
import re
import shutil
import subprocess
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path

from . import appenv
from .command import CommandFailed, parse_json
from . import flow as flow_check
from . import hoststate
from . import lease
from . import pinning
from .evidence import EvidenceStore, sha256_bytes, sha256_file, write_new, write_new_json
from .manifest import validate_manifest
from .refusal import CallRefused

HOST = 'resourcefs-win11'
HERE = Path(__file__).resolve().parent.parent
RUNNER = HERE / 'windows' / 'run.ps1'
LIBRARY = HERE / 'windows' / 'NativeSession.ps1'
# Window enumeration/focus helper (defines Get-JanetWindows and [Janet.Win32]). Staged and pinned as
# control/window.ps1; run.ps1 dot-sources only that staged copy, never a host folder.
WINDOW_HELPER = HERE / 'windows' / 'window.ps1'
# Files the runner writes outside the evidence ledger; everything else must be ledgered.
RUN_FILE_GLOBS = ('pinned-manifest.json', 'control/*', 'result.json', 'settings-before.json',
                  'bridge-before.txt', 'launch.cmd', 'owned-process.json', 'owned-window.json', 'owned-settings.json', 'flow.jsonl',
                  'scratch/*')
# PowerShell 7 on the host (machine-wide MSI install). Every nativeq script runs under it: over ssh, and in the
# user's session through the bridge (with -STA, for the clipboard). NATIVEQ_HOST_PWSH overrides the path.
HOST_PWSH = 'C:/Program Files/PowerShell/7/pwsh.exe'
MISSING_PWSH_EXIT = 97
_RUN_ID = re.compile(r'^[A-Za-z0-9][A-Za-z0-9-]{0,62}$')
_APP_ARGS = re.compile(r'^[A-Za-z0-9._= -]*$')


@dataclass(frozen=True)
class HostLayout:
    runtime: str = 'C:/janet-native-runtime-10-0-12/dotnet/dotnet.exe'
    bridge: str = 'C:/janet-mechanics/user-session-command.txt'
    task: str = 'JanetUserSession'
    drive: str = 'C'
    shell: str = field(default_factory=lambda: os.environ.get('NATIVEQ_HOST_PWSH') or HOST_PWSH)

    def remote(self, run: str) -> str:
        return f'{self.drive}:/{run}'


_LINT_CACHE: dict[tuple, dict] = {}


class RemoteError(RuntimeError):
    pass


class LaunchRefused(RuntimeError):
    def __init__(self, message: str, report: dict | None = None):
        super().__init__(message)
        self.report = report


def check_run_id(run: str) -> str:
    if not _RUN_ID.match(run or ''):
        raise CallRefused(f'Run ID must be letters, digits and dashes (at most 63): {run!r}')
    return run


def quote(text: str) -> str:
    return "'" + str(text).replace("'", "''") + "'"


def encoded(script: str) -> str:
    return base64.b64encode(script.encode('utf-16le')).decode()


_PRELUDE = ("[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false);$OutputEncoding=[Console]::OutputEncoding;"
            "$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue';")


def bridge_command(call: str, shell: str, *, restore: tuple[str, str] | None = None) -> str:
    """The user-session bridge line for `call`. The line keeps the form the bridge has always run
    (`powershell.exe ... -EncodedCommand`); that Windows PowerShell only hands `call` to PowerShell 7 (`shell`) with
    -STA and returns its exit code. If PowerShell 7 is missing it exits 97, first restoring the bridge from
    `restore` = (bridge-before file, bridge) when given, because run.ps1, which would restore it, never starts."""
    shell = shell.replace('/', '\\')  # backslashes, as windows/host-query.ps1 New-NqBridgeCommand (seen live)
    back = (f'Copy-Item -LiteralPath {quote(restore[0])} -Destination {quote(restore[1])} -Force;' if restore else '')
    outer = (f'if(!(Test-Path -LiteralPath {quote(shell)} -PathType Leaf)){{{back}exit {MISSING_PWSH_EXIT}}};'
             f'& {quote(shell)} -NoProfile -STA -ExecutionPolicy Bypass -EncodedCommand {encoded(call)};exit $LASTEXITCODE')
    return 'powershell.exe -NoProfile -ExecutionPolicy Bypass -EncodedCommand ' + encoded(outer)


class SshTransport:
    """PowerShell 7 over ssh plus scp, to a host alias from ~/.ssh/config (keys only, BatchMode).

    The host's ssh default shell is Windows PowerShell, which runs the command line; it checks that PowerShell 7 is
    at `shell` (exit 97 with a clear message otherwise) and runs the script there. A script too long for a command
    line is sent on stdin to a short encoded bootstrap."""

    MAX_ENCODED = 6000

    def __init__(self, host: str = HOST, connect_timeout: int = 5, shell: str | None = None):
        lease.require('windows', f'an ssh transport to {host}')
        self.host = host
        self.shell = (shell or os.environ.get('NATIVEQ_HOST_PWSH') or HOST_PWSH).replace('/', '\\')
        self.options = ['-o', 'BatchMode=yes', '-o', f'ConnectTimeout={connect_timeout}']

    def command(self, script: str) -> tuple[str, str | None]:
        """(remote command line, stdin text or None)."""
        payload, stdin = encoded(_PRELUDE + script), None
        if len(payload) > self.MAX_ENCODED:
            payload = encoded('[Console]::InputEncoding=[Text.UTF8Encoding]::new($false);'
                              '. ([scriptblock]::Create([Console]::In.ReadToEnd()))')
            stdin = _PRELUDE + script
        check = (f"if(!(Test-Path -LiteralPath {quote(self.shell)} -PathType Leaf)){{[Console]::Error.WriteLine("
                 f"{quote('nativeq: PowerShell 7 is missing at ' + self.shell + '; install it (README) or set NATIVEQ_HOST_PWSH')});"
                 f"exit {MISSING_PWSH_EXIT}}};")
        return check + f'& {quote(self.shell)} -NoProfile -NonInteractive -EncodedCommand {payload}', stdin

    @staticmethod
    def _stderr(text: str) -> str:
        return '\n'.join(line for line in text.splitlines() if not line.startswith('**')).strip()

    def ps(self, script: str, timeout: int = 120) -> str:
        command, stdin = self.command(script)
        result = subprocess.run(['ssh', *self.options, self.host, command], capture_output=True, text=True,
                                timeout=timeout, input=stdin, encoding='utf-8')
        if result.returncode == MISSING_PWSH_EXIT:
            raise RemoteError(self._stderr(result.stderr) or f'PowerShell 7 is missing at {self.shell}')
        if result.returncode:
            # Without stderr, the end of stdout is the only account of the failure (a PowerShell error can go there).
            detail = self._stderr(result.stderr)[-2000:] or ('stdout: ' + result.stdout.strip()[-2000:]
                                                             if result.stdout.strip() else 'no output')
            raise RemoteError(f'ssh exit {result.returncode}: {detail}')
        return result.stdout.strip().lstrip('\ufeff')

    def upload(self, local: Path, remote: str, recursive: bool = False, timeout: int = 1800) -> None:
        result = subprocess.run(['scp', *self.options, '-q', *(['-r'] if recursive else []), str(local),
                                 f'{self.host}:{remote}'], capture_output=True, text=True, timeout=timeout)
        if result.returncode:
            raise RemoteError('scp upload: ' + self._stderr(result.stderr)[-2000:])

    def download(self, remote: str, local: Path, recursive: bool = False, timeout: int = 1800) -> None:
        result = subprocess.run(['scp', *self.options, '-q', *(['-r'] if recursive else []),
                                 f'{self.host}:{remote}', str(local)], capture_output=True, text=True, timeout=timeout)
        if result.returncode:
            raise RemoteError('scp download: ' + self._stderr(result.stderr)[-2000:])


# Listing of a run root: every file with its hash; top-level junctions (verified reuse) are
# followed, nested reparse points and file links are reported as anomalies.
LIST_SCRIPT = r"""
$root=(Get-Item -LiteralPath {root}).FullName.TrimEnd('\')
$rows=New-Object 'System.Collections.Generic.List[object]'
$walk={{param([string]$dir,[string]$rel)
 foreach($item in @(Get-ChildItem -LiteralPath $dir -Force)){{
  $r=$(if($rel){{$rel+'/'+$item.Name}}else{{$item.Name}})
  $link=[bool]($item.Attributes -band [IO.FileAttributes]::ReparsePoint)
  if($item.PSIsContainer){{
   if($link -and $rel){{$rows.Add(@{{path=$r;type='nested-link'}});continue}}
   if($link){{$rows.Add(@{{path=$r;type='junction';target=[string]$item.Target}})}}
   & $walk $item.FullName $r
  }} elseif($link){{$rows.Add(@{{path=$r;type='file-link'}})}}
  else{{$rows.Add(@{{path=$r;type='file';bytes=$item.Length;sha256=(Get-FileHash -Algorithm SHA256 -LiteralPath $item.FullName).Hash.ToLowerInvariant()}})}}
 }}
}}
& $walk $root ''
ConvertTo-Json -InputObject @($rows.ToArray()) -Depth 4 -Compress
"""


def parse_listing(text: str) -> tuple[dict[str, str], list[dict], list[dict]]:
    """Parse LIST_SCRIPT output into (files path->sha256, junctions, anomalies).

    PowerShell can emit a lone object instead of a one-element array; empty output fails (CommandFailed)."""
    rows = parse_json(text, what='destination listing')
    if isinstance(rows, dict):
        rows = [rows]
    files, junctions, anomalies = {}, [], []
    for row in rows:
        kind = row.get('type')
        path = str(row.get('path', '')).replace('\\', '/')
        if kind == 'file':
            files[path] = str(row['sha256']).lower()
        elif kind == 'junction':
            junctions.append({'path': path, 'target': row.get('target')})
        else:
            anomalies.append({'path': path, 'type': kind})
    return files, junctions, anomalies


def destination_report(pinned: dict, pinned_sha256: str, listing: str, *, allowed=()) -> dict:
    """Compare a destination listing with the pin. `pinned-manifest.json` must be the staged one."""
    files, junctions, anomalies = parse_listing(listing)
    manifest_sha = files.pop('pinned-manifest.json', None)
    for name in allowed:
        files.pop(name, None)
    report = pinning.compare(pinned, files)
    report['junctions'] = junctions
    report['anomalies'] = anomalies
    report['pinnedManifest'] = {'expected': pinned_sha256, 'observed': manifest_sha}
    report['ok'] = report['ok'] and not anomalies and manifest_sha == pinned_sha256
    return report


class WindowsRuns:
    """Run lifecycle against one host. `store` holds the local record of every run."""

    def __init__(self, store: Path, transport=None, layout: HostLayout = HostLayout()):
        self.store = Path(store)
        self.transport = transport or SshTransport()
        self.layout = layout

    # -- host queries ---------------------------------------------------------------------
    def _json(self, script: str, timeout: int = 120, *, what: str = 'host PowerShell'):
        """The JSON a host script prints. Empty or non-JSON output raises CommandFailed (nativeq/command.py)."""
        return parse_json(self.transport.ps(script, timeout=timeout), what=what)

    def host_query(self, action: str, *, probe: bool = True, args=None, timeout: int = 240) -> dict:
        """One ssh round trip running windows/host-query.ps1 (see nativeq/hoststate.py)."""
        layout = self.layout
        return self._json(hoststate.query_script(action, drive=layout.drive, task=layout.task, bridge=layout.bridge,
                                                 runtime=layout.runtime, shell=layout.shell, probe=probe, args=args),
                          timeout=timeout, what=f'host-query {action}')

    def preflight(self, *, min_cpus: int = hoststate.DEFAULT_MIN_CPUS, strict: bool = False, probe: bool = True,
                  run: str | None = None, min_free_bytes: int = hoststate.DEFAULT_MIN_FREE_BYTES) -> dict:
        """Host state before a run: session, processors, leftovers, focus stealers, disk, staged runs.
        Returns {status: OK|WARN|FAIL, findings, facts}. With `probe`, the window list is taken in the user's
        session through the bridge (only while the user-session task is Ready), so run it under the GUI lease."""
        facts = self.host_query('preflight', probe=probe)
        return hoststate.evaluate_preflight(facts, min_cpus=min_cpus, strict=strict, run=run,
                                            min_free_bytes=min_free_bytes, drive=self.layout.drive,
                                            runtime_hashes=self.recorded_settings())

    def recorded_settings(self) -> dict[str, str]:
        """Windows Terminal settings hashes this store's retained runs recorded writing (owned-settings.json) -> run."""
        found = {}
        for owned in sorted(self.store.glob('*/retained/owned-settings.json')) if self.store.is_dir() else ():
            try:
                written = json.loads(owned.read_text(encoding='utf-8-sig')).get('writtenSha256')
            except (OSError, ValueError):
                continue
            if written:
                found[written] = owned.parent.parent.name
        return found

    def sweep(self, *, runs=(), mine: str | None = None, dry_run: bool = False) -> dict:
        """Stop what the named runs started and unstage them. Runs are named (`runs`) or are this store's runs whose
        ID starts with `mine`. Only proven ownership is acted on (nativeq/hoststate.py plan_sweep); everything else
        is reported as foreign. `dry_run` reports the plan and changes nothing on the host."""
        if bool(mine) == bool(runs):
            raise ValueError('Name runs with --run, or a prefix of this store\'s runs with --mine (one of them)')
        if mine:
            names = sorted(d.name for d in self.store.iterdir() if d.name.startswith(mine) and _RUN_ID.match(d.name)
                           and (d / 'pinned-manifest.json').is_file()) if self.store.is_dir() else []
        else:
            names = sorted({check_run_id(r) for r in runs})
        selected = {}
        for name in names:
            local = self.local(name)
            pin = local / 'pinned-manifest.json'
            # start-intent.json is written before the bridge is, so a start whose ssh call failed still counts.
            intent = next((f for f in (local / 'start.json', local / 'start-intent.json') if f.is_file()), None)
            selected[name] = {'pinnedSha256': sha256_file(pin) if pin.is_file() else None,
                              'bridgeCommandSha256': json.loads(intent.read_text()).get('bridgeCommandSha256')
                              if intent else None}
        report = {'dryRun': dry_run, 'selected': names, 'unstaged': {}}
        if not names:
            report['plan'] = None
            return report
        facts = self.host_query('sweep-facts', probe=False, args={'runs': names})
        plan = hoststate.plan_sweep(selected, facts, drive=self.layout.drive)
        report['plan'] = plan
        # A run another staged run of this store reuses (--reuse-from junctions its components) stays staged.
        reusers = {}
        for other in (self.store.iterdir() if self.store.is_dir() else ()):
            meta = other / 'stage.json'
            if meta.is_file() and other.name in hoststate._list(facts.get('stagedNames')):
                source = json.loads(meta.read_text()).get('reusedFrom')
                if source:
                    reusers.setdefault(source, []).append(other.name)
        for name, entry in plan['runs'].items():
            if entry.get('unstage') and reusers.get(name):
                entry['unstage'] = False
                entry['notes'].append(f"still reused by staged run(s) {', '.join(sorted(reusers[name]))}; not unstaged")
        # A run kept staged because something unproven still uses its root needs attention: it counts as failed.
        report['failed'] = sorted(n for n, e in plan['runs'].items() if e.get('blockers') or e.get('settingsBlocked'))
        if not dry_run:
            failed = set()
            if plan['stop'] or plan['bridge'] or plan['close'] or plan['settings']:
                applied = self.host_query('sweep-apply', probe=False,
                                          args={'stop': plan['stop'], 'bridge': plan['bridge'], 'close': plan['close'],
                                                'settings': plan['settings']})
                applied = applied or {}
                report['applied'] = applied
                failed |= {row['run'] for row in hoststate._list(applied.get('stopped'))
                           if not row.get('stopped') and row.get('skipped') != 'already exited'}
                failed |= {row['run'] for row in hoststate._list(applied.get('bridges')) if not row.get('restored')}
                restored = {row['run'] for row in hoststate._list(applied.get('settings')) if row.get('restored')}
                failed |= {t['run'] for t in plan['settings'] if t['run'] not in restored}
                if plan['close']:
                    close = applied.get('close') or {}
                    # An answer that is not JSON proves no window closed: the run stays staged (review F6).
                    output: dict
                    try:
                        output = parse_json(close['output'], what='sweep close probe') if close.get('output') else {}
                    except CommandFailed as error:
                        output = {'error': str(error)}
                    if not isinstance(output, dict):
                        output = {'error': f'sweep close probe answered {output!r}, not an object'}
                    close['output'] = output
                    gone = {(row.get('handle'), row.get('run')) for row in hoststate._list(output.get('closed'))
                            if row.get('gone')}
                    # A window that is not proven gone keeps its run staged: unstaging deletes owned-window.json,
                    # the only proof that the window is the run's.
                    failed |= {t['run'] for t in plan['close'] if (t['handle'], t['run']) not in gone}
            report['failed'] = sorted(failed | set(report['failed']))
            for name, entry in plan['runs'].items():
                if not (entry['owned'] and entry.get('unstage')):
                    continue
                if name in failed:
                    report['unstaged'][name] = {'skipped': 'a process stop, window close, bridge or settings restore '
                                                           'did not complete'}
                    continue
                try:
                    report['unstaged'][name] = self.unstage(name)
                except RemoteError as error:
                    report['unstaged'][name] = {'error': str(error)}
                    report['failed'].append(name)
        for name in names:
            if (self.local(name) / 'pinned-manifest.json').is_file():
                self._records(name).put_json('sweep-dry-run' if dry_run else 'sweep',
                                             {'dryRun': dry_run, 'plan': plan['runs'][name],
                                              'applied': report.get('applied'),
                                              'unstaged': report['unstaged'].get(name)}, kind='sweep')
        return report

    def free_bytes(self) -> int:
        return int(self.transport.ps('(Get-PSDrive ' + self.layout.drive + ').Free'))

    def runtime_sha256(self) -> str:
        return self.transport.ps('(Get-FileHash -Algorithm SHA256 -LiteralPath ' + quote(self.layout.runtime)
                                 + ').Hash.ToLowerInvariant()').strip().lower()

    def task_ready(self) -> bool:
        return self.transport.ps('(Get-ScheduledTask ' + quote(self.layout.task) + ').State.ToString()').strip() == 'Ready'

    def list_destination(self, remote: str) -> str:
        return self.transport.ps(LIST_SCRIPT.format(root=quote(remote)), timeout=600)

    # -- local records ---------------------------------------------------------------------
    def local(self, run: str) -> Path:
        return self.store / check_run_id(run)

    def _records(self, run: str) -> EvidenceStore:
        return EvidenceStore(self.local(run), run)

    def _pinned(self, run: str) -> tuple[dict, str]:
        raw = (self.local(run) / 'pinned-manifest.json').read_bytes()
        return json.loads(raw), sha256_bytes(raw)

    # -- verification gate -------------------------------------------------------------------
    def verify(self, run: str, *, allowed=()) -> dict:
        """List the whole remote run root and compare it with the pin. Always recorded."""
        pinned, pinned_sha = self._pinned(run)
        report = destination_report(pinned, pinned_sha, self.list_destination(self.layout.remote(run)),
                                    allowed=allowed)
        self._records(run).put_json('destination-verification', report, kind='destination-verification')
        return report

    # -- stage --------------------------------------------------------------------------------
    def stage(self, run: str, *, components: dict[str, Path], app_name: str, scenario: Path | None = None,
              app_env: dict[str, str] | None = None, reuse_from: str | None = None,
              platform: str = 'win-x64', excludes=pinning.DEFAULT_EXCLUDES, required=pinning.REQUIRED,
              minimum_free_bytes: int = 50_000_000, runtime_sha256: str | None = None,
              expect_flow_fault: str | None = None) -> dict:
        check_run_id(run)
        expectation = flow_check.expectation_bytes(expect_flow_fault)
        if reuse_from:
            check_run_id(reuse_from)
            if not (self.local(reuse_from) / 'pinned-manifest.json').is_file():
                raise CallRefused(f'--reuse-from {reuse_from}: this store ({self.store}) has no staged run of that ID')
        env = appenv.check({name: str(value).replace('{RUN}', self.layout.remote(run).replace('/', '\\'))
                            for name, value in (app_env or {}).items()}, host='windows')
        local = self.local(run)
        local.mkdir(parents=True, exist_ok=False)
        records = self._records(run)
        write_new_json(local / 'app-env.json', env)
        # The expected-fault declaration (or its absence) is a pinned control file, so the stage-end,
        # start and host checks all prove which expectation run.ps1 applies.
        write_new(local / 'flow-expectation.json', expectation)
        control = {'run.ps1': RUNNER, 'NativeSession.ps1': LIBRARY, 'window.ps1': WINDOW_HELPER,
                   'app-env.json': local / 'app-env.json', 'flow-expectation.json': local / 'flow-expectation.json'}
        if scenario:
            control['scenario.ps1'] = Path(scenario)
        pinned = pinning.pin(components, platform, required=required, excludes=excludes, control=control,
                             app_name=app_name)
        pinned_raw = (json.dumps(pinned, indent=2, sort_keys=True) + '\n').encode()
        write_new(local / 'pinned-manifest.json', pinned_raw)
        pinned_sha = sha256_bytes(pinned_raw)
        lint_report = self._lint_control(control)
        records.put_json('lint', lint_report, kind='lint')

        observed_runtime = self.runtime_sha256()
        if runtime_sha256 and observed_runtime != runtime_sha256.lower():
            raise LaunchRefused(f'Host runtime {observed_runtime} differs from the required {runtime_sha256}')

        reused = self._reusable(pinned, reuse_from) if reuse_from else {}
        upload_bytes = sum(meta['bytes'] for name, comp in pinned['components'].items() if name not in reused
                           for meta in comp['files'].values())
        free = self.free_bytes()
        if free - upload_bytes < minimum_free_bytes:
            raise LaunchRefused(f'Insufficient disk reserve: free {free}, upload {upload_bytes}')
        if not self.task_ready():
            raise LaunchRefused('User-session task is not Ready')
        remote = self.layout.remote(run)
        self.transport.ps('if(Test-Path -LiteralPath ' + quote(remote) + "){throw 'Run exists'};"
                          'New-Item -ItemType Directory -Path ' + quote(remote) + '|Out-Null')
        sources = pinning.bundle_sources(pinned)
        with tempfile.TemporaryDirectory(prefix='.upload-', dir=local) as bundle_root:
            bundle_root = Path(bundle_root)
            for name, component in pinned['components'].items():
                if name in reused:
                    self.transport.ps('New-Item -ItemType Junction -Path ' + quote(remote + '/' + name)
                                      + ' -Target ' + quote(reused[name]) + '|Out-Null')
                    continue
                for rel in component['files']:
                    source, target = sources[f'{name}/{rel}'], bundle_root / name / rel
                    target.parent.mkdir(parents=True, exist_ok=True)
                    try:
                        os.link(source, target)
                    except OSError:
                        shutil.copy2(source, target)
                    if sha256_file(target) != component['files'][rel]['sha256']:
                        raise pinning.PinError(f'Source changed after pinning: {name}/{rel}')
                self.transport.upload(bundle_root / name, remote + '/' + name, recursive=True)
        self.transport.upload(local / 'pinned-manifest.json', remote + '/pinned-manifest.json')
        parsed = self._json("$errs=@();foreach($f in @(Get-ChildItem -LiteralPath " + quote(remote + '/control')
                            + " -Filter '*.ps1')){$t=$null;$e=$null;[void][Management.Automation.Language.Parser]"
                            "::ParseFile($f.FullName,[ref]$t,[ref]$e);if($e.Count){$errs+=$f.Name+': '+($e|Out-String)}};"
                            "try{$x=(Get-Content -LiteralPath " + quote(remote + '/control/flow-expectation.json')
                            + " -Raw -Encoding UTF8|ConvertFrom-Json).expectedFault;if($null -ne $x){[void][regex]::new([string]$x)}}"
                            "catch{$errs+='flow-expectation.json: '+$_.ToString()};"
                            "@{errors=@($errs)}|ConvertTo-Json -Depth 3", what='stage parse check')
        if parsed.get('errors'):
            raise LaunchRefused(f'Staged PowerShell does not parse: {parsed["errors"]}')
        report = self.verify(run)
        free_after = self.free_bytes()
        meta = {'run': run, 'remote': remote, 'host': getattr(self.transport, 'host', None),
                'appName': app_name, 'platform': platform, 'pinnedManifestSha256': pinned_sha,
                'runtime': {'path': self.layout.runtime, 'sha256': observed_runtime,
                            'required': runtime_sha256},
                'flowExpectation': {'expectedFault': flow_check.check_pattern(expect_flow_fault),
                                    'sha256': sha256_bytes(expectation)},
                'processors': {'dotnetProcessorCount': appenv.processors(env, None)['dotnetProcessorCount']},
                'lint': {k: lint_report.get(k) for k in ('ok', 'files', 'findings', 'skipped')},
                'reusedFrom': reuse_from, 'reusedComponents': reused, 'uploadBytes': upload_bytes,
                'freeBeforeStage': free, 'freeAfterStage': free_after, 'minimumFreeBytes': minimum_free_bytes,
                'verification': {k: report[k] for k in ('ok', 'missingComponents', 'missing', 'unexpected',
                                                        'mismatched', 'componentCounts')}}
        write_new_json(local / 'stage.json', meta)
        records.put_json('stage', meta, kind='stage')
        if not report['ok']:
            raise LaunchRefused('Staged destination does not match the pin', report)
        if free_after < minimum_free_bytes:
            raise LaunchRefused(f'Post-stage reserve insufficient: {free_after}')
        return meta

    @staticmethod
    def _lint_control(control: dict[str, Path]) -> dict:
        """PSScriptAnalyzer (bug rules, nativeq/lint.py) on the PowerShell this run pins. Findings are recorded in the
        run's evidence and stage.json, and printed by the CLI; they do not refuse the stage. A linter that cannot run
        is recorded as skipped."""
        from . import lint
        files = {name: Path(path) for name, path in control.items() if name.endswith('.ps1')}
        # Keyed by name and content (and the rule settings): the same bytes always give the same findings.
        key = tuple(sorted((name, sha256_file(path)) for name, path in files.items())) + (sha256_file(lint.PSSA_SETTINGS),)
        if key not in _LINT_CACHE:
            try:
                report = lint.pssa(sorted(files.values()))
            except (CallRefused, CommandFailed) as error:
                return {'ok': None, 'files': sorted(files), 'findings': [], 'skipped': str(error)}
            except subprocess.TimeoutExpired as error:
                return {'ok': None, 'files': sorted(files), 'findings': [], 'skipped': f'PSScriptAnalyzer timed out: {error}'}
            names = {str(path): name for name, path in files.items()}
            _LINT_CACHE[key] = {'tool': report.get('tool'), 'version': report.get('version'), 'findings': [
                {'file': names.get(f['path'], f['path']), 'line': f['line'], 'rule': f['rule'], 'message': f['message']}
                for f in report['findings']]}
        cached = _LINT_CACHE[key]
        return {'ok': not cached['findings'], 'files': sorted(files), 'findings': list(cached['findings']), 'skipped': None,
                'tool': cached['tool'], 'version': cached['version']}

    def _reusable(self, pinned: dict, reuse_from: str) -> dict[str, str]:
        """Components whose pin equals a previous run's pin and whose remote copy verifies."""
        prior, prior_sha = self._pinned(reuse_from)
        same = {name for name, comp in pinned['components'].items() if name != 'control'
                and prior['components'].get(name, {}).get('files') == comp['files']}
        if not same:
            return {}
        subset = {'components': {name: pinned['components'][name] for name in same}}
        files, _, anomalies = parse_listing(self.list_destination(self.layout.remote(reuse_from)))
        observed = {k: v for k, v in files.items() if k.split('/', 1)[0] in same}
        report = pinning.compare(subset, observed)
        if not report['ok'] or anomalies:
            raise LaunchRefused(f'Reuse source {reuse_from} no longer matches its pin', report)
        return {name: self.layout.remote(reuse_from) + '/' + name for name in sorted(same)}

    # -- start ---------------------------------------------------------------------------------
    def start(self, run: str, *, mode: str = 'Scenario', app_args: str = '', ready: str = 'Ready',
              verify_only: bool = False, skip_preflight: bool = False, strict: bool = False,
              min_cpus: int = hoststate.DEFAULT_MIN_CPUS) -> dict:
        if mode not in ('Scenario', 'Smoke'):
            raise ValueError(mode)
        if not _APP_ARGS.match(app_args):
            raise ValueError('Unsafe app arguments')
        local = self.local(run)
        stage = json.loads((local / 'stage.json').read_text())
        if (local / 'start-intent.json').is_file() and not (local / 'start.json').is_file():
            raise LaunchRefused(f'{run} was started before and that start did not finish (start-intent.json without '
                                'start.json): its command may be on the bridge. Run `windows sweep --run '
                                f'{run}` (it restores the bridge if so) and start a new run ID.')
        records = self._records(run)
        # Host preflight first: a FAIL refuses before any launch gate; skipping it is recorded with the run.
        if skip_preflight:
            preflight = {'skipped': True, 'reason': '--skip-preflight'}
            records.put_json('preflight-skipped', preflight, kind='preflight')
        else:
            full = self.preflight(min_cpus=min_cpus, strict=strict, run=run)
            records.put_json('preflight', full, kind='preflight')
            preflight = {'skipped': False, 'status': full['status'], 'strict': strict,
                         'processorCount': full['processorCount'],
                         'failed': [f['check'] for f in full['findings'] if f['level'] == hoststate.FAIL],
                         'warned': [f['check'] for f in full['findings'] if f['level'] == hoststate.WARN]}
            if full['status'] == hoststate.FAIL:
                records.put_json('launch-refused', {'reason': 'preflight', 'preflight': preflight}, kind='launch-gate')
                raise LaunchRefused('Host preflight failed: ' + ', '.join(preflight['failed']), full)
        env = json.loads((local / 'app-env.json').read_text()) if (local / 'app-env.json').is_file() else {}
        processors = appenv.processors(env, preflight.get('processorCount'))
        report = self.verify(run)
        gate = {'destination': report['ok']}
        if not report['ok']:
            records.put_json('launch-refused', {'reason': 'destination', 'report': report}, kind='launch-gate')
            raise LaunchRefused('Destination does not match the pinned manifest; launch refused', report)
        runtime = self.runtime_sha256()
        gate['runtime'] = runtime == stage['runtime']['sha256']
        free = self.free_bytes()
        gate['reserve'] = free > stage['minimumFreeBytes']
        gate['taskReady'] = self.task_ready()
        if not all(gate.values()):
            records.put_json('launch-refused', {'gate': gate, 'runtime': runtime, 'free': free}, kind='launch-gate')
            raise LaunchRefused(f'Launch gate failed: {gate}')
        if verify_only:
            records.put_json('launch-gate-passed', {'gate': gate, 'verifyOnly': True, 'preflight': preflight},
                             kind='launch-gate')
            return {'gate': gate, 'launched': False, 'preflight': preflight}
        remote = stage['remote']
        call = ('& ' + quote(remote + '/control/run.ps1') + ' -Root ' + quote(remote) + ' -Mode ' + mode
                + ' -RuntimeSha256 ' + quote(stage['runtime']['sha256']) + ' -AppName ' + quote(stage['appName'])
                + ' -AppArguments ' + quote(app_args) + ' -Ready ' + quote(ready)
                + ' -Dotnet ' + quote(self.layout.runtime.replace('/', '\\'))
                + ' -Bridge ' + quote(self.layout.bridge.replace('/', '\\')))
        command = bridge_command(call, self.layout.shell, restore=(remote + '/bridge-before.txt', self.layout.bridge))
        bridge, before = quote(self.layout.bridge), quote(remote + '/bridge-before.txt')
        command_sha = sha256_bytes(command.encode())
        # Recorded before the bridge is written: if this call fails after Start-ScheduledTask, `sweep` can still
        # recognise the run's command on the bridge and restore it.
        write_new_json(local / 'start-intent.json', {'run': run, 'bridgeCommandSha256': command_sha})
        out = self.transport.ps(
            "if((Get-ScheduledTask " + quote(self.layout.task) + ").State.ToString() -ne 'Ready'){throw 'Task not Ready'};"
            "[IO.File]::Copy(" + bridge + "," + before + ",$false);"
            "try{[IO.File]::WriteAllText(" + bridge + "," + quote(command) + ");Start-ScheduledTask " + quote(self.layout.task)
            + "}catch{Copy-Item -LiteralPath " + before + " -Destination " + bridge + " -Force;throw};"
            "Get-ScheduledTask " + quote(self.layout.task) + "|Select-Object TaskName,@{n='State';e={$_.State.ToString()}}|ConvertTo-Json")
        record = {'gate': gate, 'mode': mode, 'appArguments': app_args, 'flowExpectation': stage.get('flowExpectation'),
                  'preflight': preflight, 'processors': processors, 'shell': self.layout.shell,
                  'bridgeCommandSha256': command_sha,
                  'task': parse_json(out, what='task state after start', allow_empty=True)}
        write_new_json(local / 'start.json', record)
        records.put_json('started', record, kind='launch')
        return record

    def monitor(self, run: str, wait: float | None = None, poll: float = 30,
                sleep=time.sleep, clock=time.monotonic) -> dict:
        """One snapshot {task, result}. With `wait` (seconds), poll every `poll` seconds until the run has written
        result.json and the task is Ready again (so `retain` may follow), or until `wait` passes; the snapshot then
        carries waited.timedOut."""
        remote = self.layout.remote(check_run_id(run))
        result = quote(remote + '/result.json')
        script = ("$r=$null;if(Test-Path -LiteralPath " + result + "){$r=Get-Content -LiteralPath " + result
                  + " -Raw -Encoding UTF8|ConvertFrom-Json};@{task=(Get-ScheduledTask " + quote(self.layout.task)
                  + ").State.ToString();result=$r}|ConvertTo-Json -Depth 12")
        snapshot = self._json(script, what='monitor snapshot')
        if wait is None:
            return snapshot
        deadline = clock() + wait
        while not (snapshot['result'] is not None and snapshot['task'] == 'Ready'):
            left = deadline - clock()
            if left <= 0:
                return dict(snapshot, waited={'timedOut': True, 'seconds': wait})
            sleep(min(poll, left))
            snapshot = self._json(script, what='monitor snapshot')
        return dict(snapshot, waited={'timedOut': False, 'seconds': wait})

    # -- retain / unstage ------------------------------------------------------------------------
    def retain(self, run: str) -> dict:
        """Copy everything except the runtime components, then validate the evidence ledger."""
        if not self.task_ready():
            raise RemoteError('User-session task still running; retain after it returns to Ready')
        local = self.local(run)
        pinned, _ = self._pinned(run)
        runtime = {name for name in pinned['components'] if name != 'control'}
        remote = self.layout.remote(run)
        names = self._json('ConvertTo-Json -InputObject @(Get-ChildItem -LiteralPath ' + quote(remote)
                           + ' -Force|Select-Object -ExpandProperty Name) -Compress', what='retain listing')
        if isinstance(names, str):
            names = [names]
        retained = local / 'retained'
        retained.mkdir(exist_ok=False)
        for name in names:
            if '/' in name or '\\' in name or name in ('.', '..'):
                raise RemoteError(f'Unsafe remote name {name!r}')
            if name in runtime:
                continue
            self.transport.download(remote + '/' + name, retained, recursive=True)
        ledger = retained / 'evidence.jsonl'
        if ledger.exists():
            report = validate_manifest(retained, ledger, ignore=RUN_FILE_GLOBS)
        else:
            report = {'ok': False, 'error': 'evidence.jsonl absent from retained run'}
        self._records(run).put_json('retention-validation', report, kind='retention-validation')
        return report

    def unstage(self, run: str) -> dict:
        """Delete this tool's remote run directory: junctions are unlinked, never followed."""
        _, pinned_sha = self._pinned(run)
        remote = self.layout.remote(run)
        observed = self.transport.ps('(Get-FileHash -Algorithm SHA256 -LiteralPath '
                                     + quote(remote + '/pinned-manifest.json') + ').Hash.ToLowerInvariant()').strip()
        if observed != pinned_sha:
            raise RemoteError('Remote run is not the one this store staged; not removing it')
        script = ("$root=(Get-Item -LiteralPath " + quote(remote) + ").FullName;"
                  "foreach($i in @(Get-ChildItem -LiteralPath $root -Force)){if($i.Attributes -band [IO.FileAttributes]::ReparsePoint){$i.Delete()}};"
                  "if(@(Get-ChildItem -LiteralPath $root -Recurse -Force -Attributes ReparsePoint).Count){throw 'Nested reparse point; not removing'};"
                  "Remove-Item -LiteralPath $root -Recurse -Force;@{removed=!(Test-Path -LiteralPath $root);free=(Get-PSDrive "
                  + self.layout.drive + ").Free}|ConvertTo-Json")
        record = self._json(script, timeout=600, what='unstage')
        self._records(run).put_json('unstaged', record, kind='unstage')
        return record
