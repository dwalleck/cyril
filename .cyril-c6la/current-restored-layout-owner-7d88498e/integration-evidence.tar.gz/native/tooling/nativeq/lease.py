"""Live hosts only under their GUI lease.

`T/tools/with-gui-lease --host linux|windows|both` exports `NATIVEQ_LEASE=<linux|windows|both>` to the session it
wraps. A command that launches or probes a host (the Linux run, every `windows` action, smoke-windows.py) calls
`require` first and is refused without a lease covering that host; read-only local commands never ask."""
from __future__ import annotations

import os

from .refusal import CallRefused

ENV = 'NATIVEQ_LEASE'
COVERS = {'linux': {'linux'}, 'windows': {'windows'}, 'both': {'linux', 'windows'}}


class LeaseMissing(CallRefused):
    """The command touches a host this process holds no lease for."""


def require(host: str, what: str | None = None) -> None:
    """Return when NATIVEQ_LEASE covers `host` ('linux' or 'windows'); otherwise raise LeaseMissing naming the lease."""
    if host not in ('linux', 'windows'):
        raise ValueError(f'unknown host {host!r}')
    value = os.environ.get(ENV)
    if host in COVERS.get(value or '', ()):
        return
    held = f'{ENV} is not set' if not value else f'{ENV} is {value!r}'
    raise LeaseMissing(f'{what or "this command"} touches the {host} host and needs the {host} GUI lease ({held}); '
                       f'run it inside T/tools/with-gui-lease --host {host} (or both) <track> -- …')
