"""Windows host state: `windows preflight` findings and `windows sweep` ownership.

`windows/host-query.ps1` only collects facts (one ssh round trip; the window list comes from
`windows/user-probe.ps1`, started in the user's session through the bridge). Every decision is made here, from
those facts, so the rules are testable against recorded host output:

- `evaluate_preflight(facts)` turns facts into OK/WARN/FAIL findings.
- `plan_sweep(selected, facts)` decides which processes, windows, bridge commands and run directories a sweep
  may touch. Ownership is proven, never inferred from titles: a run is ours only when the host's
  `pinned-manifest.json` hashes to the one in our store; a process is ours only when it matches the run's
  recorded identity (`owned-process.json`: pid, name, creation time, app path), or is the run's own
  `cmd.exe /c <root>\\launch.cmd` or a dotnet.exe child of it, started after the root was created; a window is
  ours only when it matches `owned-window.json`
  (handle, Windows Terminal pid and creation time, window class). Everything else is reported as foreign.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
HOST_QUERY = HERE / 'windows' / 'host-query.ps1'
USER_PROBE = HERE / 'windows' / 'user-probe.ps1'

OK, WARN, FAIL = 'OK', 'WARN', 'FAIL'
_RANK = {OK: 0, WARN: 1, FAIL: 2}
FOCUS_STEALERS = ('msedge.exe', 'OneDrive.exe', 'MoNotificationUx.exe', 'Widgets.exe')
TERMINAL = 'WindowsTerminal.exe'
DEFAULT_MIN_CPUS = 4
DEFAULT_MIN_FREE_BYTES = 1_000_000_000
_SESSION_ROW = re.compile(r'^\s*>?(?P<user>\S+)\s+(?:(?P<name>\S+)\s+)?(?P<id>\d+)\s+(?P<state>Active|Disc|Conn|Listen|'
                          r'Shadow|Idle|Down|Init|Reset)\s+(?P<idle>\S+)\s+(?P<logon>.+?)\s*$')
_APP_DLL = re.compile(r'\\app\\[^\\"]+\.dll', re.IGNORECASE)


def query_script(action: str, *, drive: str, task: str, bridge: str, runtime: str, shell: str, probe: bool = True,
                 timeout: int = 45, args=None, settings: str = '') -> str:
    """The host-query script with its inputs prepended (PowerShell single-quoted literals)."""
    def lit(text):
        return "'" + str(text).replace("'", "''") + "'"
    head = (f"$NqAction={lit(action)};$NqDrive={lit(drive)};$NqTask={lit(task)};"
            f"$NqBridge={lit(bridge)};$NqRuntime={lit(runtime)};$NqShell={lit(shell)};"
            f"$NqProbe=${'true' if probe else 'false'};$NqTimeout={int(timeout)};"
            f"$NqArgs={lit(json.dumps(args) if args is not None else '')};$NqSettings={lit(settings)};"
            f"$NqProbeScript={lit(USER_PROBE.read_text())};\n")
    return head + HOST_QUERY.read_text()


# -- facts -----------------------------------------------------------------------------------------------
def parse_query_user(text: str) -> list[dict]:
    """Rows of `query user`. A disconnected session has no session name; 'No User exists' gives no rows."""
    rows = []
    for line in (text or '').splitlines()[1:]:
        match = _SESSION_ROW.match(line)
        if match:
            row = match.groupdict()
            rows.append({'user': row['user'], 'session': row['name'], 'id': int(row['id']), 'state': row['state'],
                         'idle': row['idle'], 'logon': row['logon']})
    return rows


def _json_text(text):
    if not text:
        return None
    try:
        return json.loads(text)
    except ValueError:
        return None


def _list(value):
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def run_roots(facts: dict, drive: str = 'C') -> dict[str, str]:
    """Run name -> its root as it appears in command lines (`<drive>:\\<run>\\`, lower case)."""
    return {run['name']: f'{drive}:\\{run["name"]}\\'.lower() for run in _list(facts.get('stagedRuns'))}


def _run_of(process: dict, roots: dict[str, str]) -> str | None:
    line = (process.get('commandLine') or '').lower().replace('/', '\\')
    for name, root in roots.items():
        if root in line:
            return name
    return None


def run_name(root: str | None) -> str:
    """A run root as a launch command names it (drive, separator, run ID) -> the run ID."""
    return re.sub(r'^[A-Za-z]:[\\/]', '', root or '').strip('\\/')


def _recorded(run: dict, key: str):
    return _json_text(run.get(key))


def _matches_owned_process(process: dict, owned: dict | None) -> bool:
    return bool(owned and process.get('pid') == owned.get('pid') and process.get('name') == owned.get('name')
                and process.get('created') == owned.get('created') and owned.get('app')
                and owned['app'].lower() in (process.get('commandLine') or '').lower())


def _matches_owned_window(window: dict, owned: dict | None, processes: list[dict]) -> bool:
    if not owned or window.get('handle') != owned.get('handle') or window.get('pid') != owned.get('pid') \
            or window.get('class') != owned.get('class'):
        return False
    owner = [p for p in processes if p.get('pid') == owned.get('pid')]
    return len(owner) == 1 and owner[0].get('name') == TERMINAL and owner[0].get('created') == owned.get('processCreated')


def probe_output(facts: dict) -> dict | None:
    probe = facts.get('probe') or {}
    out = _json_text(probe.get('output')) if probe.get('ran') else None
    return out if isinstance(out, dict) and out.get('ok') else None


def _probe_answer_problem(raw) -> str:
    """Why a probe answer is not a successful report: empty, not JSON, its own error, or some other JSON."""
    if not raw or not str(raw).strip():
        return 'no output'
    try:
        answer = json.loads(raw)
    except ValueError:
        return f'answer is not JSON: {str(raw)[:300]}'
    if isinstance(answer, dict) and answer.get('error'):
        return str(answer['error'])
    return f'answer is not a successful probe report: {str(raw)[:300]}'


def shown(window: dict) -> bool:
    """A window a user could see: visible, not cloaked by DWM, and with an area."""
    return not window.get('cloaked') and (window.get('width') or 0) > 0 and (window.get('height') or 0) > 0


# A side shorter than this is a sliver no user would see or click (a minimised window's placeholder is 160x28).
MIN_ON_SCREEN_SIDE = 16


def _overlaps(window: dict, monitor: dict) -> bool:
    def span(rect, start, size):
        low = rect.get(start) or 0
        return low, low + (rect.get(size) or 0)
    (wl, wr), (wt, wb) = span(window, 'left', 'width'), span(window, 'top', 'height')
    (ml, mr), (mt, mb) = span(monitor, 'left', 'width'), span(monitor, 'top', 'height')
    return wl < mr and ml < wr and wt < mb and mt < wb


def on_screen(window: dict, monitors: list[dict] | None = None) -> bool:
    """A window that could take focus in front of the user: shown, visible, not minimised, not a sliver, and at least
    partly on a monitor. `monitors` are the probe's monitor rectangles; without them (an older probe) the window counts
    wherever it is."""
    return (shown(window) and window.get('visible', True) and not window.get('minimized')
            and (window.get('width') or 0) >= MIN_ON_SCREEN_SIDE and (window.get('height') or 0) >= MIN_ON_SCREEN_SIDE
            and (not monitors or any(_overlaps(window, m) for m in monitors)))


# -- display power and lock -----------------------------------------------------------------------------------
# The task's action runs powershell.exe with -WindowStyle Hidden, which a console host such as Windows Terminal ignores;
# a headless console host gives it no window at all. Reported for the user's approval; nativeq never changes the task.
BRIDGE_WINDOW_FIX = ("set the JanetUserSession action to `conhost.exe --headless powershell.exe <its current arguments>` "
                     '(or start it through a windowless launcher)')
DISPLAY_CHECKS = ('display-off', 'sleep', 'screen-saver', 'lock-on-resume')
_AC_INDEX = re.compile(r'Current AC Power Setting Index:\s*0x([0-9a-fA-F]+)')
# What the user would run to make each check OK (reported for approval; preflight never changes the host).
DISPLAY_FIXES = {
    'display-off': 'powercfg /change monitor-timeout-ac 0',
    'sleep': 'powercfg /change standby-timeout-ac 0',
    'consoleLock': 'powercfg /setacvalueindex SCHEME_CURRENT SUB_NONE CONSOLELOCK 0; powercfg /setactive SCHEME_CURRENT',
    'screen-saver': "Set-ItemProperty -Path 'HKCU:\\Control Panel\\Desktop' -Name ScreenSaveActive -Value 0",
    'secureSaver': "Set-ItemProperty -Path 'HKCU:\\Control Panel\\Desktop' -Name ScreenSaverIsSecure -Value 0",
    'inactivity': 'remove the InactivityTimeoutSecs policy (HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System)',
}


def ac_index(text) -> int | None:
    """The AC value of one `powercfg /qh SCHEME_CURRENT <group> <setting>` output, or None when it is not there."""
    match = _AC_INDEX.search(text or '')
    return int(match.group(1), 16) if match else None


def standby_states(text) -> list[str] | None:
    """The standby (sleep) states `powercfg /a` lists as available, or None when the text is not that output.
    Hibernate is not a standby state: STANDBYIDLE only puts the host into standby."""
    if not text or 'sleep states are' not in text:
        return None
    available, section = [], None
    for line in text.splitlines():
        if 'sleep states are available' in line:
            section = 'available'
        elif 'sleep states are not available' in line:
            section = 'unavailable'
        elif section == 'available' and line.strip().startswith('Standby'):
            available.append(line.strip())
    return available


def _display_findings(facts: dict, add, strict: bool, console_user: str | None):
    """Display-off, sleep, screen saver and lock settings of the console user: WARN by default, FAIL with strict.
    A setting that could not be read is WARN (FAIL with strict) too: nothing proves it harmless."""
    bad = FAIL if strict else WARN
    display = facts.get('display')
    if not isinstance(display, dict):
        for check in DISPLAY_CHECKS:
            add(check, bad, 'Display power and lock settings were not collected (older host-query output)')
        return
    for check, key, what, never in (('display-off', 'videoIdle', 'The display turns off', 'The display never turns off on AC'),
                                    ('sleep', 'standbyIdle', 'The host sleeps', 'The host never sleeps on AC')):
        seconds = ac_index(display.get(key))
        states = standby_states(display.get('sleepStates')) if check == 'sleep' else None
        if check == 'sleep' and states == []:
            add(check, OK, f'The host has no sleep state (powercfg /a), so the sleep timeout ({seconds} s on AC) cannot '
                           'apply', seconds=seconds, standbyStates=[])
        elif seconds is None:
            add(check, bad, f'{what} after an unknown idle time: powercfg output could not be read',
                raw=display.get(key))
        elif seconds:
            where = f" (available: {', '.join(states)})" if states else ''
            add(check, bad, f'{what} after {seconds} s idle on AC{where}; a run that waits without input can lose the '
                            f'desktop (fix, for approval: {DISPLAY_FIXES[check]})', seconds=seconds)
        else:
            add(check, OK, never, seconds=0)
    user, policy = display.get('screenSaver') or {}, display.get('screenSaverPolicy') or {}

    def value(name):
        return policy.get(name) if policy.get(name) is not None else user.get(name)
    exe, timeout, active = value('SCRNSAVE.EXE'), value('ScreenSaveTimeOut'), value('ScreenSaveActive')
    saver = active == '1' and bool((exe or '').strip())
    secure = saver and value('ScreenSaverIsSecure') == '1'
    other_user = console_user and display.get('user') and display['user'].lower() != console_user.lower()
    if other_user:
        add('screen-saver', bad, f"Screen saver settings were read for {display['user']}, not the console user "
                                 f'{console_user}', user=display['user'])
    elif saver:
        add('screen-saver', bad, f"A screen saver ({exe}) starts after {timeout or 'an unset'} s idle"
                                 f"{' and locks the session' if secure else ''} (fix, for approval: "
                                 f"{DISPLAY_FIXES['screen-saver']})", exe=exe, timeout=timeout, secure=secure)
    else:
        add('screen-saver', OK, 'No screen saver', active=active, exe=exe)
    locks, fixes = [], []
    lock = ac_index(display.get('consoleLock'))
    if lock is None:
        locks.append('password on wakeup unknown (powercfg output could not be read)')
    elif lock:
        locks.append('a password on wakeup is required on AC (CONSOLELOCK)')
        fixes.append(DISPLAY_FIXES['consoleLock'])
    if secure:
        locks.append('the screen saver locks the session')
        fixes.append(DISPLAY_FIXES['secureSaver'])
    inactivity = display.get('inactivityTimeoutSecs')
    if inactivity not in (None, '', '0'):
        locks.append(f'machine inactivity limit {inactivity} s locks the session')
        fixes.append(DISPLAY_FIXES['inactivity'])
    if locks:
        add('lock-on-resume', bad, 'The session can lock: ' + '; '.join(locks)
            + (f" (fix, for approval: {'; '.join(fixes)})" if fixes else ''), reasons=locks)
    else:
        add('lock-on-resume', OK, 'No password on wakeup, no locking screen saver, no inactivity limit')


def _settings_finding(facts: dict, add, run: str | None, runtime_hashes: dict[str, str]):
    """Windows Terminal's settings.json must be a baseline, not some run's run-time file: one that exports into a
    run's scratch directory (other than the run about to start, while it is staged) or whose hash a run recorded
    writing (owned-settings.json on the host, or in this store's retained runs). Saved as the next run's baseline, such
    a file outlives its run directory (windowsrf23-keypaths-r1 -> r2, r3: 'Native buffer export absent')."""
    terminal = facts.get('terminalSettings')
    if not isinstance(terminal, dict):
        add('terminal-settings', WARN, 'Windows Terminal settings.json was not checked (older host-query output)')
        return
    staged = {r['name']: r for r in _list(facts.get('stagedRuns'))}
    problems = []
    for buffer in _list(terminal.get('runBuffers')):
        name = buffer.get('run')
        if name == run and name in staged:
            continue
        where = f'staged run {name}' if name in staged else f'{name}, which is no longer staged'
        problems.append(f"it exports into {buffer.get('path')} ({where})")
    recorded = dict(runtime_hashes)
    for name, entry in staged.items():
        written = (_recorded(entry, 'ownedSettings') or {}).get('writtenSha256')
        if written:
            recorded.setdefault(written, name)
    sha = terminal.get('sha256')
    if sha and sha in recorded and recorded[sha] != run:
        problems.append(f'its hash {sha[:12]}... is the run-time file run {recorded[sha]} recorded writing')
    if problems:
        names = sorted({b.get('run') for b in _list(terminal.get('runBuffers'))} | ({recorded[sha]} if sha in recorded else set()))
        add('terminal-settings', FAIL, "Windows Terminal settings.json is a run's run-time file: " + '; '.join(problems)
            + '. Restore it with `windows sweep --run <run>` from the store that started '
            + ', '.join(n for n in names if n) + ", or from that run's settings-before.json",
            sha256=sha, runBuffers=terminal.get('runBuffers'))
    elif not sha:
        add('terminal-settings', WARN, f"Windows Terminal settings.json not found at {terminal.get('path')}")
    else:
        add('terminal-settings', OK, f'Windows Terminal settings.json is not a run-time file ({sha[:12]}...)', sha256=sha)


# -- preflight -------------------------------------------------------------------------------------------
def evaluate_preflight(facts: dict, *, min_cpus: int = DEFAULT_MIN_CPUS, strict: bool = False,
                       min_free_bytes: int = DEFAULT_MIN_FREE_BYTES, run: str | None = None,
                       drive: str = 'C', runtime_hashes: dict[str, str] | None = None) -> dict:
    """Findings for one host-query `preflight` result. `run` is the run about to start (its own staging is
    expected). `runtime_hashes` maps Windows Terminal settings hashes that runs recorded writing (their
    owned-settings.json, from the local store) to the run. Returns {status, findings, ...}; status is the worst
    finding."""
    findings = []

    def add(check, level, message, **details):
        findings.append({'check': check, 'level': level, 'message': message, **({'details': details} if details else {})})

    # Interactive console session: JanetUserSession is an interactive-logon task and runs only for a logged-on user.
    sessions = parse_query_user((facts.get('sessions') or {}).get('text', ''))
    active = [s for s in sessions if s['state'] == 'Active']
    console = None
    if not active:
        add('session', FAIL, 'No Active interactive session: log on to the console (the user-session task cannot run)',
            sessions=sessions, raw=(facts.get('sessions') or {}).get('text'))
    else:
        console = [s for s in active if (s['session'] or '').lower() == 'console'] or active
        add('session', OK, f"Active session {console[0]['id']} ({console[0]['user']}, {console[0]['session']}, idle "
                           f"{console[0]['idle']})", sessions=sessions)

    cpu = facts.get('processors') or {}
    count = cpu.get('processorCount')
    topology = dict(processorCount=count, sockets=cpu.get('sockets'), cores=cpu.get('cores'), logical=cpu.get('logical'))
    if not isinstance(count, int) or count < min_cpus:
        add('processors', FAIL, f'Windows uses {count} processors (minimum {min_cpus}); with {cpu.get("sockets")} '
                                f'socket(s) and {cpu.get("cores")} core(s) in use, check the VM topology: Windows 11 Pro uses '
                                "at most 2 sockets, so give libvirt <topology sockets='1' cores='N'/>", **topology)
    elif (cpu.get('sockets') or 0) > 1 and cpu.get('cores') == cpu.get('sockets'):
        add('processors', WARN, f'{count} processors as {cpu.get("sockets")} single-core sockets; prefer one socket '
                                'with N cores', **topology)
    else:
        add('processors', OK, f'{count} processors ({cpu.get("sockets")} socket(s), {cpu.get("cores")} core(s))', **topology)

    task = facts.get('task')
    add('task', OK if task == 'Ready' else FAIL,
        'User-session task is Ready' if task == 'Ready' else f'User-session task is {task}; a run may be in progress')

    # A run's launch command still on the bridge (its run.ps1 never started, e.g. nobody was logged on) would be
    # saved by the next start as its bridge-before.txt and restored after it, so it would never go away.
    # A command whose run is no longer staged can launch nothing (its run.ps1 is gone): WARN. One whose run is
    # still staged without a result never ran: FAIL.
    live = sorted({run_name(root) for root in _list(facts.get('liveRuns'))})
    if live:
        add('run-in-progress', FAIL, f"run.ps1 is running for {', '.join(live)}: another run is in progress", runs=live)
    bridge_run = facts.get('bridgeRun')
    if 'bridgeRun' in facts:
        name = run_name(bridge_run)
        pending = {r['name']: r for r in _list(facts.get('stagedRuns'))}.get(name)
        if not bridge_run:
            add('bridge', OK, 'The bridge holds no run launch command')
        elif pending and not pending.get('hasResult'):
            add('bridge', FAIL, f'The bridge still holds the launch command of staged run {name}, which never ran; '
                                "restore the bridge from its bridge-before.txt (`windows sweep --run` from the store "
                                'that started it)', run=name)
        else:
            add('bridge', WARN, f'The bridge idles on the launch command of {name}, which is no longer pending; it '
                                'cannot start that run, but the bridge has no neutral idle line', run=name)

    shell = facts.get('hostShell') or {}
    add('powershell', OK if shell.get('present') else FAIL,
        f"PowerShell 7 present at {shell.get('path')}" if shell.get('present') else
        f"PowerShell 7 missing at {shell.get('path')}; install it machine-wide (README)",
        sshPsVersion=facts.get('psVersion'), path=shell.get('path'))

    probe = facts.get('probe') or {}
    out = probe_output(facts)
    if probe.get('skipped') == 'disabled':
        add('user-session', WARN, 'Window probe disabled (--no-window-probe): windows and focus were not checked')
    elif out is None:
        reason = probe.get('skipped') or probe.get('error') or _probe_answer_problem(probe.get('output'))
        add('user-session', FAIL, f'User-session probe did not run: {reason}', probe=probe)
    elif probe.get('bridgeRestored') is False:
        add('user-session', FAIL, 'User-session probe ran but the bridge was not restored by hash', probe=probe)
    else:
        add('user-session', OK, f"User-session probe ran in session {out.get('sessionId')} in {probe.get('seconds')} s "
                                f"(PowerShell {out.get('psVersion')}, {out.get('apartment')})",
            sessionId=out.get('sessionId'), psVersion=out.get('psVersion'), apartment=out.get('apartment'))
    windows = _list(out.get('windows')) if out else []
    monitors = _list(out.get('monitors')) if out else []
    # The probe names the user-session task's own processes (`bridge`) and marks their windows: the action script's
    # console is the harness's own window, never a leftover or a foreign app (windowsrf23-keypaths-r1 sweep).
    if out and isinstance(out.get('bridge'), dict):
        mine = [w for w in windows if w.get('bridge') and shown(w)]
        if mine:
            add('bridge-window', WARN, f"The user-session task's own console window is visible ('{mine[0].get('title')}', "
                                       f"{mine[0].get('process')}): the task's -WindowStyle Hidden did not hide it (a console "
                                       'host such as Windows Terminal ignores it). It is the harness, not a foreign app. '
                                       f'Fix, for approval: {BRIDGE_WINDOW_FIX}', windows=mine,
                actionPid=out['bridge'].get('actionPid'))
        else:
            add('bridge-window', OK, "The user-session task's own console window is hidden",
                actionPid=out['bridge'].get('actionPid'))
    windows = [w for w in windows if not w.get('bridge')] + [dict(w, ignored='bridge') for w in windows if w.get('bridge')]

    processes = _list(facts.get('processes'))
    roots = run_roots(facts, drive)
    staged = {r['name']: r for r in _list(facts.get('stagedRuns'))}
    owned_apps = {name: _recorded(r, 'ownedProcess') for name, r in staged.items()}

    def describe(p):
        return {k: p.get(k) for k in ('pid', 'name', 'session', 'createdUtc', 'commandLine')} | {'run': _run_of(p, roots)}

    apps, other_dotnet = [], []
    for p in processes:
        line = p.get('commandLine') or ''
        janet = 'janet' in p.get('name', '').lower() or (p.get('name') == 'dotnet.exe' and
                                                         (_APP_DLL.search(line) or 'janet' in line.lower()))
        if janet:
            row = describe(p)
            row['recordedBy'] = next((n for n, o in owned_apps.items() if _matches_owned_process(p, o)), None)
            apps.append(row)
        elif p.get('name') == 'dotnet.exe':
            other_dotnet.append(describe(p))
    if apps:
        add('janet-apps', FAIL, f'{len(apps)} Janet app process(es) already running (leftover from another run)',
            processes=apps)
    else:
        add('janet-apps', OK, 'No Janet app running')
    if other_dotnet:
        add('dotnet', WARN, f'{len(other_dotnet)} other dotnet process(es) in the interactive session', processes=other_dotnet)

    launches = [describe(p) for p in processes if p.get('name') == 'cmd.exe' and _run_of(p, roots)]
    if launches:
        add('run-processes', FAIL, f'{len(launches)} launch.cmd process(es) of staged runs still running', processes=launches)

    terminals = [describe(p) for p in processes if p.get('name') == TERMINAL]
    consoles = [describe(p) for p in processes if p.get('name') == 'OpenConsole.exe']
    if out is None:
        if terminals:
            add('terminal-windows', WARN, 'Windows Terminal is running; its windows could not be listed',
                terminals=terminals, openConsole=consoles)
        else:
            add('terminal-windows', OK, 'Windows Terminal is not running')
    else:
        term_windows = [w for w in windows if w.get('process') == 'WindowsTerminal' and shown(w) and not w.get('bridge')]
        leftovers, others = [], []
        for w in term_windows:
            owner = next((n for n, r in staged.items()
                          if _matches_owned_window(w, _recorded(r, 'ownedWindow'), processes)), None)
            row = dict(w, run=owner)
            (leftovers if owner or 'janet' in (w.get('title') or '').lower() else others).append(row)
        if leftovers:
            add('terminal-windows', FAIL, f'{len(leftovers)} Windows Terminal window(s) left from another run',
                windows=leftovers, openConsole=consoles)
        if others:
            add('terminal-windows', WARN, f'{len(others)} other Windows Terminal window(s) open', windows=others)
        if not leftovers and not others:
            add('terminal-windows', OK, 'No Windows Terminal window open', terminals=terminals, openConsole=consoles)

    for name in FOCUS_STEALERS:
        present = [p['pid'] for p in processes if p.get('name') == name]
        label = name[:-4]
        if not present:
            add('focus:' + label, OK, f'{label} not running')
            continue
        if out is None:
            add('focus:' + label, WARN, f'{label} is running ({len(present)} process(es)); window visibility unknown',
                pids=present)
            continue
        theirs = [w for w in windows if w.get('pid') in present]
        visible = [w for w in theirs if on_screen(w, monitors)]
        # Shown but not on screen (Edge's background "New tab" window, minimised at -32000): kept as evidence.
        off_screen = [w for w in theirs if shown(w) and not on_screen(w, monitors)]
        if visible:
            add('focus:' + label, FAIL if strict else WARN,
                f'{label} has {len(visible)} visible window(s) and can take focus from the run', windows=visible)
        elif off_screen:
            add('focus:' + label, OK, f'{label} running without a window on screen ({len(present)} process(es); '
                                      f'{len(off_screen)} window(s) minimised, hidden, off screen or too small)',
                pids=present, offScreen=off_screen)
        else:
            add('focus:' + label, OK, f'{label} running without a visible window ({len(present)} process(es))', pids=present)

    if out is not None:
        fg = out.get('foreground')
        hidden = '' if not fg or fg.get('visible', True) else ' (not visible)'
        if fg and fg.get('process') == 'LockApp':
            add('foreground', FAIL, 'The session is locked (LockApp has the foreground): unlock the console', window=fg)
        elif not fg:
            add('foreground', WARN, 'No foreground window (the session may be locked or on another desktop)')
        elif fg.get('bridge'):
            add('foreground', OK, f"Foreground: the user-session task's own console (the probe's task) '{fg.get('title')}'"
                                  f'{hidden}', window=fg)
        else:
            add('foreground', OK, f"Foreground: {fg.get('process')} '{fg.get('title')}'{hidden}", window=fg)

    _display_findings(facts, add, strict, (console or [{}])[0].get('user') if active else None)

    _settings_finding(facts, add, run, runtime_hashes or {})

    free = facts.get('freeBytes')
    if not isinstance(free, int) or free < min_free_bytes:
        add('disk', FAIL, f'{drive}: has {free} bytes free (minimum {min_free_bytes})')
    else:
        add('disk', OK, f'{drive}: has {free / 1e9:.1f} GB free')

    others = [dict(name=n, createdUtc=r.get('createdUtc'), hasResult=r.get('hasResult'), resultOk=r.get('resultOk'))
              for n, r in sorted(staged.items()) if n != run]
    add('staged-runs', OK, f'{len(others)} staged run director(y/ies) on the host' + (f' besides {run}' if run else ''),
        runs=others)

    status = max((f['level'] for f in findings), key=lambda level: _RANK[level], default=OK)
    return {'schema': 'nativeq.preflight/1', 'status': status, 'strict': strict, 'minCpus': min_cpus,
            'processorCount': count, 'findings': findings, 'facts': facts}


def summary(report: dict) -> str:
    lines = [f"preflight: {report['status']}"]
    for f in report['findings']:
        lines.append(f"  {f['level']:<4} {f['check']:<18} {f['message']}")
    return '\n'.join(lines)


# -- sweep -----------------------------------------------------------------------------------------------
def plan_sweep(selected: dict[str, dict], facts: dict, *, drive: str = 'C') -> dict:
    """What a sweep may touch. `selected` maps each named run to its local record:
    {'pinnedSha256': ..., 'bridgeCommandSha256': ... or None}. `facts` is a host-query `sweep-facts` result.

    Returns {runs: {run: {...}}, stop: [...], bridge: [...], close: [...], foreign: [...]}. Nothing outside the
    proven runs is ever in stop/bridge/close; every watched process left alone is listed under foreign."""
    processes = _list(facts.get('processes'))
    host_runs = {r['name']: r for r in _list(facts.get('stagedRuns'))}
    live_runs = {run_name(root) for root in _list(facts.get('liveRuns'))}
    plan = {'runs': {}, 'stop': [], 'bridge': [], 'close': [], 'settings': [], 'foreign': []}
    terminal = facts.get('terminalSettings') or {}
    claimed: set[int] = set()
    for name, local in sorted(selected.items()):
        host = host_runs.get(name)
        entry = {'owned': False, 'staged': host is not None, 'stop': [], 'close': [], 'notes': []}
        plan['runs'][name] = entry
        if host is None:
            entry['notes'].append('not staged on the host')
            continue
        if not local.get('pinnedSha256'):
            entry['notes'].append('this store did not stage the run: not ours, left alone')
            continue
        if host.get('pinnedSha256') != local['pinnedSha256']:
            entry['notes'].append('host pinned-manifest.json differs from this store: not ours, left alone')
            continue
        entry['owned'] = True
        if name in live_runs or (facts.get('task') != 'Ready' and not host.get('hasResult')):
            # Its run.ps1 is running (seen in a PowerShell command line), or the task is busy and the run has no
            # result. The task state alone cannot tell: the action script returns while run.ps1 still runs.
            entry['notes'].append('the run may be live (run.ps1 running, or task busy without a result); '
                                  'nothing stopped, closed or unstaged')
            entry['live'] = True
            entry['unstage'] = False
            continue
        root = f'{drive}:\\{name}\\'.lower()
        # run.ps1 starts `cmd.exe /c <root>\launch.cmd` (through Windows Terminal) and launch.cmd runs the app.
        launch = re.compile(r'\s/c\s+"?' + re.escape(drive.lower() + ':') + r'[\\/]' + re.escape(name.lower())
                            + r'[\\/]launch\.cmd"?\s*$')
        owned_app = _recorded(host, 'ownedProcess')
        staged_at = host.get('createdUtc') or '~'  # '~' sorts after every timestamp: nothing counts as newer
        launches = {p['pid']: p for p in processes if p.get('name') == 'cmd.exe' and (p.get('createdUtc') or '') >= staged_at
                    and launch.search((p.get('commandLine') or '').lower())}
        for p in processes:
            parent = launches.get(p.get('parent'))
            if _matches_owned_process(p, owned_app):
                reason = 'recorded app identity (owned-process.json)'
            elif p.get('pid') in launches:
                reason = "the run's launch.cmd, started after the run was staged"
            elif p.get('name') == 'dotnet.exe' and parent \
                    and (p.get('createdUtc') or '') >= (parent.get('createdUtc') or '~'):
                reason = "child of the run's launch.cmd"
            else:
                if owned_app and p.get('pid') == owned_app.get('pid'):
                    entry['notes'].append(f"pid {p['pid']} is no longer the recorded app (identity changed); left alone")
                continue
            target = {k: p.get(k) for k in ('pid', 'name', 'created', 'commandLine')} | {'run': name, 'reason': reason}
            entry['stop'].append(target)
            plan['stop'].append(target)
            claimed.add(p['pid'])
        window = _recorded(host, 'ownedWindow')
        if window:
            owner = [p for p in processes if p.get('pid') == window.get('pid') and p.get('name') == TERMINAL
                     and p.get('created') == window.get('processCreated')]
            if owner:
                target = {k: window.get(k) for k in ('handle', 'pid', 'processCreated', 'class')} | {'run': name}
                entry['close'].append(target)
                plan['close'].append(target)
            else:
                entry['notes'].append('recorded window: its Windows Terminal process is gone or restarted')
        else:
            entry['notes'].append('no owned-window.json: any window of this run cannot be proven ours')
        if local.get('bridgeCommandSha256') and facts.get('bridgeSha256') == local['bridgeCommandSha256']:
            if host.get('bridgeBefore'):
                plan['bridge'].append({'run': name, 'root': f'{drive}:\\{name}', 'commandSha256': local['bridgeCommandSha256']})
                entry['notes'].append('bridge still holds this run\'s command: restore from bridge-before.txt')
            else:
                entry['notes'].append('bridge still holds this run\'s command and bridge-before.txt is absent')
                entry['keepStaged'] = True
        # Windows Terminal's settings.json still being this run's run-time file (the run was stopped before run.ps1
        # restored it): proven by the hash the run recorded writing, or by its exportBuffer into this run's own scratch
        # directory (Windows Terminal rewrites the file after loading it). Restored from the run's settings-before.json;
        # unstaging first would leave Terminal exporting into a deleted directory (windowsrf23-keypaths-r1 -> r2, r3).
        owned_settings = _recorded(host, 'ownedSettings') or {}
        current = terminal.get('sha256')
        buffer_runs = sorted({b.get('run') for b in _list(terminal.get('runBuffers'))})
        if current and (current == owned_settings.get('writtenSha256') or name in buffer_runs):
            # settings.json is shared by every run on the host, and settings-before.json may itself be a stale run-time
            # file (windowsrf23-keypaths-r2/r3): restore only when neither can be the case (review F4).
            others = [r for r in buffer_runs if r != name]
            before_runs = _list(host.get('settingsBeforeRunBuffers'))
            busy = live_runs or facts.get('task') != 'Ready'
            if busy or others or before_runs:
                why = ('another run may be live (run.ps1 running or the task busy)' if busy else
                       f"it also exports into run(s) {', '.join(others)}" if others else
                       f"settings-before.json is itself a run-time file (run(s) {', '.join(before_runs)})")
                entry['notes'].append("Windows Terminal settings.json is this run's run-time file but is not restored: "
                                      f'{why}; not unstaged')
                entry['keepStaged'] = True
                entry['settingsBlocked'] = True  # needs attention: `windows sweep` reports the run as failed
            elif host.get('settingsBefore'):
                target = {'run': name, 'root': f'{drive}:\\{name}', 'sha256': current}
                plan['settings'].append(target)
                entry['notes'].append("Windows Terminal settings.json is this run's run-time file: restore it from "
                                      'settings-before.json')
            else:
                entry['notes'].append("Windows Terminal settings.json is this run's run-time file and "
                                      'settings-before.json is absent; not unstaged')
                entry['keepStaged'] = True
        # Anything else still using the run root would make unstaging fail part-way (a loaded DLL), possibly after
        # pinned-manifest.json is gone, leaving a run nobody can see or sweep: keep it staged.
        # Windows Terminal and OpenConsole load nothing from the root (Terminal's own command line names launch.cmd
        # when run.ps1's `wt.exe -w new ... cmd.exe /c <root>\launch.cmd` started it), so they never block.
        mine = {t['pid'] for t in entry['stop']}
        users = [p['pid'] for p in processes if p.get('pid') not in mine
                 and p.get('name') not in (TERMINAL, 'OpenConsole.exe')
                 and root in (p.get('commandLine') or '').lower().replace('/', '\\')]
        if users:
            entry['notes'].append(f"process(es) {', '.join(map(str, users))} not proven the run's still use its root; "
                                  'not unstaged')
            entry['blockers'] = users
            entry['keepStaged'] = True
        entry['unstage'] = not entry.get('keepStaged')
    plan['foreign'] = [{k: p.get(k) for k in ('pid', 'name', 'createdUtc', 'commandLine')}
                       for p in processes if p.get('pid') not in claimed]
    return plan
