"""`python3 -m nativeq lint <paths...>`: static checks for harness and control scripts.

- Python (`*.py`): pyright with `pyrightconfig.json` next to the package. Its `extraPaths` puts this directory on the
  import path, so a control script anywhere (a ticket's `controls/`) resolves `import nativeq...`. Errors are findings;
  warnings (the Optional-access family, noisy in untyped scenario code) are reported but do not fail.
- PowerShell (`*.ps1`, `*.psm1`, dot-sourced `*.ps1.inc`): PSScriptAnalyzer with `PSScriptAnalyzerSettings.psd1`,
  bug-finding rules only (no naming, style or formatting rules). Every finding fails.

A directory is searched recursively (`__pycache__`, `bin`, `obj` skipped). A path that is not there, or a linter that is
missing, refuses the call (exit 2): a lint that did not run never passes. `NATIVEQ_PYRIGHT` and `NATIVEQ_PWSH` name the
tools (default: `pyright` and `pwsh` on PATH).
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

from .command import CommandFailed, parse_json
from .refusal import CallRefused, existing

HERE = Path(__file__).resolve().parent.parent
PYRIGHT_CONFIG = HERE / 'pyrightconfig.json'
PSSA_SETTINGS = HERE / 'PSScriptAnalyzerSettings.psd1'
SKIP_DIRS = {'__pycache__', 'bin', 'obj', '.git'}
POWERSHELL_SUFFIXES = ('.ps1', '.psm1', '.ps1.inc')

_PSSA = r"""
$ErrorActionPreference='Stop'
Import-Module PSScriptAnalyzer
$rows=foreach($f in @($env:NQ_LINT_FILES|ConvertFrom-Json)){
 # Invoke-ScriptAnalyzer -Path skips files it does not take for PowerShell (a dot-sourced *.ps1.inc): pass their text.
 $found=$(if($f -like '*.ps1' -or $f -like '*.psm1'){Invoke-ScriptAnalyzer -Path $f -Settings $env:NQ_LINT_SETTINGS}
  else{Invoke-ScriptAnalyzer -ScriptDefinition ([IO.File]::ReadAllText($f)) -Settings $env:NQ_LINT_SETTINGS})
 foreach($d in @($found)){
  [ordered]@{path=$f;line=$d.Line;column=$d.Column;rule=$d.RuleName;severity=$d.Severity.ToString();message=$d.Message}}}
[ordered]@{version=(Get-Module PSScriptAnalyzer).Version.ToString();findings=@($rows)}|ConvertTo-Json -Depth 4 -Compress
"""


def collect(paths) -> tuple[list[Path], list[Path]]:
    """(python files, powershell files) under `paths`, absolute and sorted; a missing path is refused."""
    python, powershell = set(), set()
    for given in paths:
        path = existing(given, f'lint path {given}')
        candidates = [path] if path.is_file() else [p for p in path.rglob('*') if p.is_file()
                                                     and not SKIP_DIRS & set(p.relative_to(path).parts[:-1])]
        for file in candidates:
            name = file.name.lower()
            if name.endswith('.py'):
                python.add(file)
            elif name.endswith(POWERSHELL_SUFFIXES):
                powershell.add(file)
    if not python and not powershell:
        raise CallRefused(f"nothing to lint under {', '.join(map(str, paths))} (no .py, .ps1, .psm1 or .ps1.inc file)")
    return sorted(python), sorted(powershell)


def _tool(variable: str, default: str) -> str:
    name = os.environ.get(variable) or default
    found = shutil.which(name)
    if not found:
        raise CallRefused(f'{default} is not available ({variable}={name!r}); install it or the lint cannot run')
    return found


def pyright(files: list[Path]) -> dict:
    exe = _tool('NATIVEQ_PYRIGHT', 'pyright')
    done = subprocess.run([exe, '-p', str(PYRIGHT_CONFIG), '--outputjson', *map(str, files)], capture_output=True,
                          text=True, timeout=600, env=dict(os.environ, PYRIGHT_PYTHON_IGNORE_WARNINGS='1'))
    if done.returncode not in (0, 1):  # 1 = diagnostics reported
        raise CommandFailed(f'pyright exit {done.returncode}: {done.stderr.strip()[-1500:] or done.stdout[-1500:]}',
                            exit=done.returncode, stdout=done.stdout, stderr=done.stderr)
    report = parse_json(done.stdout[done.stdout.find('{'):] if '{' in done.stdout else '', what='pyright --outputjson',
                        exit=done.returncode, stderr=done.stderr)
    findings = [{'path': d.get('file'), 'line': d['range']['start']['line'] + 1,
                 'column': d['range']['start']['character'] + 1, 'rule': d.get('rule') or 'pyright',
                 'severity': d.get('severity'), 'message': d.get('message', '')}
                for d in report.get('generalDiagnostics', []) if d.get('severity') in ('error', 'warning')]
    return {'tool': 'pyright', 'version': report.get('version'), 'config': str(PYRIGHT_CONFIG), 'findings': findings,
            'failing': sum(1 for f in findings if f['severity'] == 'error')}


def pssa(files: list[Path]) -> dict:
    exe = _tool('NATIVEQ_PWSH', 'pwsh')
    done = subprocess.run([exe, '-NoProfile', '-NonInteractive', '-Command', _PSSA], capture_output=True, text=True,
                          timeout=900, env=dict(os.environ, NQ_LINT_FILES=json.dumps(list(map(str, files))),
                                                NQ_LINT_SETTINGS=str(PSSA_SETTINGS)))
    if done.returncode:
        raise CallRefused('PSScriptAnalyzer did not run: ' + (done.stderr.strip()[-1500:] or done.stdout[-1500:]))
    report = parse_json(done.stdout, what='Invoke-ScriptAnalyzer', stderr=done.stderr)
    findings = [dict(f) for f in report.get('findings') or []]
    return {'tool': 'PSScriptAnalyzer', 'version': report.get('version'), 'settings': str(PSSA_SETTINGS),
            'findings': findings, 'failing': len(findings)}


def lint(paths, *, python: bool = True, powershell: bool = True) -> dict:
    py_files, ps_files = collect(paths)
    report = {'paths': [str(p) for p in paths], 'files': {'python': len(py_files), 'powershell': len(ps_files)}}
    report['python'] = pyright(py_files) if python and py_files else {'findings': [], 'failing': 0}
    report['powershell'] = pssa(ps_files) if powershell and ps_files else {'findings': [], 'failing': 0}
    report['counts'] = {'python': report['python']['failing'], 'powershell': report['powershell']['failing'],
                        'pythonWarnings': sum(1 for f in report['python']['findings'] if f['severity'] == 'warning')}
    report['ok'] = not (report['counts']['python'] or report['counts']['powershell'])
    return report


def summary(report: dict) -> str:
    lines = []
    for kind in ('python', 'powershell'):
        for f in report[kind]['findings']:
            lines.append(f"{f['path']}:{f['line']}:{f['column']}: {f['severity']} {f['rule']}: {f['message']}")
    counts = report['counts']
    lines.append(f"lint: {'OK' if report['ok'] else 'FINDINGS'} - python {counts['python']} error(s) "
                 f"({counts['pythonWarnings']} warning(s)) in {report['files']['python']} file(s), powershell "
                 f"{counts['powershell']} finding(s) in {report['files']['powershell']} file(s)")
    return '\n'.join(lines)
