"""Exact-PID process ownership on Linux.

A process is owned by identity, not by name: (pid, start time in clock ticks);
argv is recorded for the evidence only. Cleanup signals only a PID whose current identity still equals the
recorded one, so a recycled PID is never touched. There is deliberately no
name- or pattern-based kill here (never `pkill -f`/`pgrep -f`). The Windows
equivalent (`Stop-NqOwnedProcess` in `windows/NativeSession.ps1`) compares
process name, creation time and command line.
"""
from __future__ import annotations

import os
import signal
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

PROC = Path('/proc')


@dataclass(frozen=True)
class Identity:
    pid: int
    start: int  # clock ticks after boot; fixed at fork, so (pid, start) survives exec
    argv: tuple[str, ...] = field(compare=False)  # informational: may be pre-exec when adopted early

    def to_json(self) -> dict:
        return asdict(self)


def identity(pid: int, proc: Path = PROC) -> Identity | None:
    """Current identity of `pid`, or None if it is gone or a zombie."""
    try:
        stat = (proc / str(pid) / 'stat').read_text()
        argv = (proc / str(pid) / 'cmdline').read_bytes().split(b'\0')
    except (FileNotFoundError, ProcessLookupError, PermissionError):
        return None
    fields = stat.rsplit(')', 1)[1].split()
    if fields[0] in ('Z', 'X'):
        return None
    return Identity(pid, int(fields[19]), tuple(a.decode(errors='replace') for a in argv if a))


def children(pid: int, proc: Path = PROC) -> list[int]:
    out = []
    for task in (proc / str(pid) / 'task').glob('*'):
        try:
            out.extend(int(c) for c in (task / 'children').read_text().split())
        except OSError:
            continue
    return out


def descendants(pid: int, proc: Path = PROC) -> list[int]:
    seen, stack = [], [pid]
    while stack:
        for child in children(stack.pop(), proc):
            if child not in seen:
                seen.append(child)
                stack.append(child)
    return seen


class OwnedProcesses:
    """Registry of processes a run started, cleaned up strictly by recorded identity."""

    def __init__(self, proc: Path = PROC):
        self.proc = proc
        self.owned: list[Identity] = []

    def adopt(self, pid: int) -> Identity:
        ident = identity(pid, self.proc)
        if ident is None:
            raise ProcessLookupError(pid)
        if ident not in self.owned:
            self.owned.append(ident)
        return ident

    def adopt_descendants(self, pid: int) -> list[Identity]:
        return [self.adopt(child) for child in descendants(pid, self.proc) if identity(child, self.proc)]

    def alive(self, ident: Identity) -> bool:
        return identity(ident.pid, self.proc) == ident

    def terminate(self, ident: Identity, *, grace: float = 3.0) -> dict:
        """SIGTERM, then SIGKILL after `grace`, only while the identity still matches."""
        record = {'pid': ident.pid, 'start': ident.start, 'signals': [], 'skipped': None}
        for sig, wait in ((signal.SIGTERM, grace), (signal.SIGKILL, grace)):
            current = identity(ident.pid, self.proc)
            if current is None:
                break
            if current != ident:
                record['skipped'] = 'identity changed; process untouched'
                break
            try:
                os.kill(ident.pid, sig)
            except ProcessLookupError:
                break
            record['signals'].append(sig.name)
            deadline = time.monotonic() + wait
            while self.alive(ident) and time.monotonic() < deadline:
                time.sleep(0.05)
        record['gone'] = not self.alive(ident)
        return record

    def cleanup(self, *, grace: float = 3.0) -> list[dict]:
        """Terminate every still-matching owned process, newest first."""
        return [self.terminate(ident, grace=grace) for ident in reversed(self.owned)]
