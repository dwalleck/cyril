# shellcheck shell=bash
# Shared helpers for the coordination wrappers (with-build-slot, with-gui-lease). Source it.
#
# JANET_COORD_DIR is the directory that holds the build locks, the GUI lease and its queue. It defaults to the
# implementation run's directory; tests point it at a private scratch dir.
COORD_LIVE_DIR=/home/dwalleck/.claude/tmp/janet-console-implementation
COORD_DIR=${JANET_COORD_DIR:-$COORD_LIVE_DIR}

# coord_is_live: status 0 when COORD_DIR is the live run directory (production minimums apply).
coord_is_live() { [ "$(realpath -m -- "$COORD_DIR")" = "$(realpath -m -- "$COORD_LIVE_DIR")" ]; }

# proc_ppid PID / proc_start PID: parent pid and start time (clock ticks since boot) from /proc/PID/stat.
# The command name may contain spaces or ')', so parse after the last ')'.
_proc_stat_fields() { local s; s=$(cat "/proc/$1/stat" 2>/dev/null) || return 1; echo "${s##*) }"; }
proc_ppid() { local f a; f=$(_proc_stat_fields "$1") || return 1; read -r -a a <<< "$f"; echo "${a[1]}"; }
proc_start() { local f a; f=$(_proc_stat_fields "$1") || return 1; read -r -a a <<< "$f"; echo "${a[19]}"; }

# proc_alive PID START: the process exists and is the same incarnation (guards against pid reuse).
proc_alive() { [ -n "$1" ] && [ "$(proc_start "$1" 2>/dev/null)" = "$2" ]; }

# ancestors_of PID: PID's ancestors, nearest first (PID itself excluded), up to but not including pid 0.
ancestors_of() {
  local p=$1
  while p=$(proc_ppid "$p") && [ "${p:-0}" -gt 0 ]; do echo "$p"; done
}

# lock_held_in_ancestry FILE [PID]: print the pid of PID (default: the caller's shell, $$) or of one of its
# ancestors that holds an flock(2) lock on FILE through one of its open fds, and return 0; return 1 when none does.
# /proc/PID/fdinfo/FD lists the locks held through that open file description ("lock: … FLOCK …"), which covers
# `flock -o FILE cmd` (flock(1) is the ancestor), a shell that locked an fd it keeps open, and an fd inherited
# through exec.
lock_held_in_ancestry() {
  local file=$1 self=${2:-$$} p fd
  [ -e "$file" ] || return 1
  for p in "$self" $(ancestors_of "$self"); do
    for fd in /proc/"$p"/fd/*; do
      [ "$fd" -ef "$file" ] || continue
      if grep -q -E '^lock:[[:space:]]+[0-9]+: FLOCK ' "/proc/$p/fdinfo/${fd##*/}" 2>/dev/null; then
        echo "$p"; return 0
      fi
    done
  done
  return 1
}

# mentions_check_sh ARGS...: status 0 when a word of any argument (split on blanks, newlines, quotes and
# ; & | ( )) is a path whose
# last component is check.sh, so `tools/console/check.sh`, `./check.sh` and `bash -c 'cd x && ./check.sh'` match
# and `precheck.sh` does not. A name built at run time cannot be seen; check.sh's own guard covers that.
mentions_check_sh() {
  local a w words
  for a in "$@"; do
    read -r -d '' -a words <<< "${a//[;&|()\"\'$'\n'$'\t']/ }"
    for w in "${words[@]}"; do
      [ "${w##*/}" = check.sh ] && return 0
    done
  done
  return 1
}

# is_check_command ARGS...: the command itself is the console check: `<path>/tools/console/check.sh …` or
# `bash|sh <path>/tools/console/check.sh …` (a relative tools/console/check.sh counts too).
is_check_command() {
  local c=$1
  case ${1##*/} in bash|sh) c=${2:-} ;; esac
  case /$c in */tools/console/check.sh) return 0 ;; *) return 1 ;; esac
}

# fmt_secs N: N seconds as 1h02m03s / 2m03s / 3s.
fmt_secs() {
  local s=$1
  if [ "$s" -ge 3600 ]; then printf '%dh%02dm%02ds' $((s / 3600)) $((s % 3600 / 60)) $((s % 60))
  elif [ "$s" -ge 60 ]; then printf '%dm%02ds' $((s / 60)) $((s % 60))
  else printf '%ds' "$s"; fi
}
