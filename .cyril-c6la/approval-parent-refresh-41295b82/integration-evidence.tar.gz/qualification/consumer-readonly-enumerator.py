# Exported source enumerator for consumer reuse; NOT EXECUTED by qualifier.
# Same successful qualification frows body, parameterized only at its global inputs.
import os, stat, hashlib
from pathlib import Path as FP

def carows(worktree, source_scope, external34inputs):
    FWT = FP(worktree)
    F_SCOPE = source_scope
    F_EXT = external34inputs
    F_EXCLUDE = {"target", ".git", "node_modules", "__pycache__"}
    files=[]
    for rel in [*F_SCOPE,*F_EXT]:
        p=FWT/rel
        if p.is_file() or p.is_symlink():files.append(p)
        elif p.is_dir():files.extend(q for q in p.rglob('*') if (q.is_file() or q.is_symlink()) and not set(q.relative_to(FWT).parts)&F_EXCLUDE)
    out=[]
    for p in sorted(set(files),key=lambda q:q.relative_to(FWT).as_posix()):
        st=p.lstat();link=stat.S_ISLNK(st.st_mode);data=os.fsencode(os.readlink(p)) if link else p.read_bytes();mode='120000' if link else ('100755' if st.st_mode&0o111 else '100644');row={'path':p.relative_to(FWT).as_posix(),'mode':mode,'blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'sha256':hashlib.sha256(data).hexdigest()}
        if link:
            with p.open('rb') as f:row['referent_sha256']=hashlib.file_digest(f,'sha256').hexdigest()
        out.append(row)
    return out
