"""Prepared only. A new explicit Main GO is required before invoking this file."""

import argparse
import hashlib
import importlib.metadata
import inspect
import json
import os
from pathlib import Path
import runpy
import select
import signal
import sys
import time

import pyte

from wide_overwrite import WideOverwrite

HERE = Path(__file__).resolve().parent
HARNESS = HERE / "smoke.py"
PEER = HERE / "owned_peer.py"
PROOF = HERE / "decoder-proof.py"
SCENARIO = HERE / "c6la_scenario.py"
FAILURE_FIXTURE = HERE / "v2_failed_validation_2_11_0.jsonl"
BINARY = Path("/tmp/cyril-c6la-current-main038-default-qualified-20261022T051828480539Z")
OUTPUTS = {
    "truecolor": Path("/tmp/cyril-c6la-main038-consumer-prepared-niYHEjqJ/run-truecolor-original-runtime-once"),
}
QUALIFICATION = Path("/home/dwalleck/.claude/tmp/cyril-batch3-qualification-20261020-ipe924db/c6la-current-main038-integration-green-attempt1/canonical-handoff.json")
MANIFEST = QUALIFICATION.with_name("checked-current-main038.bounded-workspace-inputs.json")
SOURCE_DESCRIPTOR = "b5d45fe2b8c78d23b5e5e26f5f8ff963822822830d2b5d54cba39f85f6c2c157"
MANUAL_SOURCE_PINS = {
    "crates/cyril-ui/src/conversation_performance_tests.rs": "627d56b0e59b4761bfe4dd55ef3b8358abdb99158892d3f82067c6cc6f18a31e",
    "crates/cyril-ui/src/floor_tests.rs": "2ce6c6bb9dd41cd9a82b2c657232486918e86c8ab9a8f954e2421e6b1048affa",
    "crates/cyril-ui/src/tool_text_tests.rs": "4b1689b79a8a7b3715a7c29ac873239923fa37d18877a3e403b1cfc4933dc715",
    "crates/cyril-ui/src/traits.rs": "9892f7ca11b90c9158f83aa463bbee032ff064ac1d7b4a635dbf0e7d372c12f5",
    "crates/cyril-ui/src/widgets/chat/presentation.rs": "842a4d50103f13b273415f7a9ce77c59855be793d35d7138ee898c608adb7af6",
    "crates/cyril-ui/src/widgets/chat_layout/mod.rs": "28a4004ce917c4e4d9c5654323c987f962c30af1fd93d2ea52377d5c9f505db2",
    "crates/cyril-ui/src/widgets/chat_layout/wrap.rs": "68eab558852a4dfb05454b657dcd8186f0e877f9c1cc00f4438e95f1341778ad",
    "crates/cyril-ui/tests/v2_failed_validation.rs": "5a13798ae11916389c2855ba11f6eb1fd2df22e1c753c7ac7a74dcc162bef7d7"
}
PINS = {
    HARNESS: "3506f50b60ac495ab10383108de81a22b45bcf77b41f4d4887e9d19175987e05",
    PEER: "6c5b5b64f1e5d4ec306b6028e299a96340891961dfaf0cdb046dc2b1240f9cfe",
    HERE / "wide_overwrite.py": "0ce4ddf57372fb428355dc0f02088fb0fb1a75499ccd796f27b899f34a400beb",
    PROOF: "e0e744c261b360693a6352ca5225b452a1099bc836636bff718d7da6ce15ffd6",
    SCENARIO: "0f230351b67945f800b92da4d7141bfe06d0f0de0f5bf035618ba1a31303f79e",
    FAILURE_FIXTURE: "4b9ee48758874a98a4eb275e35632aa32f782550d2dfdc0f285c3ec6f576da0d",
    BINARY: "993a2fd5f32353b7d0701ca37281f5b7ad5c03e5d58b3e9e0c2e60da6de57388",
    QUALIFICATION: "018f7b4b70de5933d3bf1b59b89729638b55ce0a8ca94cf003c29266adbda484",
    MANIFEST: "f14e529a5bcec86983edac49be4b83958c86ea53b504eb9ee7299b22e4106f77",
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def owned_handles(output, observations):
    """Pin process identities before inspecting their exact private-run marker."""
    handles = []
    marker = ("CYRIL_PERF_SMOKE_ROOT=" + str(output)).encode()
    app = str(output / "isolated/cyril-tested").encode()
    peer_argv = [os.fsencode(sys.executable), os.fsencode(PEER)]
    for entry in Path("/proc").iterdir():
        if not entry.name.isdecimal():
            continue
        pid = int(entry.name)
        fd = None
        try:
            fd = os.pidfd_open(pid)
            environment = (entry / "environ").read_bytes().split(b"\0")
            if marker not in environment:
                continue
            argv = [arg for arg in (entry / "cmdline").read_bytes().split(b"\0") if arg]
            expected_home = ("HOME=" + str(output / "isolated/home")).encode()
            expected_path = ("PATH=" + str(output / "isolated/bin")).encode()
            command_matches = bool(argv) and (argv[0] == app or argv == peer_argv)
            if not command_matches or expected_home not in environment or expected_path not in environment:
                observations.append({"pid": pid, "ownership": "marker matched but command/private environment not proven; not signaled"})
                continue
            observations.append({"pid": pid, "ownership": "exact marker, command and private environment proven", "argv": [os.fsdecode(arg) for arg in argv], "pgid": os.getpgid(pid), "sid": os.getsid(pid)})
            handles.append((pid, fd))
            fd = None
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
        finally:
            if fd is not None:
                os.close(fd)
    return handles


def wait_handles(handles, seconds):
    pending = {fd for _, fd in handles}
    deadline = time.monotonic() + seconds
    while pending:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        ready, _, _ = select.select(list(pending), [], [], remaining)
        pending.difference_update(ready)
    return pending


def cleanup_owned(output, receipt):
    """Never signal a PID by number: pidfds retain only proven owned identities."""
    for sweep in range(2):
        handles = owned_handles(output, receipt["observations"])
        if not handles:
            break
        try:
            for pid, fd in handles:
                try:
                    signal.pidfd_send_signal(fd, signal.SIGTERM)
                    receipt["signals"].append({"pid": pid, "signal": "SIGTERM", "sweep": sweep})
                except ProcessLookupError:
                    pass
            pending = wait_handles(handles, 5)
            for pid, fd in handles:
                if fd in pending:
                    try:
                        signal.pidfd_send_signal(fd, signal.SIGKILL)
                        receipt["signals"].append({"pid": pid, "signal": "SIGKILL", "sweep": sweep})
                    except ProcessLookupError:
                        pass
            if wait_handles(handles, 5):
                raise RuntimeError("Proven marker-owned process did not exit after bounded cleanup")
        finally:
            for _, fd in handles:
                os.close(fd)
    survivors = owned_handles(output, receipt["observations"])
    try:
        receipt["surviving_proven_owned_pids"] = [pid for pid, _ in survivors]
        receipt["unproven_marker_pids"] = sorted({row["pid"] for row in receipt["observations"] if "not proven" in row["ownership"]})
        if survivors or receipt["unproven_marker_pids"]:
            raise RuntimeError("Owned cleanup could not attest an empty marker-owned process set")
        receipt["status"] = "COMPLETE — no proven-owned survivors or unproven marker matches"
    finally:
        for _, fd in survivors:
            os.close(fd)


def interrupted(signum, _frame):
    raise SystemExit(128 + signum)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--authorization", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--color-mode", choices=["truecolor"], required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    if output != OUTPUTS[args.color_mode] or output.exists():
        raise RuntimeError("Only the fresh exact selected-mode C6 output directory is permitted")
    authorization = json.loads(args.authorization.read_text())
    if authorization.get("go") is not True or authorization.get("scopes") != ["c6la"]:
        raise RuntimeError("A new explicit Main GO limited to c6la is required")
    color_modes = authorization.get("color_modes")
    if not isinstance(color_modes, list) or args.color_mode not in color_modes:
        raise RuntimeError("Main GO does not authorize the selected color mode")
    if Path(authorization.get("binary", "")).resolve() != BINARY or authorization.get("sha256") != PINS[BINARY]:
        raise RuntimeError("GO does not identify the same qualified App binary")
    if authorization.get("source_identity_kind") != "bounded-workspace-inputs-sha256" or authorization.get("checked_source_descriptor") != SOURCE_DESCRIPTOR:
        raise RuntimeError("GO does not identify the qualified bounded workspace inputs")
    if authorization.get("qualification_status") != "PASS" or authorization.get("qualification_receipt_sha256") != PINS[QUALIFICATION]:
        raise RuntimeError("Main must bind PASS to the actual complete qualification receipt")
    for path, expected in PINS.items():
        if digest(path) != expected:
            raise RuntimeError("Pinned input changed: " + str(path))
    qualification = json.loads(QUALIFICATION.read_text())
    if qualification.get("HEAD") != "31ff479539d6c69b6a61c571cbc999bafacdb856" or qualification.get("MERGE_HEAD") != "03838a501dad8be140acd78dc3fff4cae35fafef":
        raise RuntimeError("Qualification HEAD/held incoming merge binding differs")
    checked_source = qualification
    if (
        checked_source.get("source_descriptor") != SOURCE_DESCRIPTOR
        or checked_source.get("source_input_rows") != 506
        or checked_source.get("source_manifest") != str(MANIFEST)
        or checked_source.get("source_manifest_sha256") != PINS[MANIFEST]
    ):
        raise RuntimeError("Qualification does not bind the expected bounded source manifest")
    manifest = json.loads(MANIFEST.read_text())
    manual_hashes = MANUAL_SOURCE_PINS
    manifest_hashes = {row["path"]: row["sha256"] for row in manifest}
    if len(manifest) != 506 or not isinstance(manual_hashes, dict) or len(manual_hashes) != 8 or any(manifest_hashes.get(path) != sha256 for path, sha256 in manual_hashes.items()):
        raise RuntimeError("Qualification manual source hashes differ from the bounded manifest")
    product = next((record for record in qualification.get("binaries", []) if record.get("path") == str(BINARY)), {})
    binary_metadata = BINARY.stat()
    if (
        product.get("path") != str(BINARY)
        or product.get("sha256") != PINS[BINARY]
        or product.get("bytes") != 102704856
        or product.get("mode") != "0o755"
        or product.get("source_descriptor") != SOURCE_DESCRIPTOR
        or binary_metadata.st_size != product.get("bytes")
        or oct(binary_metadata.st_mode & 0o7777) != product.get("mode")
    ):
        raise RuntimeError("Qualification private product binary differs from the candidate")
    build = next((record for record in qualification.get("commands", []) if record.get("label") == product.get("command_label")), {})
    if (
        build.get("argv") != ["cargo", "build", "-p", "cyril", "--bins"]
        or build.get("source_descriptor") != SOURCE_DESCRIPTOR
        or build.get("source_input_rows") != 506
        or build.get("returncode") != 0
    ):
        raise RuntimeError("Qualification build receipt does not bind the checked source and successful default build")
    if importlib.metadata.version("pyte") != "0.8.2" or importlib.metadata.version("wcwidth") != "0.9.2":
        raise RuntimeError("Recorded decoder environment changed")
    decoder_file = inspect.getsourcefile(pyte.Screen)
    if decoder_file is None:
        raise RuntimeError("Installed decoder source cannot be identified")
    decoder_source = Path(decoder_file)
    if digest(decoder_source) != "43bcd10d5555f6a8e53a1f9c0e557a47ec801b3914533d5b51af5828a5242ecb":
        raise RuntimeError("Installed decoder source changed")
    adapter_source = (HERE / "wide_overwrite.py").read_text()
    exact_adapter = PROOF.read_text().split("def wide(cell):", 1)[1].split("# Independent installed terminal semantics", 1)[0]
    if adapter_source.split("def wide(cell):", 1)[1] != exact_adapter:
        raise RuntimeError("Adapter differs from the exact executed offline proof")
    if not hasattr(os, "pidfd_open") or not hasattr(signal, "pidfd_send_signal"):
        raise RuntimeError("Linux pidfd cleanup APIs are required before starting the consumer")
    cleanup_path = HERE / (output.name + "-cleanup.json")
    if cleanup_path.exists():
        raise RuntimeError("Cleanup receipt already exists; this bootstrap mode is single-use")
    receipt = {"output": str(output), "observations": [], "signals": [], "status": "STARTED", "adapter_sha256": digest(HERE / "wide_overwrite.py"), "bootstrap_sha256": digest(Path(__file__)), "original_harness_sha256": PINS[HARNESS], "proof_sha256": PINS[PROOF]}
    previous_screen = pyte.Screen
    previous_argv = sys.argv
    previous_handlers = {signum: signal.getsignal(signum) for signum in (signal.SIGTERM, signal.SIGHUP)}
    for signum in previous_handlers:
        signal.signal(signum, interrupted)
    try:
        pyte.Screen = WideOverwrite
        sys.argv = [str(HARNESS), "--authorization", str(args.authorization.resolve()), "--scope", "c6la", "--color-mode", args.color_mode, "--output", str(output)]
        runpy.run_path(str(HARNESS), run_name="__main__")
    finally:
        pyte.Screen = previous_screen
        sys.argv = previous_argv
        try:
            cleanup_owned(output, receipt)
        except BaseException as error:
            receipt["status"] = "FAIL — cleanup exception"
            receipt["error"] = repr(error)
            raise
        finally:
            for signum, handler in previous_handlers.items():
                signal.signal(signum, handler)
            with cleanup_path.open("x") as stream:
                json.dump(receipt, stream, indent=2)
                stream.write("\n")


if __name__ == "__main__":
    main()
