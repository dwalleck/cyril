"""Read-only preconditions shared by the native controller and its lease drain."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import signal
import sys

HERE = Path(__file__).resolve().parent
OUTPUT = Path('/tmp/cyril-final-overlay-native-retained-halfwidth-attempt3-20261022')
STARTED = OUTPUT.with_name(OUTPUT.name + '.started.json')
SCOPE = 'cyril-final-c6-mcp-x-native-retained-halfwidth'
PYTHON = Path('/usr/bin/python3.14')
NATIVEQ = Path('/home/dwalleck/.claude/tmp/janet-followups/integration/tools/native-qualification')


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def require_unstarted():
    require(not OUTPUT.exists() and not OUTPUT.is_symlink(), 'One-attempt output already exists')
    require(not STARTED.exists() and not STARTED.is_symlink(), 'One-attempt setup marker already exists')


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def checked_file(row):
    path = Path(row['path'])
    require(path.is_absolute() and path.is_file(), 'Missing pinned file: ' + str(path))
    require(digest(path) == row['sha256'], 'File bytes changed: ' + str(path))
    return path


def verify_pins(preparation):
    for name, row in preparation['files'].items():
        path = checked_file({'path': name, **row})
        require(str(path.resolve(strict=True)) == row['resolved'], 'Resolved file changed: ' + name)
        require(path.stat().st_size == row['bytes'], 'File size changed: ' + name)
        require(bool(path.stat().st_mode & 0o111) == row['executable'], 'Executable mode changed: ' + name)


def validate(authorization, binding, output, *, source=True):
    # No subprocesses, display access, output creation or capability probes here.
    preparation_path = HERE / 'preparation.json'
    preparation = load(preparation_path)
    auth = load(authorization)
    bound_path = Path(binding).resolve(strict=True)
    bound = load(bound_path)
    require(auth.get('go') is True and auth.get('issued_by') == 'Main' and auth.get('scope') == SCOPE,
            'Fresh explicit Main native GO required; old PTY/C6 GO is not valid')
    require(auth.get('preparation_sha256') == digest(preparation_path), 'Preparation SHA differs')
    require(auth.get('binding') == str(bound_path) and auth.get('binding_sha256') == digest(bound_path),
            'Main final-union binding differs')
    require(auth.get('output') == str(OUTPUT) and Path(output).absolute() == OUTPUT,
            'Output must be the exact exclusive one-attempt root')
    require(auth.get('started_marker') == str(STARTED), 'Exact one-attempt setup marker must be authorized')
    require(auth.get('attempt_limit') == 1 and auth.get('color_modes') == ['truecolor'],
            'Only one fixed-color native leg is allowed')
    require(auth.get('independent_preparation_review') == 'PASS', 'Independent preparation review missing')
    checked_file(auth['preparation_review'])
    require(bound.get('schema') == 'cyril.final-native-binding/1' and bound.get('state') == 'QUALIFIED_FINAL_UNION',
            'HELD: final qualified union/source/private-App binding missing')
    require(bound.get('features') == 'default' and bound.get('full_source_qualification') == 'PASS',
            'Full-source default-feature final-union qualification is required')
    require(auth.get('binary') == bound['binary'] and auth.get('source') == bound['source'],
            'Main GO must repeat the entire final binary/source contract')
    require(auth.get('producer_geometry') == bound['producer_geometry'], 'Main GO producer geometry contract differs')
    checked_file(bound['qualification_receipt'])
    checked_file(bound['producer_geometry']['receipt'])
    require(bound['producer_geometry'].get('persistent_c6_render_state') is True,
            'Final producer/diff/backend receipt must exercise persistent C6 RenderState')
    require(bound['producer_geometry'].get('native_geometry_not_inherited') is True,
            'Actual native initial reason crossing must be independently established, never inherited x/y')
    binary = checked_file(bound['binary'])
    require(binary == binary.resolve(strict=True) and '/target/' not in str(binary)
            and not binary.is_relative_to(Path(bound['source']['root'])),
            'Use a preserved immutable private App, never shared target/debug/cyril')
    require(binary.stat().st_size == bound['binary']['bytes'] and os.access(binary, os.X_OK),
            'Private App size/executable mismatch')
    require(Path(sys.executable).resolve(strict=True) == PYTHON,
            'Use /usr/bin/python3.14 explicitly; do not capability-check an alias or uv Python')
    require(callable(getattr(os, 'pidfd_open', None)) and callable(getattr(signal, 'pidfd_send_signal', None)),
            'Required Linux pidfd APIs missing; this is a callable check, not a capability probe')
    verify_pins(preparation)
    if source:
        verify_source(bound)
    return preparation, auth, bound


def verify_source(bound):
    source = bound['source']
    require(source.get('coverage') == 'full-final-union-qualified-input-roster',
            'A historical component/bounded-subset manifest is not the final source contract')
    root = Path(source['root']).resolve(strict=True)
    manifest_path = checked_file(source['manifest'])
    manifest = load(manifest_path)
    require(manifest['descriptor'] == source['descriptor'] and manifest['count'] == source['count'],
            'Final source manifest descriptor/count differs')
    rows = manifest['rows']
    require(len(rows) == source['count'] and len({row['path'] for row in rows}) == len(rows),
            'Final source roster has missing/duplicate rows')
    require(len(rows) > 0, 'Empty source roster')
    for row in rows:
        relative = Path(row['path'])
        path = root / relative
        require(not relative.is_absolute() and path.resolve(strict=True).is_relative_to(root),
                'Source row escapes final worktree: ' + str(relative))
        status = path.stat()
        require(status.st_size == row['bytes'] and bool(status.st_mode & 0o111) == row['executable']
                and digest(path) == row['sha256'], 'Final source input changed: ' + str(relative))
    # Roster completeness is Main's full-source qualification contract, not a
    # claim that counting a historical manifest discovers every final input.
    return {'descriptor': source['descriptor'], 'checked_paths': len(rows),
            'manifest_sha256': digest(manifest_path), 'bytes_hash_executable_modes': 'MATCH'}
