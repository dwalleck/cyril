"""X's retained-halfwidth keys/payload/refusals; Ghostty is the only terminal.

Native exports support text/wire checks, not decoded cells. Physical columns,
whole glyphs, caret and crossing ownership remain mandatory PNG + final producer
review obligations; no pyte, inner PTY, WidthOverwrite or historical x/y oracle.
"""
from __future__ import annotations

import json
import time

from binding import require
from nativeq.evidence import write_new_json

DRAFT = 'D'
RAW = {'command': 'ｶﾞ\n:', 'path': '界界'}
PERMISSION_ID = 4


def wire(root, name):
    path = root / name
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text().splitlines(keepends=True) if line.endswith('\n')]


def responses(root):
    return [row for row in wire(root, 'client-wire.jsonl')
            if row.get('id') == PERMISSION_ID and 'method' not in row]


def popup(text):
    """Extract delimited text only. String offsets are NOT physical columns."""
    lines = text.splitlines()
    for start, line in enumerate(lines):
        if '┌' not in line or '┐' not in line or '┌ > ' in line:
            continue
        body = []
        for candidate in lines[start + 1:]:
            if '└' in candidate and '┘' in candidate:
                return {'title': line, 'body': body, 'footer': candidate}
            edges = [index for index, value in enumerate(candidate) if value == '│']
            if len(edges) != 2:
                return None
            body.append(candidate[edges[0] + 1:edges[1]])
    return None


def draft(text):
    lines = text.splitlines()
    for index, line in enumerate(lines):
        if line.startswith('┌ > '):
            body = []
            for row in lines[index + 1:]:
                if not row.startswith('│') or not row.endswith('│'):
                    break
                body.append(row[1:-1])
            return ''.join(body).replace('█', '').strip()
    return None


class Fixture:
    def __init__(self, session):
        self.session = session
        self.root = session.out
        self.started = time.monotonic()
        self.observations = []
        self.latest = ''

    def event(self, name, **fields):
        self.session.assert_app()
        self.session.evidence.put_json(name, {'seconds': time.monotonic() - self.started,
            'app': self.session.app_identity.to_json(), **fields}, kind='event')

    def pending(self):
        require(not responses(self.root), 'Unexpected early permission answer: ' + repr(responses(self.root)))

    def drain(self, seconds=.1):
        time.sleep(seconds)
        self.session.assert_app()

    def text(self):
        self.session.observation_clock()
        self.session.assert_app()
        exported = self.session.capture_split('observation', attempts=1)
        self.session.observation_clock()
        require(not exported['history'].strip(), 'Unexpected host history; active-area oracle ambiguous')
        self.latest = exported['active']
        return self.latest

    def wait(self, description, predicate, timeout=30.0, *, deadline=None):
        # One original absolute budget includes every blocking observation.
        deadline = time.monotonic() + timeout if deadline is None else deadline
        previous = self.session.observation_deadline
        self.session.observation_deadline = deadline if previous is None else min(previous, deadline)
        try:
            while True:
                self.session.observation_clock()
                self.session.assert_app()
                self.session.observation_clock()
                matched = predicate()
                self.session.observation_clock()  # A late true predicate is a failure, never PASS.
                if matched:
                    return
                require(time.monotonic() < deadline, description)
                self.session.observation_sleep(.1)
        finally:
            self.session.observation_deadline = previous

    def visible(self, *needles):
        def contains():
            text = self.text()
            return all(needle in text for needle in needles)
        self.wait('Missing native text: ' + repr(needles), contains)

    def has(self, *needles):
        box = popup(self.text())
        return box is not None and all(x in '\n'.join([box['title'], *box['body']]) for x in needles)

    def key(self, *keys):
        self.event('native-keys', keys=list(keys))
        self.session.key(*keys)

    def paste(self, value):
        self.event('native-private-paste', value=value)
        self.session.paste(value)

    def resize(self, width, height):
        before = list(self.session.grid())
        deadline = time.monotonic() + 30
        previous = self.session.observation_deadline
        self.session.observation_deadline = deadline if previous is None else min(previous, deadline)
        try:
            self.session.resize(width, height)  # existing eight-adjustment bounded native geometry
            self.wait('Actual App composer after native resize', lambda:
                ('┌ > ' + '─' * (width - 5) + '┐') in self.text()
                and ('└' + '─' * (width - 2) + '┘') in self.latest,
                deadline=deadline)
            require(tuple(self.session.grid()[:2]) == (width, height), 'App PTY grid differs')
            self.event('native-grid-resize', before=before, after=list(self.session.grid()),
                       window=self.session._geometry(), composer_text_only=True)
            self.session.observation_clock()
        finally:
            self.session.observation_deadline = previous

    def context(self, command, phase):
        self.pending()
        box = popup(self.text())
        if box is None:
            return False
        body = box['body']
        # Preserve original content checks without pretending Python string
        # positions are terminal columns. Independent PNGs must discharge the
        # original exact-row/caret/whole-glyph obligations at each tiny scene.
        return (len(body) == 4 and body[0].strip() == '界' and body[1].strip() == '界'
            and body[2].strip() == command.strip()
            and (body[3].lstrip().startswith('▸') if phase == 'option' else 'r█' in body[3]))

    def full_context(self):
        self.pending()
        box = popup(self.text())
        if box is None:
            return False
        body = [line.strip() for line in box['body']]
        return any(body[index:index + 3] == ['界界', 'ｶﾞ', ':'] for index in range(len(body) - 2)) and '▸ Deny' in body

    def capture(self, name, phase, *, pending=True, obligation):
        if pending:
            self.pending()
        self.session.assert_app()
        # Full-window PNG first, before this checkpoint's clipboard/export actions.
        png = self.session.screenshot(name)
        exported = self.session.capture_split(name, attempts=1)
        require(not exported['history'].strip(), 'Native alternate screen unexpectedly has history')
        require(draft(exported['active']) == DRAFT, 'Chat draft D changed')
        if pending:
            self.pending()
        row = {'name': name, 'phase': phase, 'png': png, 'grid': list(self.session.grid()),
            'window': self.session._geometry(), 'app': self.session.app_identity.to_json(),
            'permission_responses': responses(self.root), 'chat_draft': DRAFT,
            'native_export_semantics': 'Ghostty history+active; soft wraps unwrapped; not cell coordinates',
            'visual_status': 'PENDING independent full-window PNG inspection', 'obligation': obligation,
            'geometry_policy': 'Establish actual final native producer span/popup-left-border and row; do not inherit component x7/8,y12',
            'occlusion_policy': 'Record notifications honestly; an obscured boundary/caret is NOT PROVEN'}
        self.session.evidence.put_json(name + '-scene', row, kind='native-scene')
        self.observations.append(row)


def run(f, peer):
    _, raw, frames = peer.fixtures('retained-halfwidth')
    require(raw == RAW, 'Controlled raw input changed')
    f.visible('XAVT_OWNED_READY')
    f.paste(DRAFT)
    f.wait('Initial chat draft D', lambda: draft(f.text()) == DRAFT)
    write_new_json(f.root / 'control.tmp', {'sequence': 1, 'cases': [0]})
    (f.root / 'control.tmp').replace(f.root / 'control.json')
    f.event('peer-control', sequence=1, cases=[0])
    f.wait('Joined original path/command and initial Allow', lambda: f.has('界界', 'ｶﾞ', '▸ Allow'))
    f.key('Down')
    f.key('Down')
    f.wait('Offered manual RejectOnce selected', lambda: f.has('▸ Deny'))
    f.key('r')
    f.wait('Reason editor', lambda: f.has('Rejecting: Deny'))
    f.capture('00-initial-reason-boundary', 'reason', obligation=
        'Actual final producer underlay glyph span and left border crossing at80x40 before reason paste; intact border, no partial native glyph. Final production RenderState/diff/backend receipt is separate and mandatory.')
    f.paste('r')
    f.wait('Single-character reason draft', lambda: f.has('r█'))
    f.resize(11, 13)
    f.key('shift+Home')
    f.wait('Two identifying path rows; clipped first command; reason caret', lambda: f.context(' ', 'reason'))
    f.capture('01-reason-clipped-pair-before-enter', 'reason', obligation='Width11: two retained path rows, clipped whole pair, reason r/caret and chat D intact.')
    f.key('Return')
    f.drain(.4)
    require(f.context(' ', 'reason'), 'Reason clipped Enter did not refuse')
    f.capture('02-reason-clipped-pair-after-enter', 'reason', obligation='Same width11 reason context after refused Enter; draft/caret retained.')
    f.key('shift+End')
    f.wait('Reason tail reachable with retained path', lambda: f.context(':', 'reason'))
    f.capture('03-reason-tail-with-two-identifying-path-rows', 'reason', obligation='Width11: two path rows, command tail colon, reason draft/caret.')
    f.key('Return')
    f.drain(.4)
    require(f.context(':', 'reason'), 'Reason tail Enter did not refuse')
    f.capture('03b-reason-tail-enter-still-refused', 'reason', obligation='Tail-only context cannot accumulate prior visibility into confirmation.')
    f.key('shift+Home')
    f.wait('Reason clipped first row restored', lambda: f.context(' ', 'reason'))
    f.key('Escape')
    f.wait('Escape restores selected option without response', lambda: f.context(' ', 'option'))
    f.capture('04-option-clipped-pair-before-enter', 'option', obligation='Width11: original selected Deny option, two retained path rows, clipped first command row.')
    f.key('Return')
    f.drain(.4)
    require(f.context(' ', 'option'), 'Option clipped Enter did not refuse')
    f.capture('05-option-clipped-pair-after-enter', 'option', obligation='Clipped option Enter refuses; selection/path/draft intact.')
    f.resize(12, 13)
    f.key('shift+Home')
    f.wait('Whole pair in two-body-cell command viewport', lambda: f.has('ｶﾞ', '▸ Deny'))
    f.capture('06-two-cell-whole-pair-raw-and-decoded', 'option', obligation=
        'Width12 native whole ｶﾞ glyph pair occupies the actual two-body-cell boundary with complete border. Name retained from X; this native run does NOT capture raw ANSI or decoded cells.')
    f.resize(11, 13)
    f.key('shift+End')
    f.wait('Option tail and two retained path rows', lambda: f.context(':', 'option'))
    f.capture('07-retained-path-and-command-tail-before-enter', 'option', obligation='Width11 retained path and colon tail; no prior-view accumulation.')
    f.key('Return')
    f.drain(.4)
    require(f.context(':', 'option'), 'Option tail Enter did not refuse')
    f.capture('07b-option-tail-enter-still-refused', 'option', obligation='Tail-only selected Deny Enter remains unanswered; draft preserved.')
    f.resize(80, 40)
    f.key('shift+Home')
    f.wait('Full original command/path and selected Deny', f.full_context)
    f.capture('07c-restored-full-context-before-manual-reject', 'option', obligation=
        '80x40 current popup shows exact original command ｶﾞ newline colon, identifying 界界 and selected Deny simultaneously; not title/underlay evidence.')
    f.pending()
    f.key('Return')
    f.wait('Exactly one original RejectOnce response', lambda: len(responses(f.root)) == 1)
    response = responses(f.root)[0]
    require(response['result']['outcome'] == {'outcome': 'selected', 'optionId': 'reject'}, 'Wrong manual answer')
    require('rejectionReason' not in response['result'].get('_meta', {}).get('kiro', {}), 'Reason draft was submitted')
    f.visible('XAVT_OWNED_REJECTED_NO_EXECUTION')
    f.wait('Chat draft after rejection', lambda: draft(f.text()) == DRAFT)
    f.capture('08-rejected-clean-stop', 'dismissed', pending=False, obligation='One rejection completed owned prompt without execution; composer D remains.')
    f.capture('09-post-dismissal-restoration', 'dismissed', pending=False, obligation=
        'Uncovered actual final chat restores the whole underlying glyph/style across the former border; inspect entire native window, not an export column inference.')
    sent = wire(f.root, 'agent-wire.jsonl')
    actual = [row for row in sent if row.get('method') == 'session/request_permission' or
        (row.get('method') == 'session/update' and row['params']['update'].get('sessionUpdate') == 'tool_call')]
    require(actual == frames, 'Actual emitted fixture payload/IDs/options/stub changed')
    require(len(responses(f.root)) == 1 and len([row for row in sent if row.get('method') == 'session/request_permission']) == 1,
            'Permission exchange was not exactly once')
    require(not any(row.get('method', '').startswith(('fs/', 'terminal/', '_kiro/auth/')) for row in sent), 'Forbidden operation/auth frame')
    require(not any(row.get('method') == 'session/update' and row['params']['update'].get('status') == 'completed' for row in sent),
            'Completed tool frame replayed')
    f.session.result.update(permission_response=response, permission_response_count=1,
        wire_payload_exact=True, command_bytes=len(raw['command'].encode()), draft_retained=DRAFT,
        reason_draft_preserved_not_submitted=True, reason_clipped_enter_refused=True,
        reason_tail_enter_refused=True, option_clipped_enter_refused=True, option_tail_enter_refused=True,
        operation_executed=False, completed_tool_frame_replayed=False,
        physical_cell_ownership='PENDING native PNG review plus final production/diff/backend receipt')
