"""C6/nativeq identity registry; signal through bound pidfds, never numeric kill."""
from __future__ import annotations

import os
import select
import signal
import time

from nativeq.procs import Identity, OwnedProcesses, identity


class PidfdProcesses(OwnedProcesses):
    def terminate(self, ident, *, grace=2.0):
        row = {'pid': ident.pid, 'start': ident.start, 'signals': [], 'gone': False}
        if identity(ident.pid) != ident:
            row.update(gone=True, skipped='gone or reused; not signaled')
            return row
        fd = None
        try:
            # Compare before and after binding the handle. A recycled PID can
            # never redirect either signal after the second identity check.
            fd = os.pidfd_open(ident.pid)
            if identity(ident.pid) != ident:
                row.update(gone=True, skipped='identity changed during pin; not signaled')
                return row
            for sig in (signal.SIGTERM, signal.SIGKILL):
                if select.select([fd], [], [], 0)[0]:
                    break
                try:
                    signal.pidfd_send_signal(fd, sig)
                    row['signals'].append(sig.name)
                except ProcessLookupError:
                    break
                deadline = time.monotonic() + grace
                while time.monotonic() < deadline:
                    if select.select([fd], [], [], max(0, deadline - time.monotonic()))[0]:
                        break
            row['gone'] = bool(select.select([fd], [], [], 0)[0]) or identity(ident.pid) != ident
        except ProcessLookupError:
            row['gone'] = True
        except BaseException as error:
            row['error'] = repr(error)
        finally:
            if fd is not None:
                os.close(fd)
        return row


def restore_registry(rows):
    registry = PidfdProcesses()
    for row in rows:
        ident = Identity(int(row['pid']), int(row['start']), tuple(row['argv']))
        if ident not in registry.owned:
            registry.owned.append(ident)
    return registry
