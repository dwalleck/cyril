#!/usr/bin/python3.14
"""Lease drain: authorized recorded identities plus X's exact private-run pidfds."""
import argparse
from pathlib import Path
import sys

sys.dont_write_bytecode = True
from binding import HERE, NATIVEQ, OUTPUT, STARTED, load, require, validate


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--authorization', required=True)
    parser.add_argument('--binding', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    require(Path(args.output).absolute() == OUTPUT, 'Drain output is not this exact owned attempt')
    if not OUTPUT.exists() and not OUTPUT.is_symlink():
        require(not STARTED.exists() and not STARTED.is_symlink(),
                'Setup marker exists but output/registry is missing; retain lease for Main')
        return 0  # No setup marker and no output: controller never entered native setup.
    validate(args.authorization, args.binding, args.output, source=False)
    sys.path.insert(0, str(NATIVEQ))
    sys.path.insert(0, str(HERE / 'fixtures'))
    from nativeq import lease
    from nativeq.evidence import write_new_json
    from native_cleanup import restore_registry
    from owned_cleanup import cleanup_owned
    lease.require('linux', 'final Cyril native exact-identity lease drain')
    root = OUTPUT / 'truecolor'
    result = {'ok': False, 'errors': [], 'no_name_pattern_group_numeric_pid_kills': True}
    try:
        owner = root / 'owned-root.json'
        if owner.exists():
            owned = load(owner)
            if Path(owned['scratch']) != root / 'isolated':
                raise RuntimeError('Exact run scratch binding differs; retain lease')
            cleanup_owned(root, Path(owned['scratch']), owned['expected_commands'], result)
    except BaseException as error:
        result['errors'].append({'stage': 'independent App/Node/peer cleanup', 'error': repr(error)})
    try:
        path = root / 'owned-processes.json'
        registry = restore_registry(load(path) if path.exists() else [])
        result['host_cleanup'] = registry.cleanup(grace=1)
    except BaseException as error:
        result['errors'].append({'stage': 'native host pidfd cleanup', 'error': repr(error)})
    result['ok'] = (not result['errors'] and all(row['gone'] for row in result.get('host_cleanup', []))
        and result.get('owned_cleanup', {'status': 'COMPLETE'})['status'] == 'COMPLETE')
    write_new_json(OUTPUT / 'lease-drain.json', result)
    # Nonzero keeps the existing GUI lease for Main; never reclaim a stale lease.
    return 0 if result['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
