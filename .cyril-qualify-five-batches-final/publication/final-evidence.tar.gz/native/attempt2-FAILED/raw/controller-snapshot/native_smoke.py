#!/usr/bin/python3.14
"""One-attempt final-union native proof. Preparation alone is not launch authority.

Adapted from frozen C6 CyrilSession: same owned Ghostty/Xvfb/exports/evidence/
identity registry; KAS launch and retained-halfwidth scenario are X's unchanged
peer. No nested PTY, emulator, provider, operation or real authentication.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode = True
from binding import HERE, NATIVEQ, OUTPUT, PYTHON, STARTED, digest, require, require_unstarted, validate, verify_pins, verify_source


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--authorization', required=True)
    parser.add_argument('--binding', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--preflight', action='store_true', help='Read-only validation before acquiring the GUI lease')
    args = parser.parse_args()
    preparation, auth, bound = validate(args.authorization, args.binding, args.output)
    if args.preflight:
        require_unstarted()
        return 0
    sys.path.insert(0, str(NATIVEQ))
    from nativeq import lease
    from nativeq.evidence import EvidenceStore, write_new_json
    from nativeq.ghostty import installed_ghostty
    from nativeq.linux import GhosttySession, app_pids, ghostty_config
    from nativeq.procs import descendants, identity
    from native_cleanup import PidfdProcesses
    from native_scenario import Fixture, run
    sys.path.insert(0, str(HERE / 'fixtures'))
    from owned_cleanup import cleanup_owned

    lease.require('linux', 'final Cyril owned Ghostty/Xvfb retained-halfwidth')
    require_unstarted()
    require(not Path('/tmp/.X11-unix/X216').exists() and not Path('/tmp/.X216-lock').exists(),
            'Display :216 socket OR lock exists; never reclaim it')
    signal.signal(signal.SIGALRM, lambda _s, _f: (_ for _ in ()).throw(TimeoutError('2400-second native bound')))
    signal.alarm(2400)
    # Everything above is read-only. No setup or host command precedes Main GO,
    # exact private binary/full-source pins, independent review and GUI lease.
    write_new_json(STARTED, {'output': str(OUTPUT), 'preparation_sha256': auth['preparation_sha256'],
                            'binding_sha256': auth['binding_sha256'], 'meaning': 'Validated setup entered; preserve even if output is missing'})
    OUTPUT.mkdir(exist_ok=False)
    write_new_json(OUTPUT / 'source-before.json', verify_source(bound))
    write_new_json(OUTPUT / 'authorization-snapshot.json', auth)
    write_new_json(OUTPUT / 'final-binding-snapshot.json', bound)
    snapshot = OUTPUT / 'controller-snapshot'
    snapshot.mkdir()
    for source in HERE.iterdir():
        if source.is_file():
            shutil.copyfile(source, snapshot / source.name)
    shutil.copytree(HERE / 'fixtures', snapshot / 'fixtures')

    class CyrilSession(GhosttySession):
        def __init__(self, out):
            self.scratch = out / 'isolated'
            self.staged = self.scratch / 'cyril-tested'
            self.relay = self.scratch / 'server.js'
            self.app_identity = None
            self.window_identity = None
            self.app_environment = {
                'PATH': str(self.scratch / 'bin'), 'SHELL': '/bin/bash',
                'HOME': str(self.scratch / 'home'), 'USERPROFILE': str(self.scratch / 'home'),
                **{'XDG_' + name.upper() + '_HOME': str(self.scratch / name)
                   for name in ('config', 'data', 'cache', 'state')},
                'XDG_RUNTIME_DIR': str(self.scratch / 'runtime'),
                'TERM': 'xterm-256color', 'COLORTERM': 'truecolor', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
                'KIRO_AGENT_PATH': '/usr/bin/node', 'KIRO_KAS_SERVER_PATH': str(self.relay),
                'EJ7Y_SMOKE_OUTPUT': str(out), 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1',
            }
            argv = [str(self.staged), '--cwd', str(self.scratch / 'ws'), '--agent-engine', 'kas',
                    '--prompt', 'Display owned workflow approval fixtures; execute no operation']
            super().__init__(out, argv, app_match=str(self.staged), dotnet='/nonexistent-not-dotnet')
            self.owned = PidfdProcesses()
            self.evidence = EvidenceStore(out, run=OUTPUT.name)
            self.observation_deadline = None
            self.exports.clock = self.observation_clock
            self.exports.sleep = self.observation_sleep
            self.expected_commands = {
                'App': argv,
                'Node': ['/usr/bin/node', '--experimental-wasm-modules', str(self.relay),
                         '--transport=stdio', '--auth=acp-callback'],
                'peer': [str(PYTHON), str(HERE / 'fixtures/harness.py'), 'agent'],
                'auth-helper': ['/bin/sh', str(self.scratch / 'bin/kiro-cli'), 'chat', '_', 'get-kas-token'],
            }
            self.result = {'status': 'FAILED', 'case': 'retained-halfwidth', 'color_mode': 'truecolor',
                'argv': argv, 'source': bound['source'], 'binary': bound['binary'],
                'authorization': auth, 'app_environment': self.app_environment,
                'producer_geometry': bound['producer_geometry'], 'native_acceptance': 'PENDING independent PNG review',
                'app_returncode': 'UNOBSERVED: App belongs directly to Ghostty PTY, not this controller',
                'scope': 'One native retained-halfwidth leg only; no C6 recapture/MCP matrix/Windows/macOS/performance claim'}

        def app_command(self):
            return ['/usr/bin/env', '-i', *[k + '=' + v for k, v in self.app_environment.items()], *self.argv]

        def observation_clock(self):
            now = time.monotonic()
            if self.observation_deadline is not None and now >= self.observation_deadline:
                raise TimeoutError('Original native observation deadline expired')
            return now

        def observation_budget(self, limit):
            now = self.observation_clock()
            return limit if self.observation_deadline is None else min(limit, self.observation_deadline - now)

        def observation_sleep(self, seconds):
            time.sleep(self.observation_budget(seconds))
            self.observation_clock()

        def x(self, *cmd, timeout=15):
            value = subprocess.check_output(cmd, env=self.env, text=True, stderr=subprocess.DEVNULL,
                                            timeout=self.observation_budget(timeout)).strip()
            self.observation_clock()
            return value

        def _request(self, label, regions):
            original_timeout = self.exports.timeout
            self.exports.timeout = self.observation_budget(original_timeout)
            try:
                result = super()._request(label, regions)
                self.observation_clock()
                return result
            finally:
                self.exports.timeout = original_timeout

        def persist_owned(self):
            path = self.out / 'owned-processes.json'
            temporary = path.with_suffix('.tmp')
            with temporary.open('w', encoding='utf-8') as stream:
                json.dump([item.to_json() for item in self.owned.owned], stream, indent=2)
                stream.write('\n')
                stream.flush()
                os.fsync(stream.fileno())
            temporary.replace(path)

        def _spawn(self, argv, **kwargs):
            proc = super()._spawn(argv, **kwargs)
            self.persist_owned()
            return proc

        def adopt_tree(self):
            for proc in self.popen:
                owned = next((item for item in self.owned.owned if item.pid == proc.pid), None)
                if owned is not None and self.owned.alive(owned):
                    self.owned.adopt_descendants(proc.pid)
            self.persist_owned()

        def assert_app(self):
            if self.app_identity is not None:
                require(identity(self.app_pid) == self.app_identity, 'Owned App exited or identity changed')
            self.adopt_tree()
            if self.window_identity is not None:
                pid = int(self.x('/usr/bin/xdotool', 'getwindowpid', self.window))
                require(pid == self.window_identity.pid and identity(pid) == self.window_identity,
                        'Owned Ghostty window PID/start identity changed')

        def grid(self):
            self.assert_app()
            return super().grid()

        def key(self, *keys):
            self.assert_app()
            return super().key(*keys)

        def screenshot(self, name):
            self.assert_app()
            return super().screenshot(name)

        def start(self):
            lease.require('linux', 'Cyril on owned Ghostty/Xvfb :216')
            require(not Path('/tmp/.X11-unix/X216').exists() and not Path('/tmp/.X216-lock').exists(),
                    'Display :216 occupied; do not reclaim')
            self.result['ghostty'] = installed_ghostty('/usr/bin/ghostty')
            for name in ('home', 'bin', 'config', 'data', 'cache', 'state', 'runtime', 'ws'):
                (self.scratch / name).mkdir(parents=True)
            (self.scratch / 'runtime').chmod(0o700)
            shutil.copyfile(bound['binary']['path'], self.staged)
            self.staged.chmod(0o700)
            require(digest(self.staged) == bound['binary']['sha256'], 'Staged final App hash mismatch')
            (self.scratch / 'bin/kiro-cli').symlink_to(HERE / 'fixtures/fake-kiro-cli.sh')
            # Exact Node -> Python peer construction from X's established launcher.
            self.relay.write_text("const {spawn}=require('node:child_process');"
                f"const c=spawn({json.dumps(str(PYTHON))},[{json.dumps(str(HERE / 'fixtures/harness.py'))},'agent'],{{stdio:'inherit'}});"
                "c.on('exit',n=>process.exit(n??1));process.on('SIGTERM',()=>c.kill('SIGTERM'));", encoding='utf-8')
            self.result['relay_sha256'] = digest(self.relay)
            config = self.scratch / 'home/.config/cyril/config.toml'
            config.parent.mkdir(parents=True)
            config.write_text('[ui]\nmax_messages = 1000\nmouse_capture = true\ntheme = "cyril-dark"\ncolor_mode = "truecolor"\n\n[agent]\nengine = "kas"\nkas_hooks = "off"\n\n[memory]\nenabled = false\n', encoding='utf-8')
            write_new_json(self.out / 'owned-root.json', {'scratch': str(self.scratch),
                'expected_commands': self.expected_commands, 'marker': 'EJ7Y_SMOKE_OUTPUT=' + str(self.out)})
            write_new_json(self.out / 'case.json', {'case': 'retained-halfwidth'})
            for name in ('exports', '.private'):
                (self.out / name).mkdir()
            (self.out / '.private').chmod(0o700)
            auth_file = self.out / '.private/xauth'
            self.env = {
                'PATH': '/usr/bin:/bin', 'HOME': str(self.scratch / 'home'),
                **{'XDG_' + name.upper() + '_HOME': str(self.scratch / name)
                   for name in ('config', 'data', 'cache', 'state')},
                'XDG_RUNTIME_DIR': str(self.scratch / 'runtime'), 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
                'DISPLAY': self.display, 'XAUTHORITY': str(auth_file), 'GDK_BACKEND': 'x11',
                'TMPDIR': str(self.out / 'exports'), 'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1',
            }
            cookie = subprocess.check_output(['/usr/bin/mcookie'], env=self.env, text=True, timeout=15).strip()
            subprocess.run(['/usr/bin/xauth', '-q', '-f', str(auth_file), 'add', self.display, '.', cookie],
                           env=self.env, check=True, timeout=15)
            ghost_config = self.out / 'ghostty.conf'
            ghost_config.write_text(ghostty_config(self.font_size) + 'gtk-titlebar = false\n', encoding='utf-8')
            self._spawn(['/usr/bin/Xvfb', self.display, '-screen', '0', '2560x1600x24',
                         '-nolisten', 'tcp', '-noreset', '-auth', str(auth_file)], env=self.env,
                        stdout=subprocess.DEVNULL, stderr=(self.out / 'xvfb.log').open('x'))
            time.sleep(.7)
            command = ['/usr/bin/dbus-run-session', '--', '/usr/bin/ghostty', '--config-default-files=false',
                       '--config-file=' + str(ghost_config), '-e', *self.app_command()]
            self.result['host_environment'], self.result['host_command'] = self.env, command
            self.launcher = self._spawn(command, env=self.env, cwd=self.scratch / 'ws',
                stdout=(self.out / 'ghostty.log').open('x'), stderr=subprocess.STDOUT, start_new_session=True)
            end = time.monotonic() + 20
            while time.monotonic() < end:
                self.adopt_tree()
                try:
                    windows = self.x('/usr/bin/xdotool', 'search', '--onlyvisible', '--class', '[Gg]hostty').splitlines()
                except subprocess.CalledProcessError:
                    windows = []
                candidates = {pid: ident.argv for pid in descendants(self.launcher.pid) if (ident := identity(pid))}
                found = app_pids(candidates, self.argv, str(self.staged))
                if len(windows) == 1 and len(found) == 1:
                    self.window, self.app_pid = windows[0], found[0]
                    break
                time.sleep(.1)
            require(self.window is not None and self.app_pid is not None, 'One owned Ghostty window/App not found')
            window_pid = int(self.x('/usr/bin/xdotool', 'getwindowpid', self.window))
            self.ghostty_pids = [pid for pid in descendants(self.launcher.pid)
                if (ident := identity(pid)) and ident.argv and Path(ident.argv[0]).name == 'ghostty']
            require(window_pid in self.ghostty_pids, 'Window is not in owned Ghostty descendant tree')
            self.window_identity = self.owned.adopt(window_pid)
            self.app_identity = self.owned.adopt(self.app_pid)
            self.persist_owned()
            self.result.update(app=self.app_identity.to_json(), window=self.window,
                               window_process=self.window_identity.to_json())
            self.x('/usr/bin/xdotool', 'windowfocus', '--sync', self.window)
            self.resize(80, 40)

        def natural_exit(self):
            self.assert_app()
            self.key('ctrl+q')
            deadline = time.monotonic() + 5
            while identity(self.app_pid) == self.app_identity and time.monotonic() < deadline:
                self.adopt_tree()
                time.sleep(.05)
            self.result['natural_exit'] = identity(self.app_pid) != self.app_identity
            require(self.result['natural_exit'], 'App did not exit naturally after Ctrl+Q')

        def close(self):
            errors = []
            try:
                self.adopt_tree()
            except BaseException as error:
                errors.append({'stage': 'adopt', 'error': repr(error)})
            try:
                cleanup_owned(self.out, self.scratch, self.expected_commands, self.result)
            except BaseException as error:
                errors.append({'stage': 'independent X pidfd cleanup', 'error': repr(error)})
            # Native host cleanup runs even if partial construction, adoption or
            # App/Node/peer cleanup failed. Only recorded exact identities.
            self.result['owned_processes'] = [item.to_json() for item in self.owned.owned]
            try:
                self.result['cleanup'] = self.owned.cleanup(grace=2)
            except BaseException as error:
                errors.append({'stage': 'host pidfd cleanup', 'error': repr(error)})
            self.result['direct_child_returncodes'] = []
            for proc in self.popen:
                try:
                    self.result['direct_child_returncodes'].append({'pid': proc.pid, 'returncode': proc.wait(timeout=2)})
                except subprocess.TimeoutExpired:
                    errors.append({'stage': 'direct child wait', 'pid': proc.pid})
            auth_file = self.out / '.private/xauth'
            if auth_file.exists():
                auth_file.unlink()  # Only this run's private Xauthority, never a display socket/lock.
            self.result['cleanup_errors'] = errors
            self.result['cleanup_complete'] = (not errors and all(row['gone'] for row in self.result.get('cleanup', []))
                and self.result.get('owned_cleanup', {}).get('status') == 'COMPLETE')
            if not self.result['cleanup_complete']:
                self.result['status'] = 'FAILED'
            write_new_json(self.out / 'result.json', self.result)

    session = CyrilSession(OUTPUT / 'truecolor')
    fixture = Fixture(session)
    try:
        spec = importlib.util.spec_from_file_location('frozen_x_peer', HERE / 'fixtures/harness.py')
        require(spec is not None and spec.loader is not None, 'Frozen X peer import unavailable')
        peer = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(peer)
        session.start()
        run(fixture, peer)
        session.natural_exit()
        session.result['status'] = 'CAPTURE_COMPLETE_PENDING_VISUAL_REVIEW'
    except BaseException as error:
        session.result['error'] = repr(error)
        session.result['status'] = 'FAILED'
        if session.window is not None and session.app_identity is not None:
            try:
                session.screenshot('failure-full-window')
                session.capture_split('failure-native-export', attempts=1)
            except BaseException as capture_error:
                session.result['failure_capture_error'] = repr(capture_error)
    finally:
        signal.alarm(0)  # Cleanup retains its existing independent per-process bounds.
        session.result['observations'] = fixture.observations
        session.close()
    receipt = {'status': session.result['status'], 'cleanup_complete': session.result['cleanup_complete'],
        'native_acceptance': 'NOT PASS until independent PNG/actual-geometry obligations discharged',
        'attempts': 1, 'scenes': len(fixture.observations), 'color_modes': ['truecolor']}
    try:
        verify_pins(preparation)
        require(digest(bound['binary']['path']) == bound['binary']['sha256'], 'Original private App changed')
        write_new_json(OUTPUT / 'source-after.json', verify_source(bound))
        receipt['pins_unchanged'] = True
    except BaseException as error:
        receipt.update(status='FAILED', pins_unchanged=False, error=repr(error))
    write_new_json(OUTPUT / 'result.json', receipt)
    print(json.dumps(receipt, indent=2))
    return 1 if receipt['status'] == 'FAILED' else 0


if __name__ == '__main__':
    def interrupted(signum, _frame):
        raise KeyboardInterrupt(f'interrupted by signal {signum}')
    for sig in (signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, interrupted)
    raise SystemExit(main())
