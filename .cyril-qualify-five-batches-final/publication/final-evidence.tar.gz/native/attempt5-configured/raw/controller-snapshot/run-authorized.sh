#!/bin/sh
# PREPARATION ONLY. Do not execute without independent review, final qualified
# source/private-App binding, and a fresh Main GO at the two exact JSON paths.
/usr/bin/python3.14 -B -s /tmp/cyril-final-overlay-native-prepare-attempt5-pass-through-20261022/native_smoke.py \
  --preflight \
  --authorization /tmp/cyril-final-overlay-native-prepare-attempt5-pass-through-20261022/main-go.json \
  --binding /tmp/cyril-final-overlay-native-prepare-attempt5-pass-through-20261022/final-binding.json \
  --output /tmp/cyril-final-overlay-native-retained-halfwidth-attempt5-pass-through-20261022 || exit $?
exec /home/dwalleck/.claude/tmp/janet-console-implementation/tools/with-gui-lease \
  --host linux \
  --purpose Cyril-final-C6-MCP-X-owned-native-boundary \
  --drain '/usr/bin/python3.14 -B -s /tmp/cyril-final-overlay-native-prepare-attempt5-pass-through-20261022/native_drain.py --authorization /tmp/cyril-final-overlay-native-prepare-attempt5-pass-through-20261022/main-go.json --binding /tmp/cyril-final-overlay-native-prepare-attempt5-pass-through-20261022/final-binding.json --output /tmp/cyril-final-overlay-native-retained-halfwidth-attempt5-pass-through-20261022' \
  c6la-native -- \
  /usr/bin/python3.14 -B -s /tmp/cyril-final-overlay-native-prepare-attempt5-pass-through-20261022/native_smoke.py \
    --authorization /tmp/cyril-final-overlay-native-prepare-attempt5-pass-through-20261022/main-go.json \
    --binding /tmp/cyril-final-overlay-native-prepare-attempt5-pass-through-20261022/final-binding.json \
    --output /tmp/cyril-final-overlay-native-retained-halfwidth-attempt5-pass-through-20261022
