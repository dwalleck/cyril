#!/bin/sh
exec /usr/bin/python3.14 /tmp/cyril-nk-two-repair-owned-tni3jpx9/harness.py peer
