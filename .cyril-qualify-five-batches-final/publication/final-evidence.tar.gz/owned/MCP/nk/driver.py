#!/usr/bin/env python3
"""Focused external NK repair consumer. Preparation is not runtime authority.
Reuses the retained App consumer PTY/cells, atomic JSON and failure cleanup.
No native KAS, real login/provider, model turn, grant, browser or clipboard.
"""
import argparse
import codecs
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import pty
import select
import shlex
import signal
import struct
import sys
import tempfile
import termios
import traceback

STAGE = Path('/tmp/cyril-five-batch-final-owned-consumer-bindings-20261022/nk')
OUTPUT = STAGE / 'run02'
SCOPE = 'nk4o-two-repair-focused-owned-App-consumer'
PRECEDENT = Path('/tmp/cyril-nk4o-current-main-owned-consumer-prepare-McpLifecycle-03f68b427128')
ROOT = Path('/home/dwalleck/repos/cyril-wt-qualify-five-batches-final')
PYTHON = Path('/usr/bin/python3.14')
NODE = Path('/usr/bin/node')
OLD_BINARY_SHA = '704ee83b3098a1167d28e5b22a0afaf57a54b497e89a45ba4be048a6fd7f04c8'
OLD_SOURCE_DESCRIPTOR = '03f68b427128d98b1d11aee19a287338cb2e54590964e2d02d6dd8fdd8bd8d63'
REPAIR_PINS = {
    'crates/cyril-ui/src/mcp_panel/presentation.rs': 'cca5728d3913e3355136a87368dfa3da7ec928ce278dd3523a9287d28e43eb75',
    'crates/cyril-ui/src/mcp_panel/tests.rs': '3cdca49fad0a0717de10dd98e89773c308e97852193fe6aeb31d4f04832c6772',
    'crates/cyril-core/src/protocol/convert/kas/mcp.rs': '16b2330d61729860e45b2322c2d7c6a3307ccf00ac739f53209afe9999d2c1f0',
    'crates/cyril-core/src/protocol/convert/kas/mcp_tests.rs': '99dabaf90a8b5527463ee9057fd018440c8515f87bbc67e90c8a775f65657cd4',
}
PINS = {
    PRECEDENT / 'harness.py': '2a1d810983b5c739e1eb2315af126417a86039a7a757456376fb509ee407c4ae',
    PRECEDENT / 'wide_overwrite.py': '0ce4ddf57372fb428355dc0f02088fb0fb1a75499ccd796f27b899f34a400beb',
    PRECEDENT / 'fake-kiro-cli.sh': '61586cd278cb555d29f84b49805a1811705112713d0b6774feec42310d0ced6d',
    PYTHON: '7579d289e4d95778305acd13fc71be2a3800f7f6a202619505875234659c2c60',
    NODE: 'ed30fdcc71cd7134c5324aeedea64f1088f0dfd22bfba3834fcbee0402c28c5a',
    Path('/home/dwalleck/.cache/uv/environments-v2/harness-88bb4079c79e84aa/lib/python3.13/site-packages/pyte/screens.py'): '43bcd10d5555f6a8e53a1f9c0e557a47ec801b3914533d5b51af5828a5242ecb',
    **{ROOT / name: digest for name, digest in REPAIR_PINS.items()},
}

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

require(digest(PRECEDENT / 'harness.py') == PINS[PRECEDENT / 'harness.py'], 'Retained consumer changed')
spec = importlib.util.spec_from_file_location('retained_nk_consumer', PRECEDENT / 'harness.py')
if spec is None or spec.loader is None:
    raise RuntimeError('Retained consumer module could not be loaded')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.BINARY, base.BINARY_SHA, base.BINARY_BYTES = None, None, None
base.SOURCE_BINDING, base.SCOPE = {'status': 'NOT_AUTHORIZED'}, SCOPE
save, journal = base.save, base.journal
SID = 'sess_70000000-0000-4000-8000-000000000041'
SERVER, OTHER = 'server exact / 日', 'other visible / 日'
CASES = [
    {'label': 'unavailable-tools-reset', 'status': 'failed', 'tab': 1, 'key': 'r', 'startOAuth': False},
    {'label': 'unavailable-prompts-auth', 'status': 'failed', 'tab': 2, 'key': 'a', 'startOAuth': True},
    {'label': 'empty-resources-reset', 'status': 'connected', 'tab': 3, 'key': 'r', 'startOAuth': False},
    {'label': 'empty-templates-auth', 'status': 'connected', 'tab': 4, 'key': 'a', 'startOAuth': True},
]
MALFORMED = [('server-krn-array', True, {'krn': []}),
             ('snapshot-source-string-array', False, {'source': ['workspace']}),
             ('server-source-null-array', True, {'source': [None]})]
FENCE_METHOD = '_kiro/workflow/listRecipes'
EXPECTED_METHODS = (['initialize', 'session/new']
                    + [method for _ in CASES for method in [FENCE_METHOD, '_kiro/mcp/resetServer']]
                    + ['_kiro/mcp/resetServer'] * len(MALFORMED))

class Consumer(base.Consumer):
    def __init__(self, args):
        super().__init__(args)
        self.pidfds = {}
        self.pidfd_receipts = []

    def prepare(self):
        require(Path(__file__).resolve() == STAGE / 'driver.py', 'Exact reviewed stage driver required')
        require(Path(self.args.output) == OUTPUT and OUTPUT.resolve() == OUTPUT, 'Exact fresh run02 required')
        require(sys.flags.optimize == 0 and __debug__ and Path(sys.executable).resolve() == PYTHON,
                'Pinned unoptimized Python required')
        authorization = Path(self.args.authorization)
        require(authorization == STAGE / 'authorization.json' and authorization.is_file() and not authorization.is_symlink(),
                'Explicit stage authorization required')
        auth_bytes = authorization.read_bytes()
        self.auth = json.loads(auth_bytes)
        require(self.auth.get('go') is True and self.auth.get('authorized_by') == 'Main' and
                isinstance(self.auth.get('authorization_source'), str) and
                self.auth['authorization_source'].startswith('Main runtime GO:') and
                self.auth['authorization_source'].removeprefix('Main runtime GO:').strip(), 'Fresh explicit Main runtime GO required')
        require(self.auth.get('scope') == SCOPE and self.auth.get('output') == str(OUTPUT), 'Authorization scope/output mismatch')
        harness_bytes = Path(__file__).read_bytes()
        require(self.auth.get('harness_sha256') == hashlib.sha256(harness_bytes).hexdigest(), 'Main must bind reviewed final driver')
        for path, expected in PINS.items():
            require(path.is_file() and not path.is_symlink() and digest(path) == expected, 'Pinned input changed: '+str(path))
        binary = self.auth['binary']
        binary_path = Path(binary['path'])
        require(binary_path.parent == Path('/tmp/cyril-final-assembled-replay-repaired-default-pair-20261022T211306896512Z') and binary_path.name.startswith('cyril') and
                len(binary['sha256']) == 64 and binary['sha256'] != OLD_BINARY_SHA and binary['bytes'] > 1000000,
                'Fresh post-repair private binary required; old current521 binary refused')
        require(binary_path.is_file() and not binary_path.is_symlink() and binary_path.stat().st_size == binary['bytes'] and
                binary_path.stat().st_mode & 0o7777 == 0o755 and digest(binary_path) == binary['sha256'], 'Qualified binary pin mismatch')
        binding = self.auth['source_binding']
        require(binding['source_root'] == str(ROOT) and binding['repair_file_sha256'] == REPAIR_PINS and
                len(binding['source_descriptor']) == 64 and binding['source_descriptor'] != OLD_SOURCE_DESCRIPTOR,
                'New source descriptor and final reviewed repair pins required')
        receipt_path = Path(self.auth['qualification_receipt']['path'])
        require(receipt_path.is_absolute() and receipt_path.is_file() and not receipt_path.is_symlink(), 'Qualification receipt required')
        receipt_bytes = receipt_path.read_bytes()
        require(hashlib.sha256(receipt_bytes).hexdigest() == self.auth['qualification_receipt']['sha256'], 'Qualification receipt hash mismatch')
        receipt = json.loads(receipt_bytes)
        require(receipt.get('status') == 'PASS' and receipt.get('source_binding') == binding and
                receipt.get('private_binary') == binary and receipt.get('all_authorized_commands_exit_zero') is True and
                isinstance(receipt.get('underlying_results'), list) and bool(receipt['underlying_results']),
                'Fresh PASS qualification-to-source-to-binary receipt required')
        for entry in receipt['underlying_results']:
            result_path = Path(entry['path'])
            require(result_path.is_absolute() and result_path.is_file() and not result_path.is_symlink() and
                    digest(result_path) == entry['sha256'], 'Underlying qualification result changed')
            self.input_digests[result_path] = entry['sha256']
        base.BINARY, base.BINARY_SHA, base.BINARY_BYTES = binary_path, binary['sha256'], binary['bytes']
        base.SOURCE_BINDING, base.SCOPE = binding, SCOPE
        OUTPUT.mkdir(exist_ok=False)
        self.root = OUTPUT
        import pyte
        sys.path.insert(0, str(PRECEDENT))
        import wide_overwrite
        require(Path(wide_overwrite.__file__).resolve() == PRECEDENT / 'wide_overwrite.py', 'Pinned decoder module required')
        self.temporary = tempfile.TemporaryDirectory(prefix='cyril-nk-two-repair-owned-')
        self.scratch = Path(self.temporary.name)
        for name in ['bin', 'home', 'config', 'data', 'cache', 'state', 'runtime', 'tmp', 'ws']:
            (self.scratch / name).mkdir()
        self.binary = self.scratch / 'cyril-qualified'
        self.binary.write_bytes(binary_path.read_bytes())
        self.binary.chmod(0o500)
        self.fake = self.scratch / 'bin/kiro-cli'
        self.fake.write_bytes((PRECEDENT / 'fake-kiro-cli.sh').read_bytes())
        self.fake.chmod(0o555)
        self.frozen = self.scratch / 'harness.py'
        self.frozen.write_bytes(harness_bytes)
        self.frozen.chmod(0o444)
        self.python, self.node = PYTHON, NODE
        self.wrapper = self.scratch / 'owned-peer'
        self.wrapper.write_text('#!/bin/sh\nexec '+shlex.join([str(PYTHON), str(self.frozen), 'peer'])+'\n')
        self.wrapper.chmod(0o555)
        self.server = self.scratch / 'owned-server.js'
        self.server.write_text("const {spawn}=require('node:child_process');const c=spawn("+json.dumps(str(self.wrapper))+",[],{stdio:'inherit'});c.on('exit',n=>process.exit(n??1));process.on('SIGTERM',()=>c.kill('SIGTERM'));\n")
        self.server.chmod(0o444)
        self.config = self.scratch / 'home/.config/cyril/config.toml'
        self.config.parent.mkdir(parents=True)
        self.config.write_text('[agent]\nengine = "kas"\nkas_hooks = "off"\n[memory]\nenabled = false\n')
        self.config.chmod(0o444)
        self.environment = {'TERM': 'xterm-256color', 'COLORTERM': 'truecolor', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
            'PATH': str(self.scratch / 'bin'), 'SHELL': '/bin/bash', 'HOME': str(self.scratch / 'home'),
            'USERPROFILE': str(self.scratch / 'home'), 'KIRO_HOME': str(self.scratch / 'home/.kiro'),
            'KIRO_AGENT_PATH': str(NODE), 'KIRO_KAS_SERVER_PATH': str(self.server), 'OWNED_MCP_OUTPUT': str(OUTPUT),
            'OWNED_MCP_WORKSPACE': str(self.scratch / 'ws'),
            'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1',
            **{'XDG_'+key+'_HOME': str(self.scratch / value) for key, value in [('CONFIG', 'config'), ('DATA', 'data'), ('CACHE', 'cache'), ('STATE', 'state')]},
            'XDG_RUNTIME_DIR': str(self.scratch / 'runtime'), 'TMPDIR': str(self.scratch / 'tmp')}
        self.command = ['/usr/bin/env', '-i']+[key+'='+value for key, value in self.environment.items()]+[str(self.binary), '--cwd', str(self.scratch / 'ws'), '--agent-engine', 'kas']
        for name, data in [('authorization.snapshot.json', auth_bytes), ('qualification.snapshot.json', receipt_bytes),
                           ('driver.snapshot.py', harness_bytes), ('owned-peer.snapshot.sh', self.wrapper.read_bytes()),
                           ('owned-server.snapshot.js', self.server.read_bytes()), ('config.snapshot.toml', self.config.read_bytes())]:
            path = OUTPUT / name
            path.write_bytes(data)
            path.chmod(0o444)
            self.input_digests[path] = hashlib.sha256(data).hexdigest()
        self.input_digests.update(PINS)
        self.input_digests.update({
            authorization: hashlib.sha256(auth_bytes).hexdigest(),
            Path(__file__): hashlib.sha256(harness_bytes).hexdigest(),
            binary_path: binary['sha256'], receipt_path: self.auth['qualification_receipt']['sha256'],
            self.binary: binary['sha256'], self.fake: PINS[PRECEDENT / 'fake-kiro-cli.sh'],
            self.frozen: hashlib.sha256(harness_bytes).hexdigest(),
        })
        for path in [self.wrapper, self.server, self.config]:
            self.input_digests[path] = digest(path)
        for path, expected in self.input_digests.items():
            require(digest(path) == expected, 'Input changed while freezing: '+str(path))
        save(OUTPUT / 'safety.json', {'scope': SCOPE, 'argv': self.command, 'environment': self.environment,
             'source_binding': binding, 'binary': binary, 'inputs': {str(path): value for path, value in self.input_digests.items()},
             'layer': 'actual App -> owned peer -> PTY raw ANSI -> retained pyte/WideOverwrite; not native/auth/network acceptance'})
        self.columns, self.rows = 160, 48
        self.screen = wide_overwrite.WideOverwrite(self.columns, self.rows)
        self.stream, self.decoder = pyte.Stream(self.screen), codecs.getincrementaldecoder('utf-8')('replace')
        self.raw = (OUTPUT / 'terminal.ansi').open('wb')
        self.master, self.slave = pty.openpty()
        os.set_blocking(self.master, False)
        fcntl.ioctl(self.slave, termios.TIOCSWINSZ, struct.pack('HHHH', self.rows, self.columns, 0, 0))

    def remember_process(self, identity, proof):
        super().remember_process(identity, proof)
        key = base.identity_key(identity)
        if key in self.pidfds or identity['state'] == 'Z':
            return
        try:
            fd = os.pidfd_open(identity['pid'])
        except ProcessLookupError:
            return
        try:
            current = base.process_identity(identity['pid'])
            if current is None or select.select([fd], [], [], 0)[0]:
                os.close(fd)
                return
            # Ownership is already established by direct Popen or live
            # descendant/scratch-path discovery. Exec may change argv in place.
            require(base.identity_key(current) == key,
                    'Live owned pidfd start identity could not be validated')
        except BaseException:
            os.close(fd)
            raise
        self.pidfds[key] = fd
        self.pidfd_receipts.append({'registration': identity, 'proof': proof})

    def signal_owned(self, requested_signal):
        self.cleanup_attempt('discover-before-retained-pidfd-'+requested_signal.name, self.observe_owned)
        for key, fd in list(self.pidfds.items()):
            def deliver(fd=fd, key=key):
                if not select.select([fd], [], [], 0)[0]:
                    signal.pidfd_send_signal(fd, requested_signal)
                    self.signal_receipts.append({'signal': requested_signal.name, 'target': 'retained-live-owned-pidfd', 'identity': list(key)})
            self.cleanup_attempt('retained-pidfd-'+str(key)+'-'+requested_signal.name, deliver)

    def resize(self, columns, rows):
        self.event('resize', columns=columns, rows=rows)
        fcntl.ioctl(self.master, termios.TIOCSWINSZ, struct.pack('HHHH', rows, columns, 0, 0))
        self.screen.resize(lines=rows, columns=columns)
        self.columns, self.rows = columns, rows
        fd = self.pidfds[base.identity_key(self.cyril_identity)]
        require(not select.select([fd], [], [], 0)[0], 'Owned App exited before resize')
        signal.pidfd_send_signal(fd, signal.SIGWINCH)
        self.drain(0.5)

    def wait(self, predicate, label, timeout=8):
        return super().wait(predicate, label, timeout=min(timeout, 8))

    def finish(self, outcome, original_failure=None):
        result = None
        try:
            result = super().finish(outcome, original_failure)
        finally:
            for key, fd in list(self.pidfds.items()):
                def close_owned_fd(key=key, fd=fd):
                    os.close(fd)
                    del self.pidfds[key]
                self.cleanup_attempt('close-retained-pidfd-'+str(key), close_owned_fd)
            if result is not None:
                result['cleanup']['retained_pidfd_registrations'] = self.pidfd_receipts
                result['cleanup']['retained_pidfds_closed'] = not self.pidfds
                if self.cleanup_errors:
                    result['result'] = 'FAIL-STOPPED-NO-RETRY'
                if self.root is not None:
                    self.cleanup_attempt('atomic-pidfd-result-recording', lambda: save(self.root / 'result.json', result))
                    if self.cleanup_errors:
                        result['result'] = 'FAIL-STOPPED-NO-RETRY'
                        self.cleanup_attempt('atomic-pidfd-failure-recording', lambda: save(self.root / 'result-recording-failed.json', result))
        return result

def server(status, populated=False):
    value = {'name': SERVER, 'status': status}
    if status == 'connected':
        value.update(tools=[{'name': 'retained-tool', 'disabled': False, 'inputSchema': {}}] if populated else [],
                     prompts=[], resources=[], resourceTemplates=[])
    else:
        value.update(failedAuthorization=False, errorMessage='catalog unavailable')
    return value

def peer():
    output = Path(os.environ['OWNED_MCP_OUTPUT'])
    pending, sequence, initialized, sessions, count, armed = b'', 1, 0, 0, 0, None
    fences = 0
    def send(frame):
        message = {'jsonrpc': '2.0', **frame}
        raw = (json.dumps(message, ensure_ascii=False)+'\n').encode('utf-8')
        with (output / 'peer-wire.raw').open('ab') as stream:
            stream.write(raw)
        journal(output / 'peer-wire.jsonl', message)
        sys.stdout.buffer.write(raw)
        sys.stdout.buffer.flush()
    def state():
        save(output / 'peer-state.json', {'peer_pid': os.getpid(), 'validated_management_requests': count,
             'armed': armed, 'initialized': initialized, 'sessions': sessions, 'fence_receipts': fences})
    def snapshot(servers, **extra):
        send({'method': '_kiro/mcp/status', 'params': {'sessionId': SID, 'servers': servers, **extra}})
    state()
    while True:
        ready, _, _ = select.select([sys.stdin.fileno()], [], [], 0.02)
        if ready:
            raw = os.read(sys.stdin.fileno(), 65536)
            if not raw:
                return
            with (output / 'client-wire.raw').open('ab') as stream:
                stream.write(raw)
            pending += raw
            while b'\n' in pending:
                line, pending = pending.split(b'\n', 1)
                if not line.strip():
                    continue
                frame = json.loads(line)
                journal(output / 'client-wire.jsonl', frame)
                try:
                    method, ident = frame.get('method'), frame.get('id')
                    require(ident is not None, 'No callback response, model notification or unsolicited message allowed')
                    if method == 'initialize':
                        require(initialized == sessions == count == 0 and frame['params']['protocolVersion'] == 1, 'One protocol initialization only')
                        initialized += 1
                        send({'id': ident, 'result': {'protocolVersion': 1, 'agentCapabilities': {'loadSession': False, '_meta': {'kiro': {}}},
                             'agentInfo': {'name': 'owned-NK-repair-peer-NOT-native-KAS', 'version': '1'}, 'authMethods': []}})
                    elif method == 'session/new':
                        require(initialized == 1 and sessions == count == 0, 'One new private session only')
                        sessions += 1
                        send({'id': ident, 'result': {'sessionId': SID, 'configOptions': []}})
                    elif method == FENCE_METHOD:
                        require(sessions == 1 and armed is None and fences == count and count < len(CASES),
                                'Read-only fence must follow hidden activation and precede visible-action arm')
                        require(frame['params'] == {'sessionId': SID, 'workspacePaths': [os.environ['OWNED_MCP_WORKSPACE']]},
                                'Fence may query only current-session private-workspace recipe inventory')
                        journal(output / 'peer-fence-receipts.jsonl', {'index': fences, 'management_count': count,
                                'management_armed': armed, 'frame': frame})
                        fences += 1
                        send({'id': ident, 'result': {'recipes': []}})
                    else:
                        require(sessions == 1 and armed == count and count < 7, 'Management request arrived outside explicit visible-action arm')
                        wanted = CASES[count]['startOAuth'] if count < 4 else False
                        expected = {'serverName': SERVER, **({'startOAuth': True} if wanted else {})}
                        require(method == '_kiro/mcp/resetServer' and frame['params'] == expected, 'Exact original target and OAuth wire flag required')
                        journal(output / 'peer-assertions.jsonl', {'index': count, 'pass': True, 'method': method,
                                'params': expected, 'server_name_utf8_hex': SERVER.encode('utf-8').hex()})
                        count += 1
                        armed = None
                        send({'id': ident, 'result': {'success': True}})
                    state()
                except BaseException as error:
                    save(output / 'peer-FAILED.json', {'error': repr(error), 'frame': frame, 'count': count, 'armed': armed})
                    raise
        command = output / f'control-{sequence:04d}.json'
        if command.exists():
            action = json.loads(command.read_text())['action']
            try:
                if action.startswith('catalog-'):
                    index = int(action.removeprefix('catalog-'))
                    require(count == index and armed is None, 'Catalog phase request count mismatch')
                    snapshot([server(CASES[index]['status']), {'name': OTHER, 'status': 'disabled'}])
                elif action.startswith('valid-'):
                    index = int(action.removeprefix('valid-'))
                    require(count == index+4 and armed is None, 'Valid provenance phase count mismatch')
                    snapshot([server('connected', True), {'name': OTHER, 'status': 'disabled'}])
                elif action.startswith('malformed-'):
                    index = int(action.removeprefix('malformed-'))
                    require(count == index+4 and armed is None, 'Malformed phase count mismatch')
                    _, on_server, resource = MALFORMED[index]
                    replacement = {'name': 'MUST_NOT_REPLACE_VALID_INVENTORY', 'status': 'disabled'}
                    meta = {'kiro': {'resource': resource}}
                    if on_server:
                        replacement['_meta'] = meta
                        snapshot([replacement])
                    else:
                        snapshot([replacement], _meta=meta)
                elif action.startswith('arm-'):
                    index = int(action.removeprefix('arm-'))
                    require(count == index and armed is None, 'Visible activation arm count mismatch')
                    require(index >= len(CASES) or fences == index+1, 'Actual peer FIFO fence receipt required before arming')
                    armed = index
                elif action == 'phase-check':
                    require(armed is None, 'Peer phase check found an outstanding armed request')
                else:
                    raise AssertionError(action)
                state()
                save(output / f'ack-{sequence:04d}.json', {'ok': True, 'action': action, 'count': count, 'armed': armed})
            except BaseException as error:
                save(output / f'ack-{sequence:04d}.json', {'ok': False, 'error': repr(error)})
                save(output / 'peer-FAILED.json', {'error': repr(error), 'action': action})
                raise
            sequence += 1

def count(run):
    return len(run.requests('_kiro/mcp/resetServer'))

def scenario(run):
    run.visible('Session created:')
    run.wait(lambda: (run.root / 'peer-state.json').exists(), 'Owned peer registration')
    run.command_input('/mcp')
    run.visible('MCP inventory not reported yet')
    for index, case in enumerate(CASES):
        if index:
            run.send('\x1b')
            run.command_input('/mcp')
        run.control('catalog-'+str(index))
        run.resize(80, 6)
        run.visible('> '+SERVER)
        run.send('\t'*case['tab'])
        run.send('\x1b[5~'*64)
        run.visible('Session: '+SID)
        run.capture(f'{index+1:02d}-{case["label"]}-hidden')
        run.check(case['label']+' compact Session-only paint hides both server identities',
                  run.columns == 80 and run.rows == 6 and SERVER not in run.text() and OTHER not in run.text())
        before = count(run)
        run.send(case['key'])
        run.visible('> '+SERVER)
        reanchored = run.text()
        run.capture(f'{index+1:02d}-{case["label"]}-reanchored')
        # Existing App slash ingress uses the same BridgeCommand FIFO. The
        # earlier MCP handler enqueues its SDK request before returning, so
        # this later marker cannot reach the serial peer writer ahead of it.
        # The marker's own handler may defer its send; only this one-way order
        # is required. Keep management unarmed until actual peer receipt.
        run.send('\x1b')
        run.resize(160, 48)
        run.command_input('/workflow recipes')
        run.wait(lambda: json.loads((run.root / 'peer-state.json').read_text())['fence_receipts'] == index+1,
                 'Actual owned peer receives later same-BridgeCommand FIFO inventory fence')
        run.visible('No workflow recipes available.')
        run.check(case['label']+' first key has no peer request before causal FIFO fence', count(run) == before and
                  '> '+SERVER in reanchored and OTHER not in reanchored and 'Session: '+SID not in reanchored)
        # Reopening is a new panel, not uninterrupted panel-state retention.
        # No inventory changed: first snapshot server is still the original.
        run.command_input('/mcp')
        run.resize(80, 6)
        run.send('\t'*case['tab'])
        run.visible('> '+SERVER)
        run.check(case['label']+' reopened same-session inventory preserves original visible action identity',
                  '> '+SERVER in run.text() and OTHER not in run.text())
        run.capture(f'{index+1:02d}-{case["label"]}-fenced-reopened-original')
        run.control('arm-'+str(index))
        run.send(case['key'])
        run.wait(lambda: count(run) == index+1, 'Explicit visible action reached owned peer')
        run.control('phase-check')
        run.check(case['label']+' second key sends exact original identity and OAuth flag',
                  run.requests('_kiro/mcp/resetServer')[-1]['params'] == {'serverName': SERVER, **({'startOAuth': True} if case['startOAuth'] else {})})
        run.capture(f'{index+1:02d}-{case["label"]}-visible-action')
        run.resize(160, 48)
        run.visible('ACKNOWLEDGED ['+SERVER+']')
    run.send('\x1b')
    run.command_input('/mcp')
    for index, (label, _, _) in enumerate(MALFORMED):
        run.control('valid-'+str(index))
        run.visible('> '+SERVER)
        run.send('\t')
        run.visible('retained-tool')
        run.control('malformed-'+str(index))
        run.visible('Malformed')
        run.capture('05-'+label+'-stale-valid-inventory')
        run.check(label+' diagnostic preserves valid catalog and original selected server',
                  '> '+SERVER in run.text() and 'retained-tool' in run.text() and 'MUST_NOT_REPLACE_VALID_INVENTORY' not in run.text() and
                  ('stale' in run.text().lower() or 'error' in run.text().lower()))
        run.control('arm-'+str(index+4))
        run.send('r')
        run.wait(lambda: count(run) == index+5, 'Retained action target reached owned peer after malformed provenance')
        run.control('phase-check')
        run.check(label+' malformed replacement cannot retarget reset',
                  run.requests('_kiro/mcp/resetServer')[-1]['params'] == {'serverName': SERVER})
        run.visible('ACKNOWLEDGED ['+SERVER+']')
        if index+1 < len(MALFORMED):
            run.send('\x1b')
            run.command_input('/mcp')
    run.send('\x1b')
    frames = run.wire()
    run.check('Only bootstrap, four read-only FIFO fences and seven owned reset/auth actions reached peer',
              [frame.get('method') for frame in frames] == EXPECTED_METHODS)
    run.check('No owned protocol assertion failed', not (run.root / 'peer-FAILED.json').exists())

if __name__ == '__main__':
    if len(sys.argv) == 2 and sys.argv[1] == 'peer':
        peer()
    else:
        parser = argparse.ArgumentParser(description=__doc__)
        parser.add_argument('--authorization', required=True)
        parser.add_argument('--output', required=True)
        arguments = parser.parse_args()
        consumer = Consumer(arguments)
        outcome, original_failure = 'FAIL-STOPPED-NO-RETRY', None
        def expired(signum, frame):
            raise TimeoutError('150-second bounded focused smoke expired')
        signal.signal(signal.SIGALRM, expired)
        signal.alarm(150)
        try:
            consumer.prepare()
            consumer.start()
            scenario(consumer)
            outcome = 'PASS'
        except BaseException as failure:
            original_failure = {'type': type(failure).__name__, 'error': repr(failure), 'traceback': traceback.format_exc()}
        finally:
            signal.alarm(0)
            result = consumer.finish(outcome, original_failure)
        print(json.dumps(result, ensure_ascii=False))
        raise SystemExit(0 if result['result'] == 'PASS' else 1)
