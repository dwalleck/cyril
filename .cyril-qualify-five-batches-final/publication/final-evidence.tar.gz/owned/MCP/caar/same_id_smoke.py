#!/usr/bin/env python3
"""One Main-authorized owned-peer App run; prepare-only until an explicit GO exists.

Terminal mechanics reuse drive_live.py's private tmux socket, literal send-keys,
and capture-pane text/ANSI surfaces. Peer semantics reuse mcp_startup.rs's held
Load responder, narrowed to current root A; control-0001.json / ack-0001.json
reuse the owned MCP harness's release-held convention, not a new protocol API.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import select
import shlex
import shutil
import signal
import subprocess
import sys
import time

SOURCE = "591f33395ecc7110633127f9b7343a67202fa489a6236679fe58d6d31a3deb7e"
SOURCE563 = "71f3e19759e65e91479679ce0346ca963298618686e1d845c29ae6786f503460"
MANIFEST_SHA = "c1ca5488b23bc4e7a4967904a3cf22bd4db7e0621af02a371f6330fc29e5f7f3"
RUNTIME = "/usr/bin/python3.14"
RUNTIME_SHA = "7579d289e4d95778305acd13fc71be2a3800f7f6a202619505875234659c2c60"
CAPABILITY_RECEIPT = "/tmp/cyril-nk4o-two-repair-consumer-prepare-20261022/runtime-capability-run02.json"
CAPABILITY_SHA = "f549d0fb0a77548bd9187df50dfc4615d6497327ca6e075924af7ac0f53d7f16"
OLD_BINARY_SHA = "a5c6c8a7e2b7fc5bd853cc7222467217beaaca7e989d40411f18d4964dbab36a"
ROOT_A = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa"
SERVER = "caar-p3-sameid-ready"
NOTICE = f"Session '{ROOT_A}' (requested load; response pending): MCP server '{SERVER}' ready"
CREATED = f"Session created: {ROOT_A}"
WIDTH, HEIGHT = 200, 50


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def save(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + f".{os.getpid()}.tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    os.replace(temporary, path)


def launcher_identity(pid):
    base = Path("/proc") / str(pid)
    before = (base / "stat").read_text().rsplit(")", 1)[1].split()
    argv = (base / "cmdline").read_bytes().split(b"\0")
    after = (base / "stat").read_text().rsplit(")", 1)[1].split()
    if before[19] != after[19]:
        raise RuntimeError("launcher PID changed during identity capture")
    return {"pid": pid, "start_ticks": int(after[19]),
            "argv": [os.fsdecode(value) for value in argv if value]}


def permission(path):
    go = json.loads(Path(path).read_text())
    required = {
        "authorized": True,
        "fresh_private_default_App_build_validated": True,
        "owned_runtime_authorized": True,
        "scenario": "caar-P3-current-A-same-ID-load",
        "source529_descriptor": SOURCE,
        "source563_descriptor": SOURCE563,
        "source_manifest_sha256": MANIFEST_SHA,
        "runtime_executable": RUNTIME,
        "runtime_sha256": RUNTIME_SHA,
        "runtime_capability_receipt": CAPABILITY_RECEIPT,
        "runtime_capability_receipt_sha256": CAPABILITY_SHA,
        "max_runs": 1,
        "no_real_provider_auth_or_model_turn": True,
    }
    for key, expected in required.items():
        if go.get(key) != expected:
            raise RuntimeError(f"REFUSED: Main GO field {key!r} must equal {expected!r}")
    binary = Path(go["binary"]).resolve(strict=True)
    if digest(binary) != go["binary_sha256"] or go["binary_sha256"] == OLD_BINARY_SHA:
        raise RuntimeError("REFUSED: fresh private binary hash mismatch or historical binary")
    if digest(__file__) != go["driver_sha256"]:
        raise RuntimeError("REFUSED: prepared driver hash mismatch")
    if digest(Path(__file__).with_name("owned-v2-peer")) != go["peer_wrapper_sha256"]:
        raise RuntimeError("REFUSED: owned executable peer wrapper hash mismatch")
    if Path(sys.executable).resolve(strict=True) != Path(RUNTIME) or digest(sys.executable) != RUNTIME_SHA:
        raise RuntimeError("REFUSED: runtime executable does not match retained capability identity")
    if digest(CAPABILITY_RECEIPT) != CAPABILITY_SHA:
        raise RuntimeError("REFUSED: retained runtime capability receipt hash mismatch")
    return go, binary


def peer(root):
    root = Path(root)
    sequence = 0
    new_count = load_count = 0
    pending = None
    released = False
    incoming = b""

    def journal(kind, **fields):
        nonlocal sequence
        sequence += 1
        with (root / "wire.jsonl").open("a") as stream:
            stream.write(json.dumps({"sequence": sequence, "monotonic_ns": time.monotonic_ns(),
                                     "kind": kind, "peer_pid": os.getpid(), **fields}) + "\n")

    def emit(message):
        journal("agent_to_client", message=message)
        sys.stdout.write(json.dumps(message, separators=(",", ":")) + "\n")
        sys.stdout.flush()

    journal("peer_started", root_A=ROOT_A)
    try:
        while True:
            control = root / "control-0001.json"
            if control.exists() and not released:
                if json.loads(control.read_text()) != {"action": "release-held"} or pending is None:
                    raise RuntimeError("unexpected owned release input/state")
                journal("owned_release_received", pending_request_id=pending)
                emit({"jsonrpc": "2.0", "id": pending, "result": {}})
                released = True
                journal("load_A_released", request_id=pending)
                save(root / "ack-0001.json", {"ok": True, "action": "release-held"})
            # Exact existing owned-peer control observation cadence; no delayed reply.
            ready, _, _ = select.select([sys.stdin.fileno()], [], [], 0.02)
            if not ready:
                continue
            chunk = os.read(sys.stdin.fileno(), 65536)
            if not chunk:
                journal("peer_stdin_eof", new_count=new_count, load_count=load_count,
                        load_released=released)
                return 0
            incoming += chunk
            while b"\n" in incoming:
                line, incoming = incoming.split(b"\n", 1)
                if not line:
                    continue
                message = json.loads(line)
                journal("client_to_agent", message=message)
                method = message.get("method")
                if "id" not in message:
                    if method not in ("initialized", "notifications/initialized"):
                        raise RuntimeError(f"unexpected client notification: {method}")
                    continue
                request_id = message["id"]
                if method == "initialize":
                    emit({"jsonrpc": "2.0", "id": request_id, "result": {
                        "protocolVersion": 1, "agentCapabilities": {"loadSession": True}}})
                elif method == "session/new":
                    new_count += 1
                    if new_count != 1 or load_count:
                        raise RuntimeError("only the initial New A is authorized")
                    emit({"jsonrpc": "2.0", "id": request_id,
                          "result": {"sessionId": ROOT_A}})
                    journal("initial_new_A_replied", request_id=request_id)
                elif method == "session/load":
                    load_count += 1
                    if new_count != 1 or load_count != 1 or message.get("params", {}).get("sessionId") != ROOT_A:
                        raise RuntimeError("only one same-ID Load A is authorized")
                    pending = request_id
                    journal("load_A_held", request_id=pending, target=ROOT_A)
                    emit({"jsonrpc": "2.0", "method": "_kiro.dev/mcp/server_initialized",
                          "params": {"sessionId": ROOT_A, "serverName": SERVER}})
                    journal("progress_A_sent_while_held", wire_session_id=ROOT_A,
                            source_derived_routed_and_inner_scope=ROOT_A)
                else:
                    journal("forbidden_request", method=method)
                    raise RuntimeError(f"no extra auth/model/control RPC authorized: {method}")
    except BaseException as error:
        journal("peer_failed", error=f"{type(error).__name__}: {error}")
        raise


def launch(go_path, root):
    go, binary = permission(go_path)
    root = Path(root).resolve(strict=True)
    config = root / "home/.config/cyril"
    config.mkdir(parents=True, mode=0o700)
    (config / "config.toml").write_text('[agent]\nengine = "v2"\n[memory]\nenabled = false\n')
    for name in ("bin", "workspace", "home/.local/share", "home/.cache", "home/.local/state", "runtime", "tmp"):
        (root / name).mkdir(parents=True, exist_ok=True, mode=0o700)
    environment = {
        "PATH": str(root / "bin"), "HOME": str(root / "home"),
        "XDG_CONFIG_HOME": str(root / "home/.config"),
        "XDG_DATA_HOME": str(root / "home/.local/share"),
        "XDG_CACHE_HOME": str(root / "home/.cache"),
        "XDG_STATE_HOME": str(root / "home/.local/state"), "KIRO_HOME": str(root / "home/.kiro"),
        "XDG_RUNTIME_DIR": str(root / "runtime"), "TMPDIR": str(root / "tmp"),
        "TERM": "xterm-256color", "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8",
        "PYTHONDONTWRITEBYTECODE": "1", "CYRIL_AGENT_LOCATION": "native",
    }
    bwrap = shutil.which("bwrap", path="/usr/bin:/bin")
    if not bwrap:
        raise RuntimeError("bwrap prerequisite missing; do not retry without it")
    command = [bwrap, "--ro-bind", "/", "/", "--bind", str(root), str(root),
               "--proc", "/proc", "--dev-bind", "/dev", "/dev", "--die-with-parent",
               "--unshare-pid", "--unshare-net", "--chdir", str(root / "workspace"), "--",
               str(binary), "--agent-engine", "v2", "--cwd", str(root / "workspace"),
               "--agent-command", str(Path(__file__).with_name("owned-v2-peer").resolve())]
    save(root / "launch.json", {"command": command, "environment": environment,
                               "source529_descriptor": SOURCE, "source563_descriptor": SOURCE563,
                               "source_manifest_sha256": MANIFEST_SHA, "binary": str(binary),
                               "binary_sha256": go["binary_sha256"], "driver_sha256": digest(__file__),
                               "no_network_namespace": True, "credential_copies": False,
                               "peer_wrapper_sha256": go["peer_wrapper_sha256"],
                               "runtime_executable": RUNTIME, "runtime_sha256": RUNTIME_SHA,
                               "runtime_capability_receipt": CAPABILITY_RECEIPT,
                               "runtime_capability_receipt_sha256": CAPABILITY_SHA})
    child = None
    requested_signal = None

    def stop(signum, _frame):
        nonlocal requested_signal
        requested_signal = signum
        if child is not None and child.poll() is None:
            child.send_signal(signum)

    for signum in (signal.SIGTERM, signal.SIGINT):
        signal.signal(signum, stop)
    try:
        with (root / "app.stderr").open("wb") as errors:
            child = subprocess.Popen(command, env=environment, cwd=root / "workspace", stderr=errors)
            save(root / "owned-pids.json", {"launcher_pid": os.getpid(), "bubblewrap_pid": child.pid,
                                           "launcher_start_ticks": launcher_identity(os.getpid())["start_ticks"]})
            return child.wait()
    finally:
        forced = False
        if child is not None and child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                forced = True
                child.kill()
                child.wait(timeout=3)
        save(root / "app-exit.json", {"returncode": child.poll() if child else None,
                                     "requested_signal": requested_signal, "forced_kill": forced,
                                     "monotonic_ns": time.monotonic_ns()})


def drive(go_path):
    os.umask(0o077)
    go_path = Path(go_path).resolve(strict=True)
    go, _binary = permission(go_path)
    base = Path(__file__).resolve().parent
    root = base / "one-owned-run"
    root.mkdir(mode=0o700, exist_ok=False)  # A second attempt cannot overwrite this receipt.
    tmux_exe = shutil.which("tmux")
    if not tmux_exe:
        raise RuntimeError("tmux prerequisite missing; no launch occurred")
    socket_name = f"caar-p3-sameid-{os.getpid()}-{time.monotonic_ns()}"
    tmux = [tmux_exe, "-L", socket_name, "-f", "/dev/null"]
    target = "consumer:0.0"
    captures = []
    inputs = []
    checks = []
    owned_launcher = None
    owned_launcher_fd = None
    owned_launcher_identity = None
    created = False
    released = False
    error = None
    started = time.monotonic()

    def tm(*args, text=True):
        return subprocess.check_output([*tmux, *args], text=text, timeout=5)

    def pane():
        return tm("capture-pane", "-p", "-t", target)

    def capture(label):
        text = pane()
        (root / f"{label}.txt").write_text(text)
        (root / f"{label}.ansi").write_bytes(tm("capture-pane", "-p", "-e", "-t", target, text=False))
        captures.append({"label": label, "monotonic_ns": time.monotonic_ns(), "width": WIDTH, "height": HEIGHT,
                         "text_sha256": digest(root / f"{label}.txt"), "ansi_sha256": digest(root / f"{label}.ansi")})
        return text

    def wire():
        path = root / "wire.jsonl"
        if not path.exists():
            return []
        # A writer may be between writes; complete newline-terminated rows only.
        return [json.loads(line) for line in path.read_text().splitlines(keepends=True) if line.endswith("\n")]

    def wait_for(predicate, seconds=20):
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            if predicate():
                return
            if (root / "app-exit.json").exists():
                raise RuntimeError("App exited before the required surface")
            # Existing tmux harness observation cadence, not an agent-response delay.
            select.select([], [], [], 0.1)
        if not predicate():
            raise TimeoutError("existing 20s harness observation allowance expired")

    def check(label, condition):
        checks.append({"case": label, "pass": bool(condition), "monotonic_ns": time.monotonic_ns()})
        if not condition:
            raise AssertionError(label)

    def keys(value):
        inputs.append({"literal": value, "submit_key": "Enter", "monotonic_ns": time.monotonic_ns()})
        tm("send-keys", "-t", target, "-l", "--", value)
        tm("send-keys", "-t", target, "Enter")

    def release():
        nonlocal released
        if released:
            return
        save(root / "control-0001.pending", {"action": "release-held"})
        (root / "control-0001.pending").replace(root / "control-0001.json")
        released = True

    def interrupt(signum, _frame):
        raise RuntimeError(f"owned driver interrupted by signal {signum}")

    for signum in (signal.SIGTERM, signal.SIGINT, signal.SIGALRM):
        signal.signal(signum, interrupt)
    signal.alarm(70)
    try:
        tm("new-session", "-d", "-s", "consumer", "-x", str(WIDTH), "-y", str(HEIGHT), "bash --noprofile --norc")
        created = True
        tm("set-option", "-t", "consumer", "remain-on-exit", "on")
        launcher_argv = [sys.executable, "-B", str(Path(__file__).resolve()), "--launch", str(go_path), str(root)]
        command = shlex.join(launcher_argv)
        tm("send-keys", "-t", target, "-l", "--", "exec " + command)
        tm("send-keys", "-t", target, "Enter")
        wait_for(lambda: (root / "owned-pids.json").exists())
        registration = json.loads((root / "owned-pids.json").read_text())
        owned_launcher = registration["launcher_pid"]
        candidate_fd = os.pidfd_open(owned_launcher)
        try:
            identity = launcher_identity(owned_launcher)
            if (identity["start_ticks"] != registration["launcher_start_ticks"]
                    or identity["argv"] != launcher_argv
                    or select.select([candidate_fd], [], [], 0)[0]):
                raise RuntimeError("live owned launcher identity could not be validated")
        except BaseException:
            os.close(candidate_fd)
            raise
        owned_launcher_fd = candidate_fd
        owned_launcher_identity = identity
        wait_for(lambda: CREATED in pane() and ROOT_A in pane().splitlines()[0])
        initial = capture("01-established-root-A")
        check("initial_New_A_applied_in_actual_App", initial.count(CREATED) == 1 and ROOT_A in initial.splitlines()[0])
        keys(f"/load {ROOT_A}")
        wait_for(lambda: any(row["kind"] == "progress_A_sent_while_held" for row in wire()))
        wait_for(lambda: NOTICE in pane())
        pending = capture("02-Load-A-held-response-pending")
        held_rows = wire()
        requests = [row["message"] for row in held_rows if row["kind"] == "client_to_agent" and "id" in row["message"]]
        loads = [message for message in requests if message.get("method") == "session/load"]
        check("one_actual_production_same_ID_Load_A", len(loads) == 1 and loads[0]["params"]["sessionId"] == ROOT_A)
        check("Load_A_response_still_held_during_capture", not any(row["kind"] == "load_A_released" for row in held_rows))
        check("current_root_A_remains_authoritative_while_pending", ROOT_A in pending.splitlines()[0] and pending.count(CREATED) == 1)
        check("actual_pending_wording_once", pending.count(NOTICE) == 1 and "requested load; not yet current root" not in pending)
        release()
        wait_for(lambda: any(row["kind"] == "load_A_released" for row in wire()))
        wait_for(lambda: (root / "ack-0001.json").exists())
        check("owned_release_acknowledged", json.loads((root / "ack-0001.json").read_text()) == {"ok": True, "action": "release-held"})
        wait_for(lambda: pane().count(CREATED) == 2)
        final = capture("03-Load-A-released-history-once")
        check("Load_A_success_applied_with_root_A", final.count(CREATED) == 2 and ROOT_A in final.splitlines()[0])
        check("same_notice_retained_once_after_reply", final.count(NOTICE) == 1 and "requested load; not yet current root" not in final)
        request_methods = [row["message"].get("method") for row in wire() if row["kind"] == "client_to_agent" and "id" in row["message"]]
        check("only_initialize_New_A_and_Load_A_requests", request_methods == ["initialize", "session/new", "session/load"])
        keys("/quit")
        wait_for(lambda: (root / "app-exit.json").exists(), seconds=8)
        check("clean_owned_App_exit", json.loads((root / "app-exit.json").read_text())["returncode"] == 0)
    except BaseException as caught:
        error = f"{type(caught).__name__}: {caught}"
        if created:
            try:
                capture("FAILED-current-surface")
            except Exception:
                pass
    finally:
        signal.alarm(0)
        cleanup = {"tmux_socket": socket_name, "launcher_identity": owned_launcher_identity,
                   "launcher_identity_validated": owned_launcher_identity is not None}
        if created and not (root / "app-exit.json").exists():
            try:
                if any(row["kind"] == "load_A_held" for row in wire()):
                    release()
                keys("/quit")
                wait_for(lambda: (root / "app-exit.json").exists(), seconds=5)
            except Exception as cleanup_error:
                cleanup["graceful_error"] = f"{type(cleanup_error).__name__}: {cleanup_error}"
        if owned_launcher_fd is not None:
            try:
                if not (root / "app-exit.json").exists():
                    if not select.select([owned_launcher_fd], [], [], 0)[0]:
                        signal.pidfd_send_signal(owned_launcher_fd, signal.SIGTERM)
                    cleanup["launcher_exit_observed"] = bool(select.select([owned_launcher_fd], [], [], 9)[0])
            except ProcessLookupError:
                cleanup["launcher_already_exited"] = True
            finally:
                os.close(owned_launcher_fd)
                owned_launcher_fd = None
                cleanup["launcher_pidfd_closed"] = True
        else:
            cleanup["launcher_signal_skipped"] = "No validated live launcher pidfd was retained; no numeric PID lookup or signal attempted"
        if created:
            try:
                tm("kill-server")
                cleanup["own_tmux_server_stopped"] = True
            except Exception as cleanup_error:
                cleanup["tmux_cleanup_error"] = f"{type(cleanup_error).__name__}: {cleanup_error}"
        cleanup["app_exit"] = json.loads((root / "app-exit.json").read_text()) if (root / "app-exit.json").exists() else None
        save(root / "receipt.json", {"status": "PASS_OWNED_TMUX_ACTUAL_APP_ONLY" if error is None else "FAIL_STOP_NO_RETRY",
              "error": error, "source529_descriptor": SOURCE, "source563_descriptor": SOURCE563,
              "source_manifest_sha256": MANIFEST_SHA, "runtime_executable": RUNTIME, "runtime_sha256": RUNTIME_SHA,
              "runtime_capability_receipt": CAPABILITY_RECEIPT, "runtime_capability_receipt_sha256": CAPABILITY_SHA,
              "Main_GO": str(go_path), "Main_GO_sha256": digest(go_path), "binary": go["binary"],
              "binary_sha256": go["binary_sha256"], "driver_sha256": digest(__file__), "root_A": ROOT_A,
              "notice": NOTICE, "inputs": inputs, "captures": captures, "checks": checks, "cleanup": cleanup,
              "elapsed_seconds": time.monotonic() - started, "native_host_qualification": False,
              "old_evidence_modified": False, "source_modified": False, "auth_or_model_turns": False})
    if error:
        raise SystemExit(error)
    print(json.dumps({"receipt": str(root / "receipt.json"), "status": "PASS_OWNED_TMUX_ACTUAL_APP_ONLY"}))


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--peer":
        raise SystemExit(peer(sys.argv[2]))
    if len(sys.argv) == 4 and sys.argv[1] == "--launch":
        raise SystemExit(launch(sys.argv[2], sys.argv[3]))
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--permission-receipt", type=Path, required=True)
    args = parser.parse_args()
    drive(args.permission_receipt)
