#!/usr/bin/python3.14
"""One consumer-owned entry/postflight; reuses exported qualification enumeration."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys
import time

BASE = Path(__file__).resolve().parent
QUAL = Path('/home/dwalleck/.claude/tmp/cyril-batch3-qualification-20261020-ipe924db/final-replay-repaired-resume-nine-plus-two-attempt1-20261022T211122553672Z')
BASELINE = QUAL / 'consumer-captured-repaired571-baseline-PROJECTION-NOT-RERUN.json'
BASELINE_SHA = 'c500448240252bba80f458bbc9106f7127474f2d38132f53077d7f53e7d4f236'
ENUMERATOR = Path('/home/dwalleck/.claude/tmp/cyril-batch3-qualification-20261020-ipe924db/final-five-batches-assembled-single-CI-roster-attempt1-20261022T203302963256Z/consumer-readonly-enumerator-EXPORT-NOT-EXECUTED.py')
ENUMERATOR_SHA = '0dac05c8afb8c8ccde1998c570daf3cf269afa331cb977f9e9fe03b567ea50e6'
PINS = BASE / 'immutable-input-pins.json'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def descriptor(rows):
    return hashlib.sha256(json.dumps(rows, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def save(path, value):
    temporary = path.with_name(path.name + f'.{os.getpid()}.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    os.replace(temporary, path)


if __name__ == '__main__':
    phase = sys.argv[1]
    if phase not in ('entry', 'postflight'):
        raise SystemExit('Only one entry or one postflight is supported')
    destination = BASE / f'{phase}-guard.json'
    if destination.exists():
        raise SystemExit('REFUSED: this one-shot guard receipt already exists')
    report = {'schema': 'caar-P3-consumer-one-shot-source-and-immutable-guard/v1',
              'phase': phase, 'status': 'FAIL_STOP', 'started_monotonic_ns': time.monotonic_ns(),
              'checks': [], 'immutable_inputs': [], 'source_scan_count_this_invocation': 0}
    errors = []

    def check(label, condition, **detail):
        report['checks'].append({'case': label, 'pass': bool(condition), **detail})
        if not condition:
            errors.append(label)

    try:
        check('captured_baseline_export_pin', sha(BASELINE) == BASELINE_SHA)
        check('read_only_enumerator_export_pin', sha(ENUMERATOR) == ENUMERATOR_SHA)
        if errors:
            raise RuntimeError('Export pins do not match; no import or source scan authorized')
        baseline = json.loads(BASELINE.read_text())
        pins = json.loads(PINS.read_text())['pins']
        pins += [
            {'role': 'read_only_qualification_enumerator', 'path': str(ENUMERATOR), 'sha256': ENUMERATOR_SHA},
            {'role': 'captured_qualification_baseline', 'path': str(BASELINE), 'sha256': BASELINE_SHA},
        ]
        report['guard_program_sha256'] = sha(__file__)
        report['immutable_pins_spec_sha256'] = sha(PINS)
        for pin in pins:
            path = Path(pin['path'])
            metadata = path.stat()
            actual = {'role': pin['role'], 'path': str(path), 'sha256': sha(path),
                      'bytes': metadata.st_size, 'mode': oct(stat.S_IMODE(metadata.st_mode))}
            report['immutable_inputs'].append(actual)
            check('immutable:' + pin['role'], actual['sha256'] == pin['sha256']
                  and ('bytes' not in pin or actual['bytes'] == pin['bytes'])
                  and ('mode' not in pin or actual['mode'] == pin['mode'])
                  and (not pin.get('executable_required') or bool(metadata.st_mode & 0o111)), actual=actual)
        if errors:
            raise RuntimeError('Immutable input pin mismatch; no App launch authorized')
        manifest = baseline
        module_spec = importlib.util.spec_from_file_location('caar_readonly_qualification_enumerator', ENUMERATOR)
        if module_spec is None or module_spec.loader is None:
            raise RuntimeError('Pinned enumerator cannot be loaded as a Python source module')
        enumerator = importlib.util.module_from_spec(module_spec)
        module_spec.loader.exec_module(enumerator)
        rows = enumerator.carows(manifest['worktree'], manifest['source_scope'], manifest['external34inputs'])
        report['source_scan_count_this_invocation'] = 1
        report['source563_descriptor'] = descriptor(rows)
        report['source_count'] = len(rows)
        expected = {row['path']: row for row in manifest['rows']}
        actual = {row['path']: row for row in rows}
        changed = sorted(path for path in expected.keys() | actual.keys() if expected.get(path) != actual.get(path))
        check('full563_rows_membership_modes_blobs_sha256', rows == manifest['rows'] and len(rows) == 571
              and report['source563_descriptor'] == manifest['descriptor'], changed_paths=changed)
        external = set(manifest['external34inputs'])
        legacy_rows = [row for row in rows if row['path'] not in external]
        report['source529_descriptor'] = descriptor(legacy_rows)
        check('legacy529_descriptor', len(legacy_rows) == 537 and report['source529_descriptor'] == manifest['legacy_workspace_descriptor'])
        worktree = Path(manifest['worktree'])
        dynamic = sorted(path.relative_to(worktree).as_posix() for path in (worktree / '.agents/summary').glob('*.md') if path.is_file())
        check('dynamic_summary_membership', dynamic == manifest['dynamic_summary_md_membership']
              and dynamic == baseline['dynamic_summary_md_membership'], actual=dynamic)
        report['refs'] = []
        for ref in baseline['refs']:
            path = Path(ref['path'])
            exists = path.exists()
            data = path.read_bytes() if exists else None
            matched = exists == ref['expected_exists'] and (data is None or data.hex() == ref['expected_raw_bytes_hex'])
            report['refs'].append({'name': ref['name'], 'path': str(path), 'exists': exists,
                                   'sha256': hashlib.sha256(data).hexdigest() if data is not None else None, 'pass': matched})
            check('captured_ref:' + ref['name'], matched)
        if phase == 'postflight':
            entry = json.loads((BASE / 'entry-guard.json').read_text())
            check('entry_guard_was_PASS', entry['status'] == 'PASS')
            check('immutable_inputs_unchanged_since_entry', report['immutable_inputs'] == entry['immutable_inputs'])
            check('guard_and_pin_spec_unchanged_since_entry', report['guard_program_sha256'] == entry['guard_program_sha256']
                  and report['immutable_pins_spec_sha256'] == entry['immutable_pins_spec_sha256'])
            check('Main_GO_unchanged_since_activation', sha(BASE / 'Main-GO.json') == sys.argv[2])
        report['status'] = 'PASS' if not errors else 'FAIL_STOP'
    except BaseException as error:
        report['exception'] = f'{type(error).__name__}: {error}'
        errors.append(report['exception'])
    report['errors'] = errors
    report['finished_monotonic_ns'] = time.monotonic_ns()
    save(destination, report)
    print(json.dumps({'receipt': str(destination), 'sha256': sha(destination), 'status': report['status']}))
    raise SystemExit(0 if report['status'] == 'PASS' else 1)
