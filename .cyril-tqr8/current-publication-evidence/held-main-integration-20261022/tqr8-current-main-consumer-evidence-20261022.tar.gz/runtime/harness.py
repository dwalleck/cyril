#!/home/dwalleck/.local/share/uv/python/cpython-3.13.9-linux-x86_64-gnu/bin/python3.13
# /// script
# dependencies = ["pyte"]
# ///
"""Owned peer / current integrated Tqr binary scoped consumer evidence.
No native KAS/account/network/auth/browser/clipboard/model/grants. The native
URL and failure text are retained observations; ACP envelopes and session/
request IDs are explicitly synthetic, NOT byte-for-byte native-frame replay.
Additional control-character specimens are synthetic. No private logs read.
"""
import argparse
import codecs
import fcntl
import hashlib
import json
import os
from pathlib import Path
import pty
import select
import shutil
import signal
import struct
import subprocess
import sys
import tempfile
import termios
import time

ROOT = Path('/home/dwalleck/repos/cyril-wt-fix-cyril-tqr8')
BINARY = Path('/tmp/cyril-tqr8-held-main-default-qualified-20261022T015043431767Z')
BINARY_SHA = 'd3a754b3d5176b102a154c12c74e3080edcfbef126195dcee765519450258142'
BINARY_BYTES = 102118680
SOURCE_BOUNDED503_DESCRIPTOR = '1305934e10aa4e1124a22eb0ae308e8549f7da6619a3a33a0dca13e77669d66d'
READY_RECEIPT = Path('/home/dwalleck/.claude/tmp/cyril-batch3-qualification-20261020-ipe924db/tqr8-current-main-integration-green-attempt1/ready-private-default-binary.json')
READY_RECEIPT_SHA = '41ee2cfee52d775bde45e12abc606dd41eb6b359d4ac7fd74b3f2b0656ef2ccc'
CANDIDATE_BINDING_STATUS = 'FINAL_READY_RECEIPT_BOUND'
PREPARED_ROOT = Path('/tmp/cyril-tqr8-current-main-consumer-prepared-20261022')
FIXED_OUTPUT = PREPARED_ROOT / 'run-once'
ADAPTER = PREPARED_ROOT / 'wide_overwrite.py'
ADAPTER_SHA = '0ce4ddf57372fb428355dc0f02088fb0fb1a75499ccd796f27b899f34a400beb'
PYTHON = Path('/home/dwalleck/.local/share/uv/python/cpython-3.13.9-linux-x86_64-gnu/bin/python3.13')
PYTHON_SHA = '71daa72c960ba060292470b003b4c2e790a77e02b1da1c93f2f4b6cf26d677ed'
NODE = Path('/usr/bin/node')
NODE_SHA = 'ed30fdcc71cd7134c5324aeedea64f1088f0dfd22bfba3834fcbee0402c28c5a'
HARNESS_PYTHONPATH = '/home/dwalleck/.cache/uv/environments-v2/harness-88bb4079c79e84aa/lib/python3.13/site-packages'
FAKE = ROOT / 'crates/cyril-core/tests/fixtures/fake-kiro-cli.sh'
FAKE_SHA = '61586cd278cb555d29f84b49805a1811705112713d0b6774feec42310d0ced6d'
PUBLIC = ROOT / '.cyril-tqr8/publication-evidence'
NATIVE_SCREEN = PUBLIC / 'native-live-active-df5d9437--06-active-manual-url-visible-before-any-local-oauth.txt'
NATIVE_PROJECTION = PUBLIC / 'native-live-active-df5d9437--live--wire.nonsecret.jsonl'
PUBLISHED_B_INPUTS = PUBLIC / 'controlled-peer-b-reconstructed-inputs.json'
URL_SHA = '92961ea663eec802f2dc1a32a3893165cf170cfa2869f8588647d1c7e9346c5a'
SESSION = 'sess_tqr_owned_synthetic'
URL_REQUEST_ID = 10010
CONTROL_URL = 'http://127.0.0.1:1/authorize?state=apostrophe\'a\\b&hint=café&quote="exact"&control=\x1b[31m\n\r\t\u202e&tail=TQR_SAFE_TAIL'
CONTROL_DISPLAY = 'http://127.0.0.1:1/authorize?state=apostrophe\'a\\b&hint=café&quote="exact"&control=\\u{1b}[31m\\n\\r\\t\\u{202e}&tail=TQR_SAFE_TAIL'
ERROR = 'MCP server "fixture-failed" failed to connect: Error POSTing to endpoint: {"error":"synthetic_unavailable","error_description":"Deliberately unavailable synthetic MCP endpoint."}'
CURRENT_URL = CONTROL_URL + '&phase=TQR_CURRENT_NOTICE'
CURRENT_DISPLAY = CONTROL_DISPLAY + '&phase=TQR_CURRENT_NOTICE'
CURRENT_URL_REQUEST_ID = 30
DRAFT_WITH_CARET = 'DRAFT_NOT_SUBMITTED█'
FOREIGN_SESSION = 'sess_tqr_foreign_"quote"\\日\x1b\u202e'
MAIN_BEFORE = 'TQR_CURRENT_MAIN_BEFORE'
MAIN_BETWEEN = 'TQR_CURRENT_MAIN_BETWEEN'
CHILD_BEFORE = 'TQR_CURRENT_FOREIGN_CHILD_BEFORE'
CHILD_AFTER = 'TQR_CURRENT_FOREIGN_CHILD_AFTER'
MAIN_AFTER = 'TQR_CURRENT_MAIN_AFTER'
MAIN_ERROR = 'TQR_CURRENT_MAIN_ERROR "quote"\\日\x1b[31m\n\u202e#MAIN_ERROR_END'
MAIN_ERROR_HEADER = '[error] TQR_CURRENT_MAIN_ERROR'
MAIN_ERROR_PAYLOAD = '"quote"\\日\\u{1b}[31m\\n\\u{202e}#MAIN_ERROR_END'
CHILD_ERROR = 'TQR_CURRENT_CHILD_ERROR CHILD_OPAQUE_0123456789_ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz_0123456789_ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz_0123456789_ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz_"quote"\\日\x1b[31m\n\u202e#CHILD_ERROR_END'
CHILD_ERROR_HEADER = '[error] [session sess_tqr_foreign_"quote"\\日\\u{1b}\\u{202e}] TQR_CURRENT_CHILD_ERROR'
CHILD_ERROR_PAYLOAD = 'CHILD_OPAQUE_0123456789_ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz_0123456789_ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz_0123456789_ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz_"quote"\\日\\u{1b}[31m\\n\\u{202e}#CHILD_ERROR_END'
WORKFLOW_ERROR = 'TQR_CURRENT_WORKFLOW_ERROR WORKFLOW_OPAQUE_0123456789_ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz_0123456789_ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz_0123456789_ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz_"quote"\\日\x1b[32m\n\u202e#WORKFLOW_ERROR_END'
WORKFLOW_ERROR_HEADER = '[error] [session sess_tqr_foreign_"quote"\\日\\u{1b}\\u{202e}] TQR_CURRENT_WORKFLOW_ERROR'
WORKFLOW_ERROR_PAYLOAD = 'WORKFLOW_OPAQUE_0123456789_ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz_0123456789_ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz_0123456789_ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz_"quote"\\日\\u{1b}[32m\\n\\u{202e}#WORKFLOW_ERROR_END'
WORKFLOW_AFTER = 'TQR_CURRENT_WORKFLOW_MAIN_TAIL'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def journal(path, value):
    with path.open('a') as stream:
        stream.write(json.dumps(value, ensure_ascii=False) + '\n')


def release(args):
    if not __debug__ or sys.flags.optimize:
        raise RuntimeError('Optimized Python is forbidden: all assertions must execute')
    authorization = json.loads(Path(args.authorization).read_text())
    assert authorization['candidate_binding_status'] == CANDIDATE_BINDING_STATUS == 'FINAL_READY_RECEIPT_BOUND'
    assert authorization['go'] is True
    assert authorization['authorized_by'] == 'Main'
    assert isinstance(authorization['authorization_source'], str) and authorization['authorization_source'].strip()
    assert Path(__file__).resolve() == PREPARED_ROOT / 'current-consumer.py'
    assert authorization['runner_sha256'] == sha(Path(__file__))
    assert args.output == str(FIXED_OUTPUT) and authorization['output'] == str(FIXED_OUTPUT)
    assert not FIXED_OUTPUT.exists(), 'fixed run-once output must not already exist'
    assert authorization['binary_sha256'] == BINARY_SHA
    assert authorization['source_bounded503_descriptor_not_git_tree'] == SOURCE_BOUNDED503_DESCRIPTOR
    assert authorization['adapter_sha256'] == ADAPTER_SHA
    assert authorization['ready_receipt_sha256'] == READY_RECEIPT_SHA
    assert sha(BINARY) == BINARY_SHA and BINARY.stat().st_size == BINARY_BYTES
    assert BINARY.stat().st_mode & 0o777 == 0o755
    assert sha(READY_RECEIPT) == READY_RECEIPT_SHA
    ready = json.loads(READY_RECEIPT.read_text())
    assert ready['private_path'] == str(BINARY) and ready['sha256'] == BINARY_SHA
    assert ready['source_descriptor'] == SOURCE_BOUNDED503_DESCRIPTOR
    assert ready['bytes'] == BINARY_BYTES and ready['mode'] == '0o755'
    assert Path(sys.executable) == PYTHON and sha(PYTHON) == PYTHON_SHA
    assert Path(shutil.which('node')).resolve(strict=True) == NODE and sha(NODE) == NODE_SHA
    assert os.environ.get('PYTHONPATH') == HARNESS_PYTHONPATH
    assert sha(ADAPTER) == ADAPTER_SHA

def native_values():
    assert sha(NATIVE_SCREEN) == '6cc09b32d18455b532ed0c4690ed2102a466a79bb34ef06d32a72229ff82e2ca'
    assert sha(NATIVE_PROJECTION) == '8ae4f551697ae74d079da6915d63a5f052740bc22c1424fc11924bc6344b768d'
    assert sha(PUBLISHED_B_INPUTS) == 'd7f29a544c3669a32e293a02551a9781b6905b0aa8375bc83d5278b22bcad015'
    published = json.loads(PUBLISHED_B_INPUTS.read_text())
    lines = NATIVE_SCREEN.read_text().splitlines()
    session = next(line.removeprefix('Session created: ') for line in lines if line.startswith('Session created: '))
    index = lines.index('Sign-in requested. Open in browser:') + 1
    value = ''
    while lines[index].strip():
        value += lines[index].rstrip()
        index += 1
    assert hashlib.sha256(value.encode()).hexdigest() == URL_SHA
    projections = [json.loads(line) for line in NATIVE_PROJECTION.read_text().splitlines()]
    callback = next(frame for frame in projections if frame.get('method') == '_kiro/openExternalUrl')
    assert callback['url_sha256'] == URL_SHA and callback['id'] == 10
    observed_session_hashes = {frame['session_id_sha256'] for frame in projections if 'session_id_sha256' in frame}
    # The public screen redacts native identity; its original SID is unavailable.
    assert session == 'sess_PRIVATE_NATIVE_ID_REDACTED'
    assert published['native_session_sha256_from_projection'] in observed_session_hashes
    assert published['controlled_peer_synthetic_session'] == SESSION
    assert published['controlled_native_url_callback_reconstructed_envelope'] == {
        'jsonrpc': '2.0', 'id': URL_REQUEST_ID, 'method': '_kiro/openExternalUrl', 'params': {'url': value}}
    assert published['native_url_sha256'] == URL_SHA
    assert ERROR == published['native_failure_message_observed_on_terminal']
    assert CONTROL_URL == published['synthetic_control_url']
    assert CONTROL_DISPLAY == published['synthetic_expected_visible_control_url']
    assert ERROR == lines[5].removeprefix('[error] ') + ' ' + lines[6]
    return SESSION, value


def agent():
    output = Path(os.environ['TQR_OWNED_OUTPUT'])
    session, url = native_values()
    buffer, sequence, session_request = b'', 0, None

    def send(frame):
        journal(output / 'agent-wire.jsonl', frame)
        print(json.dumps(frame, ensure_ascii=False), flush=True)

    def update(value):
        send({'jsonrpc': '2.0', 'method': 'session/update', 'params': {'sessionId': session, 'update': value}})

    while True:
        readable, _, _ = select.select([sys.stdin.fileno()], [], [], 0.02)
        if readable:
            chunk = os.read(sys.stdin.fileno(), 65536)
            if not chunk:
                return
            buffer += chunk
            while b'\n' in buffer:
                line, buffer = buffer.split(b'\n', 1)
                frame = json.loads(line)
                journal(output / 'client-wire.jsonl', frame)
                method, ident = frame.get('method'), frame.get('id')
                assert method not in ['session/prompt', 'session/request_permission', '_kiro/mcp/resetServer'], frame
                if method == 'initialize':
                    send({'jsonrpc': '2.0', 'id': ident, 'result': {'protocolVersion': 1,
                          'agentCapabilities': {'loadSession': True, '_meta': {'kiro': {}}},
                          'agentInfo': {'name': 'tqr-owned-source-shaped-peer-NOT-native-KAS', 'version': '0.66.43'}, 'authMethods': []}})
                elif method == 'session/new':
                    session_request = ident
                    send({'jsonrpc': '2.0', 'id': URL_REQUEST_ID, 'method': '_kiro/openExternalUrl', 'params': {'url': url}})
                elif method and ident is not None:
                    send({'jsonrpc': '2.0', 'id': ident, 'result': {}})
                elif ident == URL_REQUEST_ID:
                    assert frame.get('result') == {'success': True}, frame
                    send({'jsonrpc': '2.0', 'id': session_request, 'result': {'sessionId': session}})
        control = output / 'control.json'
        if not control.exists():
            continue
        command = json.loads(control.read_text())
        if command['sequence'] <= sequence:
            continue
        sequence = command['sequence']
        action = command['action']
        if action == 'error':
            update({'sessionUpdate': 'session_info_update', '_meta': {'kiro': {'kind': 'display_error',
                    'message': ERROR, 'errorType': 'mcp_connection_error'}}})
        elif action == 'control-url':
            send({'jsonrpc': '2.0', 'id': 20, 'method': '_kiro/openExternalUrl', 'params': {'url': CONTROL_URL}})
        elif action == 'fill':
            for index in range(50):
                update({'sessionUpdate': 'agent_message_chunk', 'content': {'type': 'text',
                        'text': f'OWNED_NAVIGATION_ROW_{index:02d} no action or authorization\n'}})
        elif action == 'current-url':
            send({'jsonrpc': '2.0', 'id': CURRENT_URL_REQUEST_ID, 'method': '_kiro/openExternalUrl', 'params': {'url': CURRENT_URL}})
        elif action == 'current-errors':
            update({'sessionUpdate': 'agent_message_chunk', 'content': {'type': 'text', 'text': MAIN_BEFORE + '\n'}})
            update({'sessionUpdate': 'session_info_update', '_meta': {'kiro': {'kind': 'display_error',
                    'message': MAIN_ERROR, 'errorType': 'mcp_connection_error'}}})
            update({'sessionUpdate': 'agent_message_chunk', 'content': {'type': 'text', 'text': MAIN_BETWEEN + '\n'}})
            send({'jsonrpc': '2.0', 'method': 'session/update', 'params': {'sessionId': FOREIGN_SESSION,
                  'update': {'sessionUpdate': 'agent_message_chunk', 'content': {'type': 'text', 'text': CHILD_BEFORE + '\n'}}}})
            send({'jsonrpc': '2.0', 'method': 'session/update', 'params': {'sessionId': FOREIGN_SESSION,
                  'update': {'sessionUpdate': 'session_info_update', '_meta': {'kiro': {'kind': 'display_error',
                             'message': CHILD_ERROR, 'errorType': 'mcp_connection_error'}}}}})
            send({'jsonrpc': '2.0', 'method': 'session/update', 'params': {'sessionId': FOREIGN_SESSION,
                  'update': {'sessionUpdate': 'agent_message_chunk', 'content': {'type': 'text', 'text': CHILD_AFTER + '\n'}}}})
            update({'sessionUpdate': 'agent_message_chunk', 'content': {'type': 'text', 'text': MAIN_AFTER + '\n'}})
        elif action == 'workflow-errors':
            send({'jsonrpc': '2.0', 'method': '_kiro/workflow/run_start',
                  'params': {'workflowId': 'wf_tqr_current_owned', 'workflowName': 'owned', 'inputs': {}, 'nodeTree': []}})
            send({'jsonrpc': '2.0', 'method': '_kiro/workflow/node_start',
                  'params': {'workflowId': 'wf_tqr_current_owned', 'nodeId': 'step',
                             'nodePath': ['wf_tqr_current_owned', 'step'], 'type': 'step', 'sessionId': FOREIGN_SESSION}})
            send({'jsonrpc': '2.0', 'method': 'session/update', 'params': {'sessionId': FOREIGN_SESSION,
                  'update': {'sessionUpdate': 'session_info_update', '_meta': {'kiro': {'kind': 'display_error',
                             'message': WORKFLOW_ERROR, 'errorType': 'mcp_connection_error'}}}}})
            update({'sessionUpdate': 'agent_message_chunk', 'content': {'type': 'text', 'text': WORKFLOW_AFTER + '\n'}})
        else:
            raise AssertionError(action)


def main(args):
    release(args)
    sys.dont_write_bytecode = True
    from wide_overwrite import WideOverwrite
    import pyte
    assert sha(BINARY) == BINARY_SHA and sha(FAKE) == FAKE_SHA
    session, url = native_values()
    output = Path(args.output)
    output.mkdir(exist_ok=False)
    (output / 'harness.py').write_bytes(Path(__file__).read_bytes())
    save(output / 'reconstructed-inputs.json', {
        'controlled_peer_synthetic_session': session,
        'native_session_sha256_from_projection': 'c003e35c4b149f5c6ad9a3542fda9456e5d5682cdaa6cb6ee3bf66fb69b26ead',
        'native_url_sha256': URL_SHA,
        'controlled_native_url_callback_reconstructed_envelope': {'jsonrpc': '2.0', 'id': URL_REQUEST_ID, 'method': '_kiro/openExternalUrl', 'params': {'url': url}},
        'native_failure_message_observed_on_terminal': ERROR,
        'synthetic_control_url': CONTROL_URL,
        'synthetic_expected_visible_control_url': CONTROL_DISPLAY,
        'provenance': {'screen': str(NATIVE_SCREEN), 'screen_sha256': sha(NATIVE_SCREEN),
                       'projection': str(NATIVE_PROJECTION), 'projection_sha256': sha(NATIVE_PROJECTION),
                       'published_b_inputs': str(PUBLISHED_B_INPUTS), 'published_b_inputs_sha256': sha(PUBLISHED_B_INPUTS),
                       'screen_is_redacted_identity_projection': True,
                       'native_identity_linkage': 'published B original-session SHA256 matches public wire projection; original native SID unavailable'},
        'limit': 'Not raw native ACP frames. Supported envelopes and session/request IDs are synthetic; only URL/error text are retained native observations.'})
    receipt = {'result': 'FAIL', 'binary_sha256': BINARY_SHA, 'binary': str(BINARY),
               'fake_cli_sha256': FAKE_SHA, 'native_url_sha256': URL_SHA,
               'scope': 'Current integrated Tqr binary manual notice/durable error under owned ACP peer/PTy; not full qualification, PR readiness, native KAS/host, C6, NK panel or caar acceptance',
               'source_bounded503_descriptor_not_git_tree': SOURCE_BOUNDED503_DESCRIPTOR,
               'ready_receipt': str(READY_RECEIPT), 'ready_receipt_sha256': READY_RECEIPT_SHA,
               'adapter_sha256': ADAPTER_SHA, 'python_sha256': PYTHON_SHA, 'node_sha256': NODE_SHA,
               'fully_qualified': False, 'pr_ready': False,
               'observations': []}
    with tempfile.TemporaryDirectory(prefix='cyril-tqr8-owned-private-') as temporary:
        scratch = Path(temporary)
        for name in ['bin', 'home', 'config', 'data', 'cache', 'tmp', 'ws']:
            (scratch / name).mkdir()
        (scratch / 'bin/kiro-cli').symlink_to(FAKE)
        node = Path(shutil.which('node')).resolve(strict=True)
        server = scratch / 'server.js'
        server.write_text("const {spawn}=require('node:child_process');" +
                          f"const c=spawn({json.dumps(sys.executable)},[{json.dumps(str(Path(__file__).resolve()))},'agent'],{{stdio:'inherit'}});" +
                          "c.on('exit',n=>process.exit(n??1));process.on('SIGTERM',()=>c.kill('SIGTERM'));")
        config = scratch / 'home/.config/cyril'
        config.mkdir(parents=True)
        (config / 'config.toml').write_text('[agent]\nengine = "kas"\nkas_hooks = "off"\n[memory]\nenabled = false\n')
        environment = {'TERM': 'xterm-256color', 'COLORTERM': 'truecolor', 'LANG': 'C.UTF-8',
                       'PATH': str(scratch / 'bin'), 'SHELL': '/bin/bash',
                       'HOME': str(scratch / 'home'), 'USERPROFILE': str(scratch / 'home'),
                       'XDG_CONFIG_HOME': str(scratch / 'config'), 'XDG_DATA_HOME': str(scratch / 'data'),
                       'XDG_CACHE_HOME': str(scratch / 'cache'), 'TMPDIR': str(scratch / 'tmp'),
                       'KIRO_HOME': str(scratch / 'home/.kiro'), 'KIRO_AGENT_PATH': str(node),
                       'KIRO_KAS_SERVER_PATH': str(server), 'TQR_OWNED_OUTPUT': str(output)}
        master, slave = pty.openpty()
        columns, rows = 140, 40
        fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack('HHHH', rows, columns, 0, 0))
        command = [str(BINARY), '--cwd', str(scratch / 'ws'), '--agent-engine', 'kas']
        process = subprocess.Popen(command, stdin=slave, stdout=slave, stderr=slave, env=environment,
                                   cwd=scratch / 'ws', start_new_session=True)
        os.close(slave)
        screen = WideOverwrite(columns, rows)
        stream = pyte.Stream(screen)
        decoder = codecs.getincrementaldecoder('utf-8')('replace')
        raw = (output / 'terminal.ansi').open('wb')
        sequence, bytes_seen = 0, 0

        def drain(seconds=0.15):
            nonlocal bytes_seen
            until = time.monotonic() + seconds
            while time.monotonic() < until:
                ready, _, _ = select.select([master], [], [], max(0, until-time.monotonic()))
                if not ready:
                    return
                try:
                    chunk = os.read(master, 65536)
                except OSError:
                    return
                if not chunk:
                    return
                raw.write(chunk)
                raw.flush()
                bytes_seen += len(chunk)
                stream.feed(decoder.decode(chunk))

        def visible():
            return '\n'.join(screen.display)

        def wait(predicate, label):
            deadline = time.monotonic() + 20
            while not predicate():
                if process.poll() is not None or time.monotonic() > deadline:
                    raise AssertionError(f'Missing {label}; exit={process.poll()}\n{visible()}')
                drain()

        def wire():
            path = output / 'client-wire.jsonl'
            return [json.loads(line) for line in path.read_text().splitlines() if line] if path.exists() else []

        def content_cell_rows():
            # Actual fixed content rectangle, not blanking or reinserting a
            # character under chrome. Full 140-column screens remain captured.
            return [''.join(screen.buffer[y][x].data for x in range(columns - 1)).rstrip()
                    for y in range(rows)]

        def complete(value):
            lines = content_cell_rows()
            for index, line in enumerate(lines):
                if line.startswith(value[:20]):
                    result = ''
                    for row in lines[index:]:
                        if not row.strip():
                            break
                        result += row
                        if result == value:
                            return True
                        if not value.startswith(result):
                            break
            return False

        def capture(name, **facts):
            (output / (name + '.txt')).write_text(visible() + '\n')
            save(output / (name + '-content-cells.json'), {
                'screen_columns': columns, 'content_columns': columns - 1,
                'gutter_column': columns - 1, 'rows': content_cell_rows(),
                'padding_masking_or_character_reinsertion': False})
            receipt['observations'].append({'capture': name + '.txt', 'columns': columns, 'rows': rows,
                                            'raw_byte_offset': bytes_seen, **facts})

        def action(value):
            nonlocal sequence
            sequence += 1
            save(output / 'control.tmp', {'sequence': sequence, 'action': value})
            (output / 'control.tmp').replace(output / 'control.json')

        def assert_current_errors(include_workflow=False):
            # Use the existing content-cell projection verbatim: no filtering,
            # replacement, separator insertion, or normalization.
            text = ''.join(content_cell_rows())
            notices = [(MAIN_ERROR_HEADER, MAIN_ERROR_PAYLOAD), (CHILD_ERROR_HEADER, CHILD_ERROR_PAYLOAD)]
            if include_workflow:
                notices.append((WORKFLOW_ERROR_HEADER, WORKFLOW_ERROR_PAYLOAD))
            for header, payload in notices:
                assert text.count(header) == 1, (header, text)
                assert text.count(payload) == 1, (payload, text)
                start = text.index(header) + len(header)
                end = text.index(payload, start)
                # The formatter may consume only this known word-wrap space.
                assert text[start:end] in {'', ' '}, repr(text[start:end])
            chronology = [MAIN_BEFORE, MAIN_ERROR_HEADER, MAIN_ERROR_PAYLOAD, MAIN_BETWEEN,
                          CHILD_ERROR_HEADER, CHILD_ERROR_PAYLOAD, MAIN_AFTER]
            if include_workflow:
                chronology += [WORKFLOW_ERROR_HEADER, WORKFLOW_ERROR_PAYLOAD, WORKFLOW_AFTER]
            positions = []
            for value in chronology:
                assert text.count(value) == 1, (value, text)
                positions.append(text.index(value))
            assert all(left < right for left, right in zip(positions, positions[1:])), positions
            assert CHILD_BEFORE not in text and CHILD_AFTER not in text
            assert '\x1b' not in text and '\u202e' not in text
            assert '\x1b' not in visible() and '\u202e' not in visible()
            assert DRAFT_WITH_CARET in visible()

        try:
            wait(lambda: complete(url) and any(frame.get('id') == URL_REQUEST_ID and frame.get('result') == {'success': True} for frame in wire()),
                 'full native URL and delivery ACK')
            capture('01-native-url-manual-ack-not-auth', full_native_url_exact=True, callback_delivery_ack=True,
                    no_connected_or_authorized_claim='connected' not in visible().lower() and 'authorized' not in visible().lower())
            assert 'Sign-in requested. Open in browser:' in visible()
            assert 'connected' not in visible().lower() and 'authorized' not in visible().lower()
            action('error')
            wait(lambda: 'Deliberately unavailable synthetic MCP endpoint.' in visible(), 'durable native-shaped failure')
            capture('02-durable-native-shaped-error', message_preserved=True)
            action('control-url')
            wait(lambda: complete(CONTROL_DISPLAY), 'printable URL exact and controls escaped visibly')
            assert '\x1b' not in visible() and '\u202e' not in visible()
            assert 'apostrophe\'a\\b' in visible() and 'café' in visible() and 'quote="exact"' in visible()
            wait(lambda: any(frame.get('id') == 20 and frame.get('result') == {'success': True} for frame in wire()), 'synthetic delivery ACK')
            capture('03-escaped-controls-printable-exact', full_synthetic_url_exact=True, apostrophe_quote_backslash_unicode_exact=True,
                    terminal_controls_and_bidi_visible_escapes=True)
            os.write(master, b'\x1b[200~DRAFT_NOT_SUBMITTED\x1b[201~')
            wait(lambda: 'DRAFT_NOT_SUBMITTED' in visible(), 'unsubmitted chat draft')
            action('fill')
            wait(lambda: 'OWNED_NAVIGATION_ROW_49' in visible(), 'unrelated subsequent content')
            capture('04-later-content-before-navigation', draft_preserved=True)
            for index in range(6):
                os.write(master, b'\x1b[5~')
                drain(0.2)
                if complete(url) and 'Deliberately unavailable synthetic MCP endpoint.' in visible():
                    break
            assert complete(url), 'full original URL not reachable by main-conversation PageUp'
            assert 'Deliberately unavailable synthetic MCP endpoint.' in visible(), 'error lost after unrelated notifications'
            assert complete(CONTROL_DISPLAY), 'escaped URL lost after unrelated notifications'
            assert 'DRAFT_NOT_SUBMITTED' in visible()
            gutter = [screen.buffer[y][columns - 1].data for y in range(1, rows - 6)]
            assert all(cell in {' ', '▲', '▼', '█', '║'} for cell in gutter), gutter
            assert any(cell != ' ' for cell in gutter), 'browse must exercise scrollbar chrome'
            capture('05-pageup-durable-full-urls-and-error', native_url_full_exact=True, synthetic_url_full_exact=True,
                    durable_error_after_other_notifications=True, draft_preserved=True)
            os.write(master, b'\x1b[6~' * 6)
            wait(lambda: 'OWNED_NAVIGATION_ROW_49' in visible(), 'return to recent conversation with PageDown')
            capture('06-pagedown-return-to-latest', draft_preserved='DRAFT_NOT_SUBMITTED' in visible())
            assert DRAFT_WITH_CARET in visible(), 'historical draft plus block caret must be retained as one literal'
            os.write(master, b'\x1b[5~')
            wait(lambda: 'OWNED_NAVIGATION_ROW_49' not in visible(), 'actual main browse before current URL')
            assert DRAFT_WITH_CARET in visible()
            capture('07-pageup-before-current-url', actual_browse_row49_absent=True, draft_and_caret_preserved=True)
            action('current-url')
            wait(lambda: complete(CURRENT_DISPLAY) and 'OWNED_NAVIGATION_ROW_49' in visible()
                 and DRAFT_WITH_CARET in visible(), 'current full URL reveals recent main and retains exact draft/caret')
            wait(lambda: any(frame == {'jsonrpc': '2.0', 'id': 30, 'result': {'success': True}} for frame in wire()),
                 'current URL delivery ACK30')
            assert '\x1b' not in visible() and '\u202e' not in visible()
            capture('08-current-url-reveals-main', full_current_url_exact=True, recent_row49_restored=True,
                    callback_delivery_ack30=True, draft_and_caret_preserved=True,
                    focused_rendering_or_canonical_child_ownership_proven=False)
            os.write(master, b'\x1b[5~')
            wait(lambda: 'OWNED_NAVIGATION_ROW_49' not in visible(), 'actual main browse before current scoped errors')
            assert DRAFT_WITH_CARET in visible()
            capture('09-pageup-before-current-errors', actual_browse_row49_absent=True, draft_and_caret_preserved=True)
            action('current-errors')
            wait(lambda: MAIN_AFTER in visible() and '#CHILD_ERROR_END' in visible(), 'current main and foreign-child notice delivery')
            assert_current_errors()
            capture('10-current-errors-reveal-main', main_and_optimistic_child_presentations_once=True,
                    actual_child_session_id_escaped=True, full_opaque_child_payload_exact=True,
                    visible_main_chronology_preserved=True, foreign_child_text_absent_from_main=True,
                    draft_and_caret_preserved=True, canonical_ownership_and_focus_are_tests_only=True)
            action('workflow-errors')
            wait(lambda: WORKFLOW_AFTER in visible() and '#WORKFLOW_ERROR_END' in visible(), 'late workflow claim and attributed notice delivery')
            assert_current_errors(include_workflow=True)
            capture('11-late-workflow-claim-and-error', original_child_presentation_still_once=True,
                    workflow_attributed_presentation_once=True, full_opaque_workflow_payload_exact=True,
                    visible_main_chronology_preserved=True, draft_and_caret_preserved=True,
                    canonical_workflow_store_and_pending_are_tests_only=True)
            client = wire()
            assert not any(frame.get('method') in ['session/prompt', '_kiro/mcp/resetServer', 'session/request_permission'] for frame in client)
            initialize = next(frame for frame in client if frame.get('method') == 'initialize')
            kiro = initialize['params']['clientCapabilities']['_meta']['kiro']
            assert kiro.get('openExternalUrl') is True and not kiro.get('secretStorage', False)
            assert len(client) == 5, client
            assert [frame.get('method') for frame in client] == ['initialize', 'session/new', None, None, None]
            assert all(frame['jsonrpc'] == '2.0' for frame in client)
            assert set(client[0]) == {'jsonrpc', 'id', 'method', 'params'}
            assert set(client[1]) == {'jsonrpc', 'id', 'method', 'params'}
            assert isinstance(client[0]['id'], str) and isinstance(client[1]['id'], str)
            assert client[0]['id'] != client[1]['id']
            assert client[0]['params']['protocolVersion'] == 1
            assert kiro.get('secretStorage', False) is False
            assert client[1]['params']['cwd'] == str(scratch / 'ws')
            assert client[1]['params']['mcpServers'] == []
            assert client[2:] == [
                {'jsonrpc': '2.0', 'id': 10010, 'result': {'success': True}},
                {'jsonrpc': '2.0', 'id': 20, 'result': {'success': True}},
                {'jsonrpc': '2.0', 'id': 30, 'result': {'success': True}},
            ], client
            peer = [json.loads(line) for line in (output / 'agent-wire.jsonl').read_text().splitlines()]
            assert len(peer) == 67, peer
            assert all(frame['jsonrpc'] == '2.0' for frame in peer)
            assert {method: sum(frame.get('method') == method for frame in peer) for method in
                    [None, '_kiro/openExternalUrl', 'session/update', '_kiro/workflow/run_start', '_kiro/workflow/node_start']} == {
                        None: 2, '_kiro/openExternalUrl': 3, 'session/update': 60,
                        '_kiro/workflow/run_start': 1, '_kiro/workflow/node_start': 1}
            responses = [frame for frame in peer if 'method' not in frame]
            assert responses == [
                {'jsonrpc': '2.0', 'id': client[0]['id'], 'result': {'protocolVersion': 1,
                 'agentCapabilities': {'loadSession': True, '_meta': {'kiro': {}}},
                 'agentInfo': {'name': 'tqr-owned-source-shaped-peer-NOT-native-KAS', 'version': '0.66.43'}, 'authMethods': []}},
                {'jsonrpc': '2.0', 'id': client[1]['id'], 'result': {'sessionId': 'sess_tqr_owned_synthetic'}},
            ]
            callbacks = [frame for frame in peer if frame.get('method') == '_kiro/openExternalUrl']
            assert callbacks == [
                {'jsonrpc': '2.0', 'id': 10010, 'method': '_kiro/openExternalUrl', 'params': {'url': url}},
                {'jsonrpc': '2.0', 'id': 20, 'method': '_kiro/openExternalUrl', 'params': {'url': CONTROL_URL}},
                {'jsonrpc': '2.0', 'id': 30, 'method': '_kiro/openExternalUrl', 'params': {'url': CURRENT_URL}},
            ]
            updates = [frame for frame in peer if frame.get('method') == 'session/update']
            assert all(set(frame) == {'jsonrpc', 'method', 'params'} for frame in updates)
            assert all(set(frame['params']) == {'sessionId', 'update'} for frame in updates)
            assert {frame['params']['sessionId'] for frame in updates} == {
                'sess_tqr_owned_synthetic', 'sess_tqr_foreign_"quote"\\日\x1b\u202e'}
            assert sum(frame['params']['sessionId'] == 'sess_tqr_owned_synthetic' for frame in updates) == 56
            assert sum(frame['params']['sessionId'] == 'sess_tqr_foreign_"quote"\\日\x1b\u202e' for frame in updates) == 4
            errors = [frame for frame in updates if frame['params']['update']['sessionUpdate'] == 'session_info_update']
            assert len(errors) == 4
            assert [frame['params']['update'] for frame in errors] == [
                {'sessionUpdate': 'session_info_update', '_meta': {'kiro': {'kind': 'display_error', 'message': value,
                 'errorType': 'mcp_connection_error'}}} for value in [ERROR, MAIN_ERROR, CHILD_ERROR, WORKFLOW_ERROR]]
            assert sum(frame['params']['update']['sessionUpdate'] == 'agent_message_chunk' for frame in updates) == 56
            assert [frame['params']['update'] for frame in updates[1:51]] == [
                {'sessionUpdate': 'agent_message_chunk', 'content': {'type': 'text',
                 'text': f'OWNED_NAVIGATION_ROW_{index:02d} no action or authorization\n'}} for index in range(50)]
            assert [(frame['params']['sessionId'], frame['params']['update']) for frame in updates[51:]] == [
                ('sess_tqr_owned_synthetic', {'sessionUpdate': 'agent_message_chunk', 'content': {'type': 'text', 'text': MAIN_BEFORE + '\n'}}),
                ('sess_tqr_owned_synthetic', {'sessionUpdate': 'session_info_update', '_meta': {'kiro': {'kind': 'display_error', 'message': MAIN_ERROR, 'errorType': 'mcp_connection_error'}}}),
                ('sess_tqr_owned_synthetic', {'sessionUpdate': 'agent_message_chunk', 'content': {'type': 'text', 'text': MAIN_BETWEEN + '\n'}}),
                ('sess_tqr_foreign_"quote"\\日\x1b\u202e', {'sessionUpdate': 'agent_message_chunk', 'content': {'type': 'text', 'text': CHILD_BEFORE + '\n'}}),
                ('sess_tqr_foreign_"quote"\\日\x1b\u202e', {'sessionUpdate': 'session_info_update', '_meta': {'kiro': {'kind': 'display_error', 'message': CHILD_ERROR, 'errorType': 'mcp_connection_error'}}}),
                ('sess_tqr_foreign_"quote"\\日\x1b\u202e', {'sessionUpdate': 'agent_message_chunk', 'content': {'type': 'text', 'text': CHILD_AFTER + '\n'}}),
                ('sess_tqr_owned_synthetic', {'sessionUpdate': 'agent_message_chunk', 'content': {'type': 'text', 'text': MAIN_AFTER + '\n'}}),
                ('sess_tqr_foreign_"quote"\\日\x1b\u202e', {'sessionUpdate': 'session_info_update', '_meta': {'kiro': {'kind': 'display_error', 'message': WORKFLOW_ERROR, 'errorType': 'mcp_connection_error'}}}),
                ('sess_tqr_owned_synthetic', {'sessionUpdate': 'agent_message_chunk', 'content': {'type': 'text', 'text': WORKFLOW_AFTER + '\n'}}),
            ]
            assert [frame for frame in peer if frame.get('method', '').startswith('_kiro/workflow/')] == [
                {'jsonrpc': '2.0', 'method': '_kiro/workflow/run_start',
                 'params': {'workflowId': 'wf_tqr_current_owned', 'workflowName': 'owned', 'inputs': {}, 'nodeTree': []}},
                {'jsonrpc': '2.0', 'method': '_kiro/workflow/node_start',
                 'params': {'workflowId': 'wf_tqr_current_owned', 'nodeId': 'step',
                            'nodePath': ['wf_tqr_current_owned', 'step'], 'type': 'step',
                            'sessionId': 'sess_tqr_foreign_"quote"\\日\x1b\u202e'}},
            ]
            receipt.update(client_wire_frames=5, peer_wire_frames=67, peer_session_update_frames=60,
                           display_error_notifications=4, external_url_callbacks=3,
                           app_launch_sites=1, owned_node_launch_sites=1, owned_python_peer_launch_sites=1,
                           session_new_requests=1, distinct_notification_session_ids=2,
                           current_url_revealed_main_from_browse=True, exact_draft_and_caret_retained=True,
                           main_child_workflow_presentations_once=True, original_child_not_represented_after_late_claim=True,
                           no_extra_client_methods_or_host_callbacks=True,
                           focus_canonical_ownership_pending_and_workflow_store_proof='existing source/API tests only; not native App claim')
            receipt.update(result='PASS', callback_during_new_wait=True, main_conversation_navigation='PageUp then PageDown',
                           full_native_url_exact=True, manual_display_ack_is_not_authorization=True,
                           durable_error_after_unrelated_notifications=True, no_prompt_reset_permission=True,
                           secret_storage_absent=True, native_frame_fidelity='synthetic envelopes/session/request IDs, retained native URL/error text; no raw-frame replay claim')
        except BaseException as error:
            receipt['error'] = repr(error)
            capture('FAILED-final-screen')
            raise
        finally:
            if process.poll() is None:
                os.write(master, b'\x11')
                drain(0.3)
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGTERM)
                    process.wait(timeout=5)
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            raw.close()
            os.close(master)
            receipt['consumer_returncode'] = process.returncode
            receipt['cleanup_requested_on_exit'] = True
            receipt['external_post_exit_root_and_marker_observation_required'] = True
            receipt['no_private_logs_read_or_packaged'] = True
            receipt['launch'] = {'command': command, 'environment': environment,
                                 'boundary': 'fresh isolated roots, PATH contains only immutable fake kiro-cli; explicit Node->owned Python peer, no actual native KAS'}
            save(output / 'result.json', receipt)
    print(json.dumps({key: value for key, value in receipt.items() if key not in ['observations', 'launch']}, indent=2))


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'agent':
        agent()
    else:
        parser = argparse.ArgumentParser()
        parser.add_argument('--output', required=True)
        parser.add_argument('--authorization', required=True)
        main(parser.parse_args())
