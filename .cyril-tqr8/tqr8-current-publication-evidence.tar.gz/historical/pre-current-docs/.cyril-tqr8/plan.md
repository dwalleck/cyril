# cyril-tqr8 implementation plan

Approved design: `design.md` Approval (DG, Main, 2026-10-19). Source premises: `evidence.md`. Existing responsibility boundaries and manual URL behavior are unchanged by this plan. No feature budget or new dependency is proposed.

## Slice 1: Supported URL callback and visible MCP failure

**Outcome:** A bound KAS process can request actual URL surfacing through its advertised real callback; Cyril displays the manual URL and acknowledges accepted delivery. MCP connection display-errors reach the visible consumer without falsely ending a turn. v2/no-KAS callback refusal and existing v2 MCP behavior remain intact. Design C1–C5.

**Changes:** One atomic, caller-complete slice across core and UI. Core owns new typed `Notification::ExternalUrlRequested { url: String }` (no invented server/session fields) and `Notification::McpConnectionError { message: String }` (variant supplies the error classification), concrete external-URL adapter presence, host request parsing/dispatch/delivery acknowledgement, KAS display-error conversion, and core/exhaustive caller migration. App/UI own only manual-link and durable error presentation through the typed events. Core and consumer edits can be prepared independently under this exact notification contract but form one assembled slice. Generic HostMediator remains capability-agnostic. No browser/clipboard/secret backend/dark completion path is introduced.

LSP references were attempted before extending exported Notification: rust-analyzer reports ready but references and hover for the linked-worktree enum both returned none despite known usages. Reported through `xd://report_issue`; code owner must investigate relevant exhaustive consumers with bounded textual fallback rather than interpreting the empty result as no callers. Dynamic registration and wire names also need text search.

**Verification:**
- Parent observes actual pre-fix red then repaired green for SDK callback/adapter refusal-reachability and KAS display-error-to-consumer regressions → real dropped-callback/error sensitivity, not only helper assertions.
- Parent runs default and KAS core suites plus consumer/UI tests, workspace formatting/type/lint/build gates → caller completeness and existing behavior preserved. Use `env -u CARGO_TARGET_DIR cargo ...` because the ambient variable is empty.
- Parent qualifies `.cyril-tqr8/fixture.py` before using it, then runs the real consumer against clean-root loopback MCP OAuth/failure endpoints → actual URL/error visible, no browser/clipboard/secret writes, no callback/reset acknowledgement mistaken for authorization, owned descendants shut down.
- Integrated passive/reset/status completion C4 waits for the substantive nk4o PR, whose own consumer work must remain distinct. Standalone tqr8 must still exercise its real callback/error entry points without requiring that panel.
- Parent obtains ordinary independent code review for this issue and opens its own substantive PR; blockers are resolved before publication.

**Dependencies:** No unresolved external premise for this slice. Worker explicitly skips tests/build/lint/formatters/smoke; Main owns all checkpoint judgments, fixture qualification, docs/changelog after successful smoke and publication. That ownership transfer is not a PASS or shipping waiver.

## Delivery increment

One tqr8 issue PR containing the entire slice. Approved subsequent stack is nk4o then caar, whose absent-inventory acceptance decision is now explicit in its owning spec. No commits/pushes by worker.

## Checkpoint record

**Delivered edits:** Concrete adapter-derived real URL callback parsing/dispatch, bounded accepted-delivery acknowledgement, malformed/closed-path and non-KAS refusal, flat-authoritative MCP display-error conversion, typed global URL/scoped error consumption through durable system messages (including existing peer stream and binary example). The UI's tiny private streaming text formatter preserves printable URL characters/Unicode exactly and visibly escapes only controls/bidi without an intermediate allocation; its own regression tests cover that distinction. No browser/clipboard/secret backend/dark completion or turn-completion effect. Core/consumer workers added wire/domain/App/render behavior tests but ran no checks.

**Publication boundary:** The older per-file patch series below this directory records the original `8e5c325e` assembly, not the final delivery source. Do not apply those patches as a final-base publication recipe. The final actual worktree uses common test-fixture base `6c0f41c7` plus 18 feature source/test paths, now including the DG-approved `widgets/chat.rs` viewport repair and its four regression tests. `publication-manifest.json` hashes their actual postimages and the documentation/evidence allowlist. Its archive carries those explicit paths only, with no binary, private HOME, Cyril logs or credentials. Parent owns commits and the actual PR.

**Exact Main sensitivity checkpoints:** On pristine production, transplant only `external_url_wire.rs`, `mcp_error.rs` and their test-module registrations (they do not reference new enum variants), then observe red; run repaired stack green:

```sh
env -u CARGO_TARGET_DIR cargo test -p cyril-core --features kas --lib protocol::domain_mediator::tests::external_url_wire::external_url_callback_wire_result -- --exact
env -u CARGO_TARGET_DIR cargo test -p cyril-core --features kas --lib protocol::domain_mediator::tests::mcp_error::kas_mcp_display_error_preserves_conversion_result_and_message -- --exact
env -u CARGO_TARGET_DIR cargo test -p cyril-core
env -u CARGO_TARGET_DIR cargo test -p cyril-core --features kas
env -u CARGO_TARGET_DIR cargo test -p cyril-ui external_url_request_is_manual_and_nonterminal
env -u CARGO_TARGET_DIR cargo test -p cyril-ui mcp_connection_error_is_durable_and_nonterminal
env -u CARGO_TARGET_DIR cargo test -p cyril-ui mcp_notice
env -u CARGO_TARGET_DIR cargo test -p cyril --bin cyril app::tests::mcp_oauth
env -u CARGO_TARGET_DIR cargo test -p cyril --no-default-features --bin cyril app::tests::mcp_oauth
env -u CARGO_TARGET_DIR cargo check -p cyril --all-targets
```

**Performed checks and results:** See the owning `evidence.md` delivery checkpoint and source-pinned portable parent handoffs. Historical bg121/artifact818 remains pre-repair PASS (2,839passed,13ignored/not executed). The first controlled consumer's full-URL PageUp FAIL remains immutable. Parent later observed all four unchanged renderer tests RED on old layout and restored GREEN, plus exact indicator-only width1 mutation RED/restored GREEN; fresh amended gutter source review is correct0.97. On post-format source tree851c, workspace all-target Clippy and all seven explicitly continued changed-path gates passed, but full workspace tests failed with `runtime_drop_retains_evidence_until_core_completion` / `"missing EOF window"` (2,834passed,1failed,13ignored/not executed before stop). Under separate Main GO, actual owned B/C consumers passed full-URL PageUp/PageDown, escaping, durable error, draft and ACK-not-auth observations on partial candidate2954. B was already a valid synthetic sess_ fixture; C is only an additional variant, not a new requirement. No worker Cargo/check/formatter/native operation occurred.

**Unresolved acceptance:** Mandatory full-workspace acceptance remains BLOCKED and unwaived; candidate2954 and the owned-consumer PASS are partial qualification, not PR readiness. Parent owns its diagnosis/disposition, all completion gates and commit/tracker/own PR. Earlier native NK passive17/17 PASS and active31/32 rawFAIL with separate normal-reset adjudication remain distinct; no fresh native-Tqr frame/sourceURL/run is invented. Native retry/login/account/config changes remain unauthorized after the before-initialize auth failure. NK previews/inventory and caar deadlines remain unqualified and are not Tqr features. The publication manifest/archive is a portable partial-evidence handoff, not shipping authorization.
