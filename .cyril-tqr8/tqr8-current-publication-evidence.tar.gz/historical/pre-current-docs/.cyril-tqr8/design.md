# cyril-tqr8 — real URL callback and visible MCP errors

## Route and inputs

Structural route in `route.md`; full issue and primary-source conclusions in `evidence.md`. Inspected design base is `8e5c325e`; the final actual-tree checkpoint is separately pinned in `publication-index.json` and `publication-manifest.json`. The settled design has delegated approval recorded below. Current verification and unresolved acceptance live in `evidence.md`, delivery checkpoint; approval is not a shipping waiver.

The issue fixes the **active callback/error leg**. The distinct `nk4o` PR fixes the passive status/panel/reset leg. URL callback implementation is independently useful and must not require an MCP panel to be open or a server name/session ID the actual request never carried.

## Behavior

- Install a real URL host-callback adapter on the bound KAS engine. Derive `clientCapabilities._meta.kiro.openExternalUrl:true` from that installation, using the same adapter datum that permits dispatch. v2 and no-KAS builds must neither advertise nor execute it.
- Parse the current request `{url}` in core. Queue a typed, global URL-surfacing event through the existing bounded host/domain path and display a manual sign-in link. Match existing v2 manual-URL behavior; no browser launch, clipboard subprocess, shell command or confirmation framework is introduced.
- Reply `{success:true}` after the URL event is accepted for delivery. This means **handled for display**, not opened, authorized, connected, or OAuth completed. Delivery failure cannot return success. Malformed handled requests produce an explicit parameter error; unsupported engine requests are refused as method-not-found rather than `null` success.
- Preserve the original URL in the typed core event. For presentation, ordinary URL/message characters (including printable quotes, backslashes and Unicode) remain exact; a tiny private streaming UI formatter visibly escapes terminal controls and Unicode bidi controls with `char::escape_debug` only for those characters. The existing App/UI paths have no reusable full-URL escaper; applying `str::escape_debug` to the whole URL would unnecessarily alter printable characters. Never execute it. Do not log or persist OAuth query/fragment data in structured diagnostic records; retain only safe lifecycle metadata there. No speculative URL rewriting/normalization or intermediate escaped-string allocation.
- Convert KAS `session_info_update` `display_error` with `errorType:"mcp_connection_error"` into a typed consumer-visible error carrying the original message and classification. It must remain visible even if an MCP status later updates, and it must not complete/fail a chat turn or fabricate a disconnect. Other `display_error` classifications are not silently claimed by this issue.
- Initial passive OAuth arrives in `mcp/status`, not necessarily this callback. In the integrated stack, the panel shows that URL, explicit authenticate sends reset with `startOAuth:true`, and status—not acknowledgements—clears pending auth and shows connected.
- Keep `secretStorage` absent. Credential persistence is not requested; KAS's supported in-memory OAuth fallback is retained. Do not implement or wait for dark `oauthCompleted` / `oauthCompletion:"notification"` fields absent from the producer.

## Placement / module shape

| Owner | Decision and interface | Forbidden |
|---|---|---|
| `protocol/engine.rs` | Extend adapter-set data with the concrete external-URL concern and derive both callback reachability and advertisement. Follow ADR-0001 amendment. | A naked advertised bool unrelated to dispatch; feature-only execution on bound v2; one adapter per method or generic provider framework. |
| `protocol/kas/callbacks.rs` and a cohesive URL callback implementation beneath `protocol/kas/` if needed | Parse typed request; hold/resolve SDK-facing responder on the existing host drain; enqueue typed display event and acknowledge delivery. The lifecycle remains in `HostMediator`; its capability-agnostic interface needs no new URL knowledge. | Browser, clipboard, OAuth token storage, form interpretation, UI rendering; new responsibility body in generic lifecycle mediation. |
| `protocol/domain_mediator/host.rs`, `client.rs` | Registration/wiring into existing bounded host-request path and adapter refusal only. Host drain remains available before initialize/new completes. | New serial-loop await on a human/browser; raw callback JSON crossing into App. |
| `protocol/convert/kas.rs` / existing `convert/kas/` family owner | Decode MCP display-error classification and message at the KAS wire seam. | KAS metadata parsing in App/UI or generic ACP conversion. |
| Core `types` notifications | Own typed URL-surfacing/error payloads; all existing exhaustive consumers migrate atomically. Perform LSP references before exported symbol changes. | SDK or JSON-RPC request/responder types escaping core. |
| `crates/cyril/src/app.rs` | Thin routing only; reuse the established manual-URL consumer behavior. | Parsing JSON, claiming OAuth completion, spawning an opener. |
| `cyril-ui` notification/state rendering owners | Show escaped URL and durable connection error using existing semantic roles/message paths. | Async calls, bridge commands, capability decisions. |

Protected parents `App`, generic host lifecycle and Engine retain wiring/declarations, not a new OAuth state machine. Compiler/dependency checks and independent review are sufficient for placement; no bespoke source-parser gate is proposed.

The alternative of adding a cross-platform opener plus a new host-question overlay is rejected: neither the ticket nor current first-party semantics requires browser execution, and it would add process/approval ownership without fixing passive OAuth. Merely setting the capability bool is rejected because it advertises a nonexistent handler.

## Claims / falsification

Claims and verification meaning remain approved and unchanged. Current results are recorded once in `evidence.md`, delivery checkpoint. Main DG approved the bounded stable-gutter correction within C2's full visible-URL obligation. Parent subsequently observed four old-layout RED/restored GREEN pairs and exact indicator-only width1 mutation RED/restored GREEN; source review is correct0.97. Actual controlled B/C consumer proof passes at140×40 on partial candidate2954. Workspace Clippy and explicitly continued changed-path gates pass, but mandatory full-workspace tests FAIL and remain unwaived. No all-claims PASS, fully qualified candidate or PR readiness is asserted.

| ID | Claim and cases | Falsifier / verification | Regression coverage |
|---|---|---|---|
| C1 | KAS advertisement and execution derive from one installed adapter; bound v2/no-KAS refuse the same request even in a KAS-enabled build. | Extend existing adapter/handshake reachability matrix through the actual SDK callback seam. Failure: advertised-without-handler, executable-on-v2, or unsupported request returns `null`. | Existing `engine.rs` capability matrix plus host-dispatch behavioral tests; default and KAS builds. |
| C2 | A real `{url}` request is acknowledged only after typed event delivery; accepted URL visibly appears without server/session fields and without launching anything. | SDK fake-agent sends the supported callback during new-session wait and after session creation, records exact `{success}` reply and consumer event; real consumer loopback fixture captures the visible URL. Simulate closed delivery channel: no success acknowledgement. | Callback/SDK test and App/UI URL presentation test, including terminal control characters via established escaping. |
| C3 | MCP display-error message/type is preserved and visible independently of status/panel. | Feed actual `session/update` envelope through KAS engine conversion to consumer render; loopback failed endpoint captures a real MCP error frame. Dropped message, lost classification, duplicate turn completion or forced disconnect falsifies. | Engine-envelope-to-render regression, absent/malformed required fields diagnosed without fabricated text. Pre-fix red against missing converter arm required. |
| C4 | Passive status plus explicit reset/callback reaches connected without secret storage or dark completion messages. | With `nk4o`, run fixture's OAuth endpoint: passive auth-required URL; reset; actual host request; manual local HTTP authorize/callback; connected status clears notice. No fabricated completion notification is sent. A callback/reset success alone must leave pending until status. | Captured status/reset sequence replay plus real consumer acceptance under clean roots. |
| C5 | No provider/account settings or credentials are persisted by this work; v2 URL notifications remain unchanged. | Fixture and consumer environment/config ownership receipt; filesystem evidence restricted to owned roots, no `_kiro/secret/*` advertised/executed; existing v2 MCP render tests. | Capability negative assertions and existing v2 tests. Linux live evidence does not claim native Windows execution. |

Bug sensitivity: parent runs the new callback/error tests against the unmodified base before applying production changes, then green afterward. If actual pre-fix red is unavailable for a claim, checkpoint owner selects the smallest same-defect mutation under the skill; no broad custom oracle is needed. Required repository checks are inherited from AGENTS and the parent’s baseline disposition, not relaxed here.

## Safe live acceptance

The existing `.cyril-tqr8/fixture.py` and clean-root protocol in `evidence.md` supplied earlier parent-authorized native evidence. Its HTTP OAuth stub supplies real DCR/code/PKCE/token legs with synthetic credentials; it does not stand in for Cyril/KAS behavior. The actual consumer must handle the supported callback and show the actual display-error message. No model prompt, production MCP declaration, production organization change, browser or clipboard is necessary. Native authentication failed before initialize on the later first-preview attempt: no native retry, login, account/config change or fixture execution is authorized here. Main separately authorized isolated owned ACP peers on exact WORKSPACEBLOCKED partial candidate2954, producing scoped B/C PASS while preserving the original A navigation FAIL. B's sess_ identity was already valid; C is only an additional fixture variant, not a new criterion. Reconstructed-envelope versus retained native-value provenance and the unwaived full-workspace FAIL remain explicit in `evidence.md`; no fresh native frame/sourceURL or full qualification is invented.

## PR boundary / order

1. **This issue first:** actual URL adapter, advertisement, typed display event, MCP error conversion, focused regression tests. Standalone PR must include independent review and its own verified smoke; no empty capability-only PR.
2. **`nk4o` stacks on this:** passive status/panel/reset and complete management decisions, consuming this real callback. Separate consumer/regression work makes its PR substantive.
3. **`caar` stacks after inventory decision:** startup evidence can consume typed KAS status from `nk4o`; its deadline/early-event/diagnostic qualification remains distinct.

These are the approved issue boundaries. Parent owns commits, tracker changes and each substantive PR; no publication is asserted by this worker's evidence/docs handoff.

## Non-goals

Automatic browser/clipboard launching, durable secret storage and dark future completion notifications are not needed for the requested supported URL callback. Broader governance policy/focus/metering remains `cyril-0o7e`; no closure of that separate issue is implied. No new retry system, telemetry framework, generic OAuth client or production account fixture.

## Approval

**DG APPROVED — 2026-10-19, Main relaying the user's “Delegate routine sign-offs” selection.** Delegation: “I select and record evidence-backed designs. I still ask before scope changes, relaxed acceptance, architecture changes outside the existing boundaries, or explicit risk acceptance.” Main approved manual URL display/delivery acknowledgement, no browser launch, secretStorage off, supported callback/error semantics and PR order. **DG bounded repair approved — 2026-10-20:** Main subsequently authorized a fixed one-column main-conversation gutter for widths>1 with consistent content geometry, widths0/1 retaining content without scrollbar, unchanged URL/protocol/auth semantics, and behavior regressions; exact approval and implementation record are in `review-decisions.md`, Consumer/full-URL bounded repair. Neither approval waives missing proof. Fresh amended gutter source review is correct0.97; later observed parent sensitivity/gates and owned-consumer proof have their separate source pins/limits in `evidence.md`. Mandatory full-workspace acceptance remains BLOCKED and unwaived; parent owns completion and publication.
