use std::collections::{HashMap, VecDeque};
use std::time::{Duration, Instant};

use crossterm::event::{KeyCode, KeyEvent};
use cyril_core::types::*;

use crate::feedback_editor::FeedbackAction;
use crate::file_completer::FileCompleter;
use crate::theme::{
    ColorMode, Theme, ThemeId, parse_theme_id, resolve, theme_config_id, theme_label,
};
use crate::traits::*;

/// Result of handling a key event when autocomplete is active.
#[derive(Debug, PartialEq, Eq)]
pub enum AutocompleteAction {
    /// No autocomplete was active — caller should handle the key normally.
    NotActive,
    /// Key was consumed by autocomplete (navigation, dismiss). No further action needed.
    Consumed,
    /// A suggestion was accepted into the input. Caller should NOT submit.
    Accepted,
    /// A slash command suggestion was accepted AND should be submitted immediately.
    AcceptedAndSubmit,
}

pub struct UiState {
    theme: Theme,
    /// The palette and mode `theme` was resolved from (cyril-qaq0). Kept
    /// alongside the resolved `Theme` so the `/theme` picker can reopen on the
    /// current selection and re-resolve at a new mode.
    theme_id: ThemeId,
    color_mode: ColorMode,
    /// The palette under the cursor while the `/theme` picker is open. Rendered
    /// in place of `theme` so the operator sees the choice before committing;
    /// cleared on both commit and cancel, so a discarded preview can never
    /// survive into the committed appearance (cyril-qaq0).
    theme_preview: Option<Theme>,

    // Chat
    messages: Vec<ChatMessage>,
    messages_version: u64,
    streaming_text: String,
    streaming_user_text: String,
    streaming_thought: Option<String>,

    // Tool calls
    active_tool_calls: Vec<TrackedToolCall>,
    tool_call_index: HashMap<ToolCallId, usize>,
    current_plan: Option<Plan>,

    // Input
    input_text: String,
    input_cursor: usize,

    // Autocomplete
    autocomplete_suggestions: Vec<Suggestion>,
    autocomplete_selected: Option<usize>,
    file_completer: Option<FileCompleter>,
    /// Whether the one-time "@-file completion unavailable" notice has already
    /// been shown (cyril-2mfa). Surfaced on the first @-trigger, not at startup.
    completion_unavailable_notified: bool,
    command_info: Vec<(String, Option<String>)>,

    // Session info (projected by App from SessionController)
    activity: Activity,
    activity_since: Option<Instant>,
    session_label: Option<String>,
    main_session_id: Option<SessionId>,
    current_mode: Option<String>,
    current_model: Option<String>,
    /// Thinking-effort level for the toolbar (Kiro 2.5.0+). Sticky: only
    /// updated when a metadata frame reports it (frames mid-turn may omit it),
    /// and reset on session change.
    effort: Option<EffortLevel>,
    /// Extended-thinking state of the current model (cyril-k3lz), derived by
    /// `ThinkingState::apply_notification`; drives the toolbar segment.
    thinking: ThinkingState,
    context_usage: Option<f64>,
    /// KAS categorized context breakdown (KAS-2b, cyril-5et2). Retain-last: a
    /// `context_usage` frame that omits the breakdown updates `context_usage`
    /// but leaves this intact (absence ≠ cleared), so the bars don't flicker.
    context_breakdown: Option<cyril_core::types::ContextBreakdown>,
    credit_usage: Option<(f64, f64)>,
    last_turn: Option<cyril_core::types::TurnSummary>,
    session_cost: cyril_core::types::SessionCost,
    pending_tokens: Option<cyril_core::types::TokenCounts>,
    pending_metering: Option<cyril_core::types::TurnMetering>,
    /// A refusal alert was already committed to chat this turn (cyril-h8zb).
    /// Kiro's own consumer renders only the first `model_refusal` event;
    /// per-turn scope is the approved conservative reading. Reset at
    /// `TurnCompleted` and on session change/disconnect.
    refusal_alerted_this_turn: bool,
    /// A refusal-bearing metadata frame arrived this turn (cyril-h8zb).
    /// Mirrors `SessionController::pending_refusal` — the toolbar reads
    /// UiState's `last_turn`, so the render-path summary must reconcile too.
    pending_refusal: bool,
    /// The active turn is stalled (cyril-14ou; CONTEXT.md "Stalled turn").
    /// Set by `TurnStalled` while busy; cleared only by a notification that
    /// PROVES the turn is progressing — the six-variant allowlist in
    /// `apply_notification` (`AgentMessage`, `AgentThought`, `ToolCallStarted`,
    /// `ToolCallUpdated`, `PlanUpdated`, `TurnCompleted`). Bridge-synthesized
    /// command responses and every other session-less frame leave it standing,
    /// which is the safe direction but means a chip can lag the resume by up to
    /// the stall threshold (30 s).
    /// Never blocks input and never fakes a terminal: display state only.
    stall: Option<StallState>,

    // Subagent streams and tracker (private — mutated via delegating methods)
    subagents: crate::subagent_ui::SubagentUiState,
    subagent_tracker: cyril_core::subagent::SubagentTracker,

    // Workflow step-session streams (cyril-jxfu; private, same discipline)
    workflow_streams: crate::workflow_ui::WorkflowUiState,

    // Overlays
    approvals: VecDeque<ApprovalState>,
    /// The scope the KAS "Always allow" page last showed. Like Kiro's TUI
    /// (`k2t` carries `trustScope` to the next approval), the next scope page
    /// opens at it while approvals stay queued; it resets to session when a
    /// request arrives to an empty queue (cyril-auxt).
    always_allow_scope: cyril_core::always_allow::GrantScope,
    picker: Option<PickerState>,
    review_form: Option<crate::traits::ReviewForm>,
    hooks_panel: Option<HooksPanelState>,
    powers_panel: Option<PowersPanelState>,
    code_panel: Option<cyril_core::types::CodePanelData>,
    usage_panel: Option<UsagePanelState>,
    /// The last completed snapshot, kept across a panel close so a reopen is
    /// never empty (cyril-nanu D6).
    last_usage_snapshot: Option<cyril_core::types::UsageSnapshot>,
    usage_account: Option<cyril_core::types::UsageAccount>,
    usage_account_fetched_at_ms: Option<u64>,
    usage_account_status: UsageAccountStatus,

    // Session-projected flags
    code_intelligence_active: bool,

    // Chat scroll (None = follow/auto-scroll, Some(n) = n lines above bottom)
    chat_scroll_back: Option<usize>,

    // Terminal
    terminal_size: (u16, u16),
    mouse_captured: bool,
    quit_requested: bool,
    deep_idle: bool,

    // Queue steering (K1a). Count of un-consumed steers, mirrored from the
    // `steering_*` notifications for K1b's toolbar chip. Render is K1b.
    steering_queued: usize,

    // cyril-nvmh: consecutive `TurnCompleted`s observed while `steering_queued`
    // is non-zero with NO intervening `SteeringConsumed`. A tail steer's
    // queued+consumed pair defers to exactly the next turn (cyril-7z7u probe),
    // so two turn-ends without a consume prove the steer is gone — the 2nd
    // drains the optimistic chip. Reset by every steer-reconciliation event so
    // a later legitimate steer isn't drained by turn-ends that predate it.
    turns_since_steer_activity: usize,

    // Voice input (CN2 / V1a). Projected by App from VoiceEvents. `voice_level`
    // is only meaningful while `voice_status == Listening`.
    voice_status: VoiceStatus,
    voice_level: f32,
    memory_status: cyril_core::types::MemoryStatusView,

    // Config
    max_messages: usize,
}

/// The confirmation for an acknowledged thinking toggle on either engine
/// (cyril-k3lz spec B2/B3 — exact strings are fenced).
fn thinking_toggled_message(enabled: bool) -> String {
    if enabled {
        "Thinking turned on.".to_owned()
    } else {
        "Thinking turned off.".to_owned()
    }
}

/// Build the user-facing refusal system message (cyril-h8zb): the wire's
/// explanation verbatim when present, else a fallback naming cyril's own
/// commands (`/model`, `/new` — cyril has no `/rewind`, unlike Kiro's
/// fallback), with a recommendation sentence appended when the wire names a
/// model. The exact strings are fenced contracts (design claim #8).
fn refusal_message(alert: &cyril_core::types::RefusalAlert) -> String {
    let base = match alert.explanation() {
        Some(e) => e.to_string(),
        None => "The model couldn't process this request. Try a different \
                 model with /model or start a new session with /new."
            .to_string(),
    };
    match alert.recommended_model() {
        Some(m) => format!("{base} Recommended model: {m} (switch with /model)."),
        None => base,
    }
}

impl TuiState for UiState {
    /// The committed palette, or the preview while the `/theme` picker is open.
    /// Every renderer reads this one accessor, so a preview needs no separate
    /// rendering path and cannot diverge from the committed theme.
    fn theme(&self) -> Theme {
        self.theme_preview.unwrap_or(self.theme)
    }

    fn messages(&self) -> &[ChatMessage] {
        &self.messages
    }

    /// The live agent text, minus any trailing run that may still be growing
    /// into a `[STEERING <id>: …]` receipt (cyril-3qwa). Withholding is a
    /// suffix-only operation, so this stays a borrow of the buffer; the hidden
    /// bytes are released the moment the run either completes (harvested away)
    /// or is disproved (`withheld_tail` returns 0).
    fn streaming_text(&self) -> &str {
        let cut = self.streaming_text.len() - steer_receipt::withheld_tail(&self.streaming_text);
        &self.streaming_text[..cut]
    }

    fn streaming_thought(&self) -> Option<&str> {
        self.streaming_thought.as_deref()
    }

    fn messages_version(&self) -> u64 {
        self.messages_version
    }

    fn active_tool_calls(&self) -> &[TrackedToolCall] {
        &self.active_tool_calls
    }

    fn current_plan(&self) -> Option<&Plan> {
        self.current_plan.as_ref()
    }

    fn input_text(&self) -> &str {
        &self.input_text
    }

    fn input_cursor(&self) -> usize {
        self.input_cursor
    }

    fn autocomplete_suggestions(&self) -> &[Suggestion] {
        &self.autocomplete_suggestions
    }

    fn autocomplete_selected(&self) -> Option<usize> {
        self.autocomplete_selected
    }

    fn activity(&self) -> Activity {
        self.activity
    }

    fn session_label(&self) -> Option<&str> {
        self.session_label.as_deref()
    }
    fn main_session_id(&self) -> Option<&SessionId> {
        self.main_session_id.as_ref()
    }

    fn current_mode(&self) -> Option<&str> {
        self.current_mode.as_deref()
    }

    fn current_model(&self) -> Option<&str> {
        self.current_model.as_deref()
    }

    fn effort(&self) -> Option<&EffortLevel> {
        self.effort.as_ref()
    }

    fn thinking_enabled(&self) -> Option<bool> {
        self.thinking.enabled()
    }

    fn steering_queued(&self) -> usize {
        self.steering_queued
    }

    fn voice_status(&self) -> VoiceStatus {
        self.voice_status
    }

    fn voice_level(&self) -> f32 {
        self.voice_level
    }
    fn memory_status(&self) -> &cyril_core::types::MemoryStatusView {
        &self.memory_status
    }

    fn context_usage(&self) -> Option<f64> {
        self.context_usage
    }

    fn context_breakdown(&self) -> Option<&cyril_core::types::ContextBreakdown> {
        self.context_breakdown.as_ref()
    }

    fn stall(&self) -> Option<crate::traits::StallState> {
        self.stall
    }

    fn credit_usage(&self) -> Option<(f64, f64)> {
        self.credit_usage
    }

    fn last_turn(&self) -> Option<&cyril_core::types::TurnSummary> {
        self.last_turn.as_ref()
    }

    fn session_cost(&self) -> &cyril_core::types::SessionCost {
        &self.session_cost
    }

    fn approval(&self) -> Option<&ApprovalState> {
        self.approvals.front()
    }

    fn review_form(&self) -> Option<&crate::traits::ReviewForm> {
        self.review_form.as_ref()
    }

    fn picker(&self) -> Option<&PickerState> {
        self.picker.as_ref()
    }

    fn hooks_panel(&self) -> Option<&HooksPanelState> {
        self.hooks_panel.as_ref()
    }

    fn powers_panel(&self) -> Option<&PowersPanelState> {
        self.powers_panel.as_ref()
    }

    fn code_panel(&self) -> Option<&cyril_core::types::CodePanelData> {
        self.code_panel.as_ref()
    }

    fn usage_panel(&self) -> Option<&UsagePanelState> {
        self.usage_panel.as_ref()
    }

    fn code_intelligence_active(&self) -> bool {
        self.code_intelligence_active
    }

    fn chat_scroll_back(&self) -> Option<usize> {
        self.chat_scroll_back
    }

    fn terminal_size(&self) -> (u16, u16) {
        self.terminal_size
    }

    fn mouse_captured(&self) -> bool {
        self.mouse_captured
    }

    fn should_quit(&self) -> bool {
        self.quit_requested
    }

    fn activity_elapsed(&self) -> Option<Duration> {
        self.activity_since.map(|since| since.elapsed())
    }

    fn is_deep_idle(&self) -> bool {
        self.deep_idle
    }

    fn subagent_tracker(&self) -> &cyril_core::subagent::SubagentTracker {
        &self.subagent_tracker
    }

    fn subagent_ui(&self) -> &crate::subagent_ui::SubagentUiState {
        &self.subagents
    }
}

impl UiState {
    /// Replace the active palette and color mode. The resolved `Theme` is the
    /// only thing the renderer reads; `theme_id`/`color_mode` are its inputs.
    pub fn set_appearance(&mut self, theme_id: ThemeId, color_mode: ColorMode) {
        self.theme_id = theme_id;
        self.color_mode = color_mode;
        self.theme = resolve(theme_id, color_mode);
    }

    /// The active palette id.
    pub fn theme_id(&self) -> ThemeId {
        self.theme_id
    }

    /// The active color mode.
    pub fn color_mode(&self) -> ColorMode {
        self.color_mode
    }

    pub fn new(max_messages: usize) -> Self {
        Self {
            theme: resolve(ThemeId::CyrilDark, ColorMode::TrueColor),
            theme_id: ThemeId::CyrilDark,
            color_mode: ColorMode::TrueColor,
            theme_preview: None,
            messages: Vec::new(),
            messages_version: 0,
            streaming_text: String::new(),
            streaming_user_text: String::new(),
            streaming_thought: None,
            active_tool_calls: Vec::new(),
            tool_call_index: HashMap::new(),
            current_plan: None,
            input_text: String::new(),
            input_cursor: 0,
            autocomplete_suggestions: Vec::new(),
            autocomplete_selected: None,
            file_completer: None,
            completion_unavailable_notified: false,
            command_info: Vec::new(),
            activity: Activity::Idle,
            activity_since: None,
            session_label: None,
            main_session_id: None,
            current_mode: None,
            current_model: None,
            effort: None,
            thinking: ThinkingState::Unreported,
            context_usage: None,
            context_breakdown: None,
            credit_usage: None,
            last_turn: None,
            session_cost: cyril_core::types::SessionCost::new(),
            pending_tokens: None,
            pending_metering: None,
            refusal_alerted_this_turn: false,
            pending_refusal: false,
            stall: None,
            subagents: crate::subagent_ui::SubagentUiState::new(),
            subagent_tracker: cyril_core::subagent::SubagentTracker::new(),
            workflow_streams: crate::workflow_ui::WorkflowUiState::new(),
            approvals: VecDeque::new(),
            always_allow_scope: cyril_core::always_allow::GrantScope::Session,
            picker: None,
            review_form: None,
            hooks_panel: None,
            powers_panel: None,
            code_panel: None,
            usage_panel: None,
            last_usage_snapshot: None,
            usage_account: None,
            usage_account_fetched_at_ms: None,
            usage_account_status: UsageAccountStatus::Idle,
            code_intelligence_active: false,
            chat_scroll_back: None,
            terminal_size: (80, 24),
            mouse_captured: false,
            quit_requested: false,
            deep_idle: false,
            steering_queued: 0,
            turns_since_steer_activity: 0,
            voice_status: VoiceStatus::Idle,
            voice_level: 0.0,
            memory_status: cyril_core::types::MemoryStatusView::default(),
            max_messages,
        }
    }

    /// Number of un-consumed queued steers (K1a state; K1b renders it).
    pub fn steering_queued(&self) -> usize {
        self.steering_queued
    }

    /// Apply a notification from the bridge. Returns `true` if the UI state changed.
    pub fn apply_notification(&mut self, notification: &Notification) -> bool {
        // Stalled-turn display (cyril-14ou, C7; narrowed by PR #94 review
        // SP3): only notifications that PROVE the turn is progressing — or
        // over — end the quiet period. Bridge-synthesized command responses
        // (CommandExecuted, SettingsList, SubagentSpawned, ...) say nothing
        // about the stalled turn and must not vanish the cancel affordance;
        // new variants default to KEEPING the chip, the safe direction.
        let stall_cleared = matches!(
            notification,
            Notification::AgentMessage(_)
                | Notification::AgentThought(_)
                | Notification::ToolCallStarted(_)
                | Notification::ToolCallUpdated(_)
                | Notification::PlanUpdated(_)
                | Notification::TurnCompleted { .. }
        ) && self.stall.take().is_some();
        // Thinking state has one owner of its derivation (cyril-k3lz); this
        // state machine only holds the result for the toolbar and the KAS ack.
        let thinking_changed = self.thinking.apply_notification(notification);
        let changed = match notification {
            Notification::AgentMessage(msg) => {
                // Flush any pending user replay so the user turn commits
                // before any subsequent agent text.
                self.flush_streaming_user_text();
                // A preceding thought block ends once response text begins —
                // commit it first so it is ordered before the response.
                self.flush_streaming_thought();
                if msg.is_streaming {
                    self.streaming_text.push_str(&msg.text);
                    self.harvest_steer_receipts();
                    self.set_activity(Activity::Streaming);
                } else {
                    self.streaming_text.push_str(&msg.text);
                    self.harvest_steer_receipts();
                    self.commit_streaming();
                    self.set_activity(Activity::Ready);
                }
                true
            }
            Notification::AgentThought(thought) => {
                // Thought chunks stream as token-deltas (mirroring AgentMessage),
                // so accumulate them — overwriting would show only the last token.
                // The accumulated block is committed to the message list at the
                // next boundary (response text, tool call, user replay, turn end)
                // via flush_streaming_thought, so reasoning persists in scrollback.
                self.streaming_thought
                    .get_or_insert_with(String::new)
                    .push_str(&thought.text);
                true
            }
            Notification::UserMessage(msg) => {
                // Kiro replays user turns during session/load, potentially in
                // multiple chunks per message (mirroring AgentMessageChunk).
                // Accumulate into `streaming_user_text` and flush on boundaries
                // (tool call, turn complete, agent message). Flush any pending
                // agent text first so ordering is preserved.
                self.flush_streaming_agent_text();
                // Any pending thought belongs to the previous agent turn.
                self.flush_streaming_thought();
                self.streaming_user_text.push_str(&msg.text);
                if !msg.is_streaming {
                    self.flush_streaming_user_text();
                }
                true
            }
            Notification::ToolCallStarted(tc) => {
                self.track_tool_call(tc);
                self.set_activity(Activity::ToolRunning);
                true
            }
            Notification::ToolCallUpdated(tc) => {
                // KAS Tool Load/Subagent Response and v2 validation failures
                // can arrive without a start. Their first update owns the same
                // chronological row as a normal call; subsequent frames merge.
                self.track_tool_call(tc);
                true
            }
            Notification::PlanUpdated(plan) => {
                self.current_plan = Some(plan.clone());
                true
            }
            Notification::MetadataUpdated {
                context_usage,
                metering,
                tokens,
                duration_ms,
                effort,
                // `effort` is already derived from the reasoning snapshot
                // (cyril-q1xs), and thinking on/off is consumed above by
                // `self.thinking.apply_notification` — its single owner
                // (cyril-k3lz). Do not derive either again here.
                reasoning: _,
                // Routing tag (cyril-fh06): the App has already diverted
                // subagent-scoped frames before this state machine sees one.
                session_id: _,
                refusal,
            } => {
                // Retain-last: a frame that omits contextUsagePercentage
                // (real 2.4.1 wire shape: duration/effort-only frames) means
                // "no update", not "context dropped to zero" — overwriting
                // would stamp the toolbar to 0.0%. Same discipline as the
                // sticky `effort` below.
                if let Some(u) = context_usage {
                    self.context_usage = Some(u.percentage());
                }
                self.pending_tokens = tokens.clone();
                // Credits and duration merge independently (order-independent,
                // last-writer-wins per field): credits frames and
                // duration/effort-only frames interleave (real 2.4.1 shape)
                // and must not clobber each other — see
                // `TurnMetering::merge_pending` (cyril-1gim).
                self.pending_metering = TurnMetering::merge_pending(
                    self.pending_metering.take(),
                    metering.clone(),
                    *duration_ms,
                );
                // Sticky: absent effort means "no update" — context-only
                // frames interleave with effort frames mid-turn, so keeping
                // the current badge avoids flicker. An explicit `effort: null`
                // is the engine clearing the badge; a string sets it
                // (cyril-1gim).
                match effort {
                    EffortUpdate::Unchanged => {}
                    EffortUpdate::Clear => self.effort = None,
                    EffortUpdate::Set(level) => self.effort = Some(level.clone()),
                }
                // Model-refusal alert (cyril-h8zb): commit the system message
                // at frame arrival, not at turn end — TurnCompleted can race
                // ahead of late notifications (cyril-9akh), and the probe
                // showed the refusal frame lands just before the prompt
                // response. One alert per turn (Kiro's own consumer dedupes
                // to the first event). `add_system_message` flushes
                // streaming text first, so the message commits in
                // chronological order.
                if let Some(alert) = refusal {
                    self.pending_refusal = true;
                    if !self.refusal_alerted_this_turn {
                        self.refusal_alerted_this_turn = true;
                        self.add_system_message(refusal_message(alert));
                    }
                }
                true
            }
            Notification::TurnMeteringUpdated(update) => {
                let metering =
                    TurnMetering::from_charges(update.charges().to_vec(), update.duration_ms());
                self.pending_metering =
                    TurnMetering::merge_pending(self.pending_metering.take(), Some(metering), None);
                true
            }
            Notification::UsageAccountUpdated {
                account,
                fetched_at_ms,
            } => {
                self.usage_account = Some(account.clone());
                self.usage_account_fetched_at_ms = *fetched_at_ms;
                self.usage_account_status = UsageAccountStatus::Fresh;
                self.sync_usage_account_panel();
                true
            }
            Notification::UsageAccountQueryFailed { message } => {
                self.usage_account_status = if self.usage_account.is_some() {
                    UsageAccountStatus::Stale(message.clone())
                } else {
                    UsageAccountStatus::Unavailable(message.clone())
                };
                self.sync_usage_account_panel();
                true
            }
            Notification::UsageUpdated { used, size, .. } => {
                if *size == 0 {
                    // `size == 0` is protocol-meaningless; don't claim state
                    // changed (beyond a stall chip this frame already cleared).
                    tracing::warn!(used, "UsageUpdated with size=0, ignoring");
                    return stall_cleared;
                }
                // Clamp to [0, 100] via ContextUsage::new() — same constructor
                // SessionController uses, so the clamp rule is defined once in
                // the domain type. Avoids the toolbar rendering >100% if Kiro
                // ever reports used > size. (UiState stores the clamped f64,
                // not the ContextUsage itself.)
                let pct = (*used as f64 / *size as f64) * 100.0;
                self.context_usage = Some(ContextUsage::new(pct).percentage());
                true
            }
            Notification::UsageSessionStarted { .. } | Notification::TurnUsageCaptured(_) => {
                stall_cleared
            }
            Notification::ContextBreakdownUpdated {
                usage_percentage,
                breakdown,
            } => {
                // KAS-2b (cyril-5et2): under KAS the scalar `Context: N%` comes
                // from context_usage frames (no kiro.dev/metadata), so feed it
                // through the same ContextUsage::new() clamp the v2 path uses.
                self.context_usage = Some(ContextUsage::new(*usage_percentage).percentage());
                // Load-bearing retain-last: only overwrite when a breakdown is
                // present. A scalar-only frame (breakdown None) must NOT clear the
                // stored bars — overwriting with None would flicker them. Same
                // discipline as the sticky `effort` field above; enforced here at
                // runtime (the `if let`), not a debug_assert.
                if let Some(bd) = breakdown {
                    self.context_breakdown = Some(bd.clone());
                }
                true
            }
            Notification::TurnStalled { quiet } => {
                // A late stall signal racing a terminal must not chip an idle
                // session — the turn it described is already over.
                if matches!(self.activity, Activity::Idle | Activity::Ready) {
                    tracing::debug!(
                        quiet_secs = quiet.as_secs(),
                        "late TurnStalled for an idle session; not displayed"
                    );
                    false
                } else {
                    self.stall = Some(crate::traits::StallState {
                        quiet: *quiet,
                        since: Instant::now(),
                        cancel_sent: false,
                    });
                    true
                }
            }
            Notification::TurnCompleted { stop_reason } => {
                self.commit_streaming();
                // Reconcile (cyril-h8zb): refusal metadata + ambiguous ACP
                // EndTurn => the render-path summary reads Refusal, so the
                // toolbar's existing "Refused" chip fires. The rule lives on
                // StopReason so this and SessionController cannot drift.
                let refused = std::mem::take(&mut self.pending_refusal);
                self.refusal_alerted_this_turn = false;
                let stop_reason = stop_reason.reconcile_refusal(refused);
                self.last_turn = Some(cyril_core::types::TurnSummary::new(
                    stop_reason,
                    self.pending_tokens.take(),
                    self.pending_metering.take(),
                ));
                if let Some(m) = self.last_turn.as_ref().and_then(|t| t.metering()) {
                    self.session_cost.record_turn(m);
                }
                // cyril-7z7u: do NOT reset the steer chip at turn-end. The probe
                // (`.cyril-7z7u/findings.md`) showed the backend pairs
                // `steering_queued`+`steering_consumed` within one turn and DEFERS a
                // late steer's whole pair to the next turn — so a steer pending at
                // turn-end is genuinely still queued and drains via `SteeringConsumed`
                // (possibly next turn). The optimistic chip drains on consumed, not
                // on turn-end; resetting here would under-count a pending steer.
                //
                // cyril-nvmh: but a steer whose consume NEVER arrives (turn
                // cancelled/errored, or an accept the backend never streams a
                // consume for) would otherwise leave a phantom chip until `/new`.
                // The 7z7u pair defers to EXACTLY the next turn, so a chip that
                // survives TWO consecutive turn-ends with no intervening
                // `SteeringConsumed` is provably gone — drain it on the 2nd.
                // One idle tail (a single turn-end) is truthful and must NOT
                // drain: the real consume arrives on the next turn and resets
                // the counter first.
                if self.steering_queued > 0 {
                    self.turns_since_steer_activity += 1;
                    if self.turns_since_steer_activity >= 2 {
                        self.steering_queued = 0;
                        self.turns_since_steer_activity = 0;
                        // Keep the 7z7u oracle (counter == #Queued chips): the
                        // steer can never land now, so finalize its echoes too.
                        if self.flip_queued_steer_echoes(SteerEchoStatus::Cleared, false) {
                            self.messages_version += 1;
                        }
                    }
                }
                self.set_activity(Activity::Ready);
                true
            }
            Notification::BridgeDisconnected { reason } => {
                self.add_system_message(format!("Disconnected: {reason}"));
                self.last_turn = None;
                self.pending_tokens = None;
                self.pending_metering = None;
                self.refusal_alerted_this_turn = false;
                self.pending_refusal = false;
                // A dead connection has no live context — clear the scalar and the
                // KAS breakdown bars so the toolbar stops showing a stale
                // `Context: N%` and 5-label bar as if the session were alive.
                self.context_usage = None;
                self.context_breakdown = None;
                self.usage_account_status =
                    UsageAccountStatus::Unavailable(format!("bridge disconnected: {reason}"));
                self.sync_usage_account_panel();
                // cyril-nvmh (path d): a dead bridge can never drain a queued
                // steer, so this is an explicit drain point for the optimistic
                // chip too — otherwise it leaks past the disconnect until `/new`.
                // Finalize the Queued echoes with it to keep the 7z7u oracle
                // (counter == #Queued chips); the added system message already
                // bumps `messages_version`, so the flip's redraw is covered.
                self.steering_queued = 0;
                self.turns_since_steer_activity = 0;
                self.flip_queued_steer_echoes(SteerEchoStatus::Cleared, false);
                self.set_activity(Activity::Idle);
                true
            }
            Notification::ModeChanged { mode_id } => {
                self.current_mode = Some(mode_id.as_str().to_string());
                true
            }
            Notification::AgentSwitched {
                name,
                welcome,
                model,
                ..
            } => {
                self.current_mode = Some(name.clone());
                // Agent switches are model-state boundaries. An absent model
                // means the new agent has no known model, never "keep the old
                // agent's model".
                self.set_current_model(model.clone());
                if let Some(msg) = welcome {
                    self.add_system_message(format!("Switched to {name}: {msg}"));
                } else {
                    self.add_system_message(format!("Switched to {name}"));
                }
                true
            }
            Notification::CompactionStatus { phase, summary } => {
                use cyril_core::types::CompactionPhase;
                let message = match phase {
                    CompactionPhase::Started => "Compacting conversation context...".to_string(),
                    CompactionPhase::Completed => match summary.as_deref() {
                        Some(s) => format!("Compaction completed: {s}"),
                        None => "Compaction completed.".to_string(),
                    },
                    CompactionPhase::Failed { error } => match error.as_deref() {
                        Some(e) => format!("Compaction failed: {e}"),
                        None => "Compaction failed.".to_string(),
                    },
                };
                self.add_system_message(message);
                true
            }
            Notification::ClearStatus { message } => {
                self.add_system_message(format!("Clear: {message}"));
                true
            }
            Notification::RateLimited { message } => {
                self.add_system_message(format!("Rate limited: {message}"));
                true
            }
            // KAS-8 `_kiro/system/notify` (cyril-08eh) — level-prefixed system
            // message. Same non-terminal contract as RateLimited: does not clear
            // busy guard.
            Notification::SystemNotify { level, message } => {
                use cyril_core::types::event::SystemNotifyLevel;
                let prefix = match &level {
                    SystemNotifyLevel::Info => "info",
                    SystemNotifyLevel::Warning => "warning",
                    SystemNotifyLevel::Unknown(l) => {
                        tracing::debug!(level = %l, "unknown _kiro/system/notify level");
                        l.as_str()
                    }
                };
                self.add_system_message(format!("[{prefix}] {message}"));
                true
            }
            // cyril-7z7u: the chip count is optimistic (incremented at
            // `add_steer_echo`), so the wire confirmation must NOT re-count cyril's
            // own steer — that would double-count. A steer originated by ANOTHER
            // observer (wire echo with no local optimistic echo) is not counted
            // today; that's the single-client model — see cyril-8lfs.
            // cyril-vgcm C8: the echo's one job here is to BIND its queue id to
            // the oldest id-less Queued chip, so the id-scoped Consumed/Cleared
            // echoes can reconcile the right chip. Never a counter mutation.
            Notification::SteeringQueued { message_id, .. } => match message_id {
                Some(id) => self.bind_steer_echo_id(id),
                None => false,
            },
            Notification::SteeringConsumed { message_id, .. } => {
                // cyril-nvmh: a consume proves the queue is actively draining, so
                // reset the consecutive-turn drain counter — a later steer gets a
                // fresh idle-tail grace instead of inheriting stale turn-ends.
                self.turns_since_steer_activity = 0;
                // One queued steer drained into the turn. Id-match preferred,
                // FIFO fallback (cyril-vgcm C9); `content` is advisory, never a
                // match key. The counter tracks ACTUAL flips — a duplicate
                // injected echo (id already terminal) must not decrement, or the
                // count drifts below the Queued-chip total (cyril-7z7u:
                // counter == #Queued chips).
                if self.flip_consumed_steer_echo(message_id.as_deref()) {
                    self.steering_queued = self.steering_queued.saturating_sub(1);
                    self.messages_version += 1;
                    true
                } else {
                    false
                }
            }
            // Id-scoped queue drain (cyril-vgcm C6). KAS routinely broadcasts a
            // post-injection Cleared naming the just-injected id (findings F4),
            // so an id-blind flip-all would wrongly kill later still-queued
            // steers. EMPTY ids is the old v2 dialect's shape and means
            // "everything still queued" (C7) — flip ALL Queued, zero the count.
            Notification::SteeringCleared { message_ids } => {
                if message_ids.is_empty() {
                    self.steering_queued = 0;
                    // cyril-nvmh: reconciling the queue resets the drain counter.
                    self.turns_since_steer_activity = 0;
                    if self.flip_queued_steer_echoes(SteerEchoStatus::Cleared, false) {
                        self.messages_version += 1;
                    }
                    true
                } else {
                    let flips = self.flip_cleared_steer_echoes(message_ids);
                    if flips > 0 {
                        self.steering_queued = self.steering_queued.saturating_sub(flips);
                        // cyril-nvmh: reconciling the queue resets the drain counter.
                        self.turns_since_steer_activity = 0;
                        self.messages_version += 1;
                        true
                    } else {
                        false
                    }
                }
            }
            // Advisory ONLY (cyril-vgcm C12): `_session/steer/clear` returned
            // -32601 but steer itself still works — the queued chips are real
            // and will drain normally, so unlike SteeringUnsupported this must
            // NOT flip echoes or zero the counter.
            Notification::SteeringClearUnsupported { message } => {
                self.add_system_message(message.clone());
                true
            }
            Notification::SteeringUnsupported { message } => {
                // add_system_message bumps messages_version unconditionally, so the
                // echo flips below are covered by that redraw.
                self.add_system_message(message.clone());
                // cyril-7z7u: every optimistic steer is dead (the backend can't
                // steer), so clear the chip too — not just the echoes; otherwise the
                // optimistic count would leak. Flip ALL Queued -> Unsupported (a
                // burst may have several in flight before the single bridge-dedup'd
                // notice). Terminal states untouched.
                self.steering_queued = 0;
                // cyril-nvmh: no chip remains, so the drain counter resets too.
                self.turns_since_steer_activity = 0;
                self.flip_queued_steer_echoes(SteerEchoStatus::Unsupported, false);
                true
            }
            Notification::SessionCreated {
                session_id,
                current_mode,
                current_model,
                available_modes,
                available_models: _,
            } => {
                if self.main_session_id.as_ref() != Some(session_id) {
                    // IDs are unique only within a session. Keep old history,
                    // but never merge a new session's call into its old row.
                    self.tool_call_index.clear();
                    self.active_tool_calls.clear();
                }
                // A config picker belongs to the session whose catalog opened
                // it. Close it at the session boundary so a delayed `/new` or
                // `/load` response cannot apply the old selection to the new
                // session. Cyril's local theme picker is intentionally kept.
                if self
                    .picker
                    .as_ref()
                    .is_some_and(|picker| matches!(picker.kind, PickerKind::Config(_)))
                {
                    self.picker_cancel();
                }
                self.session_label = Some(session_id.as_str().to_string());
                self.main_session_id = Some(session_id.clone());
                self.current_mode = current_mode.as_ref().map(|m| m.as_str().to_string());
                // Session creation is likewise a model-state boundary: None
                // must clear the prior session's model rather than retain it.
                self.set_current_model(current_model.clone());
                // Effort is per-session and re-reported by the new session's
                // metadata; reset so a prior session's level doesn't linger.
                self.effort = None;
                // Context usage + the KAS breakdown bars are likewise per-session
                // and re-pushed by the new session. Reset both so a prior session's
                // `Context: N%` and 5-label breakdown bar don't linger on the fresh
                // session: retain-last governs only an *absent* frame WITHIN a
                // session, never a session boundary (same discipline as `effort`).
                self.context_usage = None;
                self.context_breakdown = None;
                self.last_turn = None;
                self.pending_tokens = None;
                self.pending_metering = None;
                self.session_cost = cyril_core::types::SessionCost::new();
                // The chip is per-session; reset it so a prior session's pending
                // steers don't leak a phantom count onto the fresh session.
                // (cyril-7z7u: the chip is optimistic — driven by add_steer_echo,
                // not the wire. It is the ONLY steer-queue counter; the old
                // SessionController.steering_depth mirror was deleted — cyril-85py.)
                self.steering_queued = 0;
                // cyril-nvmh: a fresh session starts with a clean drain counter.
                self.turns_since_steer_activity = 0;
                // Finalize any leftover Queued steer echoes from the old session.
                // The new session is a different session_id; its SteeringConsumed
                // would otherwise FIFO-flip an orphan echo from the dead session
                // (cross-session mis-attribution). The old steers can never drain
                // here, so mark them Cleared.
                self.flip_queued_steer_echoes(SteerEchoStatus::Cleared, false);
                // Per-turn refusal state is per-session by extension
                // (cyril-h8zb): a refusal buffered in the old session must not
                // dedupe-suppress or mislabel the new session's first turn.
                self.refusal_alerted_this_turn = false;
                self.pending_refusal = false;
                self.add_system_message(format!("Session created: {}", session_id.as_str()));
                // If the active mode carries a Kiro-specific welcome message
                // (e.g. kiro_planner's "Transform any idea..."), surface it.
                if let Some(mode_id) = current_mode.as_ref() {
                    match available_modes.iter().find(|m| m.id() == mode_id) {
                        Some(mode) => {
                            if let Some(welcome) = mode.welcome_message() {
                                self.add_system_message(welcome.to_string());
                            }
                        }
                        None if !available_modes.is_empty() => {
                            // current_mode names a mode not in the catalog —
                            // likely version skew or a partial session/load
                            // response. Trace so the silent suppression of a
                            // welcome message doesn't look like a bug.
                            tracing::debug!(
                                mode_id = %mode_id,
                                available = ?available_modes
                                    .iter()
                                    .map(|m| m.id().as_str().to_string())
                                    .collect::<Vec<_>>(),
                                "SessionCreated current_mode has no matching entry in available_modes"
                            );
                        }
                        None => {}
                    }
                }
                self.set_activity(Activity::Ready);
                true
            }
            Notification::ToolCallChunk { .. } => {
                self.set_activity(Activity::ToolRunning);
                true
            }
            Notification::ConfigOptionsUpdated(options)
            | Notification::ConfigOptionSet { options, .. } => {
                let model_changed = if let Some(model_opt) = options
                    .iter()
                    .find(|o| o.key == KasConfigId::Model.as_str())
                {
                    // Route through set_current_model so the "clear effort on a
                    // real model change" invariant lives in exactly one place.
                    self.set_current_model(model_opt.value.clone());
                    true
                } else {
                    false
                };
                // KAS mode chip feed (cyril-vh69 C11): KAS emits no
                // `current_mode_update`; the catalog's `mode.currentValue`
                // is the only source — always the RETURNED value, never the
                // requested one (KAS coerces an unknown mode to `vibe`).
                let mode_changed = if let Some(mode_opt) =
                    options.iter().find(|o| o.key == KasConfigId::Mode.as_str())
                {
                    let changed = self.current_mode != mode_opt.value;
                    self.current_mode = mode_opt.value.clone();
                    changed
                } else {
                    false
                };
                // KAS effort chip feed (cyril-vh69 C9, absorbs cyril-838u):
                // repopulation comes AFTER the model feed, so
                // set_current_model's clear-on-change wins within one frame —
                // a frame that switches the model and carries no effortLevel
                // leaves effort cleared (auto), and a later frame repopulates.
                // Unknown levels render verbatim via EffortLevel::Other.
                let effort_changed = if let Some(effort_opt) = options
                    .iter()
                    .find(|o| o.key == KasConfigId::Effort.as_str())
                {
                    let level = effort_opt.value.as_deref().and_then(EffortLevel::from_wire);
                    let changed = self.effort != level;
                    self.effort = level;
                    changed
                } else {
                    false
                };
                // KAS thinking ack (cyril-k3lz B3): the message follows the
                // REBUILT set, which `self.thinking` already reflects.
                let thinking_acked = matches!(
                    notification,
                    Notification::ConfigOptionSet { config_id, .. } if config_id == THINKING_CONFIG_ID
                );
                if thinking_acked {
                    let text = match self.thinking.enabled() {
                        Some(enabled) => thinking_toggled_message(enabled),
                        None => THINKING_NOT_TOGGLEABLE_MESSAGE.to_owned(),
                    };
                    self.add_system_message(text);
                }
                // Read-back confirmations (cyril-vh69 C10): a ConfigOptionSet
                // for model/mode/effortLevel posts the RETURNED currentValue,
                // so a set KAS silently ignored (bogus effort level — SUCCESS
                // with an unchanged currentValue) SHOWS the unchanged value.
                let config_acked = match notification {
                    Notification::ConfigOptionSet { config_id, .. } => {
                        KasConfigId::from_wire(config_id)
                            .is_some_and(|id| self.ack_config_set(id, options))
                    }
                    _ => false,
                };
                model_changed || mode_changed || effort_changed || thinking_acked || config_acked
            }
            // v2 `reasoning` ack (cyril-k3lz B2). The toolbar follows the next
            // metadata snapshot; the message confirms immediately.
            Notification::ThinkingToggled { enabled } => {
                self.add_system_message(thinking_toggled_message(*enabled));
                true
            }
            Notification::CommandsUpdated { .. } => {
                // Consumed by the App layer (registers in CommandRegistry).
                false
            }
            Notification::CommandOptionsReceived { .. } => {
                // Handled by the App layer (opens picker or shows message).
                false
            }
            Notification::CommandExecuted { .. } => {
                // Handled by the App layer (formats and displays the response).
                false
            }
            Notification::SettingsList { .. } => {
                // Handled by the App layer (forwards to settings UI when one
                // exists). Today there's no settings surface in cyril, so the
                // notification is observable via tracing but not displayed.
                false
            }
            Notification::McpServerInitFailure { server_name, error } => {
                if let Some(err) = error {
                    self.add_system_message(format!(
                        "MCP server '{server_name}' failed to initialize: {err}"
                    ));
                } else {
                    self.add_system_message(format!(
                        "MCP server '{server_name}' failed to initialize"
                    ));
                }
                true
            }
            Notification::McpServerInitialized { server_name } => {
                self.add_system_message(format!("MCP server '{server_name}' ready"));
                true
            }
            Notification::McpOAuthRequest { .. } => {
                // Handled by App (cross-cutting concern: displays URL for manual browser opening)
                false
            }
            Notification::ExternalUrlRequested { url } => {
                // Delivery requests manual sign-in, not authorization completion.
                // Keep the full URL while making terminal controls visible.
                self.add_system_message(format!(
                    "Sign-in requested. Open in browser: {}",
                    crate::mcp_notice::terminal_safe(url)
                ));
                true
            }
            Notification::McpConnectionError { message } => {
                // A durable, non-terminal notice: later MCP status must not
                // replace it or release the busy turn.
                self.add_system_message(format!(
                    "[error] {}",
                    crate::mcp_notice::terminal_safe(message)
                ));
                true
            }
            Notification::AgentNotFound {
                requested,
                fallback,
            } => {
                if let Some(fb) = fallback {
                    self.add_system_message(format!("Agent '{requested}' not found, using '{fb}'"));
                } else {
                    self.add_system_message(format!("Agent '{requested}' not found"));
                }
                true
            }
            Notification::AgentConfigError { path, error } => {
                self.add_system_message(format!("Agent config error in {path}: {error}"));
                true
            }
            Notification::ModelNotFound {
                requested,
                fallback,
            } => {
                if let Some(fb) = fallback {
                    self.add_system_message(format!(
                        "Model '{requested}' not available, using '{fb}'"
                    ));
                } else {
                    self.add_system_message(format!("Model '{requested}' not available"));
                }
                true
            }

            // Subagent list and inbox notifications are handled by SubagentTracker,
            // which is owned by UiState but updated separately via
            // apply_subagent_tracker_notification(). These variants are no-ops here.
            Notification::SubagentListUpdated { .. } | Notification::InboxNotification { .. } => {
                false
            }

            // Spawn/terminate/error notifications surface as system messages.
            Notification::SubagentSpawned { session_id, name } => {
                self.add_system_message(format!(
                    "Spawned subagent '{name}' ({})",
                    session_id.as_str()
                ));
                true
            }
            Notification::SubagentTerminated { session_id } => {
                // Try to resolve name via the tracker for a friendlier message.
                let name = self
                    .subagent_tracker
                    .get(session_id)
                    .map(|info| info.session_name().to_string());
                let msg = match name {
                    Some(n) => format!("Terminated subagent '{n}' ({})", session_id.as_str()),
                    None => format!("Terminated subagent ({})", session_id.as_str()),
                };
                self.add_system_message(msg);
                true
            }
            Notification::BridgeError { operation, message } => {
                self.add_system_message(format!("{operation} failed: {message}"));
                true
            }
            // cyril-9104: the App reopens the step's question first; the line
            // reads like the bridge error it replaces.
            Notification::WorkflowStepAnswerFailed { message, .. } => {
                self.add_system_message(format!("answer workflow step failed: {message}"));
                true
            }
            // cyril-gk17: a KAS-executed hook finished. Under `kas_hooks = "kas"`
            // the agent runs these commands on this host with no permission
            // prompt, so the transcript line IS the audit trail — it is the only
            // place the user can see that a hook fired at all.
            Notification::HookExecuted {
                name,
                status,
                exit_code,
            } => {
                let mut text = format!("Hook {name}: {status}");
                // Only appended when the hook actually reported one. A default
                // of 0 would assert a clean exit that was never claimed.
                if let Some(code) = exit_code {
                    text.push_str(&format!(" (exit {code})"));
                }
                self.add_system_message(text);
                true
            }
            // Workflow lifecycle is owned outside UiState. This consumer must
            // not inspect or retain the payload.
            Notification::Workflow(_) => false,
            // Same ownership rule as `Workflow`: snapshots are the App-owned
            // tracker's to consume, exactly once; reaching UiState is a
            // routing bug worth hearing about, not worth panicking over.
            Notification::WorkflowSnapshot(_) => {
                tracing::warn!("WorkflowSnapshot reached UiState; it is tracker-owned");
                false
            }
            // cyril-9104: the App hands a workflow message to the tracker and
            // renders what it resolves; reaching UiState is a routing bug.
            Notification::WorkflowMessage(_) => {
                tracing::warn!("WorkflowMessage reached UiState; it is tracker-owned");
                false
            }
            // One system message per command outcome, built by the pure
            // formatter (cyril-0qe6). Run *progress* rendering is cyril-zd8u.
            Notification::WorkflowCommand(outcome) => {
                self.add_system_message(crate::workflow_format::format_workflow_outcome(outcome));
                true
            }
            // Handled by the App via `refresh_hooks_panel`, not here
            // (cyril-gk17). It must NOT open the panel — it arrives unprompted
            // whenever KAS sees a hook file change — and this method cannot
            // express "update only if already open" without duplicating that
            // decision. Listed explicitly rather than falling into a catch-all
            // so a future notification cannot be silently swallowed.
            Notification::HooksChanged { .. } => false,
            // Handled by the App via `refresh_powers_panel`, not here
            // (cyril-v19o). Same reasoning as `HooksChanged` above: the push
            // arrives unprompted once per session (+18 ms after `session/new`)
            // and must never pop a modal open over the user, which is a
            // decision this method cannot express without duplicating the App's
            // "only if already open" rule.
            Notification::PowersChanged { .. } => false,
            // cyril-lki9 C17 (B7): a turn began — possibly one the agent
            // started itself, which may stay silent for a minute — so an idle
            // indicator becomes busy now, not at the first chunk. A turn that
            // is already busy (cyril's own dispatch) is left as it is.
            Notification::TurnStarted => {
                if matches!(self.activity, Activity::Idle | Activity::Ready) {
                    self.set_activity(Activity::Waiting);
                    true
                } else {
                    false
                }
            }
            // The header and inline notices need the App-owned wake label, so
            // the App renders them via `begin_agent_initiated_turn` /
            // `show_engine_injection` (cyril-lki9 C14); nothing to do here.
            Notification::AgentInitiatedTurn(_) | Notification::EngineMessageInjected { .. } => {
                false
            }
        };
        changed || stall_cleared || thinking_changed
    }

    /// Insert the first observed call frame, or merge into its retained row.
    fn track_tool_call(&mut self, tc: &ToolCall) {
        let inserted = if let Some(&idx) = self.tool_call_index.get(tc.id()) {
            if let ChatMessageKind::ToolCall(tracked) = &mut self.messages[idx].kind {
                tracked.update(tc);
            }
            false
        } else {
            self.flush_streaming_user_text();
            self.flush_streaming_agent_text();
            self.flush_streaming_thought();
            let idx = self.messages.len();
            self.messages
                .push(ChatMessage::tool_call(TrackedToolCall::new(tc.clone())));
            self.tool_call_index.insert(tc.id().clone(), idx);
            true
        };
        self.messages_version += 1;

        if let Some(tracked) = self
            .active_tool_calls
            .iter_mut()
            .find(|tracked| tracked.id() == tc.id())
        {
            tracked.update(tc);
        } else if inserted {
            self.active_tool_calls
                .push(TrackedToolCall::new(tc.clone()));
        }
    }

    /// Flush remaining streaming text and clear active tool call display.
    /// Tool calls are already committed at their first start or update frame;
    /// keep their history index so late updates cannot duplicate retained rows.
    pub fn commit_streaming(&mut self) {
        self.flush_streaming_user_text();
        self.flush_streaming_agent_text();

        // Clear active display — tool calls are already in messages
        self.active_tool_calls.clear();
        self.flush_streaming_thought();
        self.enforce_message_limit();
    }

    /// Commit pending user-message chunks to a single `UserText` message.
    /// Called at every boundary where an ordered commit is required
    /// (tool call start, turn completion, new agent text).
    fn flush_streaming_user_text(&mut self) {
        if !self.streaming_user_text.is_empty() {
            let text = std::mem::take(&mut self.streaming_user_text);
            self.messages.push(ChatMessage::user_text(text));
            self.messages_version += 1;
        }
    }

    /// Commit pending agent-message chunks to a single `AgentText` message.
    /// Symmetric with `flush_streaming_user_text` — called at boundaries
    /// where the agent stream must commit before the next message arrives
    /// (tool call start, user replay, turn completion).
    fn flush_streaming_agent_text(&mut self) {
        if !self.streaming_text.is_empty() {
            let text = std::mem::take(&mut self.streaming_text);
            self.messages.push(ChatMessage::agent_text(text));
            self.messages_version += 1;
        }
    }

    /// Commit any accumulated thought chunks to a single `Thought` message so the
    /// reasoning block persists in the chat log instead of vanishing when the live
    /// preview clears. Called at every boundary where a thought block ends (agent
    /// response text, tool call, user replay, turn completion).
    fn flush_streaming_thought(&mut self) {
        if let Some(text) = self.streaming_thought.take()
            && !text.trim().is_empty()
        {
            self.messages.push(ChatMessage::thought(text));
            self.messages_version += 1;
        }
    }

    /// Add a user message to the chat history.
    ///
    /// Flushes any pending streaming agent text and reasoning first, so they
    /// commit in chronological order *before* the user's message. This matters on
    /// the Enter-while-busy / `/code` paths, where a user message can be added
    /// mid-turn while a thought block is still accumulating — without the flush
    /// the reasoning would commit after the user message (and a later thought
    /// chunk would merge onto it). On the normal path both buffers are already
    /// empty, so the flushes are no-ops.
    pub fn add_user_message(&mut self, text: &str) {
        self.flush_streaming_agent_text();
        self.flush_streaming_thought();
        self.messages.push(ChatMessage::user_text(text.to_string()));
        self.messages_version += 1;
        self.enforce_message_limit();
    }

    /// Add a system message to the chat history.
    ///
    /// Flushes pending streaming agent text and reasoning first (the
    /// `add_user_message` idiom), so a message added mid-turn — a thinking
    /// ack, a bridge error, command output — commits AFTER the text that
    /// streamed before it rather than ahead of it. Outside a turn both
    /// buffers are empty and the flushes are no-ops.
    pub fn add_system_message(&mut self, text: String) {
        self.flush_streaming_agent_text();
        self.flush_streaming_thought();
        self.messages.push(ChatMessage::system(text));
        self.messages_version += 1;
        self.enforce_message_limit();
    }

    /// Open an agent-initiated turn with its header line in `transcript`
    /// (cyril-lki9 B1/B3/B4); text from [`crate::turn_labels::header_text`].
    pub fn begin_agent_initiated_turn(
        &mut self,
        transcript: Transcript<'_>,
        origin: &cyril_core::types::AgentInitiation,
        label: Option<&cyril_core::workflow::WakeLabel>,
    ) {
        let text = crate::turn_labels::header_text(origin, label);
        self.push_transcript_system(transcript, text);
    }

    /// Close an agent-initiated turn in `transcript` with what it cost, and —
    /// for the wake after a run's end — the run's credit total (cyril-2lh8);
    /// text from [`crate::turn_labels::footer_text`]. Nothing metered, no line.
    pub fn end_agent_initiated_turn(
        &mut self,
        transcript: Transcript<'_>,
        close: &cyril_core::workflow::AgentTurnClose,
    ) {
        if let Some(text) = crate::turn_labels::footer_text(close) {
            self.push_transcript_system(transcript, text);
        }
    }

    /// Show a message the engine injected into a running turn (cyril-lki9
    /// B5): a busy-session workflow completion — named, with the run's
    /// credits so far (cyril-2lh8) — or a relayed step verdict.
    pub fn show_engine_injection(
        &mut self,
        transcript: Transcript<'_>,
        content: Option<&str>,
        severity: Option<&str>,
        workflow_completion: bool,
        notice: Option<&cyril_core::workflow::CompletionNotice>,
    ) {
        let text = if workflow_completion {
            crate::turn_labels::workflow_notice_text(notice, content)
        } else {
            crate::turn_labels::step_notice_text(severity, content)
        };
        self.push_transcript_system(transcript, text);
    }

    /// Show a workflow step parked on a question in the main transcript
    /// (cyril-9104), with the step's own latest reply when cyril has no
    /// other text for it; text from [`crate::turn_labels::step_question_text`].
    pub fn show_step_question(&mut self, question: &cyril_core::workflow::StepQuestion) {
        let reply = self
            .workflow_streams
            .streams()
            .get(question.session_id())
            .and_then(crate::subagent_ui::SubagentStream::latest_agent_text);
        let text = crate::turn_labels::step_question_text(question, reply);
        self.add_system_message(text);
    }

    /// Show the parent model answering a workflow step itself (cyril-9104).
    pub fn show_parent_answer(&mut self, answer: &cyril_core::workflow::StepAnswer) {
        self.add_system_message(crate::turn_labels::parent_answer_text(answer));
    }

    fn push_transcript_system(&mut self, transcript: Transcript<'_>, text: String) {
        match transcript {
            Transcript::Main => self.add_system_message(text),
            Transcript::Workflow(session_id) => {
                self.workflow_streams.add_system_message(session_id, text)
            }
            Transcript::Subagent(session_id) => self.subagents.add_system_message(session_id, text),
        }
    }

    /// Append an optimistic queue-steer echo (ROADMAP K1b, cyril-bm1j). Added the
    /// instant the user sends a steer — the wire echoes (`SteeringConsumed` /
    /// `Cleared` / `Unsupported`) reconcile it in place later. Mirrors
    /// `add_user_message`'s streaming-flush so the echo commits in chronological
    /// order even if a thought/text block is mid-stream.
    pub fn add_steer_echo(&mut self, text: &str) {
        self.flush_streaming_agent_text();
        self.flush_streaming_thought();
        self.messages
            .push(ChatMessage::steer_echo(text.to_string()));
        // cyril-7z7u: the chip is optimistic — `steering_queued` mirrors the count
        // of Queued echoes, incremented here at user-send rather than at the wire
        // `steering_queued` (which the backend may DEFER to the next turn for a
        // late steer — see `.cyril-7z7u/findings.md`). Drained by `SteeringConsumed`;
        // zeroed by `SteeringCleared`/`SteeringUnsupported`/`SessionCreated`.
        self.steering_queued = self.steering_queued.saturating_add(1);
        self.messages_version += 1;
        self.enforce_message_limit();
    }

    /// Bind a wire-assigned steer queue id to the OLDEST id-less `Queued` echo
    /// (cyril-vgcm C8). No-op when the id is already bound to any echo (a
    /// duplicate wire echo must not claim a second chip) or when no id-less
    /// Queued chip exists (a foreign/multi-client steer — display of those is
    /// cyril-8lfs territory, out of scope). NEVER touches `steering_queued`:
    /// the optimistic count was taken at `add_steer_echo` (cyril-7z7u) and
    /// re-counting the wire echo is the double-count bug. `messages_version`
    /// is not bumped — the id is reconciliation plumbing, not rendered.
    fn bind_steer_echo_id(&mut self, id: &str) -> bool {
        let already_bound = self.messages.iter().any(|m| {
            matches!(
                m.kind(),
                ChatMessageKind::SteerEcho {
                    message_id: Some(existing),
                    ..
                } if existing == id
            )
        });
        if already_bound {
            return false;
        }
        for msg in self.messages.iter_mut() {
            if let ChatMessageKind::SteerEcho {
                status: SteerEchoStatus::Queued,
                message_id: message_id @ None,
                ..
            } = &mut msg.kind
            {
                *message_id = Some(id.to_string());
                return true;
            }
        }
        false
    }

    /// Pull every complete `[STEERING <id>: …]` receipt out of the live agent
    /// text and reconcile it onto its chip (cyril-3qwa).
    ///
    /// Called on each `AgentMessage` append, BEFORE any flush, so a receipt is
    /// excised while it is still in the streaming buffer and never reaches a
    /// committed `AgentText` message. Harvesting mutates `streaming_text` in
    /// place; the caller has already decided the notification is state-changing,
    /// so no return value is needed.
    fn harvest_steer_receipts(&mut self) {
        for receipt in steer_receipt::harvest(&mut self.streaming_text) {
            self.apply_steer_receipt(&receipt);
        }
    }

    /// Attach one receipt's note to the chip it names, flipping a still-Queued
    /// chip to Applied (cyril-3qwa).
    ///
    /// The flip matters: normally `SteeringConsumed` has already flipped the chip
    /// by the time the model emits its trailer, so this only adds the note. But a
    /// receipt is itself *proof the model saw the steer*, so when the consumed
    /// echo was dropped or renamed out from under cyril (the cyril-ppkx failure
    /// mode) the receipt recovers the chip instead of leaving it stuck at Queued.
    ///
    /// Matching prefers the bound id. The fallback — oldest note-less, id-less,
    /// non-terminal chip — covers the old id-less dialect, mirroring the FIFO
    /// convention `flip_consumed_steer_echo` already uses. A receipt naming an
    /// unknown id when every chip is already bound reconciles nothing: the note
    /// is dropped rather than risk pinning it to the wrong steer.
    fn apply_steer_receipt(&mut self, receipt: &SteerReceipt) {
        let mut fallback = None;
        for (idx, msg) in self.messages.iter().enumerate() {
            if let ChatMessageKind::SteerEcho {
                status,
                message_id,
                note,
                ..
            } = msg.kind()
            {
                if message_id.as_deref() == Some(receipt.id()) {
                    fallback = Some(idx);
                    break;
                }
                let terminal = matches!(
                    status,
                    SteerEchoStatus::Cleared | SteerEchoStatus::Unsupported
                );
                if fallback.is_none() && message_id.is_none() && note.is_none() && !terminal {
                    fallback = Some(idx);
                }
            }
        }
        let Some(idx) = fallback else {
            tracing::debug!(
                receipt_id = receipt.id(),
                "steer receipt matched no chip — note dropped"
            );
            return;
        };
        let Some(msg) = self.messages.get_mut(idx) else {
            return;
        };
        if let ChatMessageKind::SteerEcho {
            status,
            message_id,
            note,
            ..
        } = &mut msg.kind
        {
            *note = Some(receipt.note().to_string());
            if message_id.is_none() {
                *message_id = Some(receipt.id().to_string());
            }
            if *status == SteerEchoStatus::Queued {
                // Recovery path: the receipt proves pickup that the wire echo
                // failed to report. Keep the cyril-7z7u invariant
                // (counter == #Queued chips) by decrementing alongside the flip.
                *status = SteerEchoStatus::Applied;
                self.steering_queued = self.steering_queued.saturating_sub(1);
                self.turns_since_steer_activity = 0;
            }
            self.messages_version += 1;
        }
    }

    /// Flip the Queued echo a Consumed echo names (cyril-vgcm C9): the chip
    /// bound to `message_id` when one is; for an id bound to no chip, the
    /// OLDEST id-less Queued chip (a steer whose Queued echo was dropped or
    /// deferred) — never a chip bound to a DIFFERENT id (cyril-5n75: an engine
    /// `notify-*` injection must not drain the operator's queued steer); for an
    /// id-less Consumed (old dialect), the oldest Queued chip (FIFO). An id
    /// bound to a TERMINAL chip is a duplicate injected echo: flips nothing
    /// and does NOT fall back — FIFO there would drain a second, wrong chip.
    /// Returns whether a chip flipped (the caller decrements the counter by
    /// exactly that).
    fn flip_consumed_steer_echo(&mut self, message_id: Option<&str>) -> bool {
        if let Some(id) = message_id {
            for msg in self.messages.iter_mut() {
                if let ChatMessageKind::SteerEcho {
                    status,
                    message_id: Some(existing),
                    ..
                } = &mut msg.kind
                    && existing == id
                {
                    if *status == SteerEchoStatus::Queued {
                        *status = SteerEchoStatus::Applied;
                        return true;
                    }
                    return false;
                }
            }
            return self.flip_oldest_idless_queued(SteerEchoStatus::Applied);
        }
        self.flip_queued_steer_echoes(SteerEchoStatus::Applied, true)
    }

    /// Flip the Queued chips an id-scoped Cleared names (cyril-vgcm C6).
    /// Per id: a Queued chip bound to it flips to Cleared; a TERMINAL chip
    /// bound to it is consumed with no flip and no fallback (KAS's
    /// post-injection Cleared names the already-Applied id — findings F4);
    /// an unknown id falls back to the OLDEST id-less Queued chip, one per
    /// id (pre-rollout dialect / deferred Queued echo). Returns the flip
    /// count — the caller decrements the counter by exactly that, keeping
    /// the cyril-7z7u invariant (counter == #Queued chips).
    fn flip_cleared_steer_echoes(&mut self, message_ids: &[String]) -> usize {
        let mut flips = 0;
        for id in message_ids {
            let mut matched = false;
            for msg in self.messages.iter_mut() {
                if let ChatMessageKind::SteerEcho {
                    status,
                    message_id: Some(existing),
                    ..
                } = &mut msg.kind
                    && existing == id
                {
                    if *status == SteerEchoStatus::Queued {
                        *status = SteerEchoStatus::Cleared;
                        flips += 1;
                    }
                    matched = true;
                    break;
                }
            }
            if !matched && self.flip_oldest_idless_queued(SteerEchoStatus::Cleared) {
                flips += 1;
            }
        }
        flips
    }

    /// Flip the oldest Queued echo not yet bound to an id to `to` — the one
    /// fallback for an id that matches no chip, shared by Cleared (cyril-vgcm
    /// C6) and Consumed (cyril-5n75): such an id can only belong to a steer
    /// whose Queued echo was dropped or deferred, never to a chip bound to a
    /// different id. Returns whether a chip flipped.
    fn flip_oldest_idless_queued(&mut self, to: SteerEchoStatus) -> bool {
        for msg in self.messages.iter_mut() {
            if let ChatMessageKind::SteerEcho {
                status: status @ SteerEchoStatus::Queued,
                message_id: None,
                ..
            } = &mut msg.kind
            {
                *status = to;
                return true;
            }
        }
        false
    }

    /// Reconcile optimistic steer echoes in place (ROADMAP K1b, cyril-bm1j).
    /// Flips still-`Queued` echoes to `to`; terminal echoes (Applied/Cleared/
    /// Unsupported) are never re-flipped. With `oldest_only` it flips just the
    /// first (FIFO — for `SteeringConsumed`, where one steer drained); otherwise
    /// all of them (`SteeringCleared`/`SteeringUnsupported`, and session-end
    /// finalization). Returns whether any echo changed, so the caller bumps
    /// `messages_version` exactly when the transcript changed. Single source for
    /// the flip logic so the three reconciliation arms can't drift.
    fn flip_queued_steer_echoes(&mut self, to: SteerEchoStatus, oldest_only: bool) -> bool {
        let mut changed = false;
        for msg in self.messages.iter_mut() {
            if let ChatMessageKind::SteerEcho {
                status: status @ SteerEchoStatus::Queued,
                ..
            } = &mut msg.kind
            {
                *status = to;
                changed = true;
                if oldest_only {
                    break;
                }
            }
        }
        changed
    }

    /// Set the current model name (displayed in toolbar).
    ///
    /// All model mutations route through here, so the "clear effort on a real
    /// model change" invariant lives in exactly one place: effort is
    /// model-scoped (a non-thinking model never reports it), so a real change
    /// must drop any stale level — re-reported by the new model's metadata if
    /// it thinks. Absent that, switching e.g. Opus→Haiku would leave the
    /// toolbar showing a phantom level.
    pub fn set_current_model(&mut self, model: Option<String>) {
        if self.current_model != model {
            self.effort = None;
        }
        self.current_model = model;
    }

    /// Post the read-back confirmation for a KAS `ConfigOptionSet`
    /// (cyril-vh69 C10): the message names the RETURNED `currentValue`, so a
    /// set the agent silently ignored (a bogus effort level "succeeds" with
    /// an unchanged value) shows what actually holds — the read-back is the
    /// falsification surface. The request side (and its mismatch log) lives
    /// in `SessionController`. Returns whether a message was posted.
    fn ack_config_set(&mut self, id: KasConfigId, options: &[ConfigOption]) -> bool {
        let Some(returned) = options
            .iter()
            .find(|o| o.key == id.as_str())
            .and_then(|o| o.value.as_deref())
        else {
            tracing::debug!(
                config_id = id.as_str(),
                "config-set ack carries no current value; no confirmation posted"
            );
            return false;
        };
        self.add_system_message(format!("{} set to {returned}.", id.noun()));
        true
    }

    /// Add a command output message to the chat.
    pub fn add_command_output(&mut self, command: String, text: String) {
        self.messages
            .push(ChatMessage::command_output(command, text));
        self.messages_version += 1;
        self.enforce_message_limit();
    }

    /// Mark the active stall as cancel-sent (cyril-14ou): the App calls this
    /// when Esc dispatches a cancel while the stall chip is up, escalating
    /// the wording. Returns whether anything changed (idempotent; no-op when
    /// no stall is displayed).
    pub fn mark_stall_cancel_sent(&mut self) -> bool {
        match &mut self.stall {
            Some(s) if !s.cancel_sent => {
                s.cancel_sent = true;
                true
            }
            _ => false,
        }
    }

    /// Update the activity state and record when it changed.
    /// The timer starts when entering a busy state from idle/ready, and
    /// persists across busy→busy transitions (Sending→Streaming→ToolRunning)
    /// so it tracks total turn time. Cleared on Ready/Idle.
    pub fn set_activity(&mut self, activity: Activity) {
        if self.activity != activity {
            let was_busy = !matches!(self.activity, Activity::Idle | Activity::Ready);
            let is_busy = !matches!(activity, Activity::Idle | Activity::Ready);

            self.activity = activity;

            if !is_busy {
                self.activity_since = None;
                // Stall display cannot outlive busy (cyril-14ou design: chip
                // shows "while stalled && busy") — activity resets that bypass
                // the notification path must take the chip down too.
                self.stall = None;
            } else if !was_busy {
                self.activity_since = Some(Instant::now());
            }
            // busy→busy: keep existing timer

            self.deep_idle = false;
        }
    }

    /// Mark the state as deep idle (no repaints needed).
    pub fn set_deep_idle(&mut self, deep: bool) {
        self.deep_idle = deep;
    }

    /// Signal that the application should quit.
    pub fn request_quit(&mut self) {
        self.quit_requested = true;
    }

    /// Queue an approval dialog from a permission request.
    pub fn show_approval(&mut self, request: PermissionRequest) {
        if self.approvals.is_empty() {
            // Kiro's TUI keeps the scope carry-over in the approval panel's
            // own state, mounted only while an approval is pending, so a
            // request arriving to an empty queue starts at session again.
            self.always_allow_scope = cyril_core::always_allow::GrantScope::Session;
        }
        self.approvals.push_back(ApprovalState {
            session_id: request.session_id,
            tool_call: TrackedToolCall::new(request.tool_call),
            message: request.message,
            options: request.options,
            trust_options: request.trust_options,
            selected: 0,
            can_reject_with_reason: request.can_reject_with_reason,
            phase: ApprovalPhase::SelectOption,
            responder: request.responder,
            consent: request.consent,
            workflow_plan: request.workflow_plan.map(|plan| *plan),
        });

        // A malformed preview payload is logged here, once per request,
        // rather than by the renderer, which redraws the overlay every frame
        // and once wrote ~14k identical warnings per approval (cyril-q0kg).
        // The approval's tool call is not mutated after install, so the
        // classification cannot change while the overlay is open.
        if let Some(approval) = self.approvals.back()
            && let PreviewBody::Malformed { raw_input_shape } = approval.tool_call.preview_body()
        {
            tracing::warn!(
                tool_call_id = %approval.tool_call.id(),
                raw_input_shape = %raw_input_shape,
                "approval preview raw_input has no string text/content field"
            );
        }
    }

    /// Take the current input text, clearing the input buffer, cursor, and
    /// chat scroll offset (returns to follow mode so the agent's response
    /// is visible).
    pub fn take_input(&mut self) -> String {
        self.input_cursor = 0;
        self.autocomplete_suggestions.clear();
        self.autocomplete_selected = None;
        self.chat_scroll_back = None;
        std::mem::take(&mut self.input_text)
    }

    /// Update the terminal size.
    pub fn set_terminal_size(&mut self, w: u16, h: u16) {
        self.terminal_size = (w, h);
    }

    /// Set mouse capture state (used to sync with terminal on startup).
    pub fn set_mouse_captured(&mut self, captured: bool) {
        self.mouse_captured = captured;
    }

    /// Toggle mouse capture mode.
    pub fn toggle_mouse_capture(&mut self) {
        self.mouse_captured = !self.mouse_captured;
    }

    /// Clear all messages from the chat history.
    pub fn clear_messages(&mut self) {
        self.messages.clear();
        self.tool_call_index.clear();
        self.messages_version += 1;
    }

    /// Check if there is an active approval dialog.
    pub fn has_approval(&self) -> bool {
        !self.approvals.is_empty()
    }

    /// Open the `/review` consent form.
    pub fn show_review_form(&mut self, form: crate::traits::ReviewForm) {
        self.review_form = Some(form);
    }

    /// The open form, to update its file count or mark it busy.
    pub fn review_form_mut(&mut self) -> Option<&mut crate::traits::ReviewForm> {
        self.review_form.as_mut()
    }

    /// Close the form; returns whether one was open.
    pub fn close_review_form(&mut self) -> bool {
        self.review_form.take().is_some()
    }

    /// Check if there is an active picker dialog.
    pub fn has_picker(&self) -> bool {
        self.picker.is_some()
    }

    /// The overlay that owns the keyboard: the open layer closest to the top of
    /// [`Overlay::ALL`].
    ///
    /// `None` means input reaches the chat (autocomplete and the textarea). This
    /// is the single answer to "who gets this key", used by `App::handle_key`,
    /// and it is deliberately the SAME order [`crate::render`] paints in
    /// reverse, so the overlay that shows on top is the overlay that reacts
    /// (review findings 3 and 20).
    pub fn topmost_overlay(&self) -> Option<Overlay> {
        Overlay::ALL
            .into_iter()
            .rev()
            .find(|overlay| self.is_overlay_open(*overlay))
    }

    /// Whether [`Self::topmost_overlay`] is `Some` — i.e. whether keyboard
    /// input is owned by an overlay rather than the chat.
    ///
    /// Its three readers are the guards that must agree about that: the key
    /// chain, the mouse-scroll guard and the paste / voice-transcript insert
    /// path. Each of those was a hand-written list, and each list was missing
    /// overlays (the paste guard knew only about `/usage`; the mouse guard
    /// predated `/powers`) — a keystroke-free write path mutating state behind
    /// an overlay the user cannot see into (review findings 13 and 20).
    pub fn has_modal_overlay(&self) -> bool {
        self.topmost_overlay().is_some()
    }

    fn is_overlay_open(&self, overlay: Overlay) -> bool {
        match overlay {
            Overlay::Approval => self.has_approval(),
            Overlay::Picker => self.has_picker(),
            Overlay::Review => self.review_form.is_some(),
            Overlay::Hooks => self.has_hooks_panel(),
            Overlay::Powers => self.has_powers_panel(),
            Overlay::Code => self.has_code_panel(),
            Overlay::Usage => self.has_usage_panel(),
        }
    }

    /// Handle a key event for the input field.
    pub fn handle_input_key(&mut self, key: crossterm::event::KeyEvent) {
        use crossterm::event::KeyCode;

        let mut text_changed = false;

        match key.code {
            KeyCode::Char(c) => {
                self.input_text.insert(self.input_cursor, c);
                self.input_cursor += c.len_utf8();
                text_changed = true;
            }
            KeyCode::Backspace => {
                if self.input_cursor > 0 {
                    // Find the previous character boundary
                    let prev = self.input_text[..self.input_cursor]
                        .char_indices()
                        .next_back()
                        .map(|(idx, _)| idx)
                        .unwrap_or(0);
                    self.input_text.drain(prev..self.input_cursor);
                    self.input_cursor = prev;
                    text_changed = true;
                }
            }
            KeyCode::Delete => {
                if self.input_cursor < self.input_text.len() {
                    let next = self.input_text[self.input_cursor..]
                        .char_indices()
                        .nth(1)
                        .map(|(idx, _)| self.input_cursor + idx)
                        .unwrap_or(self.input_text.len());
                    self.input_text.drain(self.input_cursor..next);
                    text_changed = true;
                }
            }
            KeyCode::Left => {
                if self.input_cursor > 0 {
                    self.input_cursor = self.input_text[..self.input_cursor]
                        .char_indices()
                        .next_back()
                        .map(|(idx, _)| idx)
                        .unwrap_or(0);
                }
            }
            KeyCode::Right => {
                if self.input_cursor < self.input_text.len() {
                    self.input_cursor = self.input_text[self.input_cursor..]
                        .char_indices()
                        .nth(1)
                        .map(|(idx, _)| self.input_cursor + idx)
                        .unwrap_or(self.input_text.len());
                }
            }
            KeyCode::Home => {
                self.input_cursor = 0;
            }
            KeyCode::End => {
                self.input_cursor = self.input_text.len();
            }
            _ => {}
        }

        if text_changed {
            self.update_autocomplete();
        }
    }

    /// Insert a block of text at the cursor (used for bracketed paste).
    ///
    /// Carriage returns from other platforms/terminals (`\r\n`, lone `\r`) are
    /// normalized to `\n` so they neither corrupt the rendered buffer nor leak
    /// into the prompt sent to the agent.
    pub fn insert_text(&mut self, text: &str) {
        let normalized = text.replace("\r\n", "\n").replace('\r', "\n");
        self.input_text.insert_str(self.input_cursor, &normalized);
        self.input_cursor += normalized.len();
        self.update_autocomplete();
    }

    // --- File completer and autocomplete ---

    /// Set the file completer for @-file autocomplete.
    pub fn set_file_completer(&mut self, completer: FileCompleter) {
        self.file_completer = Some(completer);
    }

    /// Get a reference to the file completer, if loaded.
    pub fn file_completer(&self) -> Option<&FileCompleter> {
        self.file_completer.as_ref()
    }

    /// Command info tuples `(name, description)` available for slash autocomplete.
    /// Names are stored without the leading `/`.
    pub fn set_command_info(&mut self, mut info: Vec<(String, Option<String>)>) {
        info.sort_by(|(a, _), (b, _)| a.to_lowercase().cmp(&b.to_lowercase()));
        self.command_info = info;
    }

    /// Read-only access to the subagent tracker.
    pub fn subagent_tracker(&self) -> &cyril_core::subagent::SubagentTracker {
        &self.subagent_tracker
    }

    /// Apply a notification to the subagent tracker. Returns true if tracker state changed.
    pub fn apply_subagent_tracker_notification(&mut self, notification: &Notification) -> bool {
        self.subagent_tracker.apply_notification(notification)
    }

    /// Read-only access to subagent UI state.
    pub fn subagent_ui(&self) -> &crate::subagent_ui::SubagentUiState {
        &self.subagents
    }

    /// Route a notification to the per-subagent stream identified by `session_id`.
    /// Creates the stream on first contact.
    pub fn apply_subagent_notification(
        &mut self,
        session_id: &SessionId,
        notification: &Notification,
    ) -> bool {
        self.subagents.apply_notification(session_id, notification)
    }

    /// Apply a list update to subagent streams — marks terminated streams
    /// that are no longer in the active list.
    pub fn apply_subagent_list_update(
        &mut self,
        subagents: &[cyril_core::types::SubagentInfo],
    ) -> bool {
        self.subagents.apply_list_update(subagents)
    }

    /// Focus a subagent for drill-in rendering. Returns true if the
    /// session has a stream and focus was set.
    pub fn focus_subagent(&mut self, session_id: SessionId) -> bool {
        self.subagents.focus(session_id)
    }

    /// Exit drill-in mode.
    pub fn unfocus_subagent(&mut self) {
        self.subagents.unfocus();
    }

    /// True if any subagent stream is actively streaming or running tools.
    pub fn any_subagent_active(&self) -> bool {
        self.subagents.any_active()
    }

    // --- Workflow step streams (cyril-jxfu) ---

    /// Route a notification to the workflow stream identified by
    /// `session_id`. Creates the stream on first contact.
    pub fn apply_workflow_notification(
        &mut self,
        session_id: &SessionId,
        notification: &Notification,
    ) -> bool {
        self.workflow_streams
            .apply_notification(session_id, notification)
    }

    /// Re-parent an optimistic subagent stream onto the workflow store after
    /// a late claim (cyril-jxfu): the stream leaves the subagent domain with
    /// its history intact (drill-in focus clears if it pointed there), and
    /// future frames for the session route to the workflow stream. Returns
    /// `true` if a stream actually moved.
    pub fn claim_stream_for_workflow(&mut self, session_id: &SessionId) -> bool {
        let Some(stream) = self.subagents.remove_stream(session_id) else {
            return false;
        };
        self.workflow_streams.adopt(session_id.clone(), stream);
        true
    }

    /// Read-only access to workflow step streams.
    pub fn workflow_streams(
        &self,
    ) -> &std::collections::HashMap<SessionId, crate::subagent_ui::SubagentStream> {
        self.workflow_streams.streams()
    }

    /// True if any workflow step stream is actively streaming or running
    /// tools — feeds the adaptive frame rate beside the subagent check.
    pub fn any_workflow_active(&self) -> bool {
        self.workflow_streams.any_active()
    }

    // --- Voice input (CN2 / V1a) ---

    /// Update the voice status. Clears the level when leaving the listening
    /// state so a stale meter doesn't linger.
    pub fn set_voice_status(&mut self, status: VoiceStatus) {
        if !matches!(status, VoiceStatus::Listening) {
            self.voice_level = 0.0;
        }
        self.voice_status = status;
    }
    /// Replace the process-global memory status snapshot atomically.
    pub fn set_memory_status(&mut self, status: cyril_core::types::MemoryStatusView) -> bool {
        if self.memory_status == status {
            return false;
        }
        self.memory_status = status;
        true
    }

    /// Update the current voice input level, normalized to `0.0..=1.0`.
    ///
    /// A `NaN` input — possible once V1b derives the level from real audio (RMS
    /// over an empty buffer / divide-by-zero) — is treated as silence rather
    /// than stored. (`clamp(0.0, 1.0)` itself never panics — the bounds are
    /// valid — but it would *propagate* NaN, and NaN compares false to
    /// everything, so it has no business living in a level field.)
    pub fn set_voice_level(&mut self, level: f32) {
        self.voice_level = if level.is_nan() {
            0.0
        } else {
            level.clamp(0.0, 1.0)
        };
    }

    /// True while voice capture/transcription is in progress — drives the
    /// fast-tick frame rate so the meter animates.
    pub fn any_voice_active(&self) -> bool {
        !matches!(self.voice_status, VoiceStatus::Idle)
    }

    /// Recompute autocomplete suggestions based on current input text.
    fn update_autocomplete(&mut self) {
        let text = &self.input_text;
        let trimmed = text.trim();

        // Slash command autocomplete
        if trimmed.starts_with('/') && !trimmed.contains(' ') {
            let query = trimmed[1..].to_lowercase();
            self.autocomplete_suggestions = self
                .command_info
                .iter()
                .filter(|(name, _)| name.to_lowercase().starts_with(&query))
                .map(|(name, desc)| Suggestion {
                    text: format!("/{name}"),
                    description: desc.clone(),
                })
                .collect();
            self.autocomplete_selected = if self.autocomplete_suggestions.is_empty() {
                None
            } else {
                Some(0)
            };
            return;
        }

        // File autocomplete — look for @ trigger
        if let Some(at_pos) = text[..self.input_cursor].rfind('@') {
            let query = &text[at_pos + 1..self.input_cursor];
            if !query.is_empty()
                && !query.contains(' ')
                && let Some(ref completer) = self.file_completer
            {
                if let Some(reason) = completer.unavailable_reason() {
                    // cyril-2mfa: the completer failed to load (not a git
                    // repository, git missing, ...). Tell the user ONCE, at the
                    // moment the silence would otherwise bite. A completer that
                    // loaded fine with zero files never takes this path.
                    if !self.completion_unavailable_notified {
                        let notice = format!("@-file completion unavailable: {reason}");
                        self.completion_unavailable_notified = true;
                        self.add_system_message(notice);
                    }
                } else {
                    let suggestions: Vec<Suggestion> = completer
                        .suggest(query, 10)
                        .into_iter()
                        .map(|path| Suggestion {
                            text: format!("@{path}"),
                            description: None,
                        })
                        .collect();
                    if !suggestions.is_empty() {
                        self.autocomplete_suggestions = suggestions;
                        self.autocomplete_selected = Some(0);
                        return;
                    }
                }
            }
        }

        // No autocomplete
        self.autocomplete_suggestions.clear();
        self.autocomplete_selected = None;
    }

    /// Accept the currently selected autocomplete suggestion.
    /// Returns true if a suggestion was accepted.
    pub fn accept_autocomplete(&mut self) -> bool {
        let selected = match self.autocomplete_selected {
            Some(idx) => idx,
            None => return false,
        };
        let suggestion = match self.autocomplete_suggestions.get(selected) {
            Some(s) => s.text.clone(),
            None => return false,
        };

        // For slash commands, replace the entire input
        if suggestion.starts_with('/') {
            self.input_text = format!("{suggestion} ");
            self.input_cursor = self.input_text.len();
        }
        // For @file references, replace from the @ to the cursor
        else if suggestion.starts_with('@')
            && let Some(at_pos) = self.input_text[..self.input_cursor].rfind('@')
        {
            let after_cursor = self.input_text[self.input_cursor..].to_string();
            self.input_text = format!("{}{suggestion} {after_cursor}", &self.input_text[..at_pos]);
            self.input_cursor = at_pos + suggestion.len() + 1; // +1 for space
        }

        self.autocomplete_suggestions.clear();
        self.autocomplete_selected = None;
        true
    }

    /// Move autocomplete selection to the previous item.
    pub fn autocomplete_prev(&mut self) {
        if let Some(ref mut idx) = self.autocomplete_selected
            && *idx > 0
        {
            *idx -= 1;
        }
    }

    /// Move autocomplete selection to the next item.
    pub fn autocomplete_next(&mut self) {
        if let Some(ref mut idx) = self.autocomplete_selected
            && *idx + 1 < self.autocomplete_suggestions.len()
        {
            *idx += 1;
        }
    }

    /// Dismiss the autocomplete menu.
    pub fn dismiss_autocomplete(&mut self) {
        self.autocomplete_suggestions.clear();
        self.autocomplete_selected = None;
    }

    /// Handle a key event when autocomplete is active (Layer 2.5).
    /// Returns an action telling the caller what to do next.
    ///
    /// This is the single authority for autocomplete key handling — the caller
    /// should NOT inspect autocomplete state or make decisions about it.
    pub fn handle_autocomplete_key(&mut self, key: KeyEvent) -> AutocompleteAction {
        if self.autocomplete_suggestions.is_empty() {
            return AutocompleteAction::NotActive;
        }

        match key.code {
            KeyCode::Tab => {
                self.accept_autocomplete();
                AutocompleteAction::Accepted
            }
            KeyCode::Up => {
                self.autocomplete_prev();
                AutocompleteAction::Consumed
            }
            KeyCode::Down => {
                self.autocomplete_next();
                AutocompleteAction::Consumed
            }
            KeyCode::Esc => {
                self.dismiss_autocomplete();
                AutocompleteAction::Consumed
            }
            KeyCode::Enter => {
                let is_slash = self
                    .autocomplete_suggestions
                    .first()
                    .is_some_and(|s| s.text.starts_with('/'));
                self.accept_autocomplete();
                if is_slash {
                    AutocompleteAction::AcceptedAndSubmit
                } else {
                    AutocompleteAction::Accepted
                }
            }
            _ => {
                // Any other key dismisses autocomplete and passes through to normal input
                self.dismiss_autocomplete();
                AutocompleteAction::NotActive
            }
        }
    }

    // --- Approval dialog methods ---

    /// Move approval selection to the previous option.
    pub fn approval_select_prev(&mut self) {
        if let Some(approval) = self.approvals.front_mut()
            && approval.selected > 0
            && !matches!(
                approval.phase,
                ApprovalPhase::EnterReason { .. } | ApprovalPhase::EnterFolder { .. }
            )
        {
            approval.selected -= 1;
        }
    }

    /// Move approval selection to the next option.
    pub fn approval_select_next(&mut self) {
        if let Some(approval) = self.approvals.front_mut() {
            let max = match approval.phase {
                ApprovalPhase::SelectOption => approval.options.len(),
                ApprovalPhase::SelectTrust { .. } => approval.trust_options.len(),
                ApprovalPhase::SelectScope { .. } => approval.scope_choices().len(),
                ApprovalPhase::EnterReason { .. } | ApprovalPhase::EnterFolder { .. } => return,
            };
            if approval.selected + 1 < max {
                approval.selected += 1;
            }
        }
    }
    /// Whether the front approval currently owns the feedback editor.
    pub fn approval_feedback_active(&self) -> bool {
        matches!(
            self.approvals.front().map(|approval| &approval.phase),
            Some(ApprovalPhase::EnterReason { .. })
        )
    }

    /// Enter the request-local feedback phase for the currently selected
    /// reject_once option. The shared ApprovalState predicate keeps the hint,
    /// key entry, and transition in agreement.
    pub fn approval_begin_feedback(&mut self) -> bool {
        let Some(approval) = self.approvals.front_mut() else {
            return false;
        };
        if !approval.can_reject_with_reason() {
            return false;
        }
        let Some(chosen_option_id) = approval
            .options
            .get(approval.selected)
            .map(|option| option.id.clone())
        else {
            return false;
        };
        approval.phase = ApprovalPhase::EnterReason {
            chosen_option_id,
            editor: RejectionFeedback::new(),
        };
        true
    }

    /// Forward one key to the active feedback editor. The editor owns text
    /// editing; this state machine owns the terminal submit/back transitions.
    pub fn approval_feedback_key(&mut self, key: KeyEvent) -> bool {
        let action = {
            let Some(approval) = self.approvals.front_mut() else {
                return false;
            };
            let ApprovalPhase::EnterReason { editor, .. } = &mut approval.phase else {
                return false;
            };
            editor.handle_key(key)
        };

        match action {
            FeedbackAction::Consumed => true,
            FeedbackAction::Submit => {
                drop(self.approval_confirm());
                true
            }
            FeedbackAction::Cancel => {
                self.approval_feedback_cancel();
                true
            }
        }
    }

    /// Forward a bracketed paste to the active feedback editor only.
    pub fn approval_feedback_paste(&mut self, text: &str) -> bool {
        let Some(approval) = self.approvals.front_mut() else {
            return false;
        };
        let ApprovalPhase::EnterReason { editor, .. } = &mut approval.phase else {
            return false;
        };
        editor.insert_text(text);
        true
    }

    /// Discard feedback and return to the same option without answering or
    /// cancelling the originating request.
    pub fn approval_feedback_cancel(&mut self) -> bool {
        let Some(approval) = self.approvals.front_mut() else {
            return false;
        };
        let ApprovalPhase::EnterReason {
            chosen_option_id, ..
        } = &approval.phase
        else {
            return false;
        };
        let Some(restored) = approval
            .options
            .iter()
            .position(|option| &option.id == chosen_option_id)
        else {
            tracing::warn!("feedback option missing from originating approval");
            return false;
        };
        approval.phase = ApprovalPhase::SelectOption;
        approval.selected = restored;
        true
    }

    fn approval_submit_feedback(
        responder: tokio::sync::oneshot::Sender<PermissionResponse>,
        chosen_option_id: PermissionOptionId,
        editor: RejectionFeedback,
    ) {
        let response = if editor.is_blank() {
            PermissionResponse::Selected {
                option_id: chosen_option_id,
                trust_option: None,
            }
        } else {
            PermissionResponse::RejectWithReason {
                option_id: chosen_option_id,
                reason: editor.into_text(),
            }
        };
        if responder.send(response).is_err() {
            tracing::debug!("approval response dropped — agent receiver no longer listening");
        }
    }

    /// Confirm the current approval selection, sending the response.
    ///
    /// In phase 1 (SelectOption): if AllowAlways is chosen and trust options
    /// exist, transitions to phase 2 (SelectTrust). Otherwise sends the
    /// response immediately.
    ///
    /// In phase 2 (SelectTrust): sends AllowAlways with the selected trust
    /// option label and **returns the originating `SessionId` with the chosen
    /// `TrustOption`** so the caller (App) can decide whether the grant belongs
    /// to the active agent's durable config. Returns `None` in every other case
    /// (trust transition, ordinary or feedback decision, no active dialog).
    ///
    /// A confirm acts only on what is on screen (cyril-vojx): while the frame
    /// the state reports leaves the selection (or the reason editor), or the
    /// call's target path, undrawn, this does nothing. Esc still answers
    /// through [`approval_cancel`](Self::approval_cancel). The one exception
    /// is an option-page selection that names no option, which answers
    /// Cancel exactly as Esc would: it decides nothing the user could need to
    /// see.
    pub fn approval_confirm(
        &mut self,
    ) -> Option<(cyril_core::types::SessionId, cyril_core::types::TrustOption)> {
        let decides = self.approvals.front().is_some_and(|approval| {
            !matches!(approval.phase, ApprovalPhase::SelectOption)
                || approval.options.get(approval.selected).is_some()
        });
        if decides && !crate::widgets::approval::confirm_on_screen(self) {
            tracing::debug!(
                terminal_size = ?self.terminal_size,
                "approval confirm ignored: the selection or its target path is not on screen"
            );
            return None;
        }
        // Pop ownership upfront. Only the phase-2 transition restores the same
        // request at the front; terminal paths expose the next queued request.
        let mut approval = self.approvals.pop_front()?;

        match approval.phase {
            ApprovalPhase::SelectOption => {
                let picked = approval
                    .options
                    .get(approval.selected)
                    .map(|o| (o.kind, o.id.clone()));
                match picked {
                    Some((PermissionOptionKind::AllowAlways, chosen_option_id))
                        if !approval.trust_options.is_empty() =>
                    {
                        // Transition to phase 2 — restore this request at the
                        // front so later requests cannot overtake it.
                        // The phase carries the picked id: `selected` will
                        // re-index trust_options from here on.
                        approval.phase = ApprovalPhase::SelectTrust { chosen_option_id };
                        approval.selected = 0;
                        self.approvals.push_front(approval);
                    }
                    Some((PermissionOptionKind::AllowAlways, chosen_option_id))
                        if approval.consent.is_some() =>
                    {
                        // KAS (cyril-auxt): Always allow persists only from
                        // the consent echo, so the operator chooses its scope
                        // and resource first, as in Kiro's TUI.
                        let owned = cyril_core::always_allow::is_main_session_request(
                            &approval.session_id,
                            self.main_session_id.as_ref(),
                        );
                        approval.phase = ApprovalPhase::SelectScope {
                            chosen_option_id,
                            scope: self.always_allow_scope,
                            owned,
                        };
                        approval.selected = 0;
                        self.approvals.push_front(approval);
                    }
                    Some((_, option_id)) => {
                        // The reply names the exact picked option — KAS
                        // user_input questions share one kind across all
                        // options, so the id is the only faithful answer.
                        let response = PermissionResponse::Selected {
                            option_id,
                            trust_option: None,
                        };
                        if approval.responder.send(response).is_err() {
                            tracing::debug!(
                                "approval response dropped — agent receiver no longer listening"
                            );
                        }
                    }
                    None => {
                        tracing::warn!(
                            "approval_confirm selection out of bounds; defaulting to Cancel"
                        );
                        if approval.responder.send(PermissionResponse::Cancel).is_err() {
                            tracing::debug!(
                                "approval response dropped — agent receiver no longer listening"
                            );
                        }
                    }
                }
                None
            }
            ApprovalPhase::SelectTrust { chosen_option_id } => {
                // Keep the full chosen option (setting_key + patterns) so the
                // caller can persist it; the response only carries the label.
                // The option id is the phase-1 AllowAlways pick carried by
                // the phase itself.
                let chosen = approval.trust_options.get(approval.selected).cloned();
                let response = PermissionResponse::Selected {
                    option_id: chosen_option_id,
                    trust_option: chosen.as_ref().map(|t| t.label.clone()),
                };
                if approval.responder.send(response).is_err() {
                    tracing::debug!(
                        "approval response dropped — agent receiver no longer listening"
                    );
                }
                chosen.map(|trust| (approval.session_id, trust))
            }
            ApprovalPhase::EnterReason {
                chosen_option_id,
                editor,
            } => {
                Self::approval_submit_feedback(approval.responder, chosen_option_id, editor);
                None
            }
            ApprovalPhase::SelectScope {
                ref chosen_option_id,
                scope,
                owned,
            } => {
                let chosen_option_id = chosen_option_id.clone();
                let choice = approval.scope_choices().into_iter().nth(approval.selected);
                match choice {
                    Some(cyril_core::always_allow::ScopeChoice::Folder(offer)) => {
                        let editor = RejectionFeedback::with_text(offer.prefill());
                        approval.phase = ApprovalPhase::EnterFolder {
                            chosen_option_id,
                            scope,
                            owned,
                            offer,
                            editor,
                            attempted: false,
                        };
                        self.approvals.push_front(approval);
                    }
                    Some(choice) => match choice.resource() {
                        Some(resource) => self.approval_send_grant(
                            approval,
                            chosen_option_id,
                            owned,
                            cyril_core::always_allow::AlwaysAllowGrant::new(scope, resource),
                        ),
                        None => {
                            tracing::warn!("scope row grants no resource; staying on the page");
                            self.approvals.push_front(approval);
                        }
                    },
                    None => {
                        tracing::warn!("scope selection out of bounds; staying on the page");
                        self.approvals.push_front(approval);
                    }
                }
                None
            }
            ApprovalPhase::EnterFolder {
                ref chosen_option_id,
                scope,
                owned,
                ref offer,
                ref editor,
                ..
            } => {
                match offer.validate(editor.text()) {
                    Ok(folder) => {
                        let chosen_option_id = chosen_option_id.clone();
                        self.approval_send_grant(
                            approval,
                            chosen_option_id,
                            owned,
                            cyril_core::always_allow::AlwaysAllowGrant::new(
                                scope,
                                cyril_core::always_allow::GrantResource::Folder(folder),
                            ),
                        );
                    }
                    Err(reason) => {
                        tracing::debug!(%reason, "folder grant refused; editor stays open");
                        if let ApprovalPhase::EnterFolder { attempted, .. } = &mut approval.phase {
                            *attempted = true;
                        }
                        self.approvals.push_front(approval);
                    }
                }
                None
            }
        }
    }

    /// Answer `approval` with an "Always allow" grant, resolved the way Kiro's
    /// TUI resolves it for the request's session, then settle the waiting
    /// approvals that grant covers.
    fn approval_send_grant(
        &mut self,
        approval: ApprovalState,
        chosen_option_id: PermissionOptionId,
        owned: bool,
        grant: cyril_core::always_allow::AlwaysAllowGrant,
    ) {
        let response = match &approval.consent {
            Some(consent) => cyril_core::always_allow::resolve(
                consent,
                owned,
                &approval.options,
                chosen_option_id,
                grant,
            ),
            None => {
                tracing::warn!("always-allow grant without KAS consent; sending the plain pick");
                PermissionResponse::Selected {
                    option_id: chosen_option_id,
                    trust_option: None,
                }
            }
        };
        let release = cyril_core::always_allow::QueueRelease::for_answer(
            &approval.queued_view(),
            &response,
            self.main_session_id.as_ref(),
        );
        if approval.responder.send(response).is_err() {
            tracing::debug!("approval response dropped — agent receiver no longer listening");
        }
        self.release_queued_approvals(&release);
    }

    /// Answer every waiting approval `release` covers with its `allow_once`
    /// option, as Kiro's TUI does after an "Always allow" (`k8n`); the rest
    /// keep their place in the queue. No metadata rides these answers.
    fn release_queued_approvals(&mut self, release: &cyril_core::always_allow::QueueRelease) {
        if *release == cyril_core::always_allow::QueueRelease::Nothing {
            return;
        }
        let main = self.main_session_id.clone();
        let mut released = 0usize;
        let mut waiting = VecDeque::with_capacity(self.approvals.len());
        for queued in std::mem::take(&mut self.approvals) {
            let once = release
                .covers(&queued.queued_view(), main.as_ref())
                .cloned();
            match once {
                Some(option_id) => {
                    released += 1;
                    let response = PermissionResponse::Selected {
                        option_id,
                        trust_option: None,
                    };
                    if queued.responder.send(response).is_err() {
                        tracing::debug!(
                            "released approval dropped — agent receiver no longer listening"
                        );
                    }
                }
                None => waiting.push_back(queued),
            }
        }
        self.approvals = waiting;
        if released > 0 {
            tracing::info!(released, "always-allow grant settled waiting approvals");
        }
    }

    /// Cancel option selection, or return from trust/feedback to option selection.
    pub fn approval_cancel(&mut self) {
        if self.approval_feedback_active() {
            self.approval_feedback_cancel();
            return;
        }
        if let Some(approval) = self.approvals.front_mut()
            && let ApprovalPhase::SelectTrust { chosen_option_id } = &approval.phase
        {
            // Go back to phase 1, restoring the cursor to the exact option the
            // user picked to enter phase 2 rather than snapping to the first.
            // Replacing the phase discards the carried id — a re-pick must
            // send the newly picked option, never the stale carry.
            let restored = approval
                .options
                .iter()
                .position(|o| o.id == *chosen_option_id)
                .unwrap_or(0);
            approval.phase = ApprovalPhase::SelectOption;
            approval.selected = restored;
            return;
        }
        if let Some(approval) = self.approvals.front_mut() {
            match &approval.phase {
                ApprovalPhase::SelectScope {
                    chosen_option_id, ..
                } => {
                    // Back to the options, on the Always-allow pick.
                    let restored = approval
                        .options
                        .iter()
                        .position(|o| o.id == *chosen_option_id)
                        .unwrap_or(0);
                    approval.phase = ApprovalPhase::SelectOption;
                    approval.selected = restored;
                    return;
                }
                ApprovalPhase::EnterFolder {
                    chosen_option_id,
                    scope,
                    owned,
                    ..
                } => {
                    // Back to the scope page, on the folder row.
                    approval.phase = ApprovalPhase::SelectScope {
                        chosen_option_id: chosen_option_id.clone(),
                        scope: *scope,
                        owned: *owned,
                    };
                    approval.selected = approval
                        .scope_choices()
                        .iter()
                        .position(|choice| {
                            matches!(choice, cyril_core::always_allow::ScopeChoice::Folder(_))
                        })
                        .unwrap_or(0);
                    return;
                }
                _ => {}
            }
        }
        if let Some(approval) = self.approvals.pop_front() {
            // Same rationale as approval_confirm: a dropped receiver means the
            // request was already cancelled upstream; log at debug level.
            if approval.responder.send(PermissionResponse::Cancel).is_err() {
                tracing::debug!("approval cancel dropped — agent receiver no longer listening");
            }
        }
    }

    /// `s` on the scope page: session → workspace → user → session. The
    /// highlighted row stays highlighted when it is still offered; a folder
    /// row's label names its scope, so it falls back to the first row, as in
    /// Kiro's TUI.
    pub fn approval_cycle_scope(&mut self) {
        let Some(approval) = self.approvals.front_mut() else {
            return;
        };
        let ApprovalPhase::SelectScope { scope, .. } = approval.phase else {
            return;
        };
        let highlighted = approval.scope_choices().into_iter().nth(approval.selected);
        if let ApprovalPhase::SelectScope { scope: current, .. } = &mut approval.phase {
            *current = scope.next();
        }
        // A highlighted row the new scope no longer offers falls back to the
        // first row, as the TUI's `osr` does.
        approval.selected = match highlighted {
            Some(cyril_core::always_allow::ScopeChoice::Folder(_)) | None => 0,
            Some(row) => approval
                .scope_choices()
                .iter()
                .position(|choice| *choice == row)
                .unwrap_or(0),
        };
        self.always_allow_scope = scope.next();
    }

    /// Whether the front approval's folder editor owns the keyboard.
    pub fn approval_folder_active(&self) -> bool {
        matches!(
            self.approvals.front().map(|approval| &approval.phase),
            Some(ApprovalPhase::EnterFolder { .. })
        )
    }

    /// Forward one key to the folder editor: Enter grants the folder when it
    /// is valid, Esc returns to the scope page, anything else edits.
    pub fn approval_folder_key(&mut self, key: KeyEvent) -> bool {
        let action = {
            let Some(approval) = self.approvals.front_mut() else {
                return false;
            };
            let ApprovalPhase::EnterFolder { editor, .. } = &mut approval.phase else {
                return false;
            };
            editor.handle_key(key)
        };
        match action {
            FeedbackAction::Consumed => {}
            FeedbackAction::Submit => drop(self.approval_confirm()),
            FeedbackAction::Cancel => self.approval_cancel(),
        }
        true
    }

    /// Insert a bracketed paste into the folder editor only.
    pub fn approval_folder_paste(&mut self, text: &str) -> bool {
        let Some(approval) = self.approvals.front_mut() else {
            return false;
        };
        let ApprovalPhase::EnterFolder { editor, .. } = &mut approval.phase else {
            return false;
        };
        editor.insert_text(text);
        true
    }

    // --- Picker dialog methods ---

    /// The value cyril believes is active for the picker named `title`.
    ///
    /// The picker's title *is* the command name (`show_picker` is called with
    /// `Notification::CommandOptionsReceived.command`, and `picker_confirm`
    /// hands it back as the command to execute), so it doubles as the key for
    /// this lookup. Returns `None` for any other picker — nothing to join on.
    fn active_option_value(&self, title: &str) -> Option<&str> {
        match title {
            "model" => self.current_model.as_deref(),
            "effort" => self.effort.as_ref().map(EffortLevel::as_str),
            _ => None,
        }
    }

    /// Show a picker dialog with the given title and options.
    ///
    /// Marks the row matching cyril's own current value (cyril-imjx).
    /// kiro-cli 2.14.2 never sends `current` on `/model` options and encodes
    /// it into the `/effort` label only after an in-session change, so the
    /// wire alone leaves the picker unmarked. Cyril already tracks both values
    /// for the toolbar, so the join happens here rather than on the wire.
    ///
    /// Precedence: cyril's own value wins when it names an option in the list
    /// — it reflects the last `commands/execute` cyril made, so it is fresher
    /// than a stale `current` flag. Otherwise whatever the agent sent survives
    /// untouched, which keeps agents that DO send `current` working.
    pub fn show_picker(&mut self, title: String, mut options: Vec<CommandOption>) {
        if let Some(active) = self.active_option_value(&title) {
            match options.iter().position(|o| o.value == active) {
                Some(idx) => {
                    for (i, opt) in options.iter_mut().enumerate() {
                        opt.is_current = i == idx;
                    }
                }
                None => tracing::debug!(
                    picker = %title,
                    active,
                    "current value is absent from the option list; \
                     falling back to whatever the agent marked"
                ),
            }
        }

        let filtered_indices: Vec<usize> = (0..options.len()).collect();
        self.picker = Some(PickerState {
            title,
            options,
            filter: String::new(),
            filtered_indices,
            selected: 0,
            kind: PickerKind::Agent,
        });
        self.sync_theme_preview();
    }

    /// Open the picker over a KAS session config select (`/model` `/effort`
    /// `/mode`, cyril-vh69).
    ///
    /// Unlike `show_picker` there is NO `active_option_value` join: that join
    /// exists only for v2 agent titles, and these rows arrive from the
    /// session's config snapshot with `is_current` already set — honored
    /// exactly as sent. The title is the setting's noun ("model", "effort",
    /// "mode"); the target, not the title, is what confirming sets.
    pub fn show_config_picker(&mut self, picker: ConfigPicker) {
        let (target, options) = picker.into_parts();
        let filtered_indices: Vec<usize> = (0..options.len()).collect();
        // Open on the current value's row when one is marked — "confirm what
        // I already have / see where I am" is one keystroke shorter (review
        // round 1, F5). The filter starts empty, so filtered order IS option
        // order here.
        let selected = options
            .iter()
            .position(|option| option.is_current)
            .unwrap_or(0);
        self.picker = Some(PickerState {
            title: target.id().noun().to_ascii_lowercase(),
            options,
            filter: String::new(),
            filtered_indices,
            selected,
            kind: PickerKind::Config(target),
        });
        self.sync_theme_preview();
    }

    /// Open Cyril's own palette picker (cyril-qaq0).
    ///
    /// The catalog is built here because `cyril-ui` owns it: `cyril-core` only
    /// signals the intent, and never learns a palette id or label. The current
    /// palette is marked so the picker opens on the operator's own value.
    pub fn open_theme_picker(&mut self) {
        let options: Vec<CommandOption> = ThemeId::ALL
            .iter()
            .copied()
            .map(|id| CommandOption {
                label: theme_label(id).to_owned(),
                value: theme_config_id(id).to_owned(),
                description: None,
                group: None,
                is_current: id == self.theme_id,
            })
            .collect();
        let filtered_indices: Vec<usize> = (0..options.len()).collect();
        let selected = options
            .iter()
            .position(|option| option.is_current)
            .unwrap_or(0);
        self.picker = Some(PickerState {
            title: "theme".to_owned(),
            options,
            filter: String::new(),
            filtered_indices,
            selected,
            kind: PickerKind::Theme,
        });
        self.sync_theme_preview();
    }

    /// Which kind of picker is open, if any.
    pub fn picker_kind(&self) -> Option<&PickerKind> {
        self.picker.as_ref().map(|picker| &picker.kind)
    }

    /// Commit the highlighted palette and close the picker. Returns the palette
    /// that became active, or `None` if no palette picker is open.
    ///
    /// The color mode is preserved: choosing a palette must not silently change
    /// how colors are emitted.
    pub fn commit_theme(&mut self) -> Option<ThemeId> {
        if self.picker.as_ref()?.kind != PickerKind::Theme {
            return None;
        }
        let picker = self.picker.take()?;
        let index = picker.filtered_indices.get(picker.selected).copied()?;
        let theme_id = parse_theme_id(&picker.options.get(index)?.value)?;
        self.theme_preview = None;
        self.set_appearance(theme_id, self.color_mode);
        Some(theme_id)
    }

    /// Recompute the preview from the picker's highlighted row.
    fn sync_theme_preview(&mut self) {
        let Some(picker) = self.picker.as_ref() else {
            self.theme_preview = None;
            return;
        };
        if picker.kind != PickerKind::Theme {
            self.theme_preview = None;
            return;
        }
        let highlighted = picker
            .filtered_indices
            .get(picker.selected)
            .and_then(|index| picker.options.get(*index));
        self.theme_preview = highlighted
            .and_then(|option| parse_theme_id(&option.value))
            .map(|id| resolve(id, self.color_mode));
    }

    /// Get the picker title, if a picker is active.
    pub fn picker_title(&self) -> Option<&str> {
        self.picker.as_ref().map(|p| p.title.as_str())
    }

    /// Move picker selection to the previous option.
    pub fn picker_select_prev(&mut self) {
        if let Some(ref mut picker) = self.picker
            && picker.selected > 0
        {
            picker.selected -= 1;
        }
        self.sync_theme_preview();
    }

    /// Move picker selection to the next option.
    pub fn picker_select_next(&mut self) {
        if let Some(ref mut picker) = self.picker
            && !picker.filtered_indices.is_empty()
            && picker.selected + 1 < picker.filtered_indices.len()
        {
            picker.selected += 1;
        }
        self.sync_theme_preview();
    }

    /// Confirm the picker selection and close the dialog.
    ///
    /// Returns a [`PickerConfirmation`] carrying the kind (whose KAS Config
    /// target is the dispatch key), title (the command name on the v2 Agent
    /// path), and selected value — the caller needs them to construct the
    /// right bridge command. `None` if nothing was selected.
    pub fn picker_confirm(&mut self) -> Option<PickerConfirmation> {
        let picker = self.picker.take()?;
        let idx = picker.filtered_indices.get(picker.selected).copied()?;
        let value = picker.options.get(idx)?.value.clone();
        Some(PickerConfirmation {
            kind: picker.kind,
            title: picker.title,
            value,
        })
    }

    /// Cancel and close the picker dialog.
    pub fn picker_cancel(&mut self) {
        self.picker = None;
        // Esc must leave the committed appearance exactly as it was: dropping
        // the preview is what makes "discard" true rather than merely "close".
        self.theme_preview = None;
    }

    /// Type a character into the picker filter.
    pub fn picker_type_char(&mut self, c: char) {
        if let Some(ref mut picker) = self.picker {
            picker.filter.push(c);
            Self::refilter_picker(picker);
        }
        self.sync_theme_preview();
    }

    /// Delete the last character from the picker filter.
    pub fn picker_backspace(&mut self) {
        if let Some(ref mut picker) = self.picker {
            picker.filter.pop();
            Self::refilter_picker(picker);
        }
        self.sync_theme_preview();
    }

    /// Re-compute filtered indices after filter text changes.
    fn refilter_picker(picker: &mut PickerState) {
        let filter_lower = picker.filter.to_lowercase();
        picker.filtered_indices = picker
            .options
            .iter()
            .enumerate()
            .filter(|(_, opt)| {
                filter_lower.is_empty()
                    || opt.label.to_lowercase().contains(&filter_lower)
                    || opt.value.to_lowercase().contains(&filter_lower)
            })
            .map(|(i, _)| i)
            .collect();
        // Clamp selected index
        if picker.filtered_indices.is_empty() {
            picker.selected = 0;
        } else if picker.selected >= picker.filtered_indices.len() {
            picker.selected = picker.filtered_indices.len() - 1;
        }
    }

    // --- Hooks panel methods ---

    /// Open the hooks panel overlay with a list of hooks from the `hooks` command.
    ///
    /// Hooks are sorted on insert by `(trigger, command)` so the widget can
    /// iterate `state.hooks` directly without re-sorting on every render
    /// frame. The stored order is the panel's display order — callers that
    /// need the original wire order should keep their own copy.
    pub fn show_hooks_panel(&mut self, hooks: Vec<HookInfo>) {
        self.hooks_panel = Some(HooksPanelState {
            hooks: Self::sorted_hooks(&hooks),
            scroll_offset: 0,
        });
    }

    /// Order a registry the way the widget paints it: `(trigger, command)`.
    fn sorted_hooks(hooks: &[HookInfo]) -> Vec<HookInfo> {
        let mut ordered = hooks.to_vec();
        ordered.sort_by(|a, b| {
            a.trigger
                .cmp(&b.trigger)
                .then_with(|| a.command.cmp(&b.command))
        });
        ordered
    }

    /// Replace the hooks panel's contents **only if it is already open**,
    /// returning whether anything VISIBLY changed (cyril-gk17).
    ///
    /// KAS pushes `_kiro/hooks/didChange` whenever a hook file is edited,
    /// unprompted. Routing that through
    /// [`show_hooks_panel`](Self::show_hooks_panel) would make a modal overlay
    /// open itself over whatever the user was doing — a worse outcome than a
    /// stale panel — so an unprompted change with the panel closed is
    /// deliberately invisible until the next `/hooks`.
    ///
    /// The scroll offset is preserved and then clamped: a refresh that
    /// shortens the list must not strand the viewport past the end, and one
    /// that merely flips an `enabled` flag must not yank the user to the top.
    ///
    /// `false` for a push that leaves the panel's rows identical (a file
    /// rewrite, or an edit the registry does not reflect): the caller redraws
    /// only when there is something to redraw (review finding 19).
    pub fn refresh_hooks_panel(&mut self, hooks: &[HookInfo]) -> bool {
        let Some(panel) = self.hooks_panel.as_ref() else {
            return false;
        };
        let ordered = Self::sorted_hooks(hooks);
        if panel.hooks == ordered {
            return false;
        }
        let scroll = panel.scroll_offset.min(ordered.len().saturating_sub(1));
        self.hooks_panel = Some(HooksPanelState {
            hooks: ordered,
            scroll_offset: scroll,
        });
        true
    }

    /// Close the hooks panel overlay.
    pub fn hide_hooks_panel(&mut self) {
        self.hooks_panel = None;
    }

    /// Check if the hooks panel is currently visible.
    pub fn has_hooks_panel(&self) -> bool {
        self.hooks_panel.is_some()
    }

    /// Scroll the hooks panel up by `lines`. Saturates at 0.
    pub fn hooks_panel_scroll_up(&mut self, lines: usize) {
        if let Some(panel) = self.hooks_panel.as_mut() {
            panel.scroll_offset = panel.scroll_offset.saturating_sub(lines);
        }
    }

    /// Scroll the hooks panel down by `lines`. Saturates at `hooks.len() - 1`
    /// so `scroll_offset` never exceeds the last hook's index. This is a
    /// strict clamp on the index, not a viewport-aware bound — with a tall
    /// panel and a short list, the last item can end up alone at the top of
    /// the visible area with blank rows below it. Matches `PickerState`'s
    /// scroll convention in this codebase; viewport-aware clamping would
    /// require threading `visible_rows` through from the renderer.
    pub fn hooks_panel_scroll_down(&mut self, lines: usize) {
        if let Some(panel) = self.hooks_panel.as_mut() {
            let max = panel.hooks.len().saturating_sub(1);
            panel.scroll_offset = (panel.scroll_offset + lines).min(max);
        }
    }

    // --- Powers panel ---

    /// Open the powers panel overlay with the catalog the agent pushed.
    ///
    /// Rows are ordered here, on insert, so the widget iterates
    /// `state.powers` directly without re-sorting every frame. The key is the
    /// *display* title compared as ASCII lowercase, tie-broken by identifier:
    /// the title is what the user reads, two powers can share one, and the id
    /// is what makes the order total — `sort_by_cached_key` computes each key
    /// once rather than once per comparison.
    pub fn show_powers_panel(&mut self, powers: Vec<PowerInfo>) {
        self.powers_panel = Some(PowersPanelState {
            powers: Self::sorted_powers(&powers),
            scroll_offset: 0,
        });
    }

    /// Order a catalog for display: title (ASCII-lowercase), then identifier.
    fn sorted_powers(powers: &[PowerInfo]) -> Vec<PowerInfo> {
        let mut ordered = powers.to_vec();
        ordered.sort_by_cached_key(|power| {
            (power.title().to_ascii_lowercase(), power.name().to_owned())
        });
        ordered
    }

    /// The last scroll offset whose window is still full.
    ///
    /// An offset past the last full window starts the viewport past the end of
    /// the catalog and leaves blank rows under a partial list (review finding 8
    /// — the hooks panel's index clamp suits one-line rows, and this panel
    /// copied it with three-line rows).
    ///
    /// The window is the one the popup ACTUALLY has, from
    /// [`crate::render::powers_window`], not [`MAX_VISIBLE_POWERS`]:
    /// `modal::place` squeezes the popup into the rows above the input, and a
    /// bound computed for the widest window leaves the tail of the catalog
    /// unreachable whenever it squeezes — nine powers on an 18-row terminal
    /// show three at a time, so a bound of `len - MAX_VISIBLE_POWERS` can never
    /// bring the last two into view.
    ///
    /// `max(1)`: a popup with nowhere to draw has no window at all; the bound
    /// then reduces to the last index, which no frame gets to use.
    fn max_powers_scroll(&self, len: usize) -> usize {
        len.saturating_sub(crate::render::powers_window(self, len).max(1))
    }

    /// Replace the powers panel's contents **only if it is already open**,
    /// returning whether anything VISIBLY changed.
    ///
    /// The catalog arrives unprompted once per session, and a second push can
    /// arrive while the user is reading the panel. Routing that through
    /// [`show_powers_panel`](Self::show_powers_panel) would make a modal
    /// overlay open itself over whatever the user was doing; an unprompted
    /// change with the panel closed is deliberately invisible until the next
    /// `/powers`.
    ///
    /// `false` for a closed panel and for a push whose rows are identical
    /// (a `/new` re-sending the same user-level catalog): neither is a
    /// repaint. A changed catalog keeps its scroll position, clamped to the
    /// window so a shorter list cannot strand the viewport past its end.
    pub fn refresh_powers_panel(&mut self, powers: &[PowerInfo]) -> bool {
        let Some(panel) = self.powers_panel.as_ref() else {
            return false;
        };
        let ordered = Self::sorted_powers(powers);
        if panel.powers == ordered {
            return false;
        }
        let scroll = panel
            .scroll_offset
            .min(self.max_powers_scroll(ordered.len()));
        self.powers_panel = Some(PowersPanelState {
            powers: ordered,
            scroll_offset: scroll,
        });
        true
    }

    /// Close the powers panel overlay.
    pub fn hide_powers_panel(&mut self) {
        self.powers_panel = None;
    }

    /// Check if the powers panel is currently visible.
    pub fn has_powers_panel(&self) -> bool {
        self.powers_panel.is_some()
    }

    /// Scroll the powers panel up by `powers`. Saturates at 0.
    ///
    /// The stored offset is normalized into the CURRENT window before it moves.
    /// A terminal that grew, an input that shrank, or a crew row that went away
    /// all enlarge the popup, and an offset clamped for the smaller window then
    /// sits past the last full window — where the widget renders the view from
    /// the window's end rather than from the offset. Subtracting from that stale
    /// number would spend keypresses walking it back into range with the
    /// viewport standing still; normalizing first means one Up moves the view by
    /// one power (review finding 8, second advisory).
    pub fn powers_panel_scroll_up(&mut self, powers: usize) {
        let Some(len) = self.powers_panel.as_ref().map(|panel| panel.powers.len()) else {
            return;
        };
        let max = self.max_powers_scroll(len);
        if let Some(panel) = self.powers_panel.as_mut() {
            panel.scroll_offset = panel.scroll_offset.min(max).saturating_sub(powers);
        }
    }

    /// Scroll the powers panel down by `powers`. Saturates at the last offset
    /// whose window is still full (`max_powers_scroll`), not at the last
    /// power's index: with three-line rows an index clamp scrolls a three-power
    /// catalog into an almost-blank panel while the title still claims three
    /// powers (review finding 8).
    ///
    /// The bound is read before the panel is borrowed mutably because it
    /// depends on the frame layout, which is derived from the state as a whole
    /// (the input's growth decides where the popup can start).
    pub fn powers_panel_scroll_down(&mut self, powers: usize) {
        let Some(len) = self.powers_panel.as_ref().map(|panel| panel.powers.len()) else {
            return;
        };
        let max = self.max_powers_scroll(len);
        if let Some(panel) = self.powers_panel.as_mut() {
            panel.scroll_offset = (panel.scroll_offset + powers).min(max);
        }
    }

    // --- Code panel ---

    pub fn show_code_panel(&mut self, data: cyril_core::types::CodePanelData) {
        self.code_panel = Some(data);
    }

    pub fn close_code_panel(&mut self) {
        self.code_panel = None;
    }

    pub fn has_code_panel(&self) -> bool {
        self.code_panel.is_some()
    }

    // --- Usage panel ---

    /// Opens the panel without waiting for a snapshot.
    ///
    /// The process's first open has nothing to show and renders the computing
    /// state; every later open carries the last completed snapshot with the
    /// refreshing marker, because `hide_usage_panel` kept it (cyril-nanu D6).
    /// Re-opening an already-open panel is simply another refresh.
    pub fn open_usage_panel(&mut self) {
        if let Some(panel) = self.usage_panel.as_mut() {
            panel.refresh = UsageRefreshStatus::Refreshing;
            return;
        }
        let (snapshot, refresh, has_snapshot) = match self.last_usage_snapshot.take() {
            Some(snapshot) => (snapshot, UsageRefreshStatus::Refreshing, true),
            None => (
                cyril_core::types::UsageSnapshot::default(),
                UsageRefreshStatus::Computing,
                false,
            ),
        };
        self.usage_panel = Some(UsagePanelState {
            snapshot,
            refresh,
            has_snapshot,
            page: UsagePage::Overview,
            scroll_offset: 0,
            account: self.usage_account.clone(),
            account_fetched_at_ms: self.usage_account_fetched_at_ms,
            account_status: self.usage_account_status.clone(),
        });
    }

    /// Marks an in-flight recompute. Keeps whatever the panel already shows.
    pub fn mark_usage_panel_refreshing(&mut self) {
        if let Some(panel) = self.usage_panel.as_mut()
            && panel.refresh != UsageRefreshStatus::Computing
        {
            panel.refresh = UsageRefreshStatus::Refreshing;
        }
    }

    /// Records a failed recompute. The held values stay; the reason is shown.
    pub fn mark_usage_panel_failed(&mut self, reason: String) {
        if let Some(panel) = self.usage_panel.as_mut() {
            panel.refresh = UsageRefreshStatus::Failed(reason);
        }
    }

    pub fn show_usage_panel(&mut self, snapshot: cyril_core::types::UsageSnapshot) {
        self.usage_panel = Some(UsagePanelState {
            snapshot,
            refresh: UsageRefreshStatus::Idle,
            has_snapshot: true,
            page: UsagePage::Overview,
            scroll_offset: 0,
            account: self.usage_account.clone(),
            account_fetched_at_ms: self.usage_account_fetched_at_ms,
            account_status: self.usage_account_status.clone(),
        });
    }

    pub fn refresh_usage_panel(&mut self, snapshot: cyril_core::types::UsageSnapshot) {
        if let Some(panel) = self.usage_panel.as_mut() {
            panel.snapshot = snapshot;
            panel.refresh = UsageRefreshStatus::Idle;
            panel.has_snapshot = true;
            panel.account = self.usage_account.clone();
            panel.account_fetched_at_ms = self.usage_account_fetched_at_ms;
            panel.account_status = self.usage_account_status.clone();
            panel.scroll_offset = panel.scroll_offset.min(panel.row_count().saturating_sub(1));
        }
    }

    pub fn mark_usage_account_loading(&mut self) {
        self.usage_account_status = if self.usage_account.is_some() {
            UsageAccountStatus::Refreshing
        } else {
            UsageAccountStatus::Loading
        };
        self.sync_usage_account_panel();
    }

    fn sync_usage_account_panel(&mut self) {
        if let Some(panel) = self.usage_panel.as_mut() {
            panel.account = self.usage_account.clone();
            panel.account_fetched_at_ms = self.usage_account_fetched_at_ms;
            panel.account_status = self.usage_account_status.clone();
        }
    }

    /// Closes the panel, keeping its snapshot so a reopen shows the last known
    /// values rather than an empty computing state (cyril-nanu D6). Only the
    /// process's first open is ever empty.
    pub fn hide_usage_panel(&mut self) {
        if let Some(panel) = self.usage_panel.take()
            && panel.has_snapshot
        {
            // Only a real snapshot is worth keeping. Storing the placeholder a
            // Computing panel carries would make the next open render the
            // empty-log message for a log that was never read.
            self.last_usage_snapshot = Some(panel.snapshot);
        }
    }

    /// Keeps a snapshot that finished after the panel closed, so the next open
    /// starts from it rather than from an older one — or from nothing.
    pub fn store_usage_snapshot(&mut self, snapshot: cyril_core::types::UsageSnapshot) {
        self.last_usage_snapshot = Some(snapshot);
    }

    pub fn has_usage_panel(&self) -> bool {
        self.usage_panel.is_some()
    }

    pub fn usage_panel_next_page(&mut self) {
        if let Some(panel) = self.usage_panel.as_mut() {
            panel.page = panel.page.next();
            panel.scroll_offset = 0;
        }
    }

    pub fn usage_panel_previous_page(&mut self) {
        if let Some(panel) = self.usage_panel.as_mut() {
            panel.page = panel.page.previous();
            panel.scroll_offset = 0;
        }
    }

    pub fn usage_panel_scroll_up(&mut self, lines: usize) {
        if let Some(panel) = self.usage_panel.as_mut() {
            panel.scroll_offset = panel.scroll_offset.saturating_sub(lines);
        }
    }

    pub fn usage_panel_scroll_down(&mut self, lines: usize) {
        if let Some(panel) = self.usage_panel.as_mut() {
            let max = panel.row_count().saturating_sub(1);
            panel.scroll_offset = panel.scroll_offset.saturating_add(lines).min(max);
        }
    }

    pub fn set_code_intelligence_active(&mut self, active: bool) {
        self.code_intelligence_active = active;
    }

    // --- Chat scroll ---

    /// Scroll chat up by `lines`. Enters browse mode from follow mode,
    /// or scrolls further up if already browsing.
    pub fn chat_scroll_up(&mut self, lines: usize) {
        self.chat_scroll_back = Some(self.chat_scroll_back.unwrap_or(0).saturating_add(lines));
    }

    /// Scroll chat down by `lines`. Returns to follow mode when offset
    /// reaches zero.
    pub fn chat_scroll_down(&mut self, lines: usize) {
        match self.chat_scroll_back {
            None => {}
            Some(n) if n <= lines => {
                self.chat_scroll_back = None;
            }
            Some(n) => {
                self.chat_scroll_back = Some(n - lines);
            }
        }
    }

    /// Return to follow mode (snap to bottom).
    pub fn chat_scroll_reset(&mut self) {
        self.chat_scroll_back = None;
    }

    /// No-op stub — streaming text is committed directly in
    /// `apply_notification`, so no timeout-based buffer flush is needed.
    /// Returns `false` unconditionally.
    pub fn flush_stream_buffer(&mut self) -> bool {
        false
    }

    /// Trim oldest messages to stay within the configured limit.
    fn enforce_message_limit(&mut self) {
        if self.messages.len() > self.max_messages {
            let excess = self.messages.len() - self.max_messages;
            self.messages.drain(..excess);
            self.tool_call_index.retain(|_, idx| {
                if let Some(shifted) = idx.checked_sub(excess) {
                    *idx = shifted;
                    true
                } else {
                    false
                }
            });
        }
    }
}

#[cfg(test)]
mod tests {
    #![allow(clippy::unwrap_used, clippy::expect_used)]

    use super::*;

    #[test]
    fn new_state_is_empty() {
        let state = UiState::new(500);
        assert!(state.messages().is_empty());
        assert_eq!(state.messages_version(), 0);
        assert_eq!(state.streaming_text(), "");
        assert_eq!(state.activity(), Activity::Idle);
        assert!(!state.should_quit());
        assert_eq!(state.steering_queued(), 0);
    }

    /// cyril-14ou C7 fence: TurnStalled sets the stall chip; ANY other
    /// notification clears it (traffic ends the quiet period); a second quiet
    /// period sets it again; TurnCompleted clears it. Adversarial arms:
    /// a LATE TurnStalled on an idle session must not chip (races a terminal),
    /// double TurnStalled is an idempotent set, and cancel-sent marking is
    /// idempotent and dies with the chip. Buggy implementations these fail
    /// under: clear-only-on-TurnCompleted (stale chip through a resumed turn),
    /// unconditional set (idle chip), cancel-sent surviving a clear.
    #[test]
    fn stall_set_and_cleared() {
        let quiet = std::time::Duration::from_secs(31);
        let stalled = Notification::TurnStalled { quiet };
        let traffic = Notification::AgentMessage(cyril_core::types::AgentMessage {
            text: "resumed".into(),
            is_streaming: true,
        });

        let mut state = UiState::new(500);
        // Late signal on an idle session: display nothing.
        assert!(!state.apply_notification(&stalled));
        assert!(state.stall().is_none(), "idle session must not chip");

        // Busy turn stalls: chip up.
        state.set_activity(Activity::Streaming);
        assert!(state.apply_notification(&stalled));
        assert_eq!(state.stall().map(|s| s.quiet), Some(quiet));

        // Idempotent double-set (no traffic between): still chipped.
        assert!(state.apply_notification(&stalled));
        assert!(state.stall().is_some());

        // Cancel-sent escalation is idempotent.
        assert!(state.mark_stall_cancel_sent());
        assert!(!state.mark_stall_cancel_sent());
        assert_eq!(state.stall().map(|s| s.cancel_sent), Some(true));

        // ANY other notification clears — resumed traffic ends the period.
        assert!(state.apply_notification(&traffic));
        assert!(state.stall().is_none(), "traffic must clear the chip");
        assert!(!state.mark_stall_cancel_sent(), "no chip, nothing to mark");

        // Second quiet period chips again with fresh cancel state...
        assert!(state.apply_notification(&stalled));
        assert_eq!(state.stall().map(|s| s.cancel_sent), Some(false));

        // ...and the terminal clears it.
        assert!(state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        }));
        assert!(state.stall().is_none(), "terminal must clear the chip");

        // PR #94 review SP3: bridge-synthesized command responses say nothing
        // about the stalled turn — the chip (the cancel affordance) survives
        // them; only agent-turn traffic clears it.
        state.set_activity(Activity::Streaming);
        assert!(state.apply_notification(&stalled));
        state.apply_notification(&Notification::CommandExecuted {
            command: "tools".into(),
            response: serde_json::Value::Null,
        });
        assert!(
            state.stall().is_some(),
            "a command response must not vanish the stall chip"
        );
        state.apply_notification(&Notification::SettingsList {
            settings: serde_json::Value::Null,
        });
        assert!(state.stall().is_some(), "settings list must not clear");
        assert!(state.apply_notification(&traffic));
        assert!(state.stall().is_none(), "agent traffic still clears");

        // Review fix 1: an activity reset that BYPASSES the notification path
        // (e.g. a failed deferred send forcing Idle) must take the chip down —
        // stall display cannot outlive busy.
        state.set_activity(Activity::Streaming);
        assert!(state.apply_notification(&stalled));
        assert!(state.stall().is_some());
        state.set_activity(Activity::Idle);
        assert!(
            state.stall().is_none(),
            "stall display must not outlive busy"
        );
    }

    #[test]
    fn workflow_notification_is_ui_noop() {
        let workflow_id =
            WorkflowId::try_from("workflow".to_owned()).expect("non-empty workflow id");
        let node_id = WorkflowNodeId::try_from("node".to_owned()).expect("non-empty node id");
        let node_path =
            WorkflowNodePath::try_new(&workflow_id, vec!["workflow".to_owned(), "node".to_owned()])
                .expect("canonical node path");
        let details = WorkflowNodeStartDetails::new()
            .with_agent_name("agent".to_owned())
            .with_session_id(SessionId::new("session"))
            .with_prompt("prompt".repeat(1024))
            .with_iteration(u32::MAX)
            .with_branch_id("branch".to_owned());
        let notification = Notification::Workflow(Box::new(WorkflowEvent::NodeStarted(
            WorkflowNodeStarted::new(
                workflow_id,
                node_id,
                node_path,
                WorkflowNodeType::Step,
                details,
            ),
        )));

        let mut state = UiState::new(500);
        state.input_text = "preserve input".to_owned();
        state.streaming_text = "preserve stream".to_owned();
        state.set_activity(Activity::Sending);
        let before = (
            state.messages.len(),
            state.messages_version,
            state.input_text.clone(),
            state.streaming_text.clone(),
            state.activity,
            state.quit_requested,
        );

        assert!(!state.apply_notification(&notification));
        assert_eq!(
            (
                state.messages.len(),
                state.messages_version,
                state.input_text.clone(),
                state.streaming_text.clone(),
                state.activity,
                state.quit_requested,
            ),
            before
        );

        let expected_discriminant = std::mem::discriminant(&Notification::CommandsUpdated {
            commands: Vec::new(),
            prompts: Vec::new(),
        });
        let started = Instant::now();
        for _ in 0..10_000 {
            let unrelated = Notification::CommandsUpdated {
                commands: Vec::new(),
                prompts: Vec::new(),
            };
            assert_eq!(std::mem::discriminant(&unrelated), expected_discriminant);
            assert!(!state.apply_notification(&unrelated));
        }
        // Perf fence, not a latency contract: the CI-safe 5 s ceiling never
        // flakes on a loaded runner, while a regression that makes the
        // unrelated-notification path do real per-call work against the
        // retained workflow payload still overshoots it.
        assert!(
            started.elapsed() <= Duration::from_secs(5),
            "10,001 direct notification calls exceeded 5 s: {:?}",
            started.elapsed()
        );
    }

    // cyril-nd4h claim C4. Once `ui.mouse_capture` is honored, startup state is
    // no longer unconditionally `true`, so the toggle must be correct from
    // EITHER starting state -- the first press always changes the mode.
    //
    // STRESS FIXTURE: both directions, deliberately. A fixture that only starts
    // from the historical hardcoded default cannot distinguish a real toggle
    // from an implementation that ignores current state (`= true`) or inverts
    // it -- and "inverted Ctrl+M" is the exact failure the App startup comment
    // has been warning about.
    #[test]
    fn mouse_capture_toggles_from_either_starting_state() {
        for start in [false, true] {
            let mut state = UiState::new(500);
            state.set_mouse_captured(start);
            assert_eq!(state.mouse_captured(), start, "setter must stick");

            state.toggle_mouse_capture();
            assert_eq!(
                state.mouse_captured(),
                !start,
                "first toggle from {start} must flip the mode, not force a constant"
            );

            state.toggle_mouse_capture();
            assert_eq!(
                state.mouse_captured(),
                start,
                "second toggle from {start} must return to the starting mode"
            );
        }
    }

    #[test]
    fn new_state_uses_cyril_dark_truecolor() {
        let state = UiState::new(500);
        assert_eq!(
            TuiState::theme(&state),
            crate::theme::resolve(
                crate::theme::ThemeId::CyrilDark,
                crate::theme::ColorMode::TrueColor,
            )
        );
    }

    // Slice A / design claim 12: SteeringUnsupported -> exactly one system message.
    #[test]
    fn steering_unsupported_adds_one_message() {
        let mut state = UiState::new(500);
        let before = state.messages().len();
        let changed = state.apply_notification(&Notification::SteeringUnsupported {
            message: "steering requires kiro-cli 2.7.0+".into(),
        });
        assert!(changed);
        assert_eq!(state.messages().len(), before + 1);
        let last = state.messages().last().unwrap();
        assert!(
            matches!(last.kind(), ChatMessageKind::System(s) if s.contains("kiro-cli 2.7.0+")),
            "expected a system message containing the steering text, got {:?}",
            last.kind()
        );
    }

    // cyril-vgcm C8: a wire SteeringQueued{Some(id)} binds the id to the OLDEST
    // id-less Queued chip and never re-counts. Bug classes this fixture fails
    // under: newest-first binding, double-bind on a duplicate echo, wire-echo
    // re-count (the 7z7u double-count), and chip creation for foreign steers.
    // Oracle: counter == #Queued chips after every step (7z7u contract).
    #[test]
    fn steering_queued_binds_id_no_count() {
        fn chips(s: &UiState) -> Vec<(SteerEchoStatus, Option<String>)> {
            s.messages()
                .iter()
                .filter_map(|m| match m.kind() {
                    ChatMessageKind::SteerEcho {
                        status, message_id, ..
                    } => Some((*status, message_id.clone())),
                    _ => None,
                })
                .collect()
        }
        fn queued_count(s: &UiState) -> usize {
            chips(s)
                .iter()
                .filter(|(st, _)| *st == SteerEchoStatus::Queued)
                .count()
        }

        let mut state = UiState::new(500);
        // Foreign steer (id, zero local chips) -> no-op: no chip, no count.
        assert!(!state.apply_notification(&Notification::SteeringQueued {
            message: Some("foreign".into()),
            message_id: Some("steer-foreign".into()),
        }));
        assert_eq!(state.steering_queued(), 0);
        assert!(
            chips(&state).is_empty(),
            "no chip invented for a foreign steer"
        );

        state.add_steer_echo("first");
        state.add_steer_echo("second");
        assert_eq!(state.steering_queued(), 2);

        // Bind: OLDEST id-less chip gets the id; counter untouched.
        let changed = state.apply_notification(&Notification::SteeringQueued {
            message: Some("first".into()),
            message_id: Some("steer-1".into()),
        });
        assert!(changed, "a successful bind is a state change");
        assert_eq!(
            chips(&state),
            vec![
                (SteerEchoStatus::Queued, Some("steer-1".into())),
                (SteerEchoStatus::Queued, None),
            ],
            "oldest id-less chip binds first"
        );
        assert_eq!(state.steering_queued(), 2, "bind must not re-count");
        assert_eq!(state.steering_queued(), queued_count(&state), "7z7u oracle");

        // Duplicate wire echo with the SAME id -> second chip must NOT bind.
        assert!(!state.apply_notification(&Notification::SteeringQueued {
            message: Some("first".into()),
            message_id: Some("steer-1".into()),
        }));
        assert_eq!(
            chips(&state)[1],
            (SteerEchoStatus::Queued, None),
            "duplicate echo must not claim a second chip"
        );

        // Old-dialect echo (no id) -> no bind, no count (unchanged behavior).
        assert!(!state.apply_notification(&Notification::SteeringQueued {
            message: Some("second".into()),
            message_id: None,
        }));
        assert_eq!(state.steering_queued(), 2);
        assert_eq!(state.steering_queued(), queued_count(&state), "7z7u oracle");
    }

    // cyril-vgcm C9: Consumed prefers the id-matched chip, falls back FIFO,
    // and decrements by ACTUAL flips. Bug classes: FIFO-always (id ignored —
    // flips the wrong chip), unconditional decrement (duplicate injected echo
    // drifts the counter below the chip count), underflow on a ghost id.
    // Oracle: counter == #Queued chips after every step (7z7u contract).
    #[test]
    fn steering_consumed_id_match_then_fifo() {
        fn chips(s: &UiState) -> Vec<(SteerEchoStatus, Option<String>)> {
            s.messages()
                .iter()
                .filter_map(|m| match m.kind() {
                    ChatMessageKind::SteerEcho {
                        status, message_id, ..
                    } => Some((*status, message_id.clone())),
                    _ => None,
                })
                .collect()
        }
        fn assert_oracle(s: &UiState) {
            let queued = chips(s)
                .iter()
                .filter(|(st, _)| *st == SteerEchoStatus::Queued)
                .count();
            assert_eq!(
                s.steering_queued(),
                queued,
                "7z7u: counter == #Queued chips"
            );
        }

        let mut state = UiState::new(500);
        state.add_steer_echo("A");
        state.add_steer_echo("B");
        state.apply_notification(&Notification::SteeringQueued {
            message: Some("A".into()),
            message_id: Some("id1".into()),
        });
        state.apply_notification(&Notification::SteeringQueued {
            message: Some("B".into()),
            message_id: Some("id2".into()),
        });
        assert_eq!(state.steering_queued(), 2);
        assert_oracle(&state);

        // Id-match: id2 flips B (the NEWER chip) — FIFO would wrongly flip A.
        assert!(state.apply_notification(&Notification::SteeringConsumed {
            content: None,
            message_id: Some("id2".into()),
        }));
        assert_eq!(
            chips(&state),
            vec![
                (SteerEchoStatus::Queued, Some("id1".into())),
                (SteerEchoStatus::Applied, Some("id2".into())),
            ],
            "id-match must beat FIFO"
        );
        assert_eq!(state.steering_queued(), 1);
        assert_oracle(&state);

        // Duplicate injected echo (id2 already Applied): nothing flips, no
        // decrement, and NO FIFO fallback onto A.
        assert!(!state.apply_notification(&Notification::SteeringConsumed {
            content: None,
            message_id: Some("id2".into()),
        }));
        assert_eq!(
            chips(&state)[0],
            (SteerEchoStatus::Queued, Some("id1".into()))
        );
        assert_eq!(
            state.steering_queued(),
            1,
            "duplicate echo must not decrement"
        );
        assert_oracle(&state);

        // Id-less echo (old dialect): FIFO fallback drains A.
        assert!(state.apply_notification(&Notification::SteeringConsumed {
            content: None,
            message_id: None,
        }));
        assert_eq!(
            chips(&state)[0],
            (SteerEchoStatus::Applied, Some("id1".into()))
        );
        assert_eq!(state.steering_queued(), 0);
        assert_oracle(&state);

        // Ghost id with zero Queued chips: no flip, no underflow.
        assert!(!state.apply_notification(&Notification::SteeringConsumed {
            content: None,
            message_id: Some("ghost".into()),
        }));
        assert_eq!(state.steering_queued(), 0);
        assert_oracle(&state);
    }

    // cyril-vgcm C6 — THE design's canonical fixture. Chips [A(id1, Applied),
    // B(id2, Queued), C(no-id, Queued)]; Cleared{[id1, id3]} must leave A
    // untouched (id1 matched a terminal chip — consumed, no fallback), leave
    // B untouched (id2 not named), flip C (id3 unknown -> oldest id-less
    // fallback), and decrement by 1. Kills flip-all (would flip B too),
    // len-based id-blind math (counter -2), and positional matching.
    #[test]
    fn steering_cleared_id_scoped_drain() {
        fn chips(s: &UiState) -> Vec<(SteerEchoStatus, Option<String>)> {
            s.messages()
                .iter()
                .filter_map(|m| match m.kind() {
                    ChatMessageKind::SteerEcho {
                        status, message_id, ..
                    } => Some((*status, message_id.clone())),
                    _ => None,
                })
                .collect()
        }
        fn assert_oracle(s: &UiState) {
            let queued = chips(s)
                .iter()
                .filter(|(st, _)| *st == SteerEchoStatus::Queued)
                .count();
            assert_eq!(
                s.steering_queued(),
                queued,
                "7z7u: counter == #Queued chips"
            );
        }

        let mut state = UiState::new(500);
        state.add_steer_echo("A");
        state.add_steer_echo("B");
        state.add_steer_echo("C");
        // Bind A->id1, B->id2 (oldest id-less binds first); C stays id-less.
        state.apply_notification(&Notification::SteeringQueued {
            message: Some("A".into()),
            message_id: Some("id1".into()),
        });
        state.apply_notification(&Notification::SteeringQueued {
            message: Some("B".into()),
            message_id: Some("id2".into()),
        });
        // Drain A (id1 -> Applied) — the KAS healthy-turn shape.
        state.apply_notification(&Notification::SteeringConsumed {
            content: None,
            message_id: Some("id1".into()),
        });
        assert_eq!(state.steering_queued(), 2);
        assert_oracle(&state);

        // The canonical Cleared: names the Applied id + a ghost id.
        assert!(state.apply_notification(&Notification::SteeringCleared {
            message_ids: vec!["id1".into(), "id3".into()],
        }));
        assert_eq!(
            chips(&state),
            vec![
                (SteerEchoStatus::Applied, Some("id1".into())), // NOT re-flipped
                (SteerEchoStatus::Queued, Some("id2".into())),  // not named: survives
                (SteerEchoStatus::Cleared, None),               // ghost-id fallback
            ]
        );
        assert_eq!(state.steering_queued(), 1, "counter -= actual flips (1)");
        assert_oracle(&state);

        // Ghost id with NO id-less Queued chip left: zero flips, no change.
        assert!(!state.apply_notification(&Notification::SteeringCleared {
            message_ids: vec!["id9".into()],
        }));
        assert_eq!(state.steering_queued(), 1, "no underflow, no drift");
        assert_oracle(&state);

        // C7: empty ids = the old dialect's drain-all. B finally flips.
        assert!(state.apply_notification(&Notification::SteeringCleared {
            message_ids: Vec::new(),
        }));
        assert_eq!(
            chips(&state)
                .iter()
                .filter(|(st, _)| *st == SteerEchoStatus::Queued)
                .count(),
            0,
            "empty ids flips every Queued chip"
        );
        assert_eq!(state.steering_queued(), 0);
        assert_oracle(&state);
    }

    // cyril-vgcm Slice 1 / claim C12 (UI side): SteeringClearUnsupported is
    // advisory-ONLY. The plausible copy-paste bug is wiring it to
    // SteeringUnsupported's arm, which zeroes the chip and flips every Queued
    // echo — this fixture fails under that wiring.
    #[test]
    fn steering_clear_unsupported_is_advisory_only() {
        let mut state = UiState::new(500);
        state.add_steer_echo("still alive");
        state.add_steer_echo("also alive");
        assert_eq!(state.steering_queued(), 2);
        let before = state.messages().len();

        let changed = state.apply_notification(&Notification::SteeringClearUnsupported {
            message: "steer/clear not supported by this agent".into(),
        });
        assert!(changed);
        assert_eq!(
            state.messages().len(),
            before + 1,
            "exactly one system message"
        );
        assert!(matches!(
            state.messages().last().unwrap().kind(),
            ChatMessageKind::System(s) if s.contains("steer/clear not supported")
        ));
        // The queued steers are real and will still drain — untouched.
        assert_eq!(state.steering_queued(), 2, "counter must NOT be zeroed");
        let queued = state
            .messages()
            .iter()
            .filter(|m| {
                matches!(
                    m.kind(),
                    ChatMessageKind::SteerEcho {
                        status: SteerEchoStatus::Queued,
                        ..
                    }
                )
            })
            .count();
        assert_eq!(queued, 2, "no echo may be flipped by the advisory");
    }

    // cyril-bm1j Slice 2 / claim C3: optimistic steer echo appended on send.
    #[test]
    fn add_steer_echo_appends_queued() {
        let mut state = UiState::new(500);

        // (a) the echo carries the user's text, optimistically Queued.
        state.add_steer_echo("fix tests");
        // cyril-7z7u claim 1: the chip increments optimistically at send.
        assert_eq!(state.steering_queued(), 1, "chip == #Queued echoes (1)");
        let last = state.messages().last().expect("one message");
        assert!(
            matches!(last.kind(),
                ChatMessageKind::SteerEcho { text, status: SteerEchoStatus::Queued, .. } if text == "fix tests"),
            "expected SteerEcho{{Queued,\"fix tests\"}}, got {:?}",
            last.kind()
        );

        // (b) FIFO insertion order is preserved (precondition for Slice 3's oldest-first reconcile).
        state.add_steer_echo("then this");
        let msgs = state.messages();
        assert!(matches!(msgs[msgs.len() - 2].kind(),
            ChatMessageKind::SteerEcho { text, .. } if text == "fix tests"));
        assert!(matches!(msgs[msgs.len() - 1].kind(),
            ChatMessageKind::SteerEcho { text, .. } if text == "then this"));

        // (c) empty text still appends a Queued echo (degenerate-but-valid; no silent drop).
        state.add_steer_echo("");
        assert!(matches!(state.messages().last().unwrap().kind(),
            ChatMessageKind::SteerEcho { text, status: SteerEchoStatus::Queued, .. } if text.is_empty()));
        // cyril-7z7u claim 1: three sends -> chip 3 (incl. the empty one).
        assert_eq!(state.steering_queued(), 3, "chip == #Queued echoes (3)");
    }

    // cyril-7z7u claim 5: SteeringUnsupported clears the optimistic chip (not just
    // the echoes) — else the optimistic count would leak on an unsupported steer.
    #[test]
    fn unsupported_clears_chip() {
        let mut state = UiState::new(500);
        state.add_steer_echo("a");
        state.add_steer_echo("b");
        assert_eq!(state.steering_queued(), 2);
        state.apply_notification(&Notification::SteeringUnsupported {
            message: "steering requires kiro-cli 2.7.0+".into(),
        });
        assert_eq!(
            state.steering_queued(),
            0,
            "unsupported clears the optimistic chip"
        );
        assert!(
            state.messages().iter().all(|m| !matches!(
                m.kind(),
                ChatMessageKind::SteerEcho {
                    status: SteerEchoStatus::Queued,
                    ..
                }
            )),
            "all Queued echoes flipped off Queued"
        );
    }

    // cyril-nvmh fence helper: number of still-`Queued` steer echoes. The
    // cyril-7z7u oracle is `steering_queued() == queued_echoes(&state)`, so
    // every drain path must zero BOTH the counter and the Queued echoes.
    fn queued_echoes(s: &UiState) -> usize {
        s.messages()
            .iter()
            .filter(|m| {
                matches!(
                    m.kind(),
                    ChatMessageKind::SteerEcho {
                        status: SteerEchoStatus::Queued,
                        ..
                    }
                )
            })
            .count()
    }

    // ---- cyril-3qwa: the `[STEERING <id>: …]` receipt the model emits ----

    /// Receipt id and note reproducing the 2026-07-23 AWS prompt-log capture's
    /// SHAPE — `steer-<uuid>` id, em dash, backticks — with neutral content,
    /// since the capture came from a private workspace. The id shape matches the
    /// KAS `messageId` capture too.
    const RECEIPT_ID: &str = "steer-3f2a9c14-7b6d-4e05-9a81-2c5d8e0b41f7";
    const RECEIPT_NOTE: &str =
        "Applied directly — used the external `region_map` sheet as the label source.";

    fn steer_note(s: &UiState) -> Option<String> {
        s.messages().iter().find_map(|m| match m.kind() {
            ChatMessageKind::SteerEcho { note, .. } => note.clone(),
            _ => None,
        })
    }

    fn agent_chunk(state: &mut UiState, text: &str, streaming: bool) {
        state.apply_notification(&Notification::AgentMessage(AgentMessage {
            text: text.into(),
            is_streaming: streaming,
        }));
    }

    // The nominal path: queued -> consumed -> the model's trailer. The receipt
    // must be excised from the committed agent text and land on the chip.
    #[test]
    fn receipt_annotates_the_chip_and_never_reaches_the_transcript() {
        let mut state = UiState::new(500);
        state.add_steer_echo("use the external spreadsheet");
        state.apply_notification(&Notification::SteeringQueued {
            message: Some("use the external spreadsheet".into()),
            message_id: Some(RECEIPT_ID.into()),
        });
        state.apply_notification(&Notification::SteeringConsumed {
            content: Some("use the external spreadsheet".into()),
            message_id: Some(RECEIPT_ID.into()),
        });
        assert_eq!(state.steering_queued(), 0, "consumed drained the chip");

        agent_chunk(&mut state, "Committed and pushed.\n\n", true);
        agent_chunk(
            &mut state,
            &format!("[STEERING {RECEIPT_ID}: {RECEIPT_NOTE}]"),
            true,
        );
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: StopReason::EndTurn,
        });

        assert_eq!(steer_note(&state).as_deref(), Some(RECEIPT_NOTE));
        let agent_text: String = state
            .messages()
            .iter()
            .filter_map(|m| match m.kind() {
                ChatMessageKind::AgentText(t) => Some(t.as_str()),
                _ => None,
            })
            .collect();
        assert_eq!(
            agent_text, "Committed and pushed.\n\n",
            "receipt leaked into the transcript"
        );
    }

    // Recovery path (the cyril-ppkx failure mode): the wire consumed echo never
    // arrives — renamed, dropped, or an unmapped dialect. The receipt is itself
    // proof the model saw the steer, so it must drain the chip rather than leave
    // it stuck at Queued. Fences the cyril-7z7u invariant across that recovery.
    #[test]
    fn receipt_recovers_a_chip_the_consumed_echo_never_drained() {
        let mut state = UiState::new(500);
        state.add_steer_echo("use the external spreadsheet");
        state.apply_notification(&Notification::SteeringQueued {
            message: Some("use the external spreadsheet".into()),
            message_id: Some(RECEIPT_ID.into()),
        });
        assert_eq!(state.steering_queued(), 1);

        // No SteeringConsumed — straight to the model's trailer.
        agent_chunk(
            &mut state,
            &format!("done. [STEERING {RECEIPT_ID}: {RECEIPT_NOTE}]"),
            true,
        );

        assert_eq!(state.steering_queued(), 0, "receipt did not drain the chip");
        assert_eq!(
            state.steering_queued(),
            queued_echoes(&state),
            "cyril-7z7u invariant broken: counter != #Queued chips"
        );
        assert_eq!(steer_note(&state).as_deref(), Some(RECEIPT_NOTE));
    }

    // The id-less pre-rollout dialect: nothing ever binds an id, so the receipt
    // falls back to the oldest note-less non-terminal chip (the same FIFO
    // convention flip_consumed_steer_echo uses) and binds the id while it is there.
    #[test]
    fn receipt_falls_back_to_fifo_on_the_id_less_dialect() {
        let mut state = UiState::new(500);
        state.add_steer_echo("first");
        state.add_steer_echo("second");
        agent_chunk(
            &mut state,
            &format!("[STEERING {RECEIPT_ID}: {RECEIPT_NOTE}]"),
            true,
        );

        let annotated: Vec<_> = state
            .messages()
            .iter()
            .filter_map(|m| match m.kind() {
                ChatMessageKind::SteerEcho { text, note, .. } => Some((text.clone(), note.clone())),
                _ => None,
            })
            .collect();
        assert_eq!(
            annotated,
            vec![
                ("first".to_string(), Some(RECEIPT_NOTE.to_string())),
                ("second".to_string(), None),
            ],
            "receipt annotated the wrong chip"
        );
    }

    // A receipt naming an id no chip carries, when every chip is already bound,
    // must reconcile nothing rather than pin the note to an unrelated steer.
    // The marker is still stripped — it is noise either way.
    #[test]
    fn unmatched_receipt_drops_the_note_but_still_strips() {
        let mut state = UiState::new(500);
        state.add_steer_echo("mine");
        state.apply_notification(&Notification::SteeringQueued {
            message: Some("mine".into()),
            message_id: Some("steer-mine".into()),
        });
        agent_chunk(
            &mut state,
            "ok [STEERING steer-someone-else: not yours]",
            false,
        );

        assert_eq!(steer_note(&state), None, "note pinned to the wrong chip");
        let agent_text: String = state
            .messages()
            .iter()
            .filter_map(|m| match m.kind() {
                ChatMessageKind::AgentText(t) => Some(t.as_str()),
                _ => None,
            })
            .collect();
        assert_eq!(agent_text, "ok ", "unmatched receipt was not stripped");
    }

    // The live view must never expose marker bytes, at any chunk boundary —
    // this is what stops the raw receipt from flashing mid-stream.
    #[test]
    fn streaming_view_never_leaks_receipt_bytes() {
        let trailer = format!("[STEERING {RECEIPT_ID}: {RECEIPT_NOTE}]");
        // Split the trailer at every byte boundary a chunk could land on.
        for split in 1..trailer.len() {
            if !trailer.is_char_boundary(split) {
                continue;
            }
            let mut state = UiState::new(500);
            agent_chunk(&mut state, "Done. ", true);
            agent_chunk(&mut state, &trailer[..split], true);
            assert_eq!(
                state.streaming_text(),
                "Done. ",
                "leaked at split {split}: {:?}",
                state.streaming_text()
            );
            agent_chunk(&mut state, &trailer[split..], true);
            assert_eq!(
                state.streaming_text(),
                "Done. ",
                "residue after completion at split {split}"
            );
        }
    }

    // Prose that merely opens with `[` must not be withheld from the live view —
    // withholding real text would look like the stream had stalled.
    #[test]
    fn ordinary_bracket_prose_is_not_withheld() {
        let mut state = UiState::new(500);
        agent_chunk(&mut state, "see [1] and the [STEERING GROUP] notes", true);
        assert_eq!(
            state.streaming_text(),
            "see [1] and the [STEERING GROUP] notes"
        );
    }

    // cyril-nvmh path (c): the backend accepts a tail steer (queued:true) but
    // never streams a `SteeringConsumed`. A steer that survives TWO consecutive
    // turn-ends with no intervening consume is provably gone (cyril-7z7u probe:
    // a tail steer's queued+consumed pair defers to exactly the NEXT turn), so
    // the optimistic chip must drain on the 2nd turn-end. Before the fix the
    // chip sticks at 1 forever.
    #[test]
    fn steer_chip_drains_after_two_turns_without_consume() {
        let mut state = UiState::new(500);
        state.add_steer_echo("finish the refactor");
        assert_eq!(state.steering_queued(), 1);

        // First turn-end: the steer is a truthful tail steer — chip survives.
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: StopReason::EndTurn,
        });
        assert_eq!(
            state.steering_queued(),
            1,
            "one idle tail must NOT drain (path a is truthful)"
        );
        assert_eq!(queued_echoes(&state), 1, "echo still Queued after one tail");

        // Second consecutive turn-end, still no consume: the steer is gone.
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: StopReason::EndTurn,
        });
        assert_eq!(
            state.steering_queued(),
            0,
            "2nd consecutive turn-end with no consume drains the phantom chip"
        );
        assert_eq!(
            queued_echoes(&state),
            0,
            "7z7u oracle: draining the chip also finalizes the Queued echo"
        );
    }

    // cyril-nvmh path (b): a turn ends non-EndTurn (cancelled / errored) with the
    // steer un-consumed. Same drain contract — two turn-ends without a consume
    // means the steer never landed. Before the fix the chip sticks forever.
    #[test]
    fn steer_chip_drains_after_cancelled_turn_without_consume() {
        let mut state = UiState::new(500);
        state.add_steer_echo("abort and retry");
        assert_eq!(state.steering_queued(), 1);

        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: StopReason::Cancelled,
        });
        assert_eq!(state.steering_queued(), 1, "one turn-tail must not drain");

        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: StopReason::Cancelled,
        });
        assert_eq!(
            state.steering_queued(),
            0,
            "cancelled/errored turns with no consume drain on the 2nd turn-end"
        );
        assert_eq!(queued_echoes(&state), 0, "7z7u oracle holds after drain");
    }

    // cyril-nvmh path (d): a dead bridge can never drain a queued steer, so
    // `BridgeDisconnected` is an explicit drain point alongside the context /
    // tokens / activity it already clears. Before the fix the chip leaks past
    // the disconnect until `/new`.
    #[test]
    fn steer_chip_drains_on_disconnect() {
        let mut state = UiState::new(500);
        state.add_steer_echo("keep going");
        state.add_steer_echo("and this too");
        assert_eq!(state.steering_queued(), 2);

        state.apply_notification(&Notification::BridgeDisconnected {
            reason: "kiro-cli exited".into(),
        });
        assert_eq!(
            state.steering_queued(),
            0,
            "a dead bridge drains the optimistic steer chip"
        );
        assert_eq!(
            queued_echoes(&state),
            0,
            "7z7u oracle: disconnect finalizes the Queued echoes too"
        );
    }

    // cyril-nvmh path (a) guard: a single idle turn-tail is TRUTHFUL, not
    // phantom (cyril-7z7u probe). The chip must survive exactly one turn-end and
    // then drain via the real `SteeringConsumed` that arrives on the NEXT turn —
    // it must NOT be drained prematurely by the 2nd-turn rule.
    #[test]
    fn steer_chip_survives_single_idle_tail() {
        let mut state = UiState::new(500);
        state.add_steer_echo("run the tests");
        assert_eq!(state.steering_queued(), 1);

        // Turn ends with the steer still queued (user then goes idle).
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: StopReason::EndTurn,
        });
        assert_eq!(
            state.steering_queued(),
            1,
            "the steer is genuinely still queued through one idle tail"
        );
        assert_eq!(queued_echoes(&state), 1, "echo remains Queued");

        // The next turn starts and the backend finally consumes the steer.
        assert!(state.apply_notification(&Notification::SteeringConsumed {
            content: None,
            message_id: None,
        }));
        assert_eq!(
            state.steering_queued(),
            0,
            "the real consume on the next turn drains the chip"
        );
        assert_eq!(queued_echoes(&state), 0);
    }

    // cyril-nvmh guard for note #4: a `SteeringConsumed` resets the
    // consecutive-turn drain counter, so a LATER legitimate steer is not wrongly
    // drained by turn-ends that predate it. Without the reset, a fresh steer
    // would inherit a stale count and drain after a single idle tail.
    #[test]
    fn steer_chip_consume_resets_drain_counter() {
        let mut state = UiState::new(500);
        state.add_steer_echo("first steer");

        // One turn-end accrues a turn against the first steer, then it consumes.
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: StopReason::EndTurn,
        });
        assert!(state.apply_notification(&Notification::SteeringConsumed {
            content: None,
            message_id: None,
        }));
        assert_eq!(state.steering_queued(), 0);

        // A brand-new steer must get a full grace of one idle tail — the stale
        // turn count from before the consume must not carry over.
        state.add_steer_echo("second steer");
        assert_eq!(state.steering_queued(), 1);
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: StopReason::EndTurn,
        });
        assert_eq!(
            state.steering_queued(),
            1,
            "the drain counter reset on consume; the new steer survives its tail"
        );
    }

    // cyril-7z7u claim 8 (stress: identical content): two same-content steers drain
    // in FIFO order — the flip is POSITIONAL, never keyed on `content`.
    #[test]
    fn fifo_multi_steer_drains_same_content() {
        fn statuses(s: &UiState) -> Vec<SteerEchoStatus> {
            s.messages()
                .iter()
                .filter_map(|m| match m.kind() {
                    ChatMessageKind::SteerEcho { status, .. } => Some(*status),
                    _ => None,
                })
                .collect()
        }
        let mut state = UiState::new(500);
        state.add_steer_echo("same");
        state.add_steer_echo("same");
        assert_eq!(state.steering_queued(), 2);
        state.apply_notification(&Notification::SteeringConsumed {
            content: Some("same".into()),
            message_id: None,
        });
        assert_eq!(
            statuses(&state),
            vec![SteerEchoStatus::Applied, SteerEchoStatus::Queued],
            "oldest same-content steer flips first (positional, not content-keyed)"
        );
        state.apply_notification(&Notification::SteeringConsumed {
            content: Some("same".into()),
            message_id: None,
        });
        assert_eq!(
            statuses(&state),
            vec![SteerEchoStatus::Applied, SteerEchoStatus::Applied]
        );
        assert_eq!(state.steering_queued(), 0);
    }

    // cyril-bm1j Slice 3 / claim C4: SteeringConsumed flips the OLDEST Queued echo.
    #[test]
    fn consumed_flips_oldest_queued_echo() {
        let mut state = UiState::new(500);

        // Helper: collect the statuses of all SteerEcho messages in order.
        fn steer_statuses(s: &UiState) -> Vec<SteerEchoStatus> {
            s.messages()
                .iter()
                .filter_map(|m| match m.kind() {
                    ChatMessageKind::SteerEcho { status, .. } => Some(*status),
                    _ => None,
                })
                .collect()
        }

        state.add_steer_echo("E1");
        state.add_steer_echo("E2");
        state.add_steer_echo("E3");

        // First consume (content None) flips E1 only — not E2/E3.
        state.apply_notification(&Notification::SteeringConsumed {
            content: None,
            message_id: None,
        });
        assert_eq!(
            steer_statuses(&state),
            vec![
                SteerEchoStatus::Applied,
                SteerEchoStatus::Queued,
                SteerEchoStatus::Queued
            ],
            "oldest (E1) flips first"
        );

        // Second consume (content Some, NOT matching any echo text) flips E2, not E3
        // — proving `content` is not used as a correlation key.
        state.apply_notification(&Notification::SteeringConsumed {
            content: Some("unrelated text".into()),
            message_id: None,
        });
        assert_eq!(
            steer_statuses(&state),
            vec![
                SteerEchoStatus::Applied,
                SteerEchoStatus::Applied,
                SteerEchoStatus::Queued
            ],
            "FIFO holds across interleaving; content ignored"
        );

        // Adversarial: consume with NO Queued echo left after E3 flips -> the 4th
        // consume finds nothing, no panic, chip saturating_sub floors at 0.
        state.apply_notification(&Notification::SteeringConsumed {
            content: None,
            message_id: None,
        }); // flips E3
        state.apply_notification(&Notification::SteeringConsumed {
            content: None,
            message_id: None,
        }); // nothing to flip
        assert_eq!(
            steer_statuses(&state),
            vec![
                SteerEchoStatus::Applied,
                SteerEchoStatus::Applied,
                SteerEchoStatus::Applied
            ],
            "empty-queue consume is a no-op on echoes"
        );
        assert_eq!(state.steering_queued(), 0, "chip floors at 0, no underflow");
    }

    // cyril-bm1j Slice 4 / claim C5: SteeringCleared flips ALL Queued, preserves terminals.
    #[test]
    fn cleared_flips_all_queued_echoes() {
        fn steer_statuses(s: &UiState) -> Vec<SteerEchoStatus> {
            s.messages()
                .iter()
                .filter_map(|m| match m.kind() {
                    ChatMessageKind::SteerEcho { status, .. } => Some(*status),
                    _ => None,
                })
                .collect()
        }

        let mut state = UiState::new(500);
        state.add_steer_echo("E1");
        state.add_steer_echo("E2");
        state.add_steer_echo("E3");
        // Flip E1 -> Applied so we can prove Cleared does NOT clobber a terminal state.
        state.apply_notification(&Notification::SteeringConsumed {
            content: None,
            message_id: None,
        });

        state.apply_notification(&Notification::SteeringCleared {
            message_ids: Vec::new(),
        });
        assert_eq!(
            steer_statuses(&state),
            vec![
                SteerEchoStatus::Applied, // E1 preserved, NOT re-flipped to Cleared
                SteerEchoStatus::Cleared, // E2
                SteerEchoStatus::Cleared, // E3
            ],
            "all Queued -> Cleared; Applied untouched"
        );
        assert_eq!(state.steering_queued(), 0);

        // Adversarial: empty transcript + Cleared -> no panic, chip stays 0.
        let mut empty = UiState::new(500);
        empty.apply_notification(&Notification::SteeringCleared {
            message_ids: Vec::new(),
        });
        assert_eq!(empty.steering_queued(), 0);
    }

    // cyril-bm1j Slice 5 / claim C6: SteeringUnsupported flips ALL Queued (burst) + one notice.
    #[test]
    fn unsupported_flips_all_echoes_and_one_message() {
        fn steer_statuses(s: &UiState) -> Vec<SteerEchoStatus> {
            s.messages()
                .iter()
                .filter_map(|m| match m.kind() {
                    ChatMessageKind::SteerEcho { status, .. } => Some(*status),
                    _ => None,
                })
                .collect()
        }
        fn system_count(s: &UiState) -> usize {
            s.messages()
                .iter()
                .filter(|m| matches!(m.kind(), ChatMessageKind::System(_)))
                .count()
        }

        let mut state = UiState::new(500);
        state.add_steer_echo("E1");
        state.add_steer_echo("E2");
        // Flip E1 -> Applied: an already-terminal echo must NOT be re-flipped.
        state.apply_notification(&Notification::SteeringConsumed {
            content: None,
            message_id: None,
        });
        // Now add two more Queued (burst still in flight when the notice lands).
        state.add_steer_echo("E3");
        state.add_steer_echo("E4");

        state.apply_notification(&Notification::SteeringUnsupported {
            message: "steering requires kiro-cli 2.7.0+".into(),
        });

        assert_eq!(
            steer_statuses(&state),
            vec![
                SteerEchoStatus::Applied,     // E1 preserved
                SteerEchoStatus::Unsupported, // E2
                SteerEchoStatus::Unsupported, // E3
                SteerEchoStatus::Unsupported, // E4
            ],
            "burst: ALL Queued flip on one notice; Applied untouched"
        );
        assert_eq!(
            system_count(&state),
            1,
            "exactly one system notice (K1a behavior preserved)"
        );
    }

    // cyril-7z7u (supersedes cyril-bm1j Slice 6 / claim C9): TurnCompleted does NOT
    // reset the steer chip — a steer pending at turn-end drains via a later
    // SteeringConsumed, not via a turn-end reset.
    #[test]
    fn turn_completed_does_not_reset_pending_steer() {
        // cyril-7z7u claim 3 (rewrites the old turn_completed_resets test, which
        // locked the now-removed reset). A late steer is queued mid-turn and the
        // backend defers it to the next turn (probe: .cyril-7z7u/findings.md), so
        // TurnCompleted must NOT reset the chip or finalize the echo — the steer is
        // genuinely still pending and drains via the next turn's SteeringConsumed.
        let mut state = UiState::new(500);
        state.add_steer_echo("a"); // optimistic: chip 1, echo Queued
        assert_eq!(state.steering_queued(), 1);

        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });
        assert_eq!(
            state.steering_queued(),
            1,
            "turn-end must NOT reset a pending steer (it drains next turn)"
        );
        assert!(
            state.messages().iter().any(|m| matches!(
                m.kind(),
                ChatMessageKind::SteerEcho {
                    status: SteerEchoStatus::Queued,
                    ..
                }
            )),
            "the pending echo stays Queued across turn-end"
        );

        // Next turn consumes the deferred steer -> chip drains, echo flips.
        state.apply_notification(&Notification::SteeringConsumed {
            content: None,
            message_id: None,
        });
        assert_eq!(state.steering_queued(), 0, "consumed drains the chip");
        assert!(
            state.messages().iter().any(|m| matches!(
                m.kind(),
                ChatMessageKind::SteerEcho {
                    status: SteerEchoStatus::Applied,
                    ..
                }
            )),
            "consumed flips the surviving echo to Applied"
        );

        // Adversarial: TurnCompleted at chip 0 stays 0 (no spurious reset/underflow).
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });
        assert_eq!(state.steering_queued(), 0);
    }

    // cyril-bm1j Slice 7: steering_queued() is readable through &dyn TuiState (live, not cached).
    #[test]
    fn steering_queued_exposed_via_tuistate_trait() {
        let mut state = UiState::new(500);
        // cyril-7z7u: the chip is optimistic — drive it via add_steer_echo
        // (user-send), not the wire SteeringQueued (which no longer counts).
        state.add_steer_echo("a");
        state.add_steer_echo("b");
        assert_eq!((&state as &dyn TuiState).steering_queued(), 2);
        // Live, not a stale snapshot: a consume is reflected through the trait.
        state.apply_notification(&Notification::SteeringConsumed {
            content: None,
            message_id: None,
        });
        assert_eq!((&state as &dyn TuiState).steering_queued(), 1);
    }

    // cyril-bm1j code-review fix: a new session must finalize the prior session's
    // Queued echoes, else the new session's SteeringConsumed FIFO-flips an orphan.
    #[test]
    fn session_created_finalizes_prior_session_steer_echoes() {
        fn status_of(state: &UiState, text: &str) -> Option<SteerEchoStatus> {
            state.messages().iter().find_map(|m| match m.kind() {
                ChatMessageKind::SteerEcho {
                    text: t, status, ..
                } if t == text => Some(*status),
                _ => None,
            })
        }

        let mut state = UiState::new(500);
        state.add_steer_echo("old-session steer"); // Queued, never consumed

        // New session abandons the old steer.
        state.apply_notification(&Notification::SessionCreated {
            session_id: SessionId::new("fresh"),
            current_mode: None,
            current_model: None,
            available_modes: Vec::new(),
            available_models: Vec::new(),
        });
        assert_eq!(
            status_of(&state, "old-session steer"),
            Some(SteerEchoStatus::Cleared),
            "prior-session echo must be finalized on new session, not left Queued"
        );

        // New session steer + consume must flip the NEW echo, not the old orphan.
        state.add_steer_echo("new-session steer");
        state.apply_notification(&Notification::SteeringConsumed {
            content: None,
            message_id: None,
        });
        assert_eq!(
            status_of(&state, "new-session steer"),
            Some(SteerEchoStatus::Applied),
            "new session's consume flips the NEW echo"
        );
        assert_eq!(
            status_of(&state, "old-session steer"),
            Some(SteerEchoStatus::Cleared),
            "old orphan echo is NOT re-flipped to Applied by the new session"
        );
    }

    // cyril-7z7u claim 4 (single-client): a bare wire SteeringQueued with no
    // preceding add_steer_echo is a no-op — the chip stays 0 and no echo is added.
    // Pins the optimistic model from zero (the other tests only assert "no re-count"
    // starting from an already-optimistic count, so they can't catch a regression
    // that makes the wire arm increment again).
    #[test]
    fn bare_wire_steering_queued_is_a_noop() {
        let mut state = UiState::new(500);
        let before = state.messages().len();
        let changed = state.apply_notification(&Notification::SteeringQueued {
            message: Some("from another observer".into()),
            message_id: None,
        });
        assert!(
            !changed,
            "wire SteeringQueued changes no UiState (returns false)"
        );
        assert_eq!(
            state.steering_queued(),
            0,
            "wire SteeringQueued must not increment the optimistic chip from zero"
        );
        assert_eq!(
            state.messages().len(),
            before,
            "wire SteeringQueued adds no SteerEcho (echoes are local-send only)"
        );
    }

    // cyril-7z7u (supersedes Slice A / design claim 13): optimistic chip mirror —
    // add_steer_echo->+1, wire SteeringQueued is a no-op, SteeringConsumed->-1,
    // Cleared/SessionCreated->0, floor at 0.
    #[test]
    fn steering_queue_mirror() {
        // cyril-7z7u: the chip is OPTIMISTIC — driven by add_steer_echo (user-send),
        // drained by SteeringConsumed, zeroed by Cleared/SessionCreated. The wire
        // SteeringQueued no longer counts (it would double-count the optimistic add).
        // (Rewrites the old wire-driven mirror.)
        let mut state = UiState::new(500);
        assert_eq!(state.steering_queued(), 0);

        state.add_steer_echo("a");
        state.add_steer_echo("b");
        assert_eq!(state.steering_queued(), 2, "optimistic: counted at send");

        // claim 4: a wire SteeringQueued must NOT change the count (no double-count).
        state.apply_notification(&Notification::SteeringQueued {
            message: Some("a".into()),
            message_id: None,
        });
        assert_eq!(
            state.steering_queued(),
            2,
            "wire steering_queued must not re-count an already-optimistic steer"
        );

        // claim 2 (count): consumed decrements.
        state.apply_notification(&Notification::SteeringConsumed {
            content: Some("a".into()),
            message_id: None,
        });
        assert_eq!(state.steering_queued(), 1);

        // claim 6: cleared zeroes the count.
        state.apply_notification(&Notification::SteeringCleared {
            message_ids: Vec::new(),
        });
        assert_eq!(state.steering_queued(), 0);

        // claim 9: consumed at 0 floors at 0 (saturating, no underflow panic).
        state.apply_notification(&Notification::SteeringConsumed {
            content: None,
            message_id: None,
        });
        assert_eq!(state.steering_queued(), 0);

        // claim 7: a new session zeroes the count — a pending optimistic steer must
        // not leak a phantom chip onto the fresh session.
        state.add_steer_echo("leftover");
        assert_eq!(state.steering_queued(), 1);
        state.apply_notification(&Notification::SessionCreated {
            session_id: SessionId::new("fresh"),
            current_mode: None,
            current_model: None,
            available_modes: Vec::new(),
            available_models: Vec::new(),
        });
        assert_eq!(
            state.steering_queued(),
            0,
            "steering_queued must reset on a new session"
        );
    }

    #[test]
    fn apply_agent_message_streams() {
        let mut state = UiState::new(500);
        let changed = state.apply_notification(&Notification::AgentMessage(AgentMessage {
            text: "hello ".into(),
            is_streaming: true,
        }));
        assert!(changed);
        assert_eq!(state.streaming_text(), "hello ");
        assert_eq!(state.activity(), Activity::Streaming);
    }

    #[test]
    fn apply_agent_thought_accumulates_deltas() {
        let mut state = UiState::new(500);
        // Thought chunks arrive as token-deltas, mirroring agent_message_chunk.
        state.apply_notification(&Notification::AgentThought(AgentThought {
            text: "I'm".into(),
        }));
        let changed = state.apply_notification(&Notification::AgentThought(AgentThought {
            text: " working".into(),
        }));
        assert!(changed);
        // Must accumulate, not overwrite with only the latest delta.
        assert_eq!(state.streaming_thought(), Some("I'm working"));
    }

    #[test]
    fn thought_persists_to_chat_log_on_turn_complete() {
        let mut state = UiState::new(500);
        state.apply_notification(&Notification::AgentThought(AgentThought {
            text: "reasoning".into(),
        }));
        assert_eq!(state.streaming_thought(), Some("reasoning"));
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });
        // Live preview cleared, but the thought is committed to scrollback.
        assert_eq!(state.streaming_thought(), None);
        assert_eq!(state.messages().len(), 1);
        assert!(
            matches!(state.messages()[0].kind(), ChatMessageKind::Thought(t) if t == "reasoning")
        );
    }

    #[test]
    fn thought_commits_before_agent_response() {
        let mut state = UiState::new(500);
        state.apply_notification(&Notification::AgentThought(AgentThought {
            text: "thinking".into(),
        }));
        state.apply_notification(&Notification::AgentMessage(AgentMessage {
            text: "answer".into(),
            is_streaming: true,
        }));
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });
        // Thought commits BEFORE the response text, preserving chronological order.
        let msgs = state.messages();
        assert_eq!(msgs.len(), 2);
        assert!(matches!(msgs[0].kind(), ChatMessageKind::Thought(t) if t == "thinking"));
        assert!(matches!(msgs[1].kind(), ChatMessageKind::AgentText(t) if t == "answer"));
    }

    #[test]
    fn empty_thought_is_not_committed() {
        let mut state = UiState::new(500);
        // A whitespace-only thought must not create a noise message.
        state.apply_notification(&Notification::AgentThought(AgentThought {
            text: "   ".into(),
        }));
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });
        assert!(state.messages().is_empty());
    }

    #[test]
    fn thought_commits_before_user_message() {
        // Enter-while-busy / steering: a user message added mid-thinking must
        // commit the accumulated reasoning BEFORE it, not after (and not merge a
        // later thought chunk onto it).
        let mut state = UiState::new(500);
        state.apply_notification(&Notification::AgentThought(AgentThought {
            text: "reasoning".into(),
        }));
        state.add_user_message("steer left");

        let msgs = state.messages();
        assert_eq!(msgs.len(), 2);
        assert!(matches!(msgs[0].kind(), ChatMessageKind::Thought(t) if t == "reasoning"));
        assert!(matches!(msgs[1].kind(), ChatMessageKind::UserText(t) if t == "steer left"));
        assert_eq!(state.streaming_thought(), None);
    }

    #[test]
    fn thought_commits_before_tool_call() {
        // A thought preceding a tool call must land before it in the message
        // list — the boundary where chronological order matters most.
        let mut state = UiState::new(500);
        state.apply_notification(&Notification::AgentThought(AgentThought {
            text: "planning the edit".into(),
        }));
        let tc = ToolCall::new(
            ToolCallId::new("tc_1"),
            "fs_write".into(),
            ToolKind::Write,
            ToolCallStatus::InProgress,
            None,
        );
        state.apply_notification(&Notification::ToolCallStarted(tc));

        let msgs = state.messages();
        assert_eq!(msgs.len(), 2);
        assert!(matches!(msgs[0].kind(), ChatMessageKind::Thought(t) if t == "planning the edit"));
        assert!(matches!(msgs[1].kind(), ChatMessageKind::ToolCall(_)));
        assert_eq!(state.streaming_thought(), None);
    }

    #[test]
    fn agent_thought_starts_fresh_on_next_turn() {
        // After a turn boundary clears the buffer, the next turn's first thought
        // must start clean — not concatenate onto the prior turn's reasoning.
        let mut state = UiState::new(500);
        state.apply_notification(&Notification::AgentThought(AgentThought {
            text: "turn one".into(),
        }));
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });
        assert_eq!(state.streaming_thought(), None);

        state.apply_notification(&Notification::AgentThought(AgentThought {
            text: "turn two".into(),
        }));
        assert_eq!(
            state.streaming_thought(),
            Some("turn two"),
            "next turn must not carry over the prior turn's thought"
        );
    }

    #[test]
    fn apply_turn_completed_commits() {
        let mut state = UiState::new(500);
        state.apply_notification(&Notification::AgentMessage(AgentMessage {
            text: "response".into(),
            is_streaming: true,
        }));
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });

        assert_eq!(state.streaming_text(), "");
        assert_eq!(state.messages().len(), 1);
        assert!(
            matches!(state.messages()[0].kind(), ChatMessageKind::AgentText(t) if t == "response")
        );
        assert_eq!(state.messages_version(), 1);
        assert_eq!(state.activity(), Activity::Ready);
    }

    #[test]
    fn apply_tool_call_started() {
        let mut state = UiState::new(500);
        let tc = ToolCall::new(
            ToolCallId::new("tc_1"),
            "read".into(),
            ToolKind::Read,
            ToolCallStatus::InProgress,
            None,
        );
        let changed = state.apply_notification(&Notification::ToolCallStarted(tc));
        assert!(changed);
        assert_eq!(state.active_tool_calls().len(), 1);
        assert_eq!(state.activity(), Activity::ToolRunning);
    }

    #[test]
    fn apply_tool_call_updated() {
        let mut state = UiState::new(500);
        let tc = ToolCall::new(
            ToolCallId::new("tc_1"),
            "read".into(),
            ToolKind::Read,
            ToolCallStatus::InProgress,
            None,
        );
        state.apply_notification(&Notification::ToolCallStarted(tc));

        let updated = ToolCall::new(
            ToolCallId::new("tc_1"),
            "Reading src/main.rs".into(),
            ToolKind::Read,
            ToolCallStatus::Completed,
            None,
        );
        state.apply_notification(&Notification::ToolCallUpdated(updated));

        assert_eq!(state.active_tool_calls()[0].title(), "Reading src/main.rs");
    }

    #[test]
    fn source_derived_absent_and_partial_raw_input_display_safely() {
        const FIXTURE: &str = include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../cyril-core/tests/fixtures/kas/tool_call_raw_input_2_18_1_source_derived.jsonl"
        ));

        let notifications = cyril_core::test_support::kas_capture_to_routed(FIXTURE);
        assert_eq!(notifications.len(), 4, "all source-derived frames convert");

        let mut state = UiState::new(500);
        for (_, notification) in notifications {
            state.apply_notification(&notification);
        }

        let tracked = |id: &str| {
            state.messages().iter().find_map(|message| {
                let ChatMessageKind::ToolCall(call) = message.kind() else {
                    return None;
                };
                (call.id().as_str() == id).then_some(call)
            })
        };
        let absent = tracked("source-absent").expect("absent-input call is committed");
        assert!(absent.raw_input().is_none());
        assert_eq!(absent.primary_path(), None);
        assert_eq!(absent.command_text(), None);

        let partial = tracked("source-partial").expect("partial-input call is committed");
        assert_eq!(
            partial.raw_input(),
            Some(&serde_json::json!({
                "path": "/workspace/src/space ü.rs",
                "newStr": "partial replacement"
            }))
        );
        assert_eq!(partial.primary_path(), Some("/workspace/src/space ü.rs"));
        assert_eq!(partial.command_text(), None);
    }

    #[test]
    fn cancellation_captures_converge_to_one_failed_committed_call() {
        const CAPTURES: [(&str, &str); 6] = [
            (
                "2.16.2 attempt 1",
                include_str!("../../../.cyril-a5wo/captures/attempt-1.jsonl"),
            ),
            (
                "2.16.2 attempt 2",
                include_str!("../../../.cyril-a5wo/captures/attempt-2.jsonl"),
            ),
            (
                "2.16.2 attempt 3",
                include_str!("../../../.cyril-a5wo/captures/attempt-3.jsonl"),
            ),
            (
                "2.18.1 attempt 1",
                include_str!("../../../.cyril-a5wo/captures-2.18.1/attempt-1.jsonl"),
            ),
            (
                "2.18.1 attempt 2",
                include_str!("../../../.cyril-a5wo/captures-2.18.1/attempt-2.jsonl"),
            ),
            (
                "2.18.1 attempt 3",
                include_str!("../../../.cyril-a5wo/captures-2.18.1/attempt-3.jsonl"),
            ),
        ];

        fn assert_preserved_fields(name: &str, current: &TrackedToolCall, initial: &ToolCall) {
            assert_eq!(current.title(), initial.title(), "{name}");
            assert_eq!(current.kind(), initial.kind(), "{name}");
            assert_eq!(current.raw_input(), initial.raw_input(), "{name}");
            assert_eq!(
                format!("{:?}", current.content()),
                format!("{:?}", initial.content()),
                "{name}"
            );
            assert_eq!(
                format!("{:?}", current.locations()),
                format!("{:?}", initial.locations()),
                "{name}"
            );
        }

        for (name, capture) in CAPTURES {
            let notifications = cyril_core::test_support::kas_recording_to_routed(capture);
            let mut initial = None;
            let mut state = UiState::new(500);
            for (_, notification) in notifications {
                if let Notification::ToolCallStarted(call) = &notification {
                    assert!(initial.replace(call.clone()).is_none(), "{name}");
                }
                state.apply_notification(&notification);
                if matches!(notification, Notification::ToolCallUpdated(_)) {
                    let expected = initial
                        .as_ref()
                        .unwrap_or_else(|| panic!("{name}: update preceded initial call"));
                    let current = state
                        .messages()
                        .iter()
                        .find_map(|message| {
                            let ChatMessageKind::ToolCall(call) = message.kind() else {
                                return None;
                            };
                            (call.id() == expected.id()).then_some(call)
                        })
                        .unwrap_or_else(|| panic!("{name}: update lost committed call"));
                    assert_preserved_fields(name, current, expected);
                }
            }

            let initial = initial.unwrap_or_else(|| panic!("{name}: missing initial tool call"));
            let committed: Vec<_> = state
                .messages()
                .iter()
                .filter_map(|message| {
                    let ChatMessageKind::ToolCall(call) = message.kind() else {
                        return None;
                    };
                    Some(call)
                })
                .collect();
            assert_eq!(committed.len(), 1, "{name}");
            let committed = committed[0];
            assert_eq!(committed.id(), initial.id(), "{name}");
            assert_preserved_fields(name, committed, &initial);
            assert_eq!(committed.status(), ToolCallStatus::Failed, "{name}");
            assert!(state.active_tool_calls().is_empty(), "{name}");
            assert_eq!(state.activity(), Activity::Ready, "{name}");
        }
    }

    // --- Turn lifecycle tests ---
    // These test realistic sequences of notifications, not just individual events.

    #[test]
    fn turn_with_text_and_tool_calls_commits_both() {
        let mut state = UiState::new(500);

        // Simulate: agent streams text, starts a tool call, completes it, streams more text
        state.apply_notification(&Notification::AgentMessage(AgentMessage {
            text: "Let me read that file.".into(),
            is_streaming: true,
        }));
        let tc = ToolCall::new(
            ToolCallId::new("tc_1"),
            "Reading main.rs".into(),
            ToolKind::Read,
            ToolCallStatus::InProgress,
            None,
        );
        state.apply_notification(&Notification::ToolCallStarted(tc));

        assert_eq!(state.active_tool_calls().len(), 1);
        // Text is flushed to messages when tool call starts, and tool call is
        // committed immediately in chronological position
        assert_eq!(state.streaming_text(), "");
        assert_eq!(
            state.messages().len(),
            2,
            "text + tool call should be committed immediately"
        );

        // Turn completes
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });

        // Both text and tool call should be in committed messages
        assert!(
            state.active_tool_calls().is_empty(),
            "active tool calls should be cleared"
        );
        assert_eq!(
            state.streaming_text(),
            "",
            "streaming text should be cleared"
        );

        let messages = state.messages();
        assert!(
            messages.len() >= 2,
            "should have text + tool call messages, got {}",
            messages.len()
        );

        let has_agent_text = messages
            .iter()
            .any(|m| matches!(m.kind(), ChatMessageKind::AgentText(_)));
        let has_tool_call = messages
            .iter()
            .any(|m| matches!(m.kind(), ChatMessageKind::ToolCall(_)));
        assert!(
            has_agent_text,
            "committed messages should include agent text"
        );
        assert!(has_tool_call, "committed messages should include tool call");
    }

    #[test]
    fn turn_with_diff_content_preserves_diff_in_history() {
        use cyril_core::types::{ToolCallContent, ToolCallLocation};

        let mut state = UiState::new(500);

        let tc = ToolCall::new(
            ToolCallId::new("tc_1"),
            "Editing main.rs".into(),
            ToolKind::Write,
            ToolCallStatus::Completed,
            None,
        )
        .with_content(vec![ToolCallContent::Diff {
            path: "src/main.rs".into(),
            old_text: Some("fn main() {}".into()),
            new_text: "fn main() {\n    println!(\"hello\");\n}".into(),
        }])
        .with_locations(vec![ToolCallLocation {
            path: "src/main.rs".into(),
            line: Some(1),
        }]);

        state.apply_notification(&Notification::ToolCallStarted(tc));
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });

        // The tool call should be committed with its diff content intact
        let messages = state.messages();
        let tc_msg = messages
            .iter()
            .find(|m| matches!(m.kind(), ChatMessageKind::ToolCall(_)));
        assert!(
            tc_msg.is_some(),
            "tool call should be in committed messages"
        );

        if let ChatMessageKind::ToolCall(tracked) = tc_msg.unwrap().kind() {
            assert!(
                !tracked.content().is_empty(),
                "diff content should be preserved"
            );
            assert!(
                !tracked.locations().is_empty(),
                "locations should be preserved"
            );
            assert_eq!(tracked.primary_path(), Some("src/main.rs"));
        } else {
            panic!("expected ToolCall message kind");
        }
    }

    #[test]
    fn multiple_turns_preserve_all_content() {
        let mut state = UiState::new(500);

        // Turn 1: text only
        state.apply_notification(&Notification::AgentMessage(AgentMessage {
            text: "First response.".into(),
            is_streaming: true,
        }));
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });

        // Turn 2: text + tool call
        state.apply_notification(&Notification::AgentMessage(AgentMessage {
            text: "Second response.".into(),
            is_streaming: true,
        }));
        let tc = ToolCall::new(
            ToolCallId::new("tc_1"),
            "read".into(),
            ToolKind::Read,
            ToolCallStatus::Completed,
            None,
        );
        state.apply_notification(&Notification::ToolCallStarted(tc));
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });

        // Both turns should be in history
        let messages = state.messages();
        let agent_texts: Vec<_> = messages
            .iter()
            .filter(|m| matches!(m.kind(), ChatMessageKind::AgentText(_)))
            .collect();
        let tool_calls: Vec<_> = messages
            .iter()
            .filter(|m| matches!(m.kind(), ChatMessageKind::ToolCall(_)))
            .collect();

        assert_eq!(agent_texts.len(), 2, "both turns should have agent text");
        assert_eq!(tool_calls.len(), 1, "second turn should have tool call");
    }

    #[test]
    fn turn_with_only_tool_calls_no_text() {
        let mut state = UiState::new(500);

        // Agent does tool calls without streaming any text
        let tc = ToolCall::new(
            ToolCallId::new("tc_1"),
            "Reading config".into(),
            ToolKind::Read,
            ToolCallStatus::Completed,
            None,
        );
        state.apply_notification(&Notification::ToolCallStarted(tc));
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });

        let messages = state.messages();
        assert_eq!(
            messages.len(),
            1,
            "tool call should be committed even with no text"
        );
        assert!(matches!(messages[0].kind(), ChatMessageKind::ToolCall(_)));
    }

    #[test]
    fn message_limit_enforced() {
        let mut state = UiState::new(3);
        for i in 0..5 {
            state.add_user_message(&format!("msg {i}"));
        }
        assert_eq!(state.messages().len(), 3);
        // Oldest messages removed
        assert!(matches!(state.messages()[0].kind(), ChatMessageKind::UserText(t) if t == "msg 2"));
    }

    #[test]
    fn add_system_message() {
        let mut state = UiState::new(500);
        state.add_system_message("Welcome".into());
        assert_eq!(state.messages().len(), 1);
        assert!(matches!(state.messages()[0].kind(), ChatMessageKind::System(t) if t == "Welcome"));
    }

    /// cyril-0qe6: one system message per workflow command outcome — the
    /// double-consumption bug (also rendering the tracker-owned snapshot)
    /// would produce two messages or a panic.
    #[test]
    fn workflow_command_outcome_becomes_one_system_message() {
        let mut state = UiState::new(500);
        let changed = state.apply_notification(&Notification::WorkflowCommand(
            cyril_core::types::WorkflowCommandOutcome::Failed {
                operation: "workflow resume".into(),
                workflow_id: None,
                code: Some(-32603),
                details: "running in another process (owner pid 42, liveness verdict: live)".into(),
            },
        ));
        assert!(changed);
        assert_eq!(state.messages().len(), 1);
        assert!(matches!(
            state.messages()[0].kind(),
            ChatMessageKind::System(text) if text.contains("owner pid 42")
        ));
    }

    /// The tracker-owned snapshot never renders here: defensively ignored
    /// with a warn, no message, no panic.
    #[test]
    fn workflow_snapshot_is_ignored_by_ui_state() {
        let mut state = UiState::new(500);
        let snapshot = cyril_core::types::WorkflowSnapshot::new(
            match cyril_core::types::WorkflowId::try_from("wf_x".to_owned()) {
                Ok(id) => id,
                Err(error) => panic!("fixture id: {error}"),
            },
            "recipe".into(),
            cyril_core::types::WorkflowRunStatus::Running,
            cyril_core::types::WorkflowSnapshotData::new(
                serde_json::json!({}),
                serde_json::json!({}),
                serde_json::json!({}),
            ),
            cyril_core::types::WorkflowNodeSnapshot::new(
                cyril_core::types::WorkflowNodeDescriptor::sequence(
                    match cyril_core::types::WorkflowNodeId::try_from("root".to_owned()) {
                        Ok(id) => id,
                        Err(error) => panic!("fixture node id: {error}"),
                    },
                    Vec::new(),
                ),
                cyril_core::types::WorkflowNodeStatus::Running,
                Vec::new(),
            ),
            cyril_core::types::WorkflowSnapshotMetadata::new("2026-08-13T00:00:00Z".into(), 0),
        );
        let changed = state.apply_notification(&Notification::WorkflowSnapshot(Box::new(snapshot)));
        assert!(!changed);
        assert!(state.messages().is_empty());
    }

    /// Metadata frame carrying only a refusal alert (cyril-h8zb fences).
    fn refusal_frame(explanation: Option<&str>, recommended: Option<&str>) -> Notification {
        Notification::MetadataUpdated {
            context_usage: None,
            metering: None,
            tokens: None,
            duration_ms: None,
            effort: EffortUpdate::Unchanged,
            reasoning: None,
            session_id: None,
            refusal: Some(cyril_core::types::RefusalAlert::from_parts(
                None,
                explanation.map(str::to_string),
                recommended.map(str::to_string),
            )),
        }
    }

    fn system_message_count(state: &UiState, needle: &str) -> usize {
        state
            .messages()
            .iter()
            .filter(|m| matches!(m.kind(), ChatMessageKind::System(t) if t.contains(needle)))
            .count()
    }

    #[test]
    fn refusal_alert_dedupes_within_turn_resets_on_turn_end() {
        // Design claim #7 (cyril-h8zb): first refusal frame of a turn commits
        // ONE system message; repeats add nothing (kills no-dedupe spam); the
        // next turn alerts again (kills never-resets).
        let mut state = UiState::new(500);
        state.apply_notification(&refusal_frame(Some("blocked"), None));
        state.apply_notification(&refusal_frame(Some("blocked"), None));
        assert_eq!(
            system_message_count(&state, "blocked"),
            1,
            "second refusal frame in the same turn must not spam"
        );

        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: StopReason::EndTurn,
        });
        state.apply_notification(&refusal_frame(Some("blocked"), None));
        assert_eq!(
            system_message_count(&state, "blocked"),
            2,
            "a refusal in the next turn must alert again"
        );
    }

    #[test]
    fn refusal_alert_message_wording() {
        // Design claim #8 (cyril-h8zb): the four wording cells are exact
        // contracts (approved at the design pause). Fallback names /model and
        // /new — cyril has no /rewind, unlike Kiro's own fallback.
        const FALLBACK: &str = "The model couldn't process this request. Try a different model \
                                with /model or start a new session with /new.";
        let cases: &[(Option<&str>, Option<&str>, String)] = &[
            (
                Some("blocked by policy"),
                None,
                "blocked by policy".to_string(),
            ),
            (None, None, FALLBACK.to_string()),
            (
                Some("blocked by policy"),
                Some("claude-opus"),
                "blocked by policy Recommended model: claude-opus (switch with /model)."
                    .to_string(),
            ),
            (
                None,
                Some("claude-opus"),
                format!("{FALLBACK} Recommended model: claude-opus (switch with /model)."),
            ),
        ];
        for (explanation, recommended, expected) in cases {
            let mut state = UiState::new(500);
            state.apply_notification(&refusal_frame(*explanation, *recommended));
            let last = state.messages().last().expect("alert committed");
            assert!(
                matches!(last.kind(), ChatMessageKind::System(t) if t == expected),
                "wording for ({explanation:?}, {recommended:?}): got {:?}, want {expected:?}",
                last.kind()
            );
        }
    }

    #[test]
    fn refusal_alert_reset_on_session_created() {
        // Session swap must clear both the dedupe flag and the buffered
        // reconcile bit — the new session's first turn starts clean.
        let mut state = UiState::new(500);
        state.apply_notification(&refusal_frame(Some("blocked"), None));
        state.apply_notification(&Notification::SessionCreated {
            session_id: SessionId::new("s2"),
            current_mode: None,
            current_model: None,
            available_modes: Vec::new(),
            available_models: Vec::new(),
        });
        state.apply_notification(&refusal_frame(Some("blocked"), None));
        assert_eq!(
            system_message_count(&state, "blocked"),
            2,
            "new session must not inherit the dedupe flag"
        );
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: StopReason::EndTurn,
        });
        assert_eq!(
            state.last_turn().expect("summary").stop_reason(),
            StopReason::Refusal,
            "the new session's own refusal must still reconcile"
        );
    }

    #[test]
    fn refusal_reconciles_render_turn_summary() {
        // Design claim #9, render path (cyril-h8zb): the toolbar reads
        // UiState's TurnSummary — it must reconcile exactly like
        // SessionController's. Explicit Cancelled always wins; the flag
        // never leaks into the following turn.
        let mut state = UiState::new(500);
        state.apply_notification(&refusal_frame(Some("blocked"), None));
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: StopReason::EndTurn,
        });
        assert_eq!(
            state.last_turn().expect("summary").stop_reason(),
            StopReason::Refusal
        );

        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: StopReason::EndTurn,
        });
        assert_eq!(
            state.last_turn().expect("summary").stop_reason(),
            StopReason::EndTurn,
            "flag must not survive the turn boundary"
        );

        state.apply_notification(&refusal_frame(Some("blocked"), None));
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: StopReason::Cancelled,
        });
        assert_eq!(
            state.last_turn().expect("summary").stop_reason(),
            StopReason::Cancelled,
            "an explicit user cancel is not a refusal"
        );
    }

    #[test]
    fn take_input_clears() {
        let mut state = UiState::new(500);
        state.input_text = "hello".into();
        state.input_cursor = 5;
        let text = state.take_input();
        assert_eq!(text, "hello");
        assert_eq!(state.input_text(), "");
        assert_eq!(state.input_cursor(), 0);
    }

    #[test]
    fn voice_status_listening_tracks_level_then_clears_on_idle() {
        let mut state = UiState::new(500);
        assert!(!state.any_voice_active());

        state.set_voice_status(VoiceStatus::Listening);
        state.set_voice_level(0.8);
        assert!(state.any_voice_active());
        assert_eq!(state.voice_status(), VoiceStatus::Listening);
        assert!((state.voice_level() - 0.8).abs() < f32::EPSILON);

        // Leaving the listening state clears the meter so it doesn't linger.
        state.set_voice_status(VoiceStatus::Transcribing);
        assert!(state.any_voice_active());
        assert_eq!(state.voice_level(), 0.0);

        state.set_voice_status(VoiceStatus::Idle);
        assert!(!state.any_voice_active());
    }

    #[test]
    fn voice_level_is_clamped() {
        let mut state = UiState::new(500);
        state.set_voice_status(VoiceStatus::Listening);
        state.set_voice_level(2.5);
        assert_eq!(state.voice_level(), 1.0);
        state.set_voice_level(-1.0);
        assert_eq!(state.voice_level(), 0.0);
    }

    #[test]
    fn voice_level_nan_normalizes_to_silence() {
        // V1b RMS can yield NaN (empty buffer / divide-by-zero); it must never
        // be stored as the level (NaN compares false to everything).
        let mut state = UiState::new(500);
        state.set_voice_status(VoiceStatus::Listening);
        state.set_voice_level(f32::NAN);
        assert_eq!(state.voice_level(), 0.0);
        assert!(!state.voice_level().is_nan());
    }
    #[test]
    fn memory_status_replaces_atomically_and_survives_session_reset() {
        let mut state = UiState::new(500);
        let ready = cyril_core::types::MemoryStatusView::ready(
            "instance",
            1,
            cyril_core::types::MemoryStoreVersions::new(1, 1),
        );
        assert!(state.set_memory_status(ready.clone()));
        assert!(!state.set_memory_status(ready.clone()));
        state.apply_notification(&Notification::SessionCreated {
            session_id: SessionId::new("fresh"),
            current_mode: None,
            current_model: None,
            available_modes: Vec::new(),
            available_models: Vec::new(),
        });
        assert_eq!(state.memory_status(), &ready);

        let failed = cyril_core::types::MemoryStatusView::failed("runtime exited");
        assert!(state.set_memory_status(failed.clone()));
        assert_eq!(state.memory_status(), &failed);
        assert_eq!(state.memory_status().instance_id(), None);
    }

    #[test]
    fn insert_text_at_cursor_interleaves_and_advances() {
        let mut state = UiState::new(500);
        state.input_text = "abcd".into();
        state.input_cursor = 2;
        state.insert_text("XY");
        assert_eq!(state.input_text(), "abXYcd");
        assert_eq!(state.input_cursor(), 4);
    }

    #[test]
    fn insert_text_multibyte_keeps_byte_cursor_on_a_char_boundary() {
        let mut state = UiState::new(500);
        state.input_text = "é".into(); // 2 bytes
        state.input_cursor = "é".len(); // byte cursor at 2
        state.insert_text("日本"); // 6 bytes
        assert_eq!(state.input_text(), "é日本");
        assert_eq!(state.input_cursor(), 8);
        // The cursor must land on a valid char boundary: a following backspace
        // removes exactly one char and does not panic slicing the buffer.
        state.handle_input_key(crossterm::event::KeyEvent::from(
            crossterm::event::KeyCode::Backspace,
        ));
        assert_eq!(state.input_text(), "é日");
    }

    #[test]
    fn insert_text_normalizes_carriage_returns() {
        let mut state = UiState::new(500);
        state.insert_text("a\r\nb\rc");
        assert_eq!(state.input_text(), "a\nb\nc");
        assert_eq!(state.input_cursor(), state.input_text().len());
    }

    #[test]
    fn insert_text_empty_is_noop() {
        let mut state = UiState::new(500);
        state.input_text = "abc".into();
        state.input_cursor = 1;
        state.insert_text("");
        assert_eq!(state.input_text(), "abc");
        assert_eq!(state.input_cursor(), 1);
    }

    #[test]
    fn request_quit() {
        let mut state = UiState::new(500);
        assert!(!state.should_quit());
        state.request_quit();
        assert!(state.should_quit());
    }

    #[test]
    fn text_before_tool_call_commits_separately() {
        // Simulates: agent says "I'll edit that" → starts tool call → says "Done editing"
        // Text should NOT concatenate into "I'll edit thatDone editing"
        let mut state = UiState::new(500);

        // Agent streams text before tool call
        state.apply_notification(&Notification::AgentMessage(AgentMessage {
            text: "I'll edit that file.".into(),
            is_streaming: true,
        }));
        assert_eq!(state.streaming_text(), "I'll edit that file.");

        // Tool call starts — should flush text to messages
        let tc = ToolCall::new(
            ToolCallId::new("tc_1"),
            "write".into(),
            ToolKind::Write,
            ToolCallStatus::InProgress,
            None,
        );
        state.apply_notification(&Notification::ToolCallStarted(tc));

        // Text and tool call should both be committed in order
        assert_eq!(
            state.streaming_text(),
            "",
            "streaming text should be flushed"
        );
        assert_eq!(state.messages().len(), 2, "text + tool call committed");
        assert!(
            matches!(state.messages()[0].kind(), ChatMessageKind::AgentText(t) if t == "I'll edit that file."),
            "first message should be the pre-tool-call text"
        );
        assert!(
            matches!(state.messages()[1].kind(), ChatMessageKind::ToolCall(_)),
            "second message should be the tool call"
        );

        // Agent streams text after tool call
        state.apply_notification(&Notification::AgentMessage(AgentMessage {
            text: "Done editing.".into(),
            is_streaming: true,
        }));

        // Post-tool-call text should be separate from pre-tool-call text
        assert_eq!(state.streaming_text(), "Done editing.");

        // Turn completes
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });

        // Should have: text, tool call, text — in chronological order
        let messages = state.messages();
        assert_eq!(messages.len(), 3, "should have text + tool call + text");
        assert!(
            matches!(messages[0].kind(), ChatMessageKind::AgentText(t) if t == "I'll edit that file."),
            "first: pre-tool-call text"
        );
        assert!(
            matches!(messages[1].kind(), ChatMessageKind::ToolCall(_)),
            "second: tool call in chronological position"
        );
        assert!(
            matches!(messages[2].kind(), ChatMessageKind::AgentText(t) if t == "Done editing."),
            "third: post-tool-call text"
        );
    }

    // --- Tool call update merge tests ---
    // These test the exact Kiro scenario: initial ToolCall has content,
    // ToolCallUpdate only changes status, content must survive into committed messages.

    #[test]
    fn tool_call_update_preserves_diff_content() {
        use cyril_core::types::{ToolCallContent, ToolCallLocation};

        let mut state = UiState::new(500);

        // Phase 1: Initial ToolCall with diff content and location (Kiro sends this first)
        let tc = ToolCall::new(
            ToolCallId::new("tc_1"),
            "Editing main.rs".into(),
            ToolKind::Write,
            ToolCallStatus::Pending,
            Some(serde_json::json!({"file_path": "src/main.rs"})),
        )
        .with_content(vec![ToolCallContent::Diff {
            path: "src/main.rs".into(),
            old_text: Some("fn main() {}".into()),
            new_text: "fn main() {\n    println!(\"hello\");\n}".into(),
        }])
        .with_locations(vec![ToolCallLocation {
            path: "src/main.rs".into(),
            line: Some(1),
        }]);
        state.apply_notification(&Notification::ToolCallStarted(tc));

        assert_eq!(state.active_tool_calls().len(), 1);
        assert_eq!(state.active_tool_calls()[0].content().len(), 1);
        assert_eq!(state.active_tool_calls()[0].locations().len(), 1);

        // Phase 2: ToolCallUpdate with status=Completed but NO content/locations
        // (This is exactly what Kiro sends — only the changed fields)
        let update = ToolCall::new(
            ToolCallId::new("tc_1"),
            "Editing main.rs".into(),
            ToolKind::Write,
            ToolCallStatus::Completed,
            None,
        );
        // Note: no .with_content() or .with_locations() — empty vecs
        state.apply_notification(&Notification::ToolCallUpdated(update));

        // Content and locations must survive the update
        assert_eq!(
            state.active_tool_calls()[0].content().len(),
            1,
            "diff content must survive ToolCallUpdate"
        );
        assert_eq!(
            state.active_tool_calls()[0].locations().len(),
            1,
            "locations must survive ToolCallUpdate"
        );
        assert_eq!(
            state.active_tool_calls()[0].status(),
            ToolCallStatus::Completed,
            "status should be updated"
        );

        // Phase 3: TurnCompleted — tool calls commit to message history
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });

        let tc_msg = state
            .messages()
            .iter()
            .find(|m| matches!(m.kind(), ChatMessageKind::ToolCall(_)));
        assert!(
            tc_msg.is_some(),
            "tool call should be in committed messages"
        );

        if let ChatMessageKind::ToolCall(tracked) = tc_msg.unwrap().kind() {
            assert_eq!(
                tracked.content().len(),
                1,
                "diff content must survive through commit"
            );
            assert!(
                matches!(&tracked.content()[0], ToolCallContent::Diff { new_text, .. }
                    if new_text.contains("println")),
                "diff should contain the actual code change"
            );
            assert_eq!(tracked.primary_path(), Some("src/main.rs"));
        }
    }

    #[test]
    fn multiple_tool_call_updates_preserve_content() {
        use cyril_core::types::ToolCallContent;

        let mut state = UiState::new(500);

        // Initial ToolCall with content
        let tc = ToolCall::new(
            ToolCallId::new("tc_1"),
            "Editing lib.rs".into(),
            ToolKind::Write,
            ToolCallStatus::InProgress,
            None,
        )
        .with_content(vec![ToolCallContent::Diff {
            path: "src/lib.rs".into(),
            old_text: Some("// old".into()),
            new_text: "// new".into(),
        }]);
        state.apply_notification(&Notification::ToolCallStarted(tc));

        // First update: status changes to Pending
        let update1 = ToolCall::new(
            ToolCallId::new("tc_1"),
            "Editing lib.rs".into(),
            ToolKind::Write,
            ToolCallStatus::Pending,
            None,
        );
        state.apply_notification(&Notification::ToolCallUpdated(update1));
        assert_eq!(
            state.active_tool_calls()[0].content().len(),
            1,
            "content survives first update"
        );

        // Second update: status changes to Completed
        let update2 = ToolCall::new(
            ToolCallId::new("tc_1"),
            "Editing lib.rs".into(),
            ToolKind::Write,
            ToolCallStatus::Completed,
            None,
        );
        state.apply_notification(&Notification::ToolCallUpdated(update2));
        assert_eq!(
            state.active_tool_calls()[0].content().len(),
            1,
            "content survives second update"
        );
        assert_eq!(
            state.active_tool_calls()[0].status(),
            ToolCallStatus::Completed
        );
    }

    // --- Notification handler tests for new variants ---

    #[test]
    fn rate_limited_adds_system_message() {
        let mut state = UiState::new(500);
        let changed = state.apply_notification(&Notification::RateLimited {
            message: "Too many requests".into(),
        });
        assert!(changed);
        assert!(
            matches!(state.messages().last().unwrap().kind(), ChatMessageKind::System(t) if t.contains("Too many requests"))
        );
    }

    // cyril-3zy4 claim 5: a rate-limit notice is non-terminal — the backend
    // retries — so it must NOT clear a busy turn. Applying RateLimited mid-turn
    // leaves Activity untouched and emits no TurnCompleted.
    #[test]
    fn rate_limited_preserves_busy_activity() {
        let mut state = UiState::new(500);
        state.set_activity(Activity::Streaming);
        state.apply_notification(&Notification::RateLimited {
            message: "Rate limit exceeded".into(),
        });
        assert_eq!(
            state.activity(),
            Activity::Streaming,
            "rate_limit must not clear the busy guard (turn still retrying)"
        );
    }

    // cyril-08eh claim 8: SystemNotify adds a level-prefixed system message
    // and preserves busy guard (non-terminal, same contract as RateLimited).
    #[test]
    fn system_notify_adds_level_prefixed_message() {
        let mut state = UiState::new(500);
        use cyril_core::types::event::{Notification, SystemNotifyLevel};
        let changed = state.apply_notification(&Notification::SystemNotify {
            level: SystemNotifyLevel::Warning,
            message: "model is taking longer than usual".into(),
        });
        assert!(changed);
        assert!(
            matches!(state.messages().last().unwrap().kind(), ChatMessageKind::System(t)
                if t.contains("[warning]") && t.contains("model is taking longer than usual")),
            "system message must carry [warning] prefix"
        );
    }

    #[test]
    fn system_notify_preserves_busy_activity() {
        let mut state = UiState::new(500);
        state.set_activity(Activity::Streaming);
        use cyril_core::types::event::{Notification, SystemNotifyLevel};
        state.apply_notification(&Notification::SystemNotify {
            level: SystemNotifyLevel::Info,
            message: "delay".into(),
        });
        assert_eq!(
            state.activity(),
            Activity::Streaming,
            "system_notify must not clear the busy guard"
        );
    }

    #[test]
    fn mcp_server_init_failure_with_error() {
        let mut state = UiState::new(500);
        let changed = state.apply_notification(&Notification::McpServerInitFailure {
            server_name: "my-mcp".into(),
            error: Some("connection refused".into()),
        });
        assert!(changed);
        assert!(
            matches!(state.messages().last().unwrap().kind(), ChatMessageKind::System(t) if t.contains("my-mcp") && t.contains("connection refused"))
        );
    }

    #[test]
    fn mcp_server_init_failure_without_error() {
        let mut state = UiState::new(500);
        let changed = state.apply_notification(&Notification::McpServerInitFailure {
            server_name: "my-mcp".into(),
            error: None,
        });
        assert!(changed);
        assert!(
            matches!(state.messages().last().unwrap().kind(), ChatMessageKind::System(t) if t.contains("my-mcp") && t.contains("failed"))
        );
    }

    #[test]
    fn mcp_server_initialized_adds_system_message() {
        let mut state = UiState::new(500);
        let changed = state.apply_notification(&Notification::McpServerInitialized {
            server_name: "github-mcp".into(),
        });
        assert!(changed);
        assert!(
            matches!(state.messages().last().unwrap().kind(), ChatMessageKind::System(t) if t.contains("github-mcp") && t.contains("ready"))
        );
    }

    #[test]
    fn mcp_oauth_request_not_handled_by_ui() {
        let mut state = UiState::new(500);
        let changed = state.apply_notification(&Notification::McpOAuthRequest {
            server_name: "server".into(),
            url: "https://example.com".into(),
        });
        assert!(
            !changed,
            "McpOAuthRequest should be handled by App, not UiState"
        );
        assert!(state.messages().is_empty());
    }

    #[test]
    fn external_url_request_is_manual_and_nonterminal() {
        for (url, expected) in [
            (
                "https://example.com/authorize?code=a%2Fb&state=unchanged#continue",
                "Sign-in requested. Open in browser: https://example.com/authorize?code=a%2Fb&state=unchanged#continue",
            ),
            (
                "https://example.com/authorize?\u{1b}[31mstate=x\n\u{202e}next",
                r"Sign-in requested. Open in browser: https://example.com/authorize?\u{1b}[31mstate=x\n\u{202e}next",
            ),
        ] {
            let mut state = UiState::new(500);
            state.set_activity(Activity::Streaming);
            state.apply_notification(&Notification::TurnStalled {
                quiet: Duration::from_secs(31),
            });
            let version = state.messages_version();
            assert!(
                state.apply_notification(&Notification::ExternalUrlRequested { url: url.into() })
            );
            assert_eq!(state.messages_version(), version + 1);
            assert_eq!(state.messages().len(), 1);
            assert!(matches!(
                state.messages()[0].kind(),
                ChatMessageKind::System(text) if text == expected
            ));
            assert_eq!(state.activity(), Activity::Streaming);
            assert!(state.stall().is_some());
            assert!(state.main_session_id().is_none());
            assert!(state.last_turn().is_none());
            assert!(!state.has_modal_overlay());
        }
    }

    #[test]
    fn mcp_connection_error_is_durable_and_nonterminal() {
        for (message, expected) in [
            (
                "MCP connection failed: café endpoint refused",
                "[error] MCP connection failed: café endpoint refused",
            ),
            (
                "MCP failed:\u{1b}[2J\n\u{202e}endpoint",
                r"[error] MCP failed:\u{1b}[2J\n\u{202e}endpoint",
            ),
        ] {
            let mut state = UiState::new(500);
            state.set_activity(Activity::Waiting);
            assert!(state.apply_notification(&Notification::McpConnectionError {
                message: message.into(),
            }));
            assert_eq!(state.activity(), Activity::Waiting);
            assert!(state.last_turn().is_none());
            assert!(!state.has_modal_overlay());
            assert!(
                state.apply_notification(&Notification::McpServerInitialized {
                    server_name: "subsequent-status".into(),
                })
            );
            assert_eq!(state.activity(), Activity::Waiting);
            assert!(state.apply_notification(&Notification::SessionCreated {
                session_id: SessionId::new("new-session"),
                current_mode: None,
                current_model: None,
                available_modes: Vec::new(),
                available_models: Vec::new(),
            }));
            assert!(matches!(
                state.messages()[0].kind(),
                ChatMessageKind::System(text) if text == expected
            ));
            assert_eq!(state.messages().len(), 3);
            assert!(!state.has_modal_overlay());
        }
    }

    #[test]
    fn agent_not_found_with_fallback() {
        let mut state = UiState::new(500);
        let changed = state.apply_notification(&Notification::AgentNotFound {
            requested: "code-reviewer".into(),
            fallback: Some("default".into()),
        });
        assert!(changed);
        assert!(
            matches!(state.messages().last().unwrap().kind(), ChatMessageKind::System(t) if t.contains("code-reviewer") && t.contains("default"))
        );
    }

    #[test]
    fn agent_not_found_without_fallback() {
        let mut state = UiState::new(500);
        let changed = state.apply_notification(&Notification::AgentNotFound {
            requested: "code-reviewer".into(),
            fallback: None,
        });
        assert!(changed);
        assert!(
            matches!(state.messages().last().unwrap().kind(), ChatMessageKind::System(t) if t.contains("code-reviewer") && t.contains("not found"))
        );
    }

    #[test]
    fn agent_config_error_adds_system_message() {
        let mut state = UiState::new(500);
        let changed = state.apply_notification(&Notification::AgentConfigError {
            path: ".kiro/agents/broken.md".into(),
            error: "invalid YAML".into(),
        });
        assert!(changed);
        assert!(
            matches!(state.messages().last().unwrap().kind(), ChatMessageKind::System(t) if t.contains("broken.md") && t.contains("invalid YAML"))
        );
    }

    #[test]
    fn model_not_found_with_fallback() {
        let mut state = UiState::new(500);
        let changed = state.apply_notification(&Notification::ModelNotFound {
            requested: "claude-opus-5".into(),
            fallback: Some("claude-sonnet-4".into()),
        });
        assert!(changed);
        assert!(
            matches!(state.messages().last().unwrap().kind(), ChatMessageKind::System(t) if t.contains("claude-opus-5") && t.contains("claude-sonnet-4"))
        );
    }

    #[test]
    fn model_not_found_without_fallback() {
        let mut state = UiState::new(500);
        let changed = state.apply_notification(&Notification::ModelNotFound {
            requested: "claude-opus-5".into(),
            fallback: None,
        });
        assert!(changed);
        assert!(
            matches!(state.messages().last().unwrap().kind(), ChatMessageKind::System(t) if t.contains("claude-opus-5") && t.contains("not available"))
        );
    }

    #[test]
    fn tool_call_chunk_sets_tool_running() {
        // Subagent routing is now at the App layer via RoutedNotification —
        // UiState only sees chunks for the main session, and always sets activity.
        let mut state = UiState::new(500);
        let changed = state.apply_notification(&Notification::ToolCallChunk {
            tool_call_id: ToolCallId::new("tc-1"),
            title: "read".into(),
            kind: "read".into(),
            session_id: None,
        });
        assert!(changed);
        assert_eq!(state.activity(), Activity::ToolRunning);
    }

    #[test]
    fn subagent_spawned_adds_system_message() {
        let mut state = UiState::new(500);
        let changed = state.apply_notification(&Notification::SubagentSpawned {
            session_id: SessionId::new("sub-1"),
            name: "reviewer".into(),
        });
        assert!(changed);
        assert!(
            matches!(state.messages().last().unwrap().kind(), ChatMessageKind::System(t) if t.contains("reviewer") && t.contains("sub-1"))
        );
    }

    #[test]
    fn subagent_terminated_adds_system_message_with_name_if_tracked() {
        let mut state = UiState::new(500);
        // Register the subagent first so state can look up the name
        register_subagent(&mut state, "sub-1", "reviewer");

        let changed = state.apply_notification(&Notification::SubagentTerminated {
            session_id: SessionId::new("sub-1"),
        });
        assert!(changed);
        assert!(
            matches!(state.messages().last().unwrap().kind(), ChatMessageKind::System(t) if t.contains("reviewer") && t.contains("sub-1"))
        );
    }

    #[test]
    fn subagent_terminated_adds_system_message_without_name_if_not_tracked() {
        let mut state = UiState::new(500);
        let changed = state.apply_notification(&Notification::SubagentTerminated {
            session_id: SessionId::new("ghost"),
        });
        assert!(changed);
        // Message should still include the session id even if name can't be resolved
        assert!(
            matches!(state.messages().last().unwrap().kind(), ChatMessageKind::System(t) if t.contains("ghost") && t.contains("Terminated"))
        );
    }

    #[test]
    fn bridge_error_adds_system_message() {
        let mut state = UiState::new(500);
        let changed = state.apply_notification(&Notification::BridgeError {
            operation: "set_mode".into(),
            message: "connection refused".into(),
        });
        assert!(changed);
        assert!(
            matches!(state.messages().last().unwrap().kind(), ChatMessageKind::System(t) if t.contains("set_mode") && t.contains("connection refused"))
        );
    }

    /// cyril-k3lz C10a / spec B2: a v2 thinking ack adds exactly one message
    /// with the fenced text; the v2 failure path is the generic BridgeError
    /// message, which the operation label renders as "Thinking change failed".
    #[test]
    fn thinking_toggled_message() {
        let mut state = UiState::new(500);
        for (enabled, want) in [
            (true, "Thinking turned on."),
            (false, "Thinking turned off."),
        ] {
            let before = state.messages().len();
            assert!(state.apply_notification(&Notification::ThinkingToggled { enabled }));
            assert_eq!(state.messages().len(), before + 1, "one message per ack");
            assert!(
                matches!(state.messages().last().unwrap().kind(), ChatMessageKind::System(t) if t == want),
                "ack enabled={enabled} must read {want:?}"
            );
        }
        state.apply_notification(&Notification::BridgeError {
            operation: "Thinking change".into(),
            message: "nope".into(),
        });
        assert!(
            matches!(state.messages().last().unwrap().kind(), ChatMessageKind::System(t) if t == "Thinking change failed: nope"),
            "spec B2 failure text"
        );
    }

    /// cyril-k3lz review findings 2 + 4: the mediator's session-start order
    /// (`SessionCreated`, then the response's config snapshot) keeps the
    /// snapshot's thinking state AND model — a KAS `session/new|load` result
    /// has no `models` key, so `SessionCreated.current_model` is None and the
    /// snapshot is the only model report. Oracle: the captured `cfg_model` set
    /// (claude-sonnet-4.6, thinking on).
    #[test]
    fn session_start_order_keeps_snapshot_thinking_and_model() {
        let (_, kas) = cyril_core::test_support::thinking_capture_sequences();
        let options = kas
            .iter()
            .find_map(|(step, n)| match n {
                Notification::ConfigOptionSet { options, .. } if step == "cfg_model" => {
                    Some(options.clone())
                }
                _ => None,
            })
            .expect("captured cfg_model step");
        let mut state = UiState::new(500);
        state.apply_notification(&Notification::SessionCreated {
            session_id: SessionId::new("sess_loaded"),
            current_mode: None,
            current_model: None,
            available_modes: vec![],
            available_models: vec![],
        });
        state.apply_notification(&Notification::ConfigOptionsUpdated(options));
        assert_eq!(
            state.thinking_enabled(),
            Some(true),
            "snapshot thinking kept"
        );
        assert_eq!(
            state.current_model(),
            Some("claude-sonnet-4.6"),
            "snapshot model kept"
        );
    }

    /// cyril-k3lz C3a (UI half): the UI state machine follows the same
    /// captured sequences as `SessionController` (oracle: the capture lines
    /// read by hand — same table as the core fence), frame by frame.
    #[test]
    fn thinking_follows_captured_sequences() {
        let (v2, kas) = cyril_core::test_support::thinking_capture_sequences();
        let v2_expected = [
            (7, None),
            (8, None),
            (24, Some(true)),
            (26, Some(true)),
            (28, Some(true)),
            (30, Some(false)),
        ];
        assert_eq!(v2.len(), v2_expected.len(), "v2 frame count");
        let mut state = UiState::new(500);
        for ((line, n), (want_line, want)) in v2.iter().zip(v2_expected) {
            assert_eq!(*line, want_line, "v2 frame order");
            state.apply_notification(n);
            assert_eq!(state.thinking_enabled(), want, "v2 capture line {line}");
        }
        let kas_expected = [
            ("session_new", None),
            ("cfg_model", Some(true)),
            ("cfg_effort_max", Some(true)),
            ("cfg_thinking_off", Some(false)),
            ("cfg_effort_max2", Some(true)),
            ("cfg_thinking_bogus", Some(false)),
            ("cfg_model_gpt", None),
        ];
        assert_eq!(kas.len(), kas_expected.len(), "KAS step count");
        let mut state = UiState::new(500);
        // Production order (publish_session_start): the SessionCreated reset
        // precedes the session/new snapshot (review finding 2).
        state.apply_notification(&Notification::SessionCreated {
            session_id: SessionId::new("sess_kas"),
            current_mode: None,
            current_model: None,
            available_modes: vec![],
            available_models: vec![],
        });
        for ((step, n), (want_step, want)) in kas.iter().zip(kas_expected) {
            assert_eq!(step, want_step, "KAS step order");
            state.apply_notification(n);
            assert_eq!(state.thinking_enabled(), want, "KAS step {step}");
        }
    }

    /// cyril-k3lz C10b / spec B3: a KAS `ConfigOptionSet{config_id:"thinking"}`
    /// adds exactly one message read from the REBUILT set; a set of another
    /// option adds none.
    #[test]
    fn thinking_config_ack_messages() {
        let thinking = |value: Option<&str>| {
            value
                .map(|v| ConfigOption {
                    key: "thinking".into(),
                    label: "Thinking".into(),
                    value: Some(v.into()),
                    options: vec![
                        ConfigOptionValue::new("on", "on"),
                        ConfigOptionValue::new("off", "off"),
                    ],
                })
                .into_iter()
                .collect::<Vec<_>>()
        };
        let cases: [(&str, Vec<ConfigOption>, Option<&str>); 4] = [
            (
                "thinking",
                thinking(Some("off")),
                Some("Thinking turned off."),
            ),
            (
                "thinking",
                thinking(Some("on")),
                Some("Thinking turned on."),
            ),
            (
                "thinking",
                thinking(None),
                Some("Thinking can't be toggled on the current model."),
            ),
            ("model", thinking(Some("off")), None),
        ];
        for (config_id, options, want) in cases {
            let mut state = UiState::new(500);
            let before = state.messages().len();
            state.apply_notification(&Notification::ConfigOptionSet {
                config_id: config_id.into(),
                options,
            });
            match want {
                Some(text) => {
                    assert_eq!(
                        state.messages().len(),
                        before + 1,
                        "{config_id} ack adds one message"
                    );
                    assert!(
                        matches!(state.messages().last().unwrap().kind(), ChatMessageKind::System(t) if t == text),
                        "{config_id} ack must read {text:?}"
                    );
                }
                None => assert_eq!(
                    state.messages().len(),
                    before,
                    "a `{config_id}` set adds no thinking message"
                ),
            }
        }
    }

    // ── KAS config feed: mode/effort chips, read-back acks, config picker ─
    // cyril-vh69 C9/C10 (+ the PickerKind::Config plumbing). Oracle: the
    // design's feed rules (effort clears on a real model switch and
    // repopulates only from an effortLevel currentValue; every shown value
    // is the wire's RETURNED currentValue).

    /// A KAS catalog notification: model `model`, optional effortLevel
    /// current value, mode `vibe`. Mirrors the frame-24 shape — a model
    /// with effort support carries a separate `effortLevel` select whose
    /// `currentValue` is the only effort source.
    fn kas_catalog(model: &str, effort: Option<&str>) -> Notification {
        let option = |key: &str, value: Option<&str>| ConfigOption {
            key: key.into(),
            label: key.into(),
            value: value.map(str::to_string),
            options: vec![],
        };
        Notification::ConfigOptionsUpdated(vec![
            option("mode", Some("vibe")),
            option("model", Some(model)),
            option("effortLevel", effort),
        ])
    }

    /// cyril-vh69 C9: effort never crosses a model switch; repopulation
    /// comes only from an `effortLevel` currentValue, in the same frame or a
    /// later one.
    #[test]
    fn kas_effort_rederives_across_model_switches() {
        // auto → claude: effort stays None until the effortLevel
        // currentValue arrives.
        let mut state = UiState::new(500);
        state.apply_notification(&kas_catalog("auto", None));
        assert_eq!(state.current_model(), Some("auto"));
        assert_eq!(state.effort(), None, "auto has no effort");

        state.apply_notification(&kas_catalog("claude-sonnet-5.5", None));
        assert_eq!(state.current_model(), Some("claude-sonnet-5.5"));
        assert_eq!(
            state.effort(),
            None,
            "a model switch without an effortLevel value leaves effort cleared"
        );

        // A later frame carrying the level repopulates.
        state.apply_notification(&kas_catalog("claude-sonnet-5.5", Some("high")));
        assert_eq!(state.effort(), Some(&EffortLevel::High));

        // claude → claude: the old level clears even though both models
        // support effort — until the new model's level arrives.
        state.apply_notification(&kas_catalog("claude-opus-5.5", None));
        assert_eq!(
            state.effort(),
            None,
            "claude→claude clears the old level (cyril-838u)"
        );
        state.apply_notification(&kas_catalog("claude-opus-5.5", Some("medium")));
        assert_eq!(state.effort(), Some(&EffortLevel::Medium));

        // claude → auto: cleared, and no repopulation follows.
        state.apply_notification(&kas_catalog("auto", None));
        assert_eq!(state.effort(), None, "claude→auto clears effort");
        state.apply_notification(&kas_catalog("auto", None));
        assert_eq!(state.effort(), None, "auto never repopulates effort");
    }

    /// cyril-vh69 C9: a backend-defined level survives as
    /// `EffortLevel::Other`, rendered verbatim in the toolbar.
    #[test]
    fn kas_unknown_effort_level_renders_verbatim() {
        let mut state = UiState::new(500);
        state.apply_notification(&kas_catalog("gpt-5.6-sol", Some("turbo")));
        assert_eq!(
            state.effort(),
            Some(&EffortLevel::Other("turbo".to_string())),
            "unknown levels are preserved, never dropped"
        );
    }

    /// cyril-vh69 C11 (feed half): the catalog's `mode.currentValue` drives
    /// the mode chip — KAS emits no current_mode_update.
    #[test]
    fn kas_mode_chip_follows_the_catalog() {
        let mut state = UiState::new(500);
        assert_eq!(state.current_mode(), None);
        state.apply_notification(&kas_catalog("auto", None));
        assert_eq!(state.current_mode(), Some("vibe"));

        // A set ack for mode rewrites the chip from the RETURNED value.
        state.apply_notification(&Notification::ConfigOptionSet {
            config_id: "mode".into(),
            options: vec![
                ConfigOption {
                    key: "mode".into(),
                    label: "Mode".into(),
                    value: Some("spec".into()),
                    options: vec![],
                },
                ConfigOption {
                    key: "model".into(),
                    label: "Model".into(),
                    value: Some("auto".into()),
                    options: vec![],
                },
            ],
        });
        assert_eq!(state.current_mode(), Some("spec"));
    }

    /// cyril-vh69 C10: ConfigOptionSet posts `Model/Mode/Effort set to
    /// <currentValue>` from the RETURNED catalog — including the bogus-
    /// effort shape (SUCCESS with an unchanged currentValue), which must
    /// show the unchanged value rather than the requested one.
    #[test]
    fn kas_config_set_confirmations_read_the_returned_value() {
        let catalog_with = |key: &str, value: &str| {
            vec![ConfigOption {
                key: key.into(),
                label: key.into(),
                value: Some(value.into()),
                options: vec![],
            }]
        };
        let cases = [
            (
                "model",
                "claude-sonnet-5.5",
                "Model set to claude-sonnet-5.5.",
            ),
            ("mode", "spec", "Mode set to spec."),
            ("effortLevel", "high", "Effort set to high."),
        ];
        for (config_id, returned, want) in cases {
            let mut state = UiState::new(500);
            let before = state.messages().len();
            state.apply_notification(&Notification::ConfigOptionSet {
                config_id: config_id.into(),
                options: catalog_with(config_id, returned),
            });
            assert_eq!(state.messages().len(), before + 1, "{config_id} acks once");
            assert!(
                matches!(state.messages().last().unwrap().kind(), ChatMessageKind::System(t) if t == want),
                "{config_id} ack must read {want:?}"
            );
        }

        // The bogus-effort replay (0.66.34 shape): requested "none", the
        // ack SUCCEEDS with currentValue still "medium" — chip and message
        // both show medium, and the requested value appears nowhere.
        let mut state = UiState::new(500);
        state.apply_notification(&kas_catalog("claude-opus-5.5", Some("medium")));
        state.apply_notification(&Notification::ConfigOptionSet {
            config_id: "effortLevel".into(),
            options: vec![
                ConfigOption {
                    key: "model".into(),
                    label: "Model".into(),
                    value: Some("claude-opus-5.5".into()),
                    options: vec![],
                },
                ConfigOption {
                    key: "effortLevel".into(),
                    label: "Effort".into(),
                    value: Some("medium".into()),
                    options: vec![],
                },
            ],
        });
        assert_eq!(
            state.effort(),
            Some(&EffortLevel::Medium),
            "the chip shows the RETURNED value, never the requested one"
        );
        assert!(
            matches!(state.messages().last().unwrap().kind(), ChatMessageKind::System(t) if t == "Effort set to medium."),
            "the message shows the unchanged currentValue"
        );
    }

    /// cyril-vh69 (picker plumbing): a config picker honors `is_current`
    /// exactly as sent — no `active_option_value` join — and confirm returns
    /// the kind (carrying the target) the App dispatches on.
    #[test]
    fn config_picker_honors_sent_current_and_confirms_with_its_target() {
        let mut state = UiState::new(500);
        // cyril believes the current model is auto; the picker rows say
        // otherwise and must win (the snapshot is fresher than the join).
        state.set_current_model(Some("auto".to_string()));
        state.show_config_picker(ConfigPicker::new(
            ConfigTarget::Model,
            vec![
                CommandOption {
                    label: "Auto".into(),
                    value: "auto".into(),
                    description: None,
                    group: None,
                    is_current: false,
                },
                CommandOption {
                    label: "Claude Sonnet 5.5".into(),
                    value: "claude-sonnet-5.5".into(),
                    description: Some("Balanced".into()),
                    group: None,
                    is_current: true,
                },
            ],
        ));
        let picker = state.picker().expect("config picker open");
        assert_eq!(picker.kind, PickerKind::Config(ConfigTarget::Model));
        assert_eq!(picker.title, "model", "the title is the setting's noun");
        assert!(
            !picker.options[0].is_current && picker.options[1].is_current,
            "is_current honored as sent — no active_option_value join"
        );
        assert_eq!(
            picker.selected, 1,
            "the picker opens on the is_current row (F5)"
        );

        // Confirm the preselected current row directly — no navigation.
        let confirmation = state.picker_confirm().expect("a selection");
        assert_eq!(confirmation.kind, PickerKind::Config(ConfigTarget::Model));
        assert_eq!(confirmation.title, "model");
        assert_eq!(confirmation.value, "claude-sonnet-5.5");
        assert!(state.picker().is_none(), "confirm closes the picker");
    }

    /// F5: with no `is_current` row the picker falls back to row 0.
    #[test]
    fn config_picker_without_a_current_row_starts_at_row_zero() {
        let mut state = UiState::new(500);
        state.show_config_picker(ConfigPicker::new(
            ConfigTarget::Mode,
            vec![
                CommandOption {
                    label: "Default".into(),
                    value: "vibe".into(),
                    description: None,
                    group: None,
                    is_current: false,
                },
                CommandOption {
                    label: "Spec".into(),
                    value: "spec".into(),
                    description: None,
                    group: None,
                    is_current: false,
                },
            ],
        ));
        assert_eq!(
            state.picker().expect("config picker open").selected,
            0,
            "no is_current row → the first row"
        );
    }

    /// The v2 agent path is unchanged: confirm returns kind Agent, and the
    /// active_option_value join still marks cyril's own current value.
    #[test]
    fn agent_picker_confirm_stays_v2_shaped() {
        let mut state = UiState::new(500);
        state.set_current_model(Some("sonnet".to_string()));
        state.show_picker(
            "model".into(),
            vec![
                CommandOption {
                    label: "auto".into(),
                    value: "auto".into(),
                    description: None,
                    group: None,
                    is_current: false,
                },
                CommandOption {
                    label: "sonnet".into(),
                    value: "sonnet".into(),
                    description: None,
                    group: None,
                    is_current: false,
                },
            ],
        );
        let picker = state.picker().expect("agent picker open");
        assert_eq!(picker.kind, PickerKind::Agent);
        assert!(
            picker.options[1].is_current,
            "the v2 join still marks cyril's current model"
        );
        let confirmation = state.picker_confirm().expect("a selection");
        assert_eq!(confirmation.kind, PickerKind::Agent);
        assert_eq!(confirmation.title, "model");
    }

    // ── Subagent routing tests ───────────────────────────────────────────
    // These verify the routing contract that App::handle_notification depends
    // on: session-scoped notifications must flow to SubagentUiState, not the
    // main UiState; list updates must reach both tracker and stream cleanup.

    fn register_subagent(state: &mut UiState, id: &str, name: &str) {
        let info = cyril_core::types::SubagentInfo::new(
            SessionId::new(id),
            name,
            name,
            "query",
            cyril_core::types::SubagentStatus::Working {
                message: Some("Running".into()),
            },
        )
        .with_group(Some("crew-test".into()));
        let notif = Notification::SubagentListUpdated {
            subagents: vec![info],
            pending_stages: vec![],
        };
        state.apply_subagent_tracker_notification(&notif);
        if let Notification::SubagentListUpdated { subagents, .. } = &notif {
            state.apply_subagent_list_update(subagents);
        }
    }

    #[test]
    fn subagent_notification_routes_to_subagent_stream_not_main() {
        let mut state = UiState::new(500);
        register_subagent(&mut state, "sub-1", "reviewer");

        let sid = SessionId::new("sub-1");
        assert!(state.subagent_tracker().is_subagent(&sid));

        // Send an AgentMessage scoped to the subagent
        state.apply_subagent_notification(
            &sid,
            &Notification::AgentMessage(AgentMessage {
                text: "subagent text".into(),
                is_streaming: false,
            }),
        );

        // Main messages should be empty
        assert!(state.messages().is_empty());

        // Subagent stream should have the message
        let stream = state
            .subagent_ui()
            .streams()
            .get(&sid)
            .expect("stream should exist");
        assert_eq!(stream.messages().len(), 1);
    }

    #[test]
    fn subagent_list_update_marks_removed_streams_terminated() {
        let mut state = UiState::new(500);
        register_subagent(&mut state, "sub-1", "reviewer");

        // Stream for sub-1 exists and is working
        let sid = SessionId::new("sub-1");
        state.apply_subagent_notification(
            &sid,
            &Notification::AgentMessage(AgentMessage {
                text: "working".into(),
                is_streaming: true,
            }),
        );
        assert!(state.any_subagent_active());

        // List update removes sub-1
        let changed = state.apply_subagent_list_update(&[]);
        assert!(changed);
        // Stream still exists (preserved for history)
        assert!(state.subagent_ui().streams().contains_key(&sid));
        // But is no longer active
        assert!(!state.any_subagent_active());
    }

    #[test]
    fn subagent_list_update_no_op_returns_false() {
        let mut state = UiState::new(500);
        // No streams registered, list update is a no-op
        let changed = state.apply_subagent_list_update(&[]);
        assert!(!changed);
    }

    // ── cyril-jxfu C5/C7 substrate at the UiState seam ───────────────────────

    #[test]
    fn claim_stream_for_workflow_moves_history_and_unfocuses() {
        let mut state = UiState::new(500);
        let sid = SessionId::new("step-1");
        state.apply_subagent_notification(
            &sid,
            &Notification::AgentMessage(AgentMessage {
                text: "optimistic".into(),
                is_streaming: false,
            }),
        );
        assert!(state.focus_subagent(sid.clone()));

        assert!(state.claim_stream_for_workflow(&sid));
        assert!(
            !state.subagent_ui().streams().contains_key(&sid),
            "the claimed stream must leave the subagent domain"
        );
        assert!(
            state.subagent_ui().focused_session_id().is_none(),
            "drill-in focus on the claimed stream must clear"
        );
        assert_eq!(
            state.workflow_streams()[&sid].messages().len(),
            1,
            "adopted history must survive the move"
        );

        // A later frame lands in the workflow stream, not a re-created
        // subagent stream.
        state.apply_workflow_notification(
            &sid,
            &Notification::AgentMessage(AgentMessage {
                text: "post-claim".into(),
                is_streaming: false,
            }),
        );
        assert_eq!(state.workflow_streams()[&sid].messages().len(), 2);
        assert!(!state.subagent_ui().streams().contains_key(&sid));
    }

    #[test]
    fn claim_stream_for_workflow_without_stream_is_false() {
        let mut state = UiState::new(500);
        assert!(!state.claim_stream_for_workflow(&SessionId::new("never-seen")));
        assert!(state.workflow_streams().is_empty());
    }

    #[test]
    fn any_workflow_active_follows_stream_activity() {
        let mut state = UiState::new(500);
        let sid = SessionId::new("step-1");
        state.apply_workflow_notification(
            &sid,
            &Notification::AgentMessage(AgentMessage {
                text: "busy".into(),
                is_streaming: true,
            }),
        );
        assert!(state.any_workflow_active());
        assert!(
            !state.any_subagent_active(),
            "workflow activity must not masquerade as subagent activity"
        );
        state.apply_workflow_notification(
            &sid,
            &Notification::AgentMessage(AgentMessage {
                text: " done".into(),
                is_streaming: false,
            }),
        );
        assert!(!state.any_workflow_active());
    }

    #[test]
    fn focus_subagent_requires_existing_stream() {
        let mut state = UiState::new(500);
        let sid = SessionId::new("ghost");
        // Focus without a stream should fail
        assert!(!state.focus_subagent(sid.clone()));
        assert!(state.subagent_ui().focused_session_id().is_none());

        // After registering + notifying, focus should succeed
        register_subagent(&mut state, "sub-1", "reviewer");
        let sid = SessionId::new("sub-1");
        state.apply_subagent_notification(
            &sid,
            &Notification::AgentMessage(AgentMessage {
                text: "hi".into(),
                is_streaming: false,
            }),
        );
        assert!(state.focus_subagent(sid.clone()));
        assert_eq!(state.subagent_ui().focused_session_id(), Some(&sid));
    }

    #[test]
    fn unfocus_subagent_clears_focus() {
        let mut state = UiState::new(500);
        register_subagent(&mut state, "sub-1", "reviewer");
        let sid = SessionId::new("sub-1");
        state.apply_subagent_notification(
            &sid,
            &Notification::AgentMessage(AgentMessage {
                text: "hi".into(),
                is_streaming: false,
            }),
        );
        assert!(state.focus_subagent(sid));
        state.unfocus_subagent();
        assert!(state.subagent_ui().focused_session_id().is_none());
    }

    // --- Hooks panel tests ---

    fn sample_hook(trigger: &str, command: &str, matcher: Option<&str>) -> HookInfo {
        HookInfo::v2(trigger, command, matcher.map(String::from))
    }

    #[test]
    fn code_panel_lifecycle() {
        use cyril_core::types::{CodePanelData, LspStatus};

        let mut state = UiState::new(500);
        assert!(state.code_panel().is_none());
        assert!(!state.has_code_panel());

        let data = CodePanelData {
            status: LspStatus::Initialized,
            message: Some("LSP servers ready".into()),
            warning: None,
            root_path: Some("/home/user/project".into()),
            detected_languages: vec!["rust".into()],
            project_markers: vec!["Cargo.toml".into()],
            config_path: Some(".kiro/settings/lsp.json".into()),
            doc_url: None,
            lsps: vec![],
        };

        state.show_code_panel(data);
        assert!(state.has_code_panel());
        assert!(state.code_panel().is_some());

        state.close_code_panel();
        assert!(!state.has_code_panel());
    }

    #[test]
    fn code_intelligence_active_defaults_false() {
        let state = UiState::new(500);
        assert!(!state.code_intelligence_active());
    }

    #[test]
    fn set_code_intelligence_active() {
        let mut state = UiState::new(500);
        state.set_code_intelligence_active(true);
        assert!(state.code_intelligence_active());
    }

    // cyril-gk17: didChange arrives unprompted on ANY hook-file edit, so the
    // refresh must never open the overlay by itself — a modal appearing over
    // the user's input is worse than a stale panel.
    #[test]
    fn refresh_is_inert_while_the_panel_is_closed() {
        let mut state = UiState::new(10);
        let changed = state.refresh_hooks_panel(&[HookInfo::v2("PreToolUse", "echo", None)]);
        assert!(!changed, "a closed panel reports no change");
        assert!(!state.has_hooks_panel(), "and must stay closed");
    }

    #[test]
    fn refresh_replaces_contents_and_clamps_scroll() {
        let hooks = |n: usize| -> Vec<HookInfo> {
            (0..n)
                .map(|i| HookInfo {
                    // Reverse-ordered names so the panel's own (trigger,
                    // command) sort is exercised rather than input order.
                    trigger: format!("T{:02}", n - i),
                    command: "echo".into(),
                    matcher: None,
                    id: None,
                    name: None,
                    enabled: None,
                })
                .collect()
        };
        let mut state = UiState::new(10);
        state.show_hooks_panel(hooks(10));
        state.hooks_panel_scroll_down(7);
        assert_eq!(state.hooks_panel().map(|p| p.scroll_offset), Some(7));

        // Shrinking the registry must not strand the viewport past the end.
        assert!(state.refresh_hooks_panel(&hooks(3)));
        let panel = state.hooks_panel().expect("still open");
        assert_eq!(panel.hooks.len(), 3, "contents are replaced, not merged");
        assert_eq!(panel.scroll_offset, 2, "scroll clamps to the new last row");

        // A same-size refresh that DOES change a row (`enabled` flipped) must
        // NOT yank the user back to the top.
        let mut flipped = hooks(3);
        flipped[0].enabled = Some(true);
        assert!(state.refresh_hooks_panel(&flipped));
        assert_eq!(
            state.hooks_panel().map(|p| p.scroll_offset),
            Some(2),
            "an in-place refresh preserves the viewport"
        );

        // …while an identical push repaints nothing. The registry is replaced
        // wholesale on every hook-file edit, so most pushes carry exactly the
        // rows already on screen (review finding 19).
        assert!(
            !state.refresh_hooks_panel(&flipped),
            "an identical registry is not a change"
        );
        assert_eq!(
            state.hooks_panel().map(|p| p.scroll_offset),
            Some(2),
            "…and leaves the viewport alone"
        );
    }

    /// REGRESSION FENCE (cyril-v19o C5, ordering half — the command and push
    /// halves land with slice 3). Order is display order: title, ASCII-folded,
    /// identifier as tie-break; duplicates are never collapsed, an identical
    /// push is not a repaint, and the scroll clamp is window-aware
    /// (review findings 8, 14a, 19).
    #[test]
    fn powers_panel_orders_and_replaces() {
        fn power(name: &str, title: &str) -> PowerInfo {
            PowerInfo::new(name, Some(title.to_owned()), None, Vec::new(), false)
        }

        let mut state = UiState::new(500);
        assert!(!state.has_powers_panel(), "starts closed");

        // Deliberately unsorted, with a case difference that only an
        // ASCII-lowercased key orders correctly, and a duplicate title whose
        // ids arrive in the WRONG order. A stable sort without the identifier
        // tie-break would keep `datadog-copy` first, so the id assertion — not
        // the title one — is what the tie-break buys (review findings 14a, 16).
        state.show_powers_panel(vec![
            power("zeta", "zeta tool"),
            power("aws-infrastructure-as-code", "Build AWS"),
            power("datadog-copy", "Datadog Observability"),
            power("markdownlint", "markdownlint"),
            power("datadog", "Datadog Observability"),
        ]);
        let rows: Vec<(&str, &str)> = state
            .powers_panel()
            .expect("panel open")
            .powers
            .iter()
            .map(|power| (power.title(), power.name()))
            .collect();
        assert_eq!(
            rows,
            [
                ("Build AWS", "aws-infrastructure-as-code"),
                ("Datadog Observability", "datadog"),
                ("Datadog Observability", "datadog-copy"),
                ("markdownlint", "markdownlint"),
                ("zeta tool", "zeta"),
            ],
            "ASCII-lowercase by title; the duplicate title is ordered by id, not dropped"
        );

        // A refresh replaces the contents and reports the change…
        assert!(state.refresh_powers_panel(&[power("datadog", "Datadog Observability")]));
        assert_eq!(state.powers_panel().expect("open").powers.len(), 1);

        // …while an identical push afterwards repaints nothing (review 19).
        assert!(!state.refresh_powers_panel(&[power("datadog", "Datadog Observability")]));

        // The clamp is the last offset that still fills the window (review 8):
        // a catalog shorter than the window cannot scroll at all…
        state.show_powers_panel(vec![power("a", "A"), power("b", "B"), power("c", "C")]);
        state.powers_panel_scroll_down(2);
        assert_eq!(
            state.powers_panel().expect("open").scroll_offset,
            0,
            "three powers fit a five-power window; scrolling would paint blank \
             rows under a partial list"
        );

        // …and a longer one stops at the last full window rather than the last
        // index.
        let many: Vec<PowerInfo> = (0..9)
            .map(|n| power(&format!("p{n:02}"), &format!("P{n:02}")))
            .collect();
        state.show_powers_panel(many.clone());
        state.powers_panel_scroll_down(100);
        assert_eq!(
            state.powers_panel().expect("open").scroll_offset,
            9 - MAX_VISIBLE_POWERS,
            "the viewport stops at the last offset that fills the window"
        );

        // A refresh that shortens the catalog re-clamps into the NEW window
        // instead of stranding the viewport past its end.
        assert!(state.refresh_powers_panel(&many[..6]));
        assert_eq!(
            state.powers_panel().expect("open").scroll_offset,
            6 - MAX_VISIBLE_POWERS,
            "a shorter catalog pulls the viewport back into range"
        );

        // A closed panel is left closed by a push.
        state.hide_powers_panel();
        assert!(!state.refresh_powers_panel(&many));
        assert!(!state.has_powers_panel(), "a push never opens the panel");
    }

    /// REGRESSION FENCE (cyril-v19o, review findings 3 + 20): exactly one
    /// predicate answers "who owns the keyboard", and its order is the order
    /// `render` paints in reverse — the topmost overlay is the one painted
    /// last, so what the user sees on top is what reacts.
    ///
    /// The stack is a fixed priority, not recency: a LOWER layer opened last
    /// stays underneath. Recency is what let a push-driven panel cover an
    /// approval prompt while the prompt kept every key.
    #[test]
    fn topmost_overlay_orders_the_stack() {
        use crate::traits::Overlay;

        let mut state = UiState::new(500);
        assert_eq!(
            state.topmost_overlay(),
            None,
            "no overlay: the chat has input"
        );
        assert!(!state.has_modal_overlay());

        state.show_hooks_panel(vec![HookInfo::v2("PreToolUse", "echo", None)]);
        assert_eq!(state.topmost_overlay(), Some(Overlay::Hooks));
        assert!(state.has_modal_overlay());

        // Opened last, still underneath: the predicate reports the LAYER, not
        // the most recent open.
        state.show_usage_panel(cyril_core::types::UsageSnapshot::default());
        assert_eq!(
            state.topmost_overlay(),
            Some(Overlay::Hooks),
            "the stack is ordered by layer, not by who opened last"
        );

        // An interrupted permission request goes to the very top.
        let (request, _rx) = make_approval_request(vec![cyril_core::types::PermissionOption {
            id: cyril_core::types::PermissionOptionId::new("allow"),
            label: "Allow".into(),
            kind: cyril_core::types::PermissionOptionKind::AllowOnce,
            is_destructive: false,
        }]);
        state.show_approval(request);
        assert_eq!(state.topmost_overlay(), Some(Overlay::Approval));

        // The review form sits under a permission request: a review's own
        // workflow can ask for permission while the form is still open.
        state.show_review_form(crate::traits::ReviewForm::opening(
            cyril_core::review::target::ReviewTarget::Auto,
        ));
        assert_eq!(state.topmost_overlay(), Some(Overlay::Approval));

        // Closing the top layer hands the keyboard to the next one down, and
        // the last layer out clears the predicate entirely.
        state.approval_cancel();
        assert_eq!(state.topmost_overlay(), Some(Overlay::Review));
        state.close_review_form();
        assert_eq!(state.topmost_overlay(), Some(Overlay::Hooks));
        state.hide_hooks_panel();
        assert_eq!(state.topmost_overlay(), Some(Overlay::Usage));
        state.hide_usage_panel();
        assert_eq!(state.topmost_overlay(), None);
        assert!(!state.has_modal_overlay());

        // The enum IS the paint order, bottom-most first.
        assert_eq!(
            Overlay::ALL,
            [
                Overlay::Usage,
                Overlay::Code,
                Overlay::Powers,
                Overlay::Hooks,
                Overlay::Picker,
                Overlay::Review,
                Overlay::Approval,
            ]
        );
    }

    #[test]
    fn hooks_panel_starts_hidden() {
        let state = UiState::new(500);
        assert!(!state.has_hooks_panel());
        assert!(state.hooks_panel().is_none());
    }

    #[test]
    fn show_hooks_panel_sets_state() {
        let mut state = UiState::new(500);
        // Input order is (Pre, Post) but show_hooks_panel sorts by
        // (trigger, command), so the stored order is (Post, Pre).
        let hooks = vec![
            sample_hook("PreToolUse", "echo pre", Some("read")),
            sample_hook("PostToolUse", "echo post", None),
        ];
        state.show_hooks_panel(hooks);
        assert!(state.has_hooks_panel());
        let panel = state.hooks_panel().expect("panel should exist");
        assert_eq!(panel.hooks.len(), 2);
        assert_eq!(panel.hooks[0].trigger, "PostToolUse");
        assert_eq!(panel.hooks[0].matcher, None);
        assert_eq!(panel.hooks[1].trigger, "PreToolUse");
        assert_eq!(panel.hooks[1].matcher.as_deref(), Some("read"));
        assert_eq!(panel.scroll_offset, 0);
    }

    #[test]
    fn hide_hooks_panel_clears_state() {
        let mut state = UiState::new(500);
        state.show_hooks_panel(vec![sample_hook("Stop", "noop", None)]);
        assert!(state.has_hooks_panel());
        state.hide_hooks_panel();
        assert!(!state.has_hooks_panel());
    }

    #[test]
    fn show_hooks_panel_with_empty_list() {
        let mut state = UiState::new(500);
        state.show_hooks_panel(Vec::new());
        assert!(state.has_hooks_panel());
        assert_eq!(state.hooks_panel().expect("panel").hooks.len(), 0);
    }

    #[test]
    fn show_hooks_panel_sorts_on_insert_by_trigger() {
        // Unsorted input; expect sorted by trigger in the stored state so the
        // widget can iterate without re-sorting on every render frame.
        let mut state = UiState::new(500);
        state.show_hooks_panel(vec![
            sample_hook("Stop", "stop-cmd", None),
            sample_hook("AgentSpawn", "spawn-cmd", None),
            sample_hook("PreToolUse", "pre-cmd", Some("read")),
        ]);
        let triggers: Vec<&str> = state
            .hooks_panel()
            .expect("panel")
            .hooks
            .iter()
            .map(|h| h.trigger.as_str())
            .collect();
        assert_eq!(triggers, vec!["AgentSpawn", "PreToolUse", "Stop"]);
    }

    #[test]
    fn show_hooks_panel_sorts_by_command_within_trigger() {
        // Same trigger, different commands — expect alphabetical order by
        // command as the tiebreaker.
        let mut state = UiState::new(500);
        state.show_hooks_panel(vec![
            sample_hook("PreToolUse", "zebra", None),
            sample_hook("PreToolUse", "alpha", None),
            sample_hook("PreToolUse", "middle", None),
        ]);
        let commands: Vec<&str> = state
            .hooks_panel()
            .expect("panel")
            .hooks
            .iter()
            .map(|h| h.command.as_str())
            .collect();
        assert_eq!(commands, vec!["alpha", "middle", "zebra"]);
    }

    #[test]
    fn hooks_panel_scroll_down_respects_bound() {
        let mut state = UiState::new(500);
        let hooks = vec![
            sample_hook("A", "a", None),
            sample_hook("B", "b", None),
            sample_hook("C", "c", None),
        ];
        state.show_hooks_panel(hooks);
        state.hooks_panel_scroll_down(10); // way past the end
        // Max index is len-1 = 2
        assert_eq!(state.hooks_panel().expect("panel").scroll_offset, 2);
    }

    #[test]
    fn hooks_panel_scroll_up_saturates_at_zero() {
        let mut state = UiState::new(500);
        state.show_hooks_panel(vec![
            sample_hook("A", "a", None),
            sample_hook("B", "b", None),
        ]);
        state.hooks_panel_scroll_down(1);
        state.hooks_panel_scroll_up(5); // way past the start
        assert_eq!(state.hooks_panel().expect("panel").scroll_offset, 0);
    }

    #[test]
    fn hooks_panel_scroll_noop_when_hidden() {
        let mut state = UiState::new(500);
        // These should silently do nothing when there's no panel.
        state.hooks_panel_scroll_up(3);
        state.hooks_panel_scroll_down(3);
        assert!(!state.has_hooks_panel());
    }

    // --- Chat scroll tests ---

    #[test]
    fn chat_scroll_up_enters_browse_mode() {
        let mut state = UiState::new(500);
        assert!(state.chat_scroll_back().is_none());
        state.chat_scroll_up(5);
        assert_eq!(state.chat_scroll_back(), Some(5));
    }

    #[test]
    fn chat_scroll_up_accumulates() {
        let mut state = UiState::new(500);
        state.chat_scroll_up(5);
        state.chat_scroll_up(3);
        assert_eq!(state.chat_scroll_back(), Some(8));
    }

    #[test]
    fn chat_scroll_down_reduces_offset() {
        let mut state = UiState::new(500);
        state.chat_scroll_up(10);
        state.chat_scroll_down(3);
        assert_eq!(state.chat_scroll_back(), Some(7));
    }

    #[test]
    fn chat_scroll_down_returns_to_follow_mode() {
        let mut state = UiState::new(500);
        state.chat_scroll_up(3);
        state.chat_scroll_down(5);
        assert!(state.chat_scroll_back().is_none());
    }

    #[test]
    fn chat_scroll_down_noop_in_follow_mode() {
        let mut state = UiState::new(500);
        state.chat_scroll_down(5);
        assert!(state.chat_scroll_back().is_none());
    }

    #[test]
    fn chat_scroll_reset_returns_to_follow_mode() {
        let mut state = UiState::new(500);
        state.chat_scroll_up(10);
        state.chat_scroll_reset();
        assert!(state.chat_scroll_back().is_none());
    }

    #[test]
    fn take_input_resets_chat_scroll() {
        let mut state = UiState::new(500);
        state.chat_scroll_up(10);
        state.handle_input_key(crossterm::event::KeyEvent::from(
            crossterm::event::KeyCode::Char('h'),
        ));
        let _ = state.take_input();
        assert!(state.chat_scroll_back().is_none());
    }

    #[test]
    fn set_command_info_propagates_descriptions() {
        use crossterm::event::{KeyCode, KeyEvent};

        let mut state = UiState::new(500);
        state.set_command_info(vec![
            ("model".into(), Some("Switch model".into())),
            ("mode".into(), Some("Switch mode".into())),
            ("new".into(), None),
        ]);

        // Type "/" to trigger autocomplete for all commands
        state.handle_input_key(KeyEvent::from(KeyCode::Char('/')));
        let suggestions = state.autocomplete_suggestions();
        assert_eq!(suggestions.len(), 3);

        // Verify descriptions propagated correctly
        let model = suggestions.iter().find(|s| s.text == "/model").unwrap();
        assert_eq!(model.description.as_deref(), Some("Switch model"));

        let new = suggestions.iter().find(|s| s.text == "/new").unwrap();
        assert!(
            new.description.is_none(),
            "None description should stay None"
        );
    }

    // --- Activity timer tests ---

    #[test]
    fn set_activity_idle_to_busy_starts_timer() {
        let mut state = UiState::new(500);
        assert!(state.activity_elapsed().is_none());
        state.set_activity(Activity::Sending);
        assert!(state.activity_elapsed().is_some());
    }

    #[test]
    fn set_activity_busy_to_busy_preserves_timer() {
        let mut state = UiState::new(500);
        state.set_activity(Activity::Sending);
        let first_elapsed = state.activity_elapsed();
        assert!(first_elapsed.is_some());

        // Transition to another busy state — timer should NOT reset
        state.set_activity(Activity::ToolRunning);
        assert!(state.activity_elapsed().is_some());
        // Timer should still be running from the original start
        assert_eq!(state.activity(), Activity::ToolRunning);
    }

    #[test]
    fn set_activity_busy_to_idle_clears_timer() {
        let mut state = UiState::new(500);
        state.set_activity(Activity::Sending);
        assert!(state.activity_elapsed().is_some());

        state.set_activity(Activity::Ready);
        assert!(state.activity_elapsed().is_none());
    }

    #[test]
    fn set_activity_same_state_is_noop() {
        let mut state = UiState::new(500);
        state.set_activity(Activity::Sending);
        state.set_activity(Activity::Sending);
        // Should not panic or change behavior
        assert!(state.activity_elapsed().is_some());
    }

    #[test]
    fn effort_is_sticky_across_omitting_frames_and_resets_on_new_session() {
        let mut state = UiState::new(500);
        assert_eq!(state.effort(), None);

        // A thinking turn reports effort.
        state.apply_notification(&Notification::MetadataUpdated {
            refusal: None,
            context_usage: Some(ContextUsage::new(7.5)),
            metering: None,
            tokens: None,
            effort: EffortUpdate::Set(EffortLevel::High),
            duration_ms: None,
            reasoning: None,
            session_id: None,
        });
        assert_eq!(state.effort(), Some(&EffortLevel::High));

        // A context-only frame mid-turn omits effort — must NOT clear it.
        state.apply_notification(&Notification::MetadataUpdated {
            refusal: None,
            context_usage: Some(ContextUsage::new(8.0)),
            metering: None,
            tokens: None,
            effort: EffortUpdate::Unchanged,
            duration_ms: None,
            reasoning: None,
            session_id: None,
        });
        assert_eq!(
            state.effort(),
            Some(&EffortLevel::High),
            "omitted effort must be sticky"
        );

        // A new session resets effort (re-reported by the new session if any).
        state.apply_notification(&Notification::SessionCreated {
            session_id: SessionId::new("s2"),
            current_mode: None,
            current_model: None,
            available_modes: vec![],
            available_models: vec![],
        });
        assert_eq!(state.effort(), None, "new session clears stale effort");
    }

    #[test]
    fn explicit_effort_clear_drops_badge() {
        // tui.js checks `"effort" in e`: an explicit null is a badge-CLEAR
        // signal (cyril-1gim), distinct from an absent field — the engine can
        // turn the badge off mid-session and UiState must honor it.
        let mut state = UiState::new(500);
        state.apply_notification(&Notification::MetadataUpdated {
            refusal: None,
            context_usage: None,
            metering: None,
            tokens: None,
            duration_ms: None,
            effort: EffortUpdate::Set(EffortLevel::High),
            reasoning: None,
            session_id: None,
        });
        assert_eq!(state.effort(), Some(&EffortLevel::High));
        state.apply_notification(&Notification::MetadataUpdated {
            refusal: None,
            context_usage: None,
            metering: None,
            tokens: None,
            duration_ms: None,
            effort: EffortUpdate::Clear,
            reasoning: None,
            session_id: None,
        });
        assert_eq!(state.effort(), None, "explicit null must clear the badge");
    }

    #[test]
    fn unknown_effort_level_survives_to_ui() {
        // A backend-defined level (schema-negotiated per model, cyril-1gim)
        // must reach the toolbar instead of vanishing at the wire boundary.
        let mut state = UiState::new(500);
        state.apply_notification(&Notification::MetadataUpdated {
            refusal: None,
            context_usage: None,
            metering: None,
            tokens: None,
            duration_ms: None,
            effort: EffortUpdate::Set(EffortLevel::Other("turbo".into())),
            reasoning: None,
            session_id: None,
        });
        assert_eq!(state.effort(), Some(&EffortLevel::Other("turbo".into())));
    }

    #[test]
    fn advertised_none_effort_replaces_a_stale_level_instead_of_sticking() {
        // cyril-8yka. GPT-family models advertise "none" as a REAL level, not a
        // degenerate one: 2.16.0's KAS `config_option_update` ships
        // effortLevels ["none","low","medium","high","xhigh","max"] for the GPT
        // models, and the account default on session/new is GPT-family — so a
        // fresh session can sit on a ladder that includes it.
        //
        // The reported failure was a closed `EffortLevel` dropping "none" to
        // `None`, which the sticky rule then read as "this frame omitted
        // effort" and left the toolbar on the PREVIOUS level. `Other(String)`
        // plus the tri-state `EffortUpdate` (cyril-1gim) already close that;
        // this fence pins the behaviour so narrowing either one cannot silently
        // reopen it. It is the sentinel/absent conflation CLAUDE.md warns about
        // under "Use `Option` for absent values, not sentinels".
        assert_eq!(
            EffortLevel::from_wire("none"),
            Some(EffortLevel::Other("none".into())),
            "an advertised level must parse, not fall through to None"
        );

        let mut state = UiState::new(500);
        state.apply_notification(&Notification::MetadataUpdated {
            refusal: None,
            context_usage: None,
            metering: None,
            tokens: None,
            duration_ms: None,
            effort: EffortUpdate::Set(EffortLevel::High),
            reasoning: None,
            session_id: None,
        });
        assert_eq!(state.effort(), Some(&EffortLevel::High));

        // `/effort none` — the badge must FOLLOW, not keep reading "high".
        state.apply_notification(&Notification::MetadataUpdated {
            refusal: None,
            context_usage: None,
            metering: None,
            tokens: None,
            duration_ms: None,
            effort: EffortUpdate::Set(EffortLevel::Other("none".into())),
            reasoning: None,
            session_id: None,
        });
        assert_eq!(
            state.effort(),
            Some(&EffortLevel::Other("none".into())),
            "effort=none is a real level, not a no-update"
        );
    }

    #[test]
    fn duration_merge_is_order_independent() {
        // Credits frames and duration/effort-only frames interleave (real
        // 2.4.1 shape). When the credits frame lands AFTER the duration-only
        // frames, the merged duration must survive (cyril-1gim).
        let mut state = UiState::new(500);
        state.apply_notification(&Notification::MetadataUpdated {
            refusal: None,
            context_usage: None,
            metering: None,
            tokens: None,
            duration_ms: Some(2281),
            effort: EffortUpdate::Unchanged,
            reasoning: None,
            session_id: None,
        });
        state.apply_notification(&Notification::MetadataUpdated {
            refusal: None,
            context_usage: None,
            metering: Some(
                TurnMetering::try_from_credits(Some(0.018), None).expect("valid metering fixture"),
            ),
            tokens: None,
            duration_ms: None,
            effort: EffortUpdate::Unchanged,
            reasoning: None,
            session_id: None,
        });
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: StopReason::EndTurn,
        });
        let m = state
            .last_turn()
            .expect("TurnSummary after TurnCompleted")
            .metering()
            .expect("metering present");
        assert_eq!(m.credits(), Some(0.018));
        assert_eq!(
            m.duration_ms(),
            Some(2281),
            "earlier duration not clobbered"
        );
    }

    #[test]
    fn kas_turn_metering_reaches_ui_turn_summary() {
        let mut state = UiState::new(500);
        state.apply_notification(&Notification::TurnMeteringUpdated(TurnMeteringUpdate::new(
            vec![MeteredAmount::try_new(0.25, "credit", "credits").expect("valid credit")],
            Some(4442),
            Some(UsageTurnStatus::Success),
            vec!["read_file".to_owned()],
            Some(vec!["r1".to_owned(), "r2".to_owned()]),
        )));
        assert!(
            state.last_turn().is_none(),
            "metering does not finish the turn"
        );
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: StopReason::EndTurn,
        });
        let metering = state
            .last_turn()
            .and_then(TurnSummary::metering)
            .expect("metering joins completed turn");
        assert_eq!(metering.credits(), Some(0.25));
        assert_eq!(metering.duration_ms(), Some(4442));
    }

    #[test]
    fn metadata_without_context_retains_last_context() {
        // Replays the captured 2.4.1 wire shape: duration/effort-only frames
        // omit contextUsagePercentage. Such a frame must not stamp the
        // toolbar context to 0.0%, while its metering/effort still apply.
        let mut state = UiState::new(500);
        state.apply_notification(&Notification::MetadataUpdated {
            refusal: None,
            context_usage: Some(ContextUsage::new(42.0)),
            metering: None,
            tokens: None,
            effort: EffortUpdate::Unchanged,
            duration_ms: None,
            reasoning: None,
            session_id: None,
        });
        assert!((state.context_usage().unwrap_or(-1.0) - 42.0).abs() < f64::EPSILON);

        state.apply_notification(&Notification::MetadataUpdated {
            refusal: None,
            context_usage: None,
            metering: Some(
                TurnMetering::try_from_credits(Some(0.018), Some(2281))
                    .expect("valid metering fixture"),
            ),
            tokens: None,
            effort: EffortUpdate::Set(EffortLevel::High),
            duration_ms: None,
            reasoning: None,
            session_id: None,
        });
        assert!(
            (state.context_usage().unwrap_or(-1.0) - 42.0).abs() < f64::EPSILON,
            "context-less frame must retain the last context usage"
        );
        assert_eq!(
            state.effort(),
            Some(&EffortLevel::High),
            "effort from a context-less frame must still apply"
        );

        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });
        let summary = state.last_turn().expect("TurnSummary after TurnCompleted");
        let m = summary
            .metering()
            .expect("metering from a context-less frame must still apply");
        assert!((m.credits().unwrap() - 0.018).abs() < 0.001);
        assert_eq!(m.duration_ms(), Some(2281));
    }

    #[test]
    fn effort_clears_on_model_change_within_a_session() {
        let mut state = UiState::new(500);
        state.set_current_model(Some("opus".into()));
        state.apply_notification(&Notification::MetadataUpdated {
            refusal: None,
            context_usage: Some(ContextUsage::new(7.5)),
            metering: None,
            tokens: None,
            effort: EffortUpdate::Set(EffortLevel::High),
            duration_ms: None,
            reasoning: None,
            session_id: None,
        });
        assert_eq!(state.effort(), Some(&EffortLevel::High));

        // Switching to a non-thinking model (no new session) must clear effort,
        // otherwise the toolbar shows a phantom level the new model never reports.
        state.apply_notification(&Notification::ConfigOptionsUpdated(vec![ConfigOption {
            key: "model".into(),
            label: "Model".into(),
            value: Some("haiku".into()),
            options: vec![],
        }]));
        assert_eq!(state.effort(), None, "model change must clear stale effort");

        // Re-reporting the *same* model must not disturb a freshly-set level.
        state.apply_notification(&Notification::MetadataUpdated {
            refusal: None,
            context_usage: Some(ContextUsage::new(8.0)),
            metering: None,
            tokens: None,
            effort: EffortUpdate::Set(EffortLevel::Medium),
            duration_ms: None,
            reasoning: None,
            session_id: None,
        });
        state.set_current_model(Some("haiku".into()));
        assert_eq!(
            state.effort(),
            Some(&EffortLevel::Medium),
            "unchanged model must not clear effort"
        );
    }

    #[test]
    fn effort_clears_when_set_current_model_changes_model() {
        // The set_current_model path (Kiro's model-command workaround) must
        // clear effort on a real model change, mirroring the ConfigOptionsUpdated
        // path — otherwise switching models leaves a phantom toolbar level.
        let mut state = UiState::new(500);
        state.set_current_model(Some("opus".into()));
        state.apply_notification(&Notification::MetadataUpdated {
            refusal: None,
            context_usage: Some(ContextUsage::new(7.5)),
            metering: None,
            tokens: None,
            effort: EffortUpdate::Set(EffortLevel::High),
            duration_ms: None,
            reasoning: None,
            session_id: None,
        });
        assert_eq!(state.effort(), Some(&EffortLevel::High));

        state.set_current_model(Some("haiku".into()));
        assert_eq!(
            state.effort(),
            None,
            "set_current_model with a different model must clear effort"
        );
    }

    // --- TurnSummary buffer assembly tests ---

    #[test]
    fn ui_state_turn_summary_assembled_from_metadata_and_turn_completed() {
        let mut state = UiState::new(500);

        state.apply_notification(&Notification::MetadataUpdated {
            refusal: None,
            context_usage: Some(ContextUsage::new(50.0)),
            metering: Some(
                TurnMetering::try_from_credits(Some(0.03), Some(2000))
                    .expect("valid metering fixture"),
            ),
            tokens: Some(TokenCounts::new(800, 400, Some(100))),
            effort: EffortUpdate::Unchanged,
            duration_ms: None,
            reasoning: None,
            session_id: None,
        });
        assert!(
            state.last_turn().is_none(),
            "no TurnSummary until TurnCompleted"
        );

        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });
        let summary = state
            .last_turn()
            .expect("TurnSummary should exist after TurnCompleted");
        assert_eq!(
            summary.stop_reason(),
            cyril_core::types::StopReason::EndTurn
        );
        assert!(summary.token_counts().is_some());
        assert_eq!(summary.token_counts().unwrap().input(), 800);
        assert!(summary.metering().is_some());
        assert!((summary.metering().unwrap().credits().unwrap() - 0.03).abs() < 0.001);
    }

    #[test]
    fn ui_state_turn_summary_cleared_on_session_created() {
        let mut state = UiState::new(500);

        state.apply_notification(&Notification::MetadataUpdated {
            refusal: None,
            context_usage: Some(ContextUsage::new(10.0)),
            metering: Some(
                TurnMetering::try_from_credits(Some(0.01), None).expect("valid metering fixture"),
            ),
            tokens: None,
            effort: EffortUpdate::Unchanged,
            duration_ms: None,
            reasoning: None,
            session_id: None,
        });
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });
        assert!(state.last_turn().is_some());

        state.apply_notification(&Notification::SessionCreated {
            session_id: SessionId::new("s2"),
            current_mode: None,
            current_model: None,
            available_modes: Vec::new(),
            available_models: Vec::new(),
        });
        assert!(
            state.last_turn().is_none(),
            "TurnSummary should be cleared on new session"
        );
    }

    #[test]
    fn ui_state_session_cost_accumulates() {
        let mut state = UiState::new(500);

        // Turn 1
        state.apply_notification(&Notification::MetadataUpdated {
            refusal: None,
            context_usage: Some(ContextUsage::new(10.0)),
            metering: Some(
                TurnMetering::try_from_credits(Some(0.02), Some(1000))
                    .expect("valid metering fixture"),
            ),
            tokens: None,
            effort: EffortUpdate::Unchanged,
            duration_ms: None,
            reasoning: None,
            session_id: None,
        });
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });

        // Turn 2
        state.apply_notification(&Notification::MetadataUpdated {
            refusal: None,
            context_usage: Some(ContextUsage::new(20.0)),
            metering: Some(
                TurnMetering::try_from_credits(Some(0.03), Some(2000))
                    .expect("valid metering fixture"),
            ),
            tokens: None,
            effort: EffortUpdate::Unchanged,
            duration_ms: None,
            reasoning: None,
            session_id: None,
        });
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });

        assert_eq!(state.session_cost().turn_count(), 2);
        assert!((state.session_cost().total_credits() - 0.05).abs() < 0.001);
    }

    #[test]
    fn ui_state_session_cost_reset_on_session_created() {
        let mut state = UiState::new(500);

        state.apply_notification(&Notification::MetadataUpdated {
            refusal: None,
            context_usage: Some(ContextUsage::new(10.0)),
            metering: Some(
                TurnMetering::try_from_credits(Some(0.05), Some(2000))
                    .expect("valid metering fixture"),
            ),
            tokens: None,
            effort: EffortUpdate::Unchanged,
            duration_ms: None,
            reasoning: None,
            session_id: None,
        });
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });
        assert!(state.session_cost().total_credits() > 0.0);

        state.apply_notification(&Notification::SessionCreated {
            session_id: SessionId::new("s2"),
            current_mode: None,
            current_model: None,
            available_modes: Vec::new(),
            available_models: Vec::new(),
        });

        assert_eq!(state.session_cost().total_credits(), 0.0);
        assert_eq!(state.session_cost().turn_count(), 0);
    }

    #[test]
    fn ui_state_usage_updated_sets_context_usage() {
        let mut state = UiState::new(500);
        let changed = state.apply_notification(&Notification::UsageUpdated {
            used: 80_000,
            size: 200_000,
            cost: None,
        });
        assert!(changed);
        let pct = state.context_usage().unwrap_or(0.0);
        assert!((pct - 40.0).abs() < f64::EPSILON);
    }

    #[test]
    fn ui_state_usage_updated_clamps_over_100() {
        let mut state = UiState::new(500);
        state.apply_notification(&Notification::UsageUpdated {
            used: 250_000,
            size: 200_000,
            cost: None,
        });
        let pct = state.context_usage().unwrap_or(-1.0);
        assert!(
            (pct - 100.0).abs() < f64::EPSILON,
            "expected 100.0, got {pct}"
        );
    }

    #[test]
    fn ui_state_usage_updated_zero_size_returns_false() {
        let mut state = UiState::new(500);
        let changed = state.apply_notification(&Notification::UsageUpdated {
            used: 100,
            size: 0,
            cost: None,
        });
        assert!(!changed, "size=0 should not claim state changed");
        assert!(state.context_usage().is_none());
    }

    #[test]
    fn usage_panel_page_and_scroll_state() {
        let snapshot = cyril_core::types::UsageSnapshot {
            providers: ["alpha", "beta", "gamma"]
                .into_iter()
                .map(|name| cyril_core::types::NamedUsageGroup {
                    name: Some(name.to_owned()),
                    summary: cyril_core::types::UsageSummary::default(),
                })
                .collect(),
            ..Default::default()
        };
        let mut state = UiState::new(500);
        state.show_usage_panel(snapshot);
        assert_eq!(
            state.usage_panel().map(|panel| panel.page),
            Some(UsagePage::Overview)
        );
        state.usage_panel_next_page();
        state.usage_panel_next_page();
        state.usage_panel_next_page();
        assert_eq!(
            state.usage_panel().map(|panel| panel.page),
            Some(UsagePage::Providers)
        );
        state.usage_panel_scroll_down(99);
        assert_eq!(
            state.usage_panel().map(|panel| panel.scroll_offset),
            Some(2)
        );
        state.usage_panel_previous_page();
        assert_eq!(
            state.usage_panel().map(|panel| panel.page),
            Some(UsagePage::Context)
        );
        assert_eq!(
            state.usage_panel().map(|panel| panel.scroll_offset),
            Some(0)
        );
        state.hide_usage_panel();
        assert!(!state.has_usage_panel());
    }

    #[test]
    fn usage_account_state_retains_last_known_with_status() {
        let mut state = UiState::new(500);
        state.show_usage_panel(cyril_core::types::UsageSnapshot::default());
        state.mark_usage_account_loading();
        assert!(matches!(
            state.usage_panel().map(|panel| &panel.account_status),
            Some(UsageAccountStatus::Loading)
        ));
        let account = cyril_core::types::UsageAccount {
            plan_name: "KIRO PRO MAX".to_owned(),
            billing_cycle_reset: "2026-09-01".to_owned(),
            overages_enabled: false,
            is_enterprise: false,
            overage_capable: false,
            usage_breakdowns: Vec::new(),
            bonus_credits: Vec::new(),
            add_on_credits: Vec::new(),
        };
        state.apply_notification(&Notification::UsageAccountUpdated {
            account,
            fetched_at_ms: Some(42),
        });
        assert!(matches!(
            state.usage_panel().map(|panel| &panel.account_status),
            Some(UsageAccountStatus::Fresh)
        ));
        state.mark_usage_account_loading();
        assert!(matches!(
            state.usage_panel().map(|panel| &panel.account_status),
            Some(UsageAccountStatus::Refreshing)
        ));
        state.apply_notification(&Notification::UsageAccountQueryFailed {
            message: "offline".to_owned(),
        });
        assert!(matches!(
            state.usage_panel().map(|panel| &panel.account_status),
            Some(UsageAccountStatus::Stale(message)) if message == "offline"
        ));
        state.hide_usage_panel();
        state.show_usage_panel(cyril_core::types::UsageSnapshot::default());
        let panel = state.usage_panel().expect("reopened usage panel");
        assert_eq!(panel.account_fetched_at_ms, Some(42));
        assert_eq!(
            panel.account.as_ref().map(|value| value.plan_name.as_str()),
            Some("KIRO PRO MAX")
        );
        state.apply_notification(&Notification::BridgeDisconnected {
            reason: "process exited".to_owned(),
        });
        assert!(matches!(
            state.usage_panel().map(|panel| &panel.account_status),
            Some(UsageAccountStatus::Unavailable(message))
                if message == "bridge disconnected: process exited"
        ));
    }
    fn sample_breakdown() -> cyril_core::types::ContextBreakdown {
        use cyril_core::types::{ContextBreakdown, ContextBucket};
        ContextBreakdown::new(
            ContextBucket::new(10, 1.1),
            ContextBucket::new(20, 2.2),
            ContextBucket::new(30, 3.3),
            ContextBucket::new(40, 4.4),
            ContextBucket::new(50, 5.5),
        )
    }

    #[test]
    fn ui_state_context_breakdown_retains_last_on_absent() {
        // Slice 2 / claim C4. Present-then-absent: the second (scalar-only) frame
        // must update the % but NOT clear the stored bars. Fails under
        // `self.context_breakdown = breakdown.clone()` (overwrite-with-None).
        let mut state = UiState::new(500);
        state.apply_notification(&Notification::ContextBreakdownUpdated {
            usage_percentage: 5.0,
            breakdown: Some(sample_breakdown()),
        });
        state.apply_notification(&Notification::ContextBreakdownUpdated {
            usage_percentage: 7.0,
            breakdown: None,
        });
        assert!(
            state.context_breakdown.is_some(),
            "a breakdown-absent frame must retain the last breakdown, not clear it"
        );
        let pct = state.context_usage().unwrap_or(-1.0);
        assert!(
            (pct - 7.0).abs() < f64::EPSILON,
            "scalar must update to 7.0, got {pct}"
        );
        // The retained breakdown is still the first frame's bars.
        let bd = state.context_breakdown.as_ref().expect("retained");
        assert_eq!(bd.tools().tokens(), 30);
    }

    #[test]
    fn ui_state_context_breakdown_updates_scalar() {
        // Slice 2 / claim C5. Under KAS the toolbar % comes from context_usage
        // frames. Fails under an arm that stores the breakdown but never sets the
        // scalar.
        let mut state = UiState::new(500);
        state.apply_notification(&Notification::ContextBreakdownUpdated {
            usage_percentage: 42.0,
            breakdown: Some(sample_breakdown()),
        });
        let pct = state.context_usage().unwrap_or(-1.0);
        assert!(
            (pct - 42.0).abs() < f64::EPSILON,
            "expected 42.0, got {pct}"
        );
    }

    #[test]
    fn ui_state_context_breakdown_and_scalar_cleared_on_session_created() {
        // A new session must not inherit the prior session's breakdown bars or
        // `Context: N%`. Retain-last governs only an absent frame WITHIN a session,
        // not the session boundary (mirrors the effort-reset discipline). Fails if
        // SessionCreated forgets to reset context_breakdown/context_usage.
        let mut state = UiState::new(500);
        state.apply_notification(&Notification::ContextBreakdownUpdated {
            usage_percentage: 45.0,
            breakdown: Some(sample_breakdown()),
        });
        assert!(state.context_breakdown.is_some());
        assert!(state.context_usage().is_some());

        state.apply_notification(&Notification::SessionCreated {
            session_id: SessionId::new("s2"),
            current_mode: None,
            current_model: None,
            available_modes: Vec::new(),
            available_models: Vec::new(),
        });
        assert!(
            state.context_breakdown.is_none(),
            "new session must clear the prior session's breakdown bars"
        );
        assert!(
            state.context_usage().is_none(),
            "new session must clear the prior session's Context: N% scalar"
        );
    }

    #[test]
    fn ui_state_context_cleared_on_bridge_disconnect() {
        // A dead connection has no live context — the toolbar must not keep
        // rendering the last session's bars/scalar as if it were alive.
        let mut state = UiState::new(500);
        state.apply_notification(&Notification::ContextBreakdownUpdated {
            usage_percentage: 55.0,
            breakdown: Some(sample_breakdown()),
        });
        state.apply_notification(&Notification::BridgeDisconnected {
            reason: "process exited".into(),
        });
        assert!(
            state.context_breakdown.is_none() && state.context_usage().is_none(),
            "a dead connection must clear context_breakdown and context_usage"
        );
    }

    // ---------- UserMessage / session-load replay ----------

    #[test]
    fn user_message_notification_appends_user_chat_message() {
        use crate::traits::ChatMessageKind;
        use cyril_core::types::UserMessage;

        let mut state = UiState::new(500);
        assert!(state.messages().is_empty());

        // is_streaming=false → commit immediately (single-chunk turn).
        let changed = state.apply_notification(&Notification::UserMessage(UserMessage {
            text: "explain main.rs".into(),
            is_streaming: false,
        }));
        assert!(changed);

        let msgs = state.messages();
        assert_eq!(msgs.len(), 1);
        match &msgs[0].kind {
            ChatMessageKind::UserText(text) => assert_eq!(text, "explain main.rs"),
            other => panic!("expected UserText, got {other:?}"),
        }
    }

    #[test]
    fn user_message_flushes_pending_agent_stream_first() {
        use crate::traits::ChatMessageKind;
        use cyril_core::types::UserMessage;

        let mut state = UiState::new(500);
        // Simulate a replay where an agent message chunk arrives, then a user turn
        state.apply_notification(&Notification::AgentMessage(AgentMessage {
            text: "half-written agent reply".into(),
            is_streaming: true,
        }));

        state.apply_notification(&Notification::UserMessage(UserMessage {
            text: "next user prompt".into(),
            is_streaming: false,
        }));

        let msgs = state.messages();
        // Agent stream flushed first, then user message
        assert_eq!(msgs.len(), 2);
        match &msgs[0].kind {
            ChatMessageKind::AgentText(text) => assert_eq!(text, "half-written agent reply"),
            other => panic!("expected AgentText, got {other:?}"),
        }
        match &msgs[1].kind {
            ChatMessageKind::UserText(text) => assert_eq!(text, "next user prompt"),
            other => panic!("expected UserText, got {other:?}"),
        }
    }

    /// cyril-k3lz review finding 6: a system message added mid-turn (here the
    /// v2 thinking ack) commits after the thought and text that streamed
    /// before it, and text streamed after it starts a new message.
    #[test]
    fn system_message_flushes_pending_streams_first() {
        use crate::traits::ChatMessageKind;

        let mut state = UiState::new(500);
        state.apply_notification(&Notification::AgentThought(AgentThought {
            text: "reasoning".into(),
        }));
        state.apply_notification(&Notification::AgentMessage(AgentMessage {
            text: "before the toggle".into(),
            is_streaming: true,
        }));
        state.apply_notification(&Notification::ThinkingToggled { enabled: false });
        state.apply_notification(&Notification::AgentMessage(AgentMessage {
            text: "after the toggle".into(),
            is_streaming: true,
        }));
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });

        let committed: Vec<(&str, &str)> = state
            .messages()
            .iter()
            .map(|m| match m.kind() {
                ChatMessageKind::Thought(t) => ("thought", t.as_str()),
                ChatMessageKind::AgentText(t) => ("agent", t.as_str()),
                ChatMessageKind::System(t) => ("system", t.as_str()),
                other => panic!("unexpected message {other:?}"),
            })
            .collect();
        assert_eq!(
            committed,
            [
                ("thought", "reasoning"),
                ("agent", "before the toggle"),
                ("system", "Thinking turned off."),
                ("agent", "after the toggle"),
            ],
            "chronological commit order"
        );
    }

    // ---------- approval_confirm sends the picked option's id (cyril-qo13) ----------

    fn make_approval_request(
        options: Vec<cyril_core::types::PermissionOption>,
    ) -> (
        cyril_core::types::PermissionRequest,
        tokio::sync::oneshot::Receiver<cyril_core::types::PermissionResponse>,
    ) {
        let (tx, rx) = tokio::sync::oneshot::channel();
        let tool_call = cyril_core::types::ToolCall::new(
            cyril_core::types::ToolCallId::new("tc_1"),
            "echo hi".into(),
            cyril_core::types::ToolKind::Execute,
            cyril_core::types::ToolCallStatus::Pending,
            None,
        );
        let req = cyril_core::types::PermissionRequest {
            session_id: cyril_core::types::SessionId::new("main"),
            tool_call,
            message: "Allow?".into(),
            options,
            trust_options: Vec::new(),
            can_reject_with_reason: false,
            responder: tx,
            consent: None,
            workflow_plan: None,
        };
        (req, rx)
    }
    fn lki9_echoes(state: &UiState) -> Vec<(String, SteerEchoStatus, Option<String>)> {
        state
            .messages()
            .iter()
            .filter_map(|m| match m.kind() {
                ChatMessageKind::SteerEcho {
                    text,
                    status,
                    message_id,
                    ..
                } => Some((text.clone(), *status, message_id.clone())),
                _ => None,
            })
            .collect()
    }

    fn lki9_consumed(id: Option<&str>) -> Notification {
        Notification::SteeringConsumed {
            content: None,
            message_id: id.map(str::to_owned),
        }
    }

    /// cyril-lki9 C6 / cyril-5n75: a Consumed id bound to no chip may only
    /// drain an id-less chip (a steer whose Queued echo was dropped/deferred) —
    /// never an operator chip bound to a different id; the counter moves only
    /// when a chip flips; the id-less legacy Consumed keeps FIFO.
    #[test]
    fn lki9_steer_fallback_never_drains_a_bound_chip() {
        // Bound steer-A + a deferred (id-less) chip: notify-X drains the id-less one.
        let mut state = UiState::new(500);
        state.add_steer_echo("first");
        state.apply_notification(&Notification::SteeringQueued {
            message: Some("first".into()),
            message_id: Some("steer-A".into()),
        });
        state.add_steer_echo("second");
        assert_eq!(state.steering_queued(), 2);
        assert!(state.apply_notification(&lki9_consumed(Some("notify-X"))));
        assert_eq!(
            lki9_echoes(&state),
            [
                (
                    "first".into(),
                    SteerEchoStatus::Queued,
                    Some("steer-A".into())
                ),
                ("second".into(), SteerEchoStatus::Applied, None),
            ]
        );
        assert_eq!(state.steering_queued(), 1);

        // Only a bound chip queued: notify-X flips nothing, counter unchanged.
        let mut bound_only = UiState::new(500);
        bound_only.add_steer_echo("first");
        bound_only.apply_notification(&Notification::SteeringQueued {
            message: Some("first".into()),
            message_id: Some("steer-A".into()),
        });
        assert!(!bound_only.apply_notification(&lki9_consumed(Some("notify-X"))));
        assert_eq!(
            lki9_echoes(&bound_only),
            [(
                "first".into(),
                SteerEchoStatus::Queued,
                Some("steer-A".into())
            )]
        );
        assert_eq!(
            bound_only.steering_queued(),
            1,
            "cyril-7z7u: counter == #Queued chips"
        );

        // Legacy id-less Consumed: FIFO over Queued chips, as before.
        let mut legacy = UiState::new(500);
        legacy.add_steer_echo("only");
        assert!(legacy.apply_notification(&lki9_consumed(None)));
        assert_eq!(
            lki9_echoes(&legacy),
            [("only".into(), SteerEchoStatus::Applied, None)]
        );
        assert_eq!(legacy.steering_queued(), 0);
    }

    fn lki9_streaming(text: &str) -> Notification {
        Notification::AgentMessage(AgentMessage {
            text: text.to_owned(),
            is_streaming: true,
        })
    }

    fn lki9_system_texts(messages: &[ChatMessage]) -> Vec<String> {
        messages
            .iter()
            .map(|m| match m.kind() {
                ChatMessageKind::System(t) => format!("SYS:{t}"),
                ChatMessageKind::AgentText(t) => format!("AGENT:{t}"),
                other => format!("{other:?}"),
            })
            .collect()
    }

    /// cyril-lki9 C16: an injected notice lands where it arrived — the text
    /// streamed before it is committed first, the text after it continues as
    /// a new block — in the main transcript and in a workflow step's stream;
    /// a notice before any streamed text commits no empty text block.
    #[test]
    fn lki9_notice_lands_in_arrival_order() {
        let mut state = UiState::new(500);
        state.apply_notification(&lki9_streaming("abc"));
        state.show_engine_injection(Transcript::Main, Some("OK"), Some("success"), false, None);
        state.apply_notification(&lki9_streaming("def"));
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: StopReason::EndTurn,
        });
        assert_eq!(
            lki9_system_texts(state.messages()),
            [
                "AGENT:abc",
                "SYS:⚙ workflow step · success: OK",
                "AGENT:def"
            ]
        );

        let mut fresh = UiState::new(500);
        let wake =
            cyril_core::types::AgentInitiation::new(Some("workflow-complete-wake".into()), true);
        let label = cyril_core::workflow::WakeLabel::new(
            "audit-channels-2.26.0".into(),
            cyril_core::types::WorkflowRunStatus::Completed,
        );
        fresh.begin_agent_initiated_turn(Transcript::Main, &wake, Some(&label));
        assert_eq!(
            lki9_system_texts(fresh.messages()),
            ["SYS:─── ⚙ workflow \"audit-channels-2.26.0\" completed · agent follow-up ───"],
            "no empty text block before a header"
        );

        let step = SessionId::new("step-1");
        let mut streams = UiState::new(500);
        streams.apply_workflow_notification(&step, &lki9_streaming("xyz"));
        streams.begin_agent_initiated_turn(
            Transcript::Workflow(&step),
            &cyril_core::types::AgentInitiation::new(Some("send-message-wake".into()), false),
            None,
        );
        let stream = streams
            .workflow_streams()
            .get(&step)
            .unwrap_or_else(|| panic!("step stream exists"));
        assert_eq!(
            lki9_system_texts(stream.messages()),
            [
                "AGENT:xyz",
                "SYS:─── ⚙ agent-initiated · send-message-wake ───"
            ],
            "per-session header lands in that session's stream, after its text"
        );
        assert!(
            lki9_system_texts(streams.messages()).is_empty(),
            "a step session's header never lands in the main transcript"
        );
    }

    /// cyril-lki9 C17: `TurnStarted` makes an idle indicator busy (a wake may
    /// be silent for a minute); a streaming turn is left as it is; the turn's
    /// completion returns to Ready.
    #[test]
    fn lki9_turn_started_sets_busy_indicator() {
        let mut state = UiState::new(500);
        assert_eq!(state.activity(), Activity::Idle);
        assert!(state.apply_notification(&Notification::TurnStarted));
        assert_eq!(state.activity(), Activity::Waiting);
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: StopReason::EndTurn,
        });
        assert_eq!(state.activity(), Activity::Ready);
        state.apply_notification(&lki9_streaming("mid"));
        assert!(!state.apply_notification(&Notification::TurnStarted));
        assert_eq!(state.activity(), Activity::Streaming, "busy turn untouched");
    }

    /// cyril-lki9 C18: a permission request during an agent-initiated turn
    /// takes the approval overlay exactly as in an operator turn.
    #[test]
    fn lki9_approval_during_server_turn() {
        let mut state = UiState::new(500);
        state.apply_notification(&Notification::TurnStarted);
        assert_eq!(state.activity(), Activity::Waiting);
        let (request, _receiver) =
            make_approval_request(vec![cyril_core::types::PermissionOption {
                id: cyril_core::types::PermissionOptionId::new("allow"),
                label: "Allow".into(),
                kind: cyril_core::types::PermissionOptionKind::AllowOnce,
                is_destructive: false,
            }]);
        state.show_approval(request);
        assert_eq!(state.topmost_overlay(), Some(Overlay::Approval));
    }

    #[test]
    fn rejection_feedback_sends_exact_reason() {
        use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
        use cyril_core::types::{
            PermissionOption, PermissionOptionId, PermissionOptionKind, PermissionResponse,
        };

        let (mut request, receiver) = make_approval_request(vec![PermissionOption {
            id: PermissionOptionId::new("reject-exact"),
            label: "Reject".into(),
            kind: PermissionOptionKind::RejectOnce,
            is_destructive: true,
        }]);
        request.can_reject_with_reason = true;
        let mut state = UiState::new(500);
        state.show_approval(request);

        assert!(state.approval_begin_feedback());
        assert!(state.approval_feedback_paste(" leading 解释\r\ntrailing "));
        assert!(state.approval_feedback_active());
        assert!(state.approval_feedback_key(KeyEvent::new(KeyCode::Enter, KeyModifiers::NONE,)));

        match receiver.blocking_recv() {
            Ok(PermissionResponse::RejectWithReason { option_id, reason }) => {
                assert_eq!(option_id.as_str(), "reject-exact");
                assert_eq!(reason, " leading 解释\ntrailing ");
            }
            Ok(other) => panic!("expected reasoned rejection, got {other:?}"),
            Err(_) => panic!("approval responder dropped before submit"),
        }
        assert!(!state.approval_feedback_active());
        assert!(state.approval().is_none());
    }

    #[test]
    fn rejection_feedback_blank_submits_selected_without_reason() {
        use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
        use cyril_core::types::{
            PermissionOption, PermissionOptionId, PermissionOptionKind, PermissionResponse,
        };

        let (mut request, receiver) = make_approval_request(vec![PermissionOption {
            id: PermissionOptionId::new("reject-blank"),
            label: "Reject".into(),
            kind: PermissionOptionKind::RejectOnce,
            is_destructive: true,
        }]);
        request.can_reject_with_reason = true;
        let mut state = UiState::new(500);
        state.show_approval(request);
        assert!(state.approval_begin_feedback());
        state.approval_feedback_paste(" \t\n ");
        state.approval_feedback_key(KeyEvent::new(KeyCode::Enter, KeyModifiers::NONE));

        match receiver.blocking_recv() {
            Ok(PermissionResponse::Selected {
                option_id,
                trust_option,
            }) => {
                assert_eq!(option_id.as_str(), "reject-blank");
                assert_eq!(trust_option, None);
            }
            Ok(other) => panic!("expected blank Selected response, got {other:?}"),
            Err(_) => panic!("approval responder dropped before submit"),
        }
    }

    #[test]
    fn rejection_feedback_escape_restores_option_without_response() {
        use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
        use cyril_core::types::{
            PermissionOption, PermissionOptionId, PermissionOptionKind, PermissionResponse,
        };

        let (mut request, mut receiver) = make_approval_request(vec![PermissionOption {
            id: PermissionOptionId::new("reject-esc"),
            label: "Reject".into(),
            kind: PermissionOptionKind::RejectOnce,
            is_destructive: true,
        }]);
        request.can_reject_with_reason = true;
        let mut state = UiState::new(500);
        state.show_approval(request);
        assert!(state.approval_begin_feedback());
        state.approval_feedback_paste("discard me");
        state.approval_feedback_key(KeyEvent::new(KeyCode::Esc, KeyModifiers::NONE));

        let approval = state.approval().expect("approval returns to option phase");
        assert_eq!(approval.phase, ApprovalPhase::SelectOption);
        assert_eq!(approval.selected, 0);
        assert!(matches!(
            receiver.try_recv(),
            Err(tokio::sync::oneshot::error::TryRecvError::Empty)
        ));

        state.approval_cancel();
        assert!(matches!(
            receiver.blocking_recv(),
            Ok(PermissionResponse::Cancel)
        ));
    }
    #[test]
    fn rejection_feedback_requires_capability_and_reject_once_kind() {
        use cyril_core::types::{PermissionOption, PermissionOptionId, PermissionOptionKind};

        let (request, _receiver) = make_approval_request(vec![PermissionOption {
            id: PermissionOptionId::new("reject-gated"),
            label: "Reject".into(),
            kind: PermissionOptionKind::RejectOnce,
            is_destructive: true,
        }]);
        let mut state = UiState::new(500);
        state.show_approval(request);
        assert!(!state.approval_begin_feedback());

        let (mut request, _receiver) = make_approval_request(vec![PermissionOption {
            id: PermissionOptionId::new("allow-gated"),
            label: "Allow".into(),
            kind: PermissionOptionKind::AllowOnce,
            is_destructive: false,
        }]);
        request.can_reject_with_reason = true;
        let mut state = UiState::new(500);
        state.show_approval(request);
        assert!(!state.approval_begin_feedback());
    }
    #[test]
    fn rejection_feedback_queue_is_fifo_across_sessions_with_equal_tool_ids() {
        use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
        use cyril_core::types::{
            PermissionOption, PermissionOptionId, PermissionOptionKind, PermissionResponse,
        };

        let option = |id| PermissionOption {
            id: PermissionOptionId::new(id),
            label: "Reject".into(),
            kind: PermissionOptionKind::RejectOnce,
            is_destructive: true,
        };
        let (mut first, mut first_receiver) = make_approval_request(vec![option("first-reject")]);
        let (mut second, mut second_receiver) =
            make_approval_request(vec![option("second-reject")]);
        first.session_id = cyril_core::types::SessionId::new("first-session");
        second.session_id = cyril_core::types::SessionId::new("second-session");
        first.can_reject_with_reason = true;
        second.can_reject_with_reason = true;

        let mut state = UiState::new(500);
        state.show_approval(first);
        state.show_approval(second);

        assert!(state.approval_begin_feedback());
        state.approval_feedback_paste("discarded before re-enter");
        state.approval_feedback_key(KeyEvent::new(KeyCode::Esc, KeyModifiers::NONE));
        let approval = state
            .approval()
            .expect("first approval remains at queue head");
        assert_eq!(approval.session_id.as_str(), "first-session");
        assert_eq!(approval.tool_call.id().as_str(), "tc_1");
        assert!(matches!(
            first_receiver.try_recv(),
            Err(tokio::sync::oneshot::error::TryRecvError::Empty)
        ));

        assert!(state.approval_begin_feedback());
        state.approval_feedback_paste("first reason");
        state.approval_feedback_key(KeyEvent::new(KeyCode::Enter, KeyModifiers::NONE));
        assert!(matches!(
            first_receiver.try_recv(),
            Ok(PermissionResponse::RejectWithReason { option_id, reason })
                if reason == "first reason" && option_id.as_str() == "first-reject"
        ));
        assert!(matches!(
            second_receiver.try_recv(),
            Err(tokio::sync::oneshot::error::TryRecvError::Empty)
        ));

        let approval = state
            .approval()
            .expect("second approval promoted in FIFO order");
        assert_eq!(approval.session_id.as_str(), "second-session");
        assert_eq!(approval.tool_call.id().as_str(), "tc_1");
        assert!(state.approval_begin_feedback());
        state.approval_feedback_paste("second reason");
        state.approval_feedback_key(KeyEvent::new(KeyCode::Enter, KeyModifiers::NONE));
        assert!(matches!(
            second_receiver.try_recv(),
            Ok(PermissionResponse::RejectWithReason { option_id, reason })
                if reason == "second reason" && option_id.as_str() == "second-reject"
        ));
    }

    #[test]
    fn rejection_feedback_dropped_receiver_advances_queue() {
        use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
        use cyril_core::types::{
            PermissionOption, PermissionOptionId, PermissionOptionKind, PermissionResponse,
        };

        let option = || PermissionOption {
            id: PermissionOptionId::new("reject"),
            label: "Reject".into(),
            kind: PermissionOptionKind::RejectOnce,
            is_destructive: true,
        };
        let (mut first, first_receiver) = make_approval_request(vec![option()]);
        let (mut second, second_receiver) = make_approval_request(vec![option()]);
        first.can_reject_with_reason = true;
        second.can_reject_with_reason = true;
        second.session_id = cyril_core::types::SessionId::new("surviving-session");
        drop(first_receiver);

        let mut state = UiState::new(500);
        state.show_approval(first);
        state.show_approval(second);
        assert!(state.approval_begin_feedback());
        state.approval_feedback_paste("receiver already gone");
        state.approval_feedback_key(KeyEvent::new(KeyCode::Enter, KeyModifiers::NONE));

        assert_eq!(
            state
                .approval()
                .expect("dropped first request still advances")
                .session_id
                .as_str(),
            "surviving-session"
        );
        assert!(state.approval_begin_feedback());
        state.approval_feedback_paste("surviving request");
        state.approval_feedback_key(KeyEvent::new(KeyCode::Enter, KeyModifiers::NONE));
        assert!(matches!(
            second_receiver.blocking_recv(),
            Ok(PermissionResponse::RejectWithReason { reason, .. })
                if reason == "surviving request"
        ));
    }

    /// Unwrap a `Selected` response or panic with context.
    fn expect_selected(
        response: cyril_core::types::PermissionResponse,
    ) -> (cyril_core::types::PermissionOptionId, Option<String>) {
        match response {
            cyril_core::types::PermissionResponse::Selected {
                option_id,
                trust_option,
            } => (option_id, trust_option),
            other => panic!("expected Selected response, got {other:?}"),
        }
    }

    // ---------- approval snapshot independence (cyril-j1b3 C5) ----------

    /// Two permission requests for the same toolCallId retain independent
    /// snapshots and responders while the UI resolves them in arrival order.
    #[test]
    fn approval_snapshot_is_independent() {
        use cyril_core::types::{
            PermissionOption, PermissionOptionId, PermissionOptionKind, PermissionRequest,
            PermissionResponse, ToolCall, ToolCallId, ToolCallStatus, ToolKind,
        };

        fn request(
            title: &str,
            raw: serde_json::Value,
        ) -> (
            PermissionRequest,
            tokio::sync::oneshot::Receiver<PermissionResponse>,
        ) {
            let (tx, rx) = tokio::sync::oneshot::channel();
            let req = PermissionRequest {
                session_id: cyril_core::types::SessionId::new("main"),
                tool_call: ToolCall::new(
                    ToolCallId::new("shared-id"),
                    title.into(),
                    ToolKind::Write,
                    ToolCallStatus::Pending,
                    Some(raw),
                ),
                message: title.into(),
                options: vec![PermissionOption {
                    id: PermissionOptionId::new("accept"),
                    label: "Allow".into(),
                    kind: PermissionOptionKind::AllowOnce,
                    is_destructive: false,
                }],
                trust_options: Vec::new(),
                can_reject_with_reason: false,
                responder: tx,
                consent: None,
                workflow_plan: None,
            };
            (req, rx)
        }

        let (req1, rx1) = request("first", serde_json::json!({"path": "one.md"}));
        let (req2, mut rx2) = request("second", serde_json::json!({"path": "two.md"}));
        let mut state = UiState::new(500);
        state.show_approval(req1);
        state.show_approval(req2);
        let approval = state.approvals.front().expect("first approval active");
        assert_eq!(approval.message, "first");
        assert_eq!(
            approval.tool_call.raw_input(),
            Some(&serde_json::json!({"path": "one.md"})),
            "the first request's snapshot must remain at the head"
        );
        state.approval_confirm();
        assert!(
            matches!(rx1.blocking_recv(), Ok(PermissionResponse::Selected { .. })),
            "first responder resolved"
        );
        assert!(
            matches!(
                rx2.try_recv(),
                Err(tokio::sync::oneshot::error::TryRecvError::Empty)
            ),
            "second responder remains pending"
        );
        let approval = state.approvals.front().expect("second approval active");
        assert_eq!(approval.message, "second");
        assert_eq!(
            approval.tool_call.raw_input(),
            Some(&serde_json::json!({"path": "two.md"})),
            "the second request's snapshot must remain independent"
        );
        state.approval_confirm();
        assert!(
            matches!(rx2.blocking_recv(), Ok(PermissionResponse::Selected { .. })),
            "second responder resolved"
        );
        assert!(!state.has_approval());
    }

    #[test]
    fn approval_terminal_paths_promote_next_request() {
        use cyril_core::types::{
            PermissionOption, PermissionOptionId, PermissionOptionKind, PermissionRequest,
            PermissionResponse, SessionId, ToolCall, ToolCallId, ToolCallStatus, ToolKind,
            TrustOption,
        };

        let mut state = UiState::new(500);
        let mut receivers = VecDeque::new();
        for index in 0..64 {
            let (responder, receiver) = tokio::sync::oneshot::channel();
            let option_id = PermissionOptionId::new(format!("option-{index}"));
            let allow_always = index == 3;
            state.show_approval(PermissionRequest {
                session_id: SessionId::new("repeated-session"),
                tool_call: ToolCall::new(
                    ToolCallId::new("repeated-tool"),
                    format!("tool-{index}"),
                    ToolKind::Execute,
                    ToolCallStatus::Pending,
                    Some(serde_json::json!({"index": index})),
                ),
                message: format!("request-{index}"),
                options: vec![PermissionOption {
                    id: option_id,
                    label: format!("option-{index}"),
                    kind: if allow_always {
                        PermissionOptionKind::AllowAlways
                    } else {
                        PermissionOptionKind::AllowOnce
                    },
                    is_destructive: false,
                }],
                trust_options: allow_always
                    .then(|| TrustOption {
                        label: "Full command".into(),
                        display: "tool".into(),
                        setting_key: "allowedCommands".into(),
                        patterns: vec!["tool".into()],
                    })
                    .into_iter()
                    .collect(),
                can_reject_with_reason: false,
                responder,
                consent: None,
                workflow_plan: None,
            });
            if matches!(index, 10 | 20) {
                drop(receiver);
                receivers.push_back(None);
            } else {
                receivers.push_back(Some(receiver));
            }
        }

        for index in 0..64 {
            for pending in receivers.iter_mut().filter_map(Option::as_mut) {
                assert!(matches!(
                    pending.try_recv(),
                    Err(tokio::sync::oneshot::error::TryRecvError::Empty)
                ));
            }
            let receiver = receivers.pop_front().expect("receiver slot");
            let expected_id = PermissionOptionId::new(format!("option-{index}"));
            let approval = state.approvals.front().expect("queued approval active");
            assert_eq!(approval.message, format!("request-{index}"));
            assert_eq!(approval.options[0].id, expected_id);
            assert_eq!(
                approval.tool_call.raw_input(),
                Some(&serde_json::json!({"index": index}))
            );

            let expected = match index {
                1 => {
                    state.approval_cancel();
                    PermissionResponse::Cancel
                }
                2 => {
                    state
                        .approvals
                        .front_mut()
                        .expect("invalid-selection approval")
                        .selected = usize::MAX;
                    state.approval_confirm();
                    PermissionResponse::Cancel
                }
                3 => {
                    state.approval_confirm();
                    assert_eq!(
                        state.approvals.front().expect("trust phase").message,
                        "request-3"
                    );
                    state.approval_cancel();
                    assert_eq!(
                        state
                            .approvals
                            .front()
                            .expect("restored option phase")
                            .message,
                        "request-3"
                    );
                    state.approval_confirm();
                    let (origin, chosen) = state.approval_confirm().expect("chosen trust option");
                    assert_eq!(origin, SessionId::new("repeated-session"));
                    assert_eq!(chosen.label, "Full command");
                    PermissionResponse::Selected {
                        option_id: expected_id,
                        trust_option: Some("Full command".into()),
                    }
                }
                _ if index % 2 == 0 => {
                    state.approval_confirm();
                    PermissionResponse::Selected {
                        option_id: expected_id,
                        trust_option: None,
                    }
                }
                _ => {
                    state.approval_cancel();
                    PermissionResponse::Cancel
                }
            };

            if let Some(receiver) = receiver {
                let actual = receiver.blocking_recv().expect("open responder resolved");
                match (actual, expected) {
                    (PermissionResponse::Cancel, PermissionResponse::Cancel) => {}
                    (
                        PermissionResponse::Selected {
                            option_id: actual_id,
                            trust_option: actual_trust,
                        },
                        PermissionResponse::Selected {
                            option_id: expected_id,
                            trust_option: expected_trust,
                        },
                    ) => {
                        assert_eq!(actual_id, expected_id);
                        assert_eq!(actual_trust, expected_trust);
                    }
                    (actual, expected) => {
                        panic!("unexpected response: actual={actual:?}, expected={expected:?}");
                    }
                }
            }
        }

        assert!(receivers.is_empty());
        assert!(!state.has_approval());
    }

    /// cyril-j1b3 spec snapshot-stability fence: a ToolCallUpdated applied to
    /// the session AFTER the approval is shown must not mutate the pending
    /// approval's preview — the operator decides against a request-time
    /// snapshot, not a live view.
    #[test]
    fn approval_snapshot_stable_under_later_update() {
        use cyril_core::types::{
            PermissionOption, PermissionOptionId, PermissionOptionKind, PermissionRequest,
            ToolCall, ToolCallId, ToolCallStatus, ToolKind,
        };
        let (tx, _rx) = tokio::sync::oneshot::channel();

        let req = PermissionRequest {
            session_id: cyril_core::types::SessionId::new("main"),
            tool_call: ToolCall::new(
                ToolCallId::new("tc-snap"),
                "Write File".into(),
                ToolKind::Write,
                ToolCallStatus::Pending,
                Some(serde_json::json!({"path": "a.md", "text": "original"})),
            ),
            message: "Write File".into(),
            options: vec![PermissionOption {
                id: PermissionOptionId::new("accept"),
                label: "Allow".into(),
                kind: PermissionOptionKind::AllowOnce,
                is_destructive: false,
            }],
            trust_options: Vec::new(),
            can_reject_with_reason: false,
            responder: tx,
            consent: None,
            workflow_plan: None,
        };
        let mut state = UiState::new(500);
        state.show_approval(req);

        // A later update mutating the tracked call in the message list...
        state.apply_notification(&cyril_core::types::Notification::ToolCallStarted(
            ToolCall::new(
                ToolCallId::new("tc-snap"),
                "Write File".into(),
                ToolKind::Write,
                ToolCallStatus::InProgress,
                Some(serde_json::json!({"path": "a.md", "text": "original"})),
            ),
        ));
        state.apply_notification(&cyril_core::types::Notification::ToolCallUpdated(
            ToolCall::new(
                ToolCallId::new("tc-snap"),
                "Write File".into(),
                ToolKind::Write,
                ToolCallStatus::Completed,
                Some(serde_json::json!({"path": "a.md", "text": "REPLACED"})),
            ),
        ));
        let approval = state.approvals.front().expect("approval still active");
        assert_eq!(
            approval.tool_call.raw_input(),
            Some(&serde_json::json!({"path": "a.md", "text": "original"})),
            "approval preview must keep the request-time snapshot"
        );
    }

    #[test]
    fn approval_confirm_reject_always_sends_its_option_id() {
        use cyril_core::types::{PermissionOption, PermissionOptionKind};

        let (req, rx) = make_approval_request(vec![
            PermissionOption {
                id: cyril_core::types::PermissionOptionId::new("opt_allow"),
                label: "Yes".into(),
                kind: PermissionOptionKind::AllowOnce,
                is_destructive: false,
            },
            PermissionOption {
                id: cyril_core::types::PermissionOptionId::new("opt_reject_always"),
                label: "Never".into(),
                kind: PermissionOptionKind::RejectAlways,
                is_destructive: true,
            },
        ]);

        let mut state = UiState::new(500);
        state.show_approval(req);
        state.approval_select_next(); // move from index 0 (Allow) to 1 (RejectAlways)
        state.approval_confirm();

        let response = rx.blocking_recv().expect("responder fired");
        let (option_id, trust_option) = expect_selected(response);
        assert_eq!(option_id.as_str(), "opt_reject_always");
        assert!(trust_option.is_none());
    }

    #[test]
    fn approval_confirm_allow_always_without_trust_sends_its_option_id() {
        use cyril_core::types::{PermissionOption, PermissionOptionKind};

        // AllowAlways with NO trust options confirms immediately (no phase 2)
        // and replies with the picked option's id.
        let (req, rx) = make_approval_request(vec![PermissionOption {
            id: cyril_core::types::PermissionOptionId::new("opt_always"),
            label: "Always".into(),
            kind: PermissionOptionKind::AllowAlways,
            is_destructive: false,
        }]);

        let mut state = UiState::new(500);
        state.show_approval(req);
        state.approval_confirm();

        let response = rx.blocking_recv().expect("responder fired");
        let (option_id, trust_option) = expect_selected(response);
        assert_eq!(option_id.as_str(), "opt_always");
        assert!(trust_option.is_none());
    }

    #[test]
    fn approval_confirm_same_kind_options_sends_picked_id() {
        use cyril_core::types::{PermissionOption, PermissionOptionKind};

        // THE cyril-qo13 bug: KAS user_input questions carry N options all of
        // kind allow_once. Picking the LAST must reply with ITS id — the old
        // kind-keyed response always collapsed to option 0.
        let options: Vec<PermissionOption> = (0..3)
            .map(|i| PermissionOption {
                id: cyril_core::types::PermissionOptionId::new(format!("q-option-{i}")),
                label: format!("Answer {i}"),
                kind: PermissionOptionKind::AllowOnce,
                is_destructive: false,
            })
            .collect();
        let (req, rx) = make_approval_request(options);

        let mut state = UiState::new(500);
        state.show_approval(req);
        state.approval_select_next();
        state.approval_select_next(); // index 2, the last option
        state.approval_confirm();

        let response = rx.blocking_recv().expect("responder fired");
        let (option_id, trust_option) = expect_selected(response);
        assert_eq!(option_id.as_str(), "q-option-2");
        assert!(trust_option.is_none());
    }

    #[test]
    fn approval_confirm_empty_options_sends_cancel() {
        use cyril_core::types::PermissionResponse;

        // No selectable options: confirm must resolve to Cancel — never a
        // fabricated id (the deleted find_option_id fallback class).
        let (req, rx) = make_approval_request(Vec::new());

        let mut state = UiState::new(500);
        state.show_approval(req);
        state.approval_confirm();

        let response = rx.blocking_recv().expect("responder fired");
        assert!(matches!(response, PermissionResponse::Cancel));
    }

    #[test]
    fn approval_confirm_out_of_bounds_selection_defaults_to_cancel() {
        use cyril_core::types::{PermissionOption, PermissionOptionKind, PermissionResponse};

        let (req, rx) = make_approval_request(vec![
            PermissionOption {
                id: cyril_core::types::PermissionOptionId::new("allow"),
                label: "Allow".into(),
                kind: PermissionOptionKind::AllowOnce,
                is_destructive: false,
            },
            PermissionOption {
                id: cyril_core::types::PermissionOptionId::new("reject"),
                label: "Reject".into(),
                kind: PermissionOptionKind::RejectOnce,
                is_destructive: true,
            },
        ]);

        let mut state = UiState::new(500);
        state.show_approval(req);
        // Force the selector out of bounds — simulates a refactor regression
        // where the selector drifts past options.len(). The handler should
        // log a warn and emit Cancel rather than panic or send an AllowOnce.
        state
            .approvals
            .front_mut()
            .expect("approval present")
            .selected = 99;
        state.approval_confirm();

        let response = rx.blocking_recv().expect("responder fired");
        assert!(matches!(response, PermissionResponse::Cancel));
    }

    fn make_approval_request_with_trust(
        options: Vec<cyril_core::types::PermissionOption>,
        trust_options: Vec<cyril_core::types::TrustOption>,
    ) -> (
        cyril_core::types::PermissionRequest,
        tokio::sync::oneshot::Receiver<cyril_core::types::PermissionResponse>,
    ) {
        let (tx, rx) = tokio::sync::oneshot::channel();
        let tool_call = cyril_core::types::ToolCall::new(
            cyril_core::types::ToolCallId::new("tc_1"),
            "echo hi".into(),
            cyril_core::types::ToolKind::Execute,
            cyril_core::types::ToolCallStatus::Pending,
            None,
        );
        let req = cyril_core::types::PermissionRequest {
            session_id: cyril_core::types::SessionId::new("main"),
            tool_call,
            message: "Allow?".into(),
            options,
            trust_options,
            can_reject_with_reason: false,
            responder: tx,
            consent: None,
            workflow_plan: None,
        };
        (req, rx)
    }

    #[test]
    fn approval_trust_phase_keeps_queue_head_until_confirmed() {
        use cyril_core::types::{
            PermissionOption, PermissionOptionId, PermissionOptionKind, PermissionResponse,
            TrustOption,
        };

        let (first, mut first_response) = make_approval_request_with_trust(
            vec![PermissionOption {
                id: PermissionOptionId::new("always"),
                label: "Always".into(),
                kind: PermissionOptionKind::AllowAlways,
                is_destructive: false,
            }],
            vec![TrustOption {
                label: "Full command".into(),
                display: "echo hi".into(),
                setting_key: "allowedCommands".into(),
                patterns: vec!["echo hi".into()],
            }],
        );
        let (mut second, mut second_response) = make_approval_request(vec![PermissionOption {
            id: PermissionOptionId::new("once"),
            label: "Once".into(),
            kind: PermissionOptionKind::AllowOnce,
            is_destructive: false,
        }]);
        second.message = "second".into();

        let mut state = UiState::new(500);
        state.show_approval(first);
        state.show_approval(second);
        state.approval_confirm();
        assert!(matches!(
            state.approval().expect("first approval active").phase,
            ApprovalPhase::SelectTrust { .. }
        ));
        state.approval_cancel();
        assert_eq!(
            state.approval().expect("first approval restored").message,
            "Allow?"
        );
        state.approval_confirm();
        let (origin, trust) = state.approval_confirm().expect("trust confirmed");

        assert_eq!(origin, SessionId::new("main"));
        assert_eq!(trust.label, "Full command");
        assert!(matches!(
            first_response.try_recv(),
            Ok(PermissionResponse::Selected { .. })
        ));
        assert!(matches!(
            second_response.try_recv(),
            Err(tokio::sync::oneshot::error::TryRecvError::Empty)
        ));
        assert_eq!(
            state.approval().expect("second approval promoted").message,
            "second"
        );
    }

    #[test]
    fn approval_allow_always_with_trust_options_transitions_to_phase2() {
        use cyril_core::types::{PermissionOption, PermissionOptionKind, TrustOption};

        let (req, _rx) = make_approval_request_with_trust(
            vec![PermissionOption {
                id: cyril_core::types::PermissionOptionId::new("always"),
                label: "Always".into(),
                kind: PermissionOptionKind::AllowAlways,
                is_destructive: false,
            }],
            vec![TrustOption {
                label: "Full command".into(),
                display: "echo hi".into(),
                setting_key: "allowedCommands".into(),
                patterns: vec!["echo hi".into()],
            }],
        );

        let mut state = UiState::new(500);
        state.show_approval(req);
        state.approval_confirm(); // should NOT send — transitions to phase 2

        let approval = state.approvals.front().expect("still active");
        assert!(
            matches!(&approval.phase, ApprovalPhase::SelectTrust { chosen_option_id } if chosen_option_id.as_str() == "always"),
            "phase 2 must carry the phase-1 pick, got {:?}",
            approval.phase
        );
        assert_eq!(approval.selected, 0);
    }

    #[test]
    fn approval_phase2_confirm_sends_allow_always_with_trust_label() {
        use cyril_core::types::{PermissionOption, PermissionOptionKind, TrustOption};

        let (req, rx) = make_approval_request_with_trust(
            vec![PermissionOption {
                id: cyril_core::types::PermissionOptionId::new("always"),
                label: "Always".into(),
                kind: PermissionOptionKind::AllowAlways,
                is_destructive: false,
            }],
            vec![
                TrustOption {
                    label: "Full command".into(),
                    display: "echo hi".into(),
                    setting_key: "allowedCommands".into(),
                    patterns: vec!["echo hi".into()],
                },
                TrustOption {
                    label: "Base command".into(),
                    display: "echo *".into(),
                    setting_key: "allowedCommands".into(),
                    patterns: vec!["echo( .*)?".into()],
                },
            ],
        );

        let mut state = UiState::new(500);
        state.show_approval(req);
        state.approval_confirm(); // → phase 2
        state.approval_select_next(); // select "Base command"
        let persisted = state.approval_confirm(); // send + return chosen tier

        // The exact origin and full chosen TrustOption are returned so App can
        // guard durable persistence and retain setting_key + patterns.
        let (origin, persisted) =
            persisted.expect("phase-2 confirm returns the origin and chosen tier");
        assert_eq!(origin, cyril_core::types::SessionId::new("main"));
        assert_eq!(persisted.label, "Base command");
        assert_eq!(persisted.setting_key, "allowedCommands");
        assert_eq!(persisted.patterns, vec!["echo( .*)?".to_string()]);

        let response = rx.blocking_recv().expect("responder fired");
        let (option_id, trust_option) = expect_selected(response);
        assert_eq!(option_id.as_str(), "always");
        assert_eq!(trust_option.as_deref(), Some("Base command"));
    }

    #[test]
    fn approval_phase2_confirm_sends_phase1_option_id_not_first_option() {
        use cyril_core::types::{PermissionOption, PermissionOptionKind, TrustOption};

        // cyril-qo13 C4 provenance: AllowAlways is NOT options[0]. After the
        // phase-2 trust confirm, the reply must carry the phase-1 pick
        // ('always-accept'), not options[approval.selected] — in phase 2
        // `selected` re-indexes trust_options and would point at 'accept'.
        let (req, rx) = make_approval_request_with_trust(
            vec![
                PermissionOption {
                    id: cyril_core::types::PermissionOptionId::new("accept"),
                    label: "Allow".into(),
                    kind: PermissionOptionKind::AllowOnce,
                    is_destructive: false,
                },
                PermissionOption {
                    id: cyril_core::types::PermissionOptionId::new("always-accept"),
                    label: "Always allow".into(),
                    kind: PermissionOptionKind::AllowAlways,
                    is_destructive: false,
                },
            ],
            vec![TrustOption {
                label: "Full command".into(),
                display: "echo hi".into(),
                setting_key: "allowedCommands".into(),
                patterns: vec!["echo hi".into()],
            }],
        );

        let mut state = UiState::new(500);
        state.show_approval(req);
        state.approval_select_next(); // index 1: the AllowAlways option
        state.approval_confirm(); // → phase 2 (selected resets to 0)
        state.approval_confirm(); // confirm trust tier 0

        let response = rx.blocking_recv().expect("responder fired");
        let (option_id, trust_option) = expect_selected(response);
        assert_eq!(option_id.as_str(), "always-accept");
        assert_eq!(trust_option.as_deref(), Some("Full command"));
    }

    #[test]
    fn approval_phase2_back_then_repick_does_not_leak_stale_id() {
        use cyril_core::types::{PermissionOption, PermissionOptionKind, TrustOption};

        // cyril-qo13 C4 staleness guard: entering phase 2 carries the
        // AllowAlways id; going BACK must discard it, so re-picking a
        // different option replies with that option's id, not the stale carry.
        let (req, rx) = make_approval_request_with_trust(
            vec![
                PermissionOption {
                    id: cyril_core::types::PermissionOptionId::new("accept"),
                    label: "Allow".into(),
                    kind: PermissionOptionKind::AllowOnce,
                    is_destructive: false,
                },
                PermissionOption {
                    id: cyril_core::types::PermissionOptionId::new("always-accept"),
                    label: "Always allow".into(),
                    kind: PermissionOptionKind::AllowAlways,
                    is_destructive: false,
                },
            ],
            vec![TrustOption {
                label: "Full command".into(),
                display: "echo hi".into(),
                setting_key: "allowedCommands".into(),
                patterns: vec!["echo hi".into()],
            }],
        );

        let mut state = UiState::new(500);
        state.show_approval(req);
        state.approval_select_next(); // pick AllowAlways
        state.approval_confirm(); // → phase 2
        state.approval_cancel(); // back to phase 1 (cursor restored to AllowAlways)
        state.approval_select_prev(); // move to 'accept'
        state.approval_confirm();

        let response = rx.blocking_recv().expect("responder fired");
        let (option_id, trust_option) = expect_selected(response);
        assert_eq!(option_id.as_str(), "accept");
        assert!(trust_option.is_none());
    }

    #[test]
    fn approval_phase2_esc_returns_to_phase1() {
        use cyril_core::types::{PermissionOption, PermissionOptionKind, TrustOption};

        let (req, _rx) = make_approval_request_with_trust(
            vec![PermissionOption {
                id: cyril_core::types::PermissionOptionId::new("always"),
                label: "Always".into(),
                kind: PermissionOptionKind::AllowAlways,
                is_destructive: false,
            }],
            vec![TrustOption {
                label: "Full command".into(),
                display: "echo hi".into(),
                setting_key: "allowedCommands".into(),
                patterns: vec![],
            }],
        );

        let mut state = UiState::new(500);
        state.show_approval(req);
        state.approval_confirm(); // → phase 2
        assert!(matches!(
            state.approvals.front().expect("active").phase,
            ApprovalPhase::SelectTrust { .. }
        ));

        state.approval_cancel(); // should go back, not dismiss
        assert!(state.has_approval());
        assert_eq!(
            state.approvals.front().expect("active").phase,
            ApprovalPhase::SelectOption
        );
    }

    #[test]
    fn approval_phase2_back_restores_allow_always_selection() {
        use cyril_core::types::{PermissionOption, PermissionOptionKind, TrustOption};

        // AllowAlways is NOT the first option, so restoring to index 0 would be
        // wrong — the cursor must return to the AllowAlways row (index 1).
        let (req, _rx) = make_approval_request_with_trust(
            vec![
                PermissionOption {
                    id: cyril_core::types::PermissionOptionId::new("once"),
                    label: "Allow Once".into(),
                    kind: PermissionOptionKind::AllowOnce,
                    is_destructive: false,
                },
                PermissionOption {
                    id: cyril_core::types::PermissionOptionId::new("always"),
                    label: "Always".into(),
                    kind: PermissionOptionKind::AllowAlways,
                    is_destructive: false,
                },
            ],
            vec![TrustOption {
                label: "Full command".into(),
                display: "echo hi".into(),
                setting_key: "allowedCommands".into(),
                patterns: vec![],
            }],
        );

        let mut state = UiState::new(500);
        state.show_approval(req);
        state.approval_select_next(); // move cursor to AllowAlways (index 1)
        state.approval_confirm(); // → phase 2 (selected reset to 0 for the tier list)
        state.approval_cancel(); // back to phase 1
        let approval = state.approvals.front().expect("active");
        assert_eq!(approval.phase, ApprovalPhase::SelectOption);
        assert_eq!(approval.selected, 1, "cursor should return to AllowAlways");
    }

    #[test]
    fn approval_allow_always_without_trust_options_sends_immediately() {
        use cyril_core::types::{PermissionOption, PermissionOptionKind};

        let (req, rx) = make_approval_request(vec![PermissionOption {
            id: cyril_core::types::PermissionOptionId::new("always"),
            label: "Always".into(),
            kind: PermissionOptionKind::AllowAlways,
            is_destructive: false,
        }]);

        let mut state = UiState::new(500);
        state.show_approval(req);
        state.approval_confirm(); // no trust options → sends immediately

        assert!(!state.has_approval());
        let response = rx.blocking_recv().expect("responder fired");
        let (option_id, trust_option) = expect_selected(response);
        assert_eq!(option_id.as_str(), "always");
        assert!(trust_option.is_none());
    }

    // ---------- SessionCreated welcome-message injection ----------

    fn mode(id: &str, welcome: Option<&str>) -> SessionMode {
        SessionMode::new(ModeId::new(id), id, None::<&str>)
            .with_welcome_message(welcome.map(String::from))
    }

    fn session_created(
        id: &str,
        current_mode: Option<&str>,
        modes: Vec<SessionMode>,
    ) -> Notification {
        Notification::SessionCreated {
            session_id: SessionId::new(id),
            current_mode: current_mode.map(ModeId::new),
            current_model: None,
            available_modes: modes,
            available_models: Vec::new(),
        }
    }

    #[test]
    fn session_created_welcome_injected_when_current_mode_has_welcome() {
        use crate::traits::ChatMessageKind;
        let mut state = UiState::new(500);
        let modes = vec![
            mode("kiro_default", None),
            mode("kiro_planner", Some("Transform any idea...")),
        ];
        state.apply_notification(&session_created("s1", Some("kiro_planner"), modes));

        // Messages: [Session created: s1, "Transform any idea..."]
        let systems: Vec<&str> = state
            .messages()
            .iter()
            .filter_map(|m| match m.kind() {
                ChatMessageKind::System(t) => Some(t.as_str()),
                _ => None,
            })
            .collect();
        assert_eq!(systems.len(), 2);
        assert!(systems[0].starts_with("Session created:"));
        assert_eq!(systems[1], "Transform any idea...");
    }

    #[test]
    fn session_created_no_welcome_when_current_mode_missing_welcome() {
        use crate::traits::ChatMessageKind;
        let mut state = UiState::new(500);
        let modes = vec![mode("kiro_default", None)];
        state.apply_notification(&session_created("s1", Some("kiro_default"), modes));

        let systems: Vec<&str> = state
            .messages()
            .iter()
            .filter_map(|m| match m.kind() {
                ChatMessageKind::System(t) => Some(t.as_str()),
                _ => None,
            })
            .collect();
        // Only the "Session created: ..." system message, no welcome.
        assert_eq!(systems.len(), 1);
        assert!(systems[0].starts_with("Session created:"));
    }

    #[test]
    fn session_created_stale_current_mode_does_not_inject_welcome() {
        use crate::traits::ChatMessageKind;
        let mut state = UiState::new(500);
        // current_mode points at an id that's not in the available list.
        let modes = vec![mode("kiro_default", Some("Welcome!"))];
        state.apply_notification(&session_created("s1", Some("missing_mode"), modes));

        let systems: Vec<&str> = state
            .messages()
            .iter()
            .filter_map(|m| match m.kind() {
                ChatMessageKind::System(t) => Some(t.as_str()),
                _ => None,
            })
            .collect();
        // Welcome from kiro_default must NOT be injected (not the active mode).
        assert_eq!(systems.len(), 1);
        assert!(!systems.contains(&"Welcome!"));
    }

    #[test]
    fn session_created_no_current_mode_skips_welcome_lookup() {
        use crate::traits::ChatMessageKind;
        let mut state = UiState::new(500);
        let modes = vec![mode("any", Some("Should not appear"))];
        state.apply_notification(&session_created("s1", None, modes));

        let systems: Vec<&str> = state
            .messages()
            .iter()
            .filter_map(|m| match m.kind() {
                ChatMessageKind::System(t) => Some(t.as_str()),
                _ => None,
            })
            .collect();
        assert_eq!(systems.len(), 1);
        assert!(!systems.contains(&"Should not appear"));
    }

    // ---------- UserMessage multi-chunk accumulation ----------

    #[test]
    fn user_message_streaming_chunks_merge_into_single_message() {
        use crate::traits::ChatMessageKind;
        let mut state = UiState::new(500);
        // Simulate Kiro chunking one logical user turn into two chunks.
        state.apply_notification(&Notification::UserMessage(UserMessage {
            text: "fix the auth ".into(),
            is_streaming: true,
        }));
        state.apply_notification(&Notification::UserMessage(UserMessage {
            text: "bug".into(),
            is_streaming: true,
        }));
        // No flush yet — nothing committed.
        assert!(state.messages().is_empty());

        // Turn completion flushes the accumulated user text.
        state.apply_notification(&Notification::TurnCompleted {
            stop_reason: cyril_core::types::StopReason::EndTurn,
        });
        assert_eq!(state.messages().len(), 1);
        match state.messages()[0].kind() {
            ChatMessageKind::UserText(t) => assert_eq!(t, "fix the auth bug"),
            other => panic!("expected UserText, got {other:?}"),
        }
    }

    #[test]
    fn user_message_flushes_on_tool_call_started() {
        use crate::traits::ChatMessageKind;
        let mut state = UiState::new(500);
        state.apply_notification(&Notification::UserMessage(UserMessage {
            text: "please read".into(),
            is_streaming: true,
        }));
        // Tool call boundary should flush the user chunk first.
        let tc = cyril_core::types::ToolCall::new(
            cyril_core::types::ToolCallId::new("tc_1"),
            "Reading".into(),
            cyril_core::types::ToolKind::Read,
            cyril_core::types::ToolCallStatus::InProgress,
            None,
        );
        state.apply_notification(&Notification::ToolCallStarted(tc));
        assert_eq!(state.messages().len(), 2);
        assert!(matches!(
            state.messages()[0].kind(),
            ChatMessageKind::UserText(t) if t == "please read"
        ));
        assert!(matches!(
            state.messages()[1].kind(),
            ChatMessageKind::ToolCall(_)
        ));
    }

    // --- cyril-imjx: picker active-row marker ---
    //
    // kiro-cli 2.14.2 never sends `current` on `/model` options and only
    // encodes it into the `/effort` LABEL (`"High  [active]"`) after an
    // in-session change. Cyril already knows both values (they drive the
    // toolbar), so `show_picker` joins the option list against its own state.
    // Live shapes are from `experiments/conductor-spike/trace-2.4.1-tui-recorder.jsonl`.

    /// Live `/model` option: `{value,label,description,group}`, no `current`.
    fn live_model_option(id: &str) -> CommandOption {
        CommandOption {
            label: id.to_string(),
            value: id.to_string(),
            description: Some(format!("The {id} model")),
            group: Some("1.30x credits".into()),
            is_current: false,
        }
    }

    fn marked_values(state: &UiState) -> Vec<String> {
        state
            .picker()
            .map(|p| {
                p.options
                    .iter()
                    .filter(|o| o.is_current)
                    .map(|o| o.value.clone())
                    .collect()
            })
            .unwrap_or_default()
    }

    #[test]
    fn picker_marks_active_row_from_current_model() {
        let mut state = UiState::new(500);
        state.set_current_model(Some("claude-opus-4.7".into()));
        state.show_picker(
            "model".into(),
            vec![
                live_model_option("auto"),
                live_model_option("claude-opus-4.7"),
                live_model_option("claude-haiku-4.5"),
            ],
        );
        assert_eq!(
            marked_values(&state),
            vec!["claude-opus-4.7".to_string()],
            "the session's current model must be the single marked row"
        );
    }

    #[test]
    fn picker_marks_active_row_from_effort_on_a_fresh_session() {
        let mut state = UiState::new(500);
        state.effort = Some(EffortLevel::High);
        // Fresh session: no option carries `[active]` and none carries `current`.
        state.show_picker(
            "effort".into(),
            vec![
                CommandOption {
                    label: "Low".into(),
                    value: "low".into(),
                    description: None,
                    group: None,
                    is_current: false,
                },
                CommandOption {
                    label: "High".into(),
                    value: "high".into(),
                    description: None,
                    group: None,
                    is_current: false,
                },
            ],
        );
        assert_eq!(
            marked_values(&state),
            vec!["high".to_string()],
            "the session's effort level must be the single marked row"
        );
    }

    #[test]
    fn picker_marks_active_row_keeps_wire_current_as_fallback() {
        // An agent that DOES send `current` still marks correctly, even when
        // cyril has no value of its own to join against.
        let mut state = UiState::new(500);
        assert!(state.current_model.is_none(), "no own value to join on");
        let mut opts = vec![live_model_option("auto"), live_model_option("glm-5")];
        opts[1].is_current = true;
        state.show_picker("model".into(), opts);
        assert_eq!(marked_values(&state), vec!["glm-5".to_string()]);
    }

    #[test]
    fn picker_marks_active_row_overrides_a_stale_wire_current() {
        // Own state wins over the wire, and marks EXACTLY one row.
        let mut state = UiState::new(500);
        state.set_current_model(Some("glm-5".into()));
        let mut opts = vec![live_model_option("auto"), live_model_option("glm-5")];
        opts[0].is_current = true;
        state.show_picker("model".into(), opts);
        assert_eq!(marked_values(&state), vec!["glm-5".to_string()]);
    }

    #[test]
    fn picker_marks_active_row_marks_nothing_when_the_value_is_absent() {
        // Current model not in the list (version skew): mark nothing rather
        // than guess.
        let mut state = UiState::new(500);
        state.set_current_model(Some("model-from-the-future".into()));
        state.show_picker("model".into(), vec![live_model_option("auto")]);
        assert!(marked_values(&state).is_empty());
    }

    #[test]
    fn picker_does_not_reuse_model_from_previous_session() {
        let mut state = UiState::new(500);
        state.set_current_model(Some("old-model".into()));
        state.apply_notification(&Notification::SessionCreated {
            session_id: SessionId::new("new-session"),
            current_mode: None,
            current_model: None,
            available_modes: Vec::new(),
            available_models: Vec::new(),
        });
        let mut options = vec![
            live_model_option("old-model"),
            live_model_option("new-model"),
        ];
        options[1].is_current = true;

        state.show_picker("model".into(), options);

        assert_eq!(marked_values(&state), vec!["new-model".to_string()]);
    }

    #[test]
    fn picker_uses_model_and_effort_from_switched_agent() {
        let mut state = UiState::new(500);
        state.set_current_model(Some("old-model".into()));
        state.effort = Some(EffortLevel::High);
        state.apply_notification(&Notification::AgentSwitched {
            name: "new-agent".into(),
            welcome: None,
            previous_agent: Some("old-agent".into()),
            model: Some("new-model".into()),
        });

        let mut model_options = vec![
            live_model_option("old-model"),
            live_model_option("new-model"),
        ];
        model_options[1].is_current = true;
        state.show_picker("model".into(), model_options);
        assert_eq!(marked_values(&state), vec!["new-model".to_string()]);

        let effort_options = vec![
            CommandOption {
                label: "High".into(),
                value: "high".into(),
                description: None,
                group: None,
                is_current: false,
            },
            CommandOption {
                label: "Medium".into(),
                value: "medium".into(),
                description: None,
                group: None,
                is_current: true,
            },
        ];
        state.show_picker("effort".into(), effort_options);
        assert_eq!(marked_values(&state), vec!["medium".to_string()]);
    }

    #[test]
    fn picker_does_not_reuse_model_when_switched_agent_omits_model() {
        let mut state = UiState::new(500);
        state.set_current_model(Some("old-model".into()));
        state.apply_notification(&Notification::AgentSwitched {
            name: "new-agent".into(),
            welcome: None,
            previous_agent: Some("old-agent".into()),
            model: None,
        });
        let mut options = vec![live_model_option("old-model"), live_model_option("auto")];
        options[1].is_current = true;

        state.show_picker("model".into(), options);

        assert_eq!(marked_values(&state), vec!["auto".to_string()]);
    }

    // --- @-completion availability fences (bug class: silently empty completion) ---

    const UNAVAILABLE_NEEDLE: &str = "@-file completion unavailable";

    /// End-to-end repro: loading the completer in a non-git cwd fails, and the
    /// FIRST time the user actually triggers @-completion, exactly one system
    /// message explains why nothing appears. Repeated triggers never add a
    /// second notice.
    #[tokio::test]
    async fn completion_unavailable_notice_shown_once() {
        let dir = tempfile::tempdir().expect("tempdir");
        let completer = FileCompleter::load(dir.path()).await;

        let mut state = UiState::new(500);
        state.set_file_completer(completer);
        assert_eq!(
            system_message_count(&state, UNAVAILABLE_NEEDLE),
            0,
            "no notice before the user triggers @-completion"
        );

        state.insert_text("@x");
        assert_eq!(
            system_message_count(&state, UNAVAILABLE_NEEDLE),
            1,
            "first @-trigger with a failed completer must surface one notice"
        );
        assert!(
            state.autocomplete_suggestions().is_empty(),
            "an unavailable completer must not offer suggestions"
        );

        // Further triggers — extending the query and starting a fresh @ token —
        // must not repeat the notice.
        state.insert_text("y");
        state.insert_text(" @z");
        assert_eq!(
            system_message_count(&state, UNAVAILABLE_NEEDLE),
            1,
            "the unavailability notice must appear exactly once"
        );
    }

    /// A git repo where `git ls-files` SUCCEEDS with zero files is NOT a
    /// failure: loaded-empty must never trigger the unavailability notice.
    #[tokio::test]
    async fn no_notice_when_git_repo_empty() {
        let dir = tempfile::tempdir().expect("tempdir");
        let status = std::process::Command::new("git")
            .args(["init", "--quiet"])
            .current_dir(dir.path())
            .status()
            .expect("spawn git init");
        assert!(status.success(), "git init failed");

        let completer = FileCompleter::load(dir.path()).await;
        let mut state = UiState::new(500);
        state.set_file_completer(completer);

        state.insert_text("@x");
        assert_eq!(
            system_message_count(&state, UNAVAILABLE_NEEDLE),
            0,
            "an empty-but-successful git repo must not be reported as unavailable"
        );
    }

    /// A completer that loaded fine keeps completing silently — no notice.
    #[test]
    fn no_notice_when_completer_has_files() {
        let mut state = UiState::new(500);
        state.set_file_completer(FileCompleter::from_files(vec!["src/main.rs".into()]));

        state.insert_text("@main");
        assert!(
            !state.autocomplete_suggestions().is_empty(),
            "a loaded completer must keep suggesting"
        );
        assert_eq!(system_message_count(&state, UNAVAILABLE_NEEDLE), 0);
    }

    // ── cyril-qaq0: /theme picker ───────────────────────────────────────────

    fn theme_picker_state() -> UiState {
        let mut state = UiState::new(500);
        state.open_theme_picker();
        state
    }

    #[test]
    fn theme_picker_lists_every_bundled_palette() {
        let state = theme_picker_state();
        assert_eq!(state.picker_title(), Some("theme"));
        assert_eq!(state.picker_kind(), Some(&PickerKind::Theme));
        let Some(picker) = TuiState::picker(&state) else {
            panic!("theme picker must be open");
        };
        assert_eq!(picker.options.len(), ThemeId::ALL.len());
        for theme in ThemeId::ALL.iter().copied() {
            let config_id = theme_config_id(theme);
            let option = picker
                .options
                .iter()
                .find(|option| option.value == config_id)
                .unwrap_or_else(|| panic!("{config_id} missing from the picker"));
            assert_eq!(option.label, theme_label(theme));
            assert_eq!(
                option.is_current,
                theme == ThemeId::CyrilDark,
                "{config_id} marked as current"
            );
        }
    }

    // C4: the preview drives what the renderer resolves, while the committed
    // appearance stays untouched until Enter.
    #[test]
    fn theme_preview_drives_the_rendered_theme_until_commit() {
        let mut state = theme_picker_state();
        for character in "gruvbox".chars() {
            state.picker_type_char(character);
        }
        assert_eq!(
            TuiState::theme(&state),
            resolve(ThemeId::GruvboxDark, ColorMode::TrueColor),
            "the filtered selection must preview"
        );
        assert_eq!(
            state.theme_id(),
            ThemeId::CyrilDark,
            "previewing must not commit"
        );

        assert_eq!(state.commit_theme(), Some(ThemeId::GruvboxDark));
        assert_eq!(state.theme_id(), ThemeId::GruvboxDark);
        assert_eq!(
            TuiState::theme(&state),
            resolve(ThemeId::GruvboxDark, ColorMode::TrueColor)
        );
        assert_eq!(state.picker_kind(), None, "commit closes the picker");
    }

    // C5: Esc discards. The committed appearance is exactly what it was, and no
    // preview survives the close.
    #[test]
    fn picker_cancel_discards_the_preview() {
        let committed = resolve(ThemeId::CyrilDark, ColorMode::TrueColor);
        let mut state = theme_picker_state();
        state.picker_select_next();
        assert_ne!(TuiState::theme(&state), committed, "selection must preview");

        state.picker_cancel();
        assert_eq!(state.theme_id(), ThemeId::CyrilDark);
        assert_eq!(state.color_mode(), ColorMode::TrueColor);
        assert_eq!(
            TuiState::theme(&state),
            committed,
            "Esc must restore the committed theme"
        );
        assert_eq!(state.picker_kind(), None);
    }

    // A palette choice must not silently change how colors are emitted.
    #[test]
    fn commit_theme_preserves_the_active_color_mode() {
        let mut state = UiState::new(500);
        state.set_appearance(ThemeId::CyrilDark, ColorMode::Ansi256);
        state.open_theme_picker();
        state.picker_select_next();
        assert_eq!(state.commit_theme(), Some(ThemeId::CyrilLight));
        assert_eq!(state.color_mode(), ColorMode::Ansi256);
        assert_eq!(
            TuiState::theme(&state),
            resolve(ThemeId::CyrilLight, ColorMode::Ansi256)
        );
    }

    // The agent picker keeps its own commit path: `commit_theme` must not
    // swallow it, and must leave it open.
    #[test]
    fn commit_theme_is_inert_for_an_agent_picker() {
        let mut state = UiState::new(500);
        state.show_picker(
            "model".into(),
            vec![CommandOption {
                label: "sonnet".into(),
                value: "sonnet".into(),
                description: None,
                group: None,
                is_current: false,
            }],
        );
        assert_eq!(state.picker_kind(), Some(&PickerKind::Agent));
        assert_eq!(state.commit_theme(), None);
        assert_eq!(
            state.picker_kind(),
            Some(&PickerKind::Agent),
            "an agent picker must stay open"
        );
        assert_eq!(
            state
                .picker_confirm()
                .map(|confirmation| confirmation.title),
            Some("model".to_owned())
        );
    }

    #[test]
    fn picker_opens_on_the_committed_palette() {
        let mut state = UiState::new(500);
        state.set_appearance(ThemeId::CatppuccinMocha, ColorMode::TrueColor);
        state.open_theme_picker();
        assert_eq!(
            TuiState::theme(&state),
            resolve(ThemeId::CatppuccinMocha, ColorMode::TrueColor),
            "the picker must open previewing the committed palette"
        );
        assert_eq!(state.commit_theme(), Some(ThemeId::CatppuccinMocha));
    }
}
