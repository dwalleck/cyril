use crate::types::command::{CommandInfo, ConfigOption};
use crate::types::message::{AgentMessage, AgentThought, UserMessage};
use crate::types::plan::Plan;
use crate::types::session::{
    CompactionPhase, ContextBreakdown, ContextUsage, EffortUpdate, ModeId, ModelInfo,
    ReasoningInfo, RefusalAlert, SessionId, SessionMode, StopReason, TokenCounts, TurnMetering,
};
use crate::types::thinking::ThinkingLever;
use crate::types::tool_call::{ToolCall, ToolCallId};
use crate::types::turn::TurnId;
use crate::types::usage::{Money, SessionOrigin, TokenUsage, TurnMeteringUpdate, UsageAccount};
use crate::types::workflow::{WorkflowEvent, WorkflowSnapshot};
use crate::types::workflow_command::{WorkflowCommandOutcome, WorkflowOp};

/// KAS `_kiro/system/notify` severity level (KAS 0.17.2+).
/// Currently `info` and `warning`; the `Unknown` arm captures future levels
/// without a parse failure so cyril doesn't reject a notification it can still
/// render.
#[derive(Debug, Clone, PartialEq)]
pub enum SystemNotifyLevel {
    Info,
    Warning,
    Unknown(String),
}

/// `BridgeError.operation` for a failed `session/set_config_option` — KAS
/// model/mode/effort sets and the KAS thinking lever. The mediator emits it
/// and consumers that reconcile a failed set (the session's pending config
/// request, the review workbench) match it, so the label lives in one place.
pub const SET_CONFIG_OPTION_OPERATION: &str = "set_config_option";

/// Notifications emitted by the ACP bridge. All variants are Send + Sync + Clone.
/// This is the primary channel for agent state updates crossing from the bridge thread into the App.
#[derive(Debug, Clone)]
pub enum Notification {
    // Agent output
    AgentMessage(AgentMessage),
    AgentThought(AgentThought),

    // User messages (replayed by the agent during session/load history replay)
    UserMessage(UserMessage),

    // Tool lifecycle
    ToolCallStarted(ToolCall),
    ToolCallUpdated(ToolCall),

    // Session state
    PlanUpdated(Plan),
    ModeChanged {
        mode_id: ModeId,
    },
    ConfigOptionsUpdated(Vec<ConfigOption>),
    /// Catalog returned by a successful standard configuration change.
    /// Unlike an unsolicited update, this acknowledges the requested option.
    ConfigOptionSet {
        config_id: String,
        options: Vec<ConfigOption>,
    },
    /// The v2 `reasoning` command acknowledged a thinking toggle with
    /// `success: true` (cyril-k3lz). Carries the REQUESTED value — the ack
    /// has no session value of its own; the state itself arrives on the next
    /// `kiro.dev/metadata` `reasoning` snapshot. KAS acks via `ConfigOptionSet`.
    ThinkingToggled {
        enabled: bool,
    },
    CommandsUpdated {
        commands: Vec<CommandInfo>,
        prompts: Vec<crate::types::PromptInfo>,
    },

    // Command system
    CommandOptionsReceived {
        command: String,
        options: Vec<crate::types::command::CommandOption>,
    },

    /// Response from executing an agent command via kiro.dev/commands/execute.
    CommandExecuted {
        command: String,
        response: serde_json::Value,
    },

    /// Response from `kiro.dev/settings/list`. Carries Kiro's on-disk
    /// settings snapshot as a flat dotted-key map (`chat.enableThinking`,
    /// `introspect.progressiveMode`, etc.) with optional sub-object
    /// nesting (`chat: {...}` alongside `chat.enableNotifications: true`).
    /// Round-trips `~/.kiro/settings/cli.json` byte for byte.
    SettingsList {
        settings: serde_json::Value,
    },

    // Kiro extensions
    MetadataUpdated {
        /// Context-window usage percentage. `None` when the metadata frame
        /// omits `contextUsagePercentage` — a real wire shape (observed in
        /// 2.4.1 multi-subagent captures: duration/effort-only frames), so
        /// consumers must treat absence as "no update", not "dropped to
        /// zero" (retain-last, same discipline as `effort` below).
        context_usage: Option<ContextUsage>,
        metering: Option<TurnMetering>,
        tokens: Option<TokenCounts>,
        /// Turn duration in ms, parsed independently of `meteringUsage`
        /// (cyril-1gim): Kiro emits duration/effort-only frames (real 2.4.1
        /// shape) with no credits aggregate. Carried separately so a lone
        /// duration reaches the turn summary instead of being dropped with
        /// the absent metering. `None` when the frame omits `turnDurationMs`.
        duration_ms: Option<u64>,
        /// Effort-level change from the `effort` field on `kiro.dev/metadata`
        /// (Kiro 2.5.0+). Tri-state per the wire (cyril-1gim): `Unchanged`
        /// when the frame omits it — which happens on non-thinking models and
        /// (observed) mid-turn on context-only frames, so consumers must
        /// retain the current level, not clear it; `Clear` for an explicit
        /// `effort: null` (engine-initiated badge clear); `Set` with a known
        /// or backend-defined level.
        effort: EffortUpdate,
        /// The full `reasoning` snapshot (kiro-cli 2.23.0+, cyril-q1xs).
        /// `Some` whenever the frame carries a well-formed block; `effort`
        /// above is already derived from it (a block without an effort is
        /// `Clear`). `None` when the frame has no block (pre-2.23.0 wire,
        /// where `effort` comes from the top-level field instead), or when
        /// the block is corrupt — that case is warned at parse time and
        /// still clears the badge, matching Kiro's own fallback.
        reasoning: Option<ReasoningInfo>,
        /// Session ID from the params-level `sessionId` on `kiro.dev/metadata`
        /// (cyril-fh06). During agent_crew runs every subagent session emits
        /// its own metadata frame; the bridge → client pathway promotes this
        /// to a scoped `RoutedNotification` (same idiom as `ToolCallChunk`)
        /// so subagent frames never stamp the main toolbar. `None` when the
        /// frame omits the field — routed global, applies to main. By the
        /// time this notification reaches state machines, routing has already
        /// happened and this field is effectively just a tag.
        session_id: Option<SessionId>,
        /// Model-refusal alert (Kiro 2.12.1+, cyril-h8zb): `Some` when the
        /// frame carries a `refusal` object or `stopReason:"CONTENT_FILTERED"`
        /// (Kiro's own consumer alerts on either signal — an OR, not an AND).
        /// `None` on every other frame; absence means "no refusal", never
        /// "refusal cleared".
        refusal: Option<RefusalAlert>,
    },
    /// Per-turn non-money metering emitted before the lifecycle terminal.
    /// KAS carries this as `session_info_update` kind `turn_completion`; it
    /// must never be interpreted as [`Notification::TurnCompleted`].
    TurnMeteringUpdated(TurnMeteringUpdate),
    /// ACP `usage_update` session notification (unstable_session_usage).
    /// Carries absolute token counts rather than the percentage from
    /// `kiro.dev/metadata`. Both may arrive within a turn; whichever notification
    /// lands last wins (both write `context_usage` in UiState / SessionController).
    UsageUpdated {
        used: u64,
        size: u64,
        /// Cumulative session cost, when the agent supplies it.
        cost: Option<Money>,
    },
    /// KAS `session_info_update` → `context_usage` (KAS-2b, cyril-5et2). KAS
    /// pushes the categorized breakdown proactively each turn (v2 sends only the
    /// scalar via `MetadataUpdated`). `usage_percentage` is the flat
    /// `_meta.kiro.usagePercentage`; `breakdown` is `None` on frames that carry
    /// only the scalar — consumers must treat absence as "no update", not
    /// "cleared" (retain-last, same discipline as `MetadataUpdated.effort`).
    ContextBreakdownUpdated {
        usage_percentage: f64,
        breakdown: Option<ContextBreakdown>,
    },
    AgentSwitched {
        name: String,
        welcome: Option<String>,
        previous_agent: Option<String>,
        model: Option<String>,
    },
    /// Kiro-specific `kiro.dev/compaction/status`. `phase` carries the
    /// lifecycle state; `summary` is populated when Kiro provides a
    /// post-compaction summary (typically only with `Completed`).
    CompactionStatus {
        phase: CompactionPhase,
        summary: Option<String>,
    },
    ClearStatus {
        message: String,
    },
    RateLimited {
        message: String,
    },
    /// KAS `_kiro/system/notify {level, message}` — connection-scoped
    /// notification (KAS 0.17.2+, kiro-cli 2.12.3+). Fires on model-request
    /// backoff during ordinary KAS turns (not remote-only).
    SystemNotify {
        level: SystemNotifyLevel,
        message: String,
    },
    ToolCallChunk {
        tool_call_id: ToolCallId,
        title: String,
        kind: String,
        /// Session ID from the outer `kiro.dev/session/update` envelope.
        /// Used by the bridge → client pathway to convert into a
        /// `RoutedNotification` at the channel boundary. By the time this
        /// notification reaches state machines, routing has already happened
        /// and this field is effectively just a tag.
        session_id: Option<SessionId>,
    },
    McpServerInitFailure {
        server_name: String,
        error: Option<String>,
    },
    McpOAuthRequest {
        server_name: String,
        url: String,
    },
    /// A global host request to surface this exact, untrusted URL for manual
    /// authorization. Delivery does not mean a browser opened or OAuth completed.
    ExternalUrlRequested {
        url: String,
    },
    /// KAS reported an MCP connection failure. This is display-only: it neither
    /// completes a chat turn nor implies that the agent disconnected.
    McpConnectionError {
        message: String,
    },
    McpServerInitialized {
        server_name: String,
    },
    AgentNotFound {
        requested: String,
        fallback: Option<String>,
    },
    AgentConfigError {
        path: String,
        error: String,
    },
    ModelNotFound {
        requested: String,
        fallback: Option<String>,
    },

    // Queue steering (Kiro 2.7.0+, `_kiro.dev/session/update` echoes; ROADMAP K1a).
    // The three echo variants below are echoes of a steer the client requested —
    // emitted for cyril's own steers AND (future, multi-client) for steers another
    // client originated. The converter produces them unconditionally: even when the
    // payload field is absent the variant is still emitted, so the depth counter
    // always transitions (a dropped transition would desync it permanently). K1a
    // routes them global; the session_id from the envelope is intentionally dropped
    // (only ToolCallChunk is promoted to scoped routing today — scoped steering is
    // K1c, cyril-28z2). `SteeringUnsupported` is the exception: it is
    // bridge-synthesized, not a converter-produced wire echo.
    /// A steer was accepted and queued for injection at the next tool boundary.
    /// `message` is the steer text, or `None` when the echo omitted it — the frame
    /// is still counted; only the (K1b) display text degrades. Never `Some("")`.
    /// `message_id` is the queue id (`messageId` on the new-family v2 echoes and
    /// KAS; absent on the pre-rollout v2 dialect). Never `Some("")`.
    SteeringQueued {
        message: Option<String>,
        message_id: Option<String>,
    },
    /// A queued steer was injected into the turn at a tool boundary. `content` is
    /// the injected text, or `None` when the echo omitted it. The variant is emitted
    /// regardless of whether `content` parsed — dropping it on a missing field
    /// would permanently inflate the queue counter. `message_id` identifies which
    /// queued steer drained (new-family v2 / KAS; `None` on the old dialect).
    SteeringConsumed {
        content: Option<String>,
        message_id: Option<String>,
    },
    /// The agent injected an engine-originated message into the running turn
    /// through its steering buffer — NOT an operator steer (cyril-lki9 B5/B6).
    /// KAS marks these with a `notify-` `messageId`: `notify-wf-<uuid>` is a
    /// workflow completion delivered while the session was busy (instead of an
    /// auto-wake turn); any other `notify-<uuid>` is a relayed step verdict
    /// (`content` = `"[notification/<severity>] <message>"`). Never routed to the
    /// operator-steer reconciler. `content` is `None` when the echo omitted it;
    /// `severity` is KAS's `notificationSeverity`, `None` when absent.
    /// `workflow_completion` is the engine's classification (a `notify-wf-`
    /// id): the dialect literal stays in the converter.
    EngineMessageInjected {
        message_id: String,
        content: Option<String>,
        severity: Option<String>,
        workflow_completion: bool,
    },
    /// Queued steers were dropped before pickup (via `_session/steer/clear`, or
    /// KAS's routine post-injection cleanup). `message_ids` names which queue
    /// entries were dropped; EMPTY means "everything still queued" — the old
    /// v2 dialect's id-less shape (a semantic convention, fenced by the
    /// id-scoped UiState tests rather than a runtime check).
    SteeringCleared {
        message_ids: Vec<String>,
    },
    /// The agent does not implement `_session/steer` (`-32601`); bridge-synthesized,
    /// not a wire echo. Surfaced once per session as a system message. The
    /// once-per-session dedup lives in the bridge (its `steering_unsupported` set),
    /// NOT in `UiState`, which adds a system message for every one it receives.
    SteeringUnsupported {
        message: String,
    },
    /// The agent does not implement `_session/steer/clear` (`-32601`);
    /// bridge-synthesized, not a wire echo. Advisory ONLY: unlike
    /// `SteeringUnsupported` it must NOT drain chips, zero the queue counter,
    /// or mark the session steering-unsupported — steer itself still works
    /// (cyril-vgcm C12; the shared-set poisoning was findings F5).
    SteeringClearUnsupported {
        message: String,
    },

    // Subagent lifecycle (kiro.dev/subagent/*)
    SubagentListUpdated {
        subagents: Vec<crate::types::SubagentInfo>,
        pending_stages: Vec<crate::types::PendingStage>,
    },
    InboxNotification {
        session_id: SessionId,
        message_count: u32,
        escalation_count: u32,
        senders: Vec<String>,
    },
    /// A subagent was spawned successfully via `session/spawn`.
    SubagentSpawned {
        session_id: SessionId,
        name: String,
    },
    /// A subagent was terminated successfully via `session/terminate`.
    SubagentTerminated {
        session_id: SessionId,
    },
    /// A bridge command failed. Surfaces to the UI as a system message.
    /// `operation` is a stable label consumers may match on (e.g.
    /// [`SET_CONFIG_OPTION_OPERATION`]).
    BridgeError {
        operation: String,
        message: String,
    },

    /// KAS announced that its on-disk hook registry changed
    /// (`_kiro/hooks/didChange`, cyril-gk17). Carries the **full** new
    /// registry, so it is a replacement rather than a delta.
    ///
    /// Deliberately distinct from the `CommandExecuted{command: "hooks"}` path
    /// that *opens* the panel: this arrives unprompted whenever a file is
    /// edited, and a modal overlay that opens itself while the user is typing
    /// is a worse outcome than a stale one. It refreshes an already-open
    /// panel and is otherwise inert.
    HooksChanged {
        hooks: Vec<crate::types::HookInfo>,
    },

    /// KAS announced its installed power set (`_kiro/powers/items_changed`,
    /// cyril-v19o). Carries the **full** new catalog, so it is a replacement
    /// rather than a delta — a power uninstalled between two pushes disappears
    /// by its absence from the later list.
    ///
    /// Same deliberate split as [`Notification::HooksChanged`]: it arrives
    /// unprompted once per session (measured: +18 ms after `session/new`
    /// replies, with no client request involved), so it must never pop a modal
    /// open over the user. It updates the catalog and refreshes an
    /// already-open panel, and is otherwise inert.
    ///
    /// `None` on the session's stored catalog means "the agent has not reported
    /// yet", which is a different state from an empty catalog — see
    /// `SessionController::powers`.
    PowersChanged {
        powers: Vec<crate::types::PowerInfo>,
    },

    /// A KAS-side hook changed state (`session_info_update`,
    /// `_meta.kiro.kind = "hook_update"`; cyril-gk17).
    ///
    /// Under `kas_hooks = "kas"` the AGENT executes hooks on this host, and no
    /// `session/request_permission` precedes them — so the transcript record is
    /// the only thing standing between the user and shell commands running
    /// invisibly on their machine. That is why this is surfaced in chat rather
    /// than logged: an audit trail nobody sees is not an audit trail.
    ///
    /// EVERY state arrives here, progress included, so a hook that hangs still
    /// leaves a record. **This does not make the trail complete:** KAS emits no
    /// `hook_update` at all for some triggers — in `kas-v2hooks-2.16.0.jsonl`
    /// the `sessionStart` hook demonstrably ran (host-side evidence file) and
    /// produced zero frames, while only the `preToolUse` hook reported. Cyril
    /// cannot surface what is never sent; see [`KasHooksMode::Kas`] for what
    /// that costs the trust decision.
    ///
    /// [`KasHooksMode::Kas`]: crate::types::KasHooksMode::Kas
    HookExecuted {
        name: String,
        /// Carved status vocabulary: `completed` | `failed` | `canceled` |
        /// `running` | `awaiting_approval` (`mapActionStateToHookStatus`). Kept
        /// as a `String` so a new upstream state surfaces verbatim instead of
        /// being silently reclassified.
        status: String,
        /// Present for `runCommand` hooks that reported one.
        exit_code: Option<i64>,
    },

    /// KAS workflow lifecycle frame. Boxed so unrelated notifications retain
    /// the enum's pre-workflow stack footprint.
    Workflow(Box<WorkflowEvent>),

    /// A persisted run's state fetched by a `/workflow` command (`inspect` /
    /// `new` reply). Consumed exactly once by the App —
    /// `WorkflowTracker::apply_snapshot` — and never forwarded to
    /// `SessionController` or `UiState`, mirroring [`Notification::Workflow`].
    /// Sent *before* its companion [`Notification::WorkflowCommand`] so the
    /// tracker is current by the time the outcome message renders.
    WorkflowSnapshot(Box<WorkflowSnapshot>),

    /// Outcome of one `/workflow` command op, rendered by `UiState` as a
    /// system message. Every dispatched [`BridgeCommand::Workflow`] produces
    /// exactly one of these (or a `BridgeError`) — never silence. Unboxed on
    /// purpose: the outcome is 64 bytes against the enum's 216 (heavy state
    /// rides inside `Fetched`'s own `Box<WorkflowSnapshot>`), so a box here
    /// would be indirection without a size win — see the fence below.
    WorkflowCommand(WorkflowCommandOutcome),

    /// A workflow `send_message` between a step and its run's parent, relayed
    /// by KAS `_kiro/session/notify` (cyril-9104). Global: the App hands it to
    /// the `WorkflowTracker` once (a step's question, the parent's answer) and
    /// never forwards it to `SessionController` or `UiState`. Boxed like
    /// [`Notification::Workflow`].
    WorkflowMessage(Box<crate::types::WorkflowMessage>),
    /// cyril-9104 review: the `session/prompt` carrying the user's answer to
    /// a parked workflow step failed. Names the step session so the App can
    /// reopen the park episode `/answer` closed on dispatch (the step is
    /// still waiting), then renders like a `BridgeError`.
    WorkflowStepAnswerFailed {
        session_id: SessionId,
        message: String,
    },
    UsageAccountUpdated {
        account: UsageAccount,
        fetched_at_ms: Option<u64>,
    },
    UsageAccountQueryFailed {
        message: String,
    },

    // Lifecycle
    /// Usage-only lifecycle marker emitted before `SessionCreated`, preserving
    /// whether a cumulative cost starts at zero or resumes existing history.
    UsageSessionStarted {
        session_id: SessionId,
        origin: SessionOrigin,
    },
    /// Standard ACP prompt-response usage for the active turn. The bridge emits
    /// this immediately before `TurnCompleted` on the same routed turn.
    TurnUsageCaptured(TokenUsage),
    SessionCreated {
        session_id: SessionId,
        current_mode: Option<ModeId>,
        current_model: Option<String>,
        /// Full mode catalog from `NewSessionResponse.modes.availableModes`.
        /// Empty when the agent didn't report any.
        available_modes: Vec<SessionMode>,
        /// Full model catalog from `NewSessionResponse.models.availableModels`.
        /// Populated when the agent reports models (cyril enables the
        /// `unstable_session_model` ACP feature). Empty otherwise.
        available_models: Vec<ModelInfo>,
    },
    /// The agent started this turn itself, with no client prompt (cyril-lki9
    /// C10) — e.g. a KAS workflow auto-wake (`reason` = `workflow-complete-wake`)
    /// or a step woken by a message (`send-message-wake`). Emitted by the
    /// bridge exactly once per session per turn, immediately before the turn's
    /// first agent-initiated frame, scoped to that frame's session, so it routes
    /// exactly as the turn's content does.
    AgentInitiatedTurn(AgentInitiation),
    /// A turn began on the session — KAS `session_info_update{kind:"turn_start"}`
    /// (cyril-lki9 B7). Carries no origin: it opens both cyril's own prompt turns
    /// and agent-initiated turns (workflow auto-wakes), which cyril never
    /// requested and which can stay silent for a minute before their first
    /// frame. The v2 engine never emits it (v2 turns begin with cyril's prompt).
    TurnStarted,
    TurnCompleted {
        stop_reason: StopReason,
    },
    /// The active turn has gone quiet past the stall threshold with no
    /// host-side work outstanding (cyril-14ou; CONTEXT.md "Stalled turn").
    /// Information, never a terminal: the turn is still live and can complete
    /// minutes later (a captured stall finished after 16), so this must not
    /// release the busy guard — the mediator forwards it untouched. Emitted at
    /// most once per quiet period, scoped to the stalled turn's session.
    TurnStalled {
        /// How long the turn had been quiet when the signal fired.
        quiet: std::time::Duration,
    },
    BridgeDisconnected {
        reason: String,
    },
}

/// A notification paired with its source session ID for routing.
///
/// `session_id == None` means the notification is **global** — bridge
/// lifecycle events (`BridgeDisconnected`, `SubagentSpawned`, etc.),
/// `SubagentListUpdated`, or anything else that doesn't belong to a specific
/// ACP session. The App routes `None` through its main pipeline because
/// there's nothing to compare against.
///
/// `session_id == Some(id)` means the notification originated from a
/// specific session (every standard ACP `SessionNotification` is wrapped
/// this way with the envelope's `session_id`). The App compares `id` against
/// its known main session: if it matches, dispatches to the main state
/// machines; otherwise routes to `SubagentUiState`.
///
/// This is the primary channel type from the bridge to the App.
#[derive(Debug, Clone)]
pub struct RoutedNotification {
    pub session_id: Option<SessionId>,
    pub notification: Notification,
    /// Which accepted turn this notification belongs to, when that is knowable
    /// (cyril-a71q).
    ///
    /// `Some(id)` — the bridge synthesized this from a source it owns (a prompt
    /// RPC result, or an error path), so it can name the turn exactly.
    ///
    /// `None` — no turn identity is available. This is the normal, expected
    /// state for the KAS wire `turn_end`: the producer emits
    /// `{kind, stopReason}` and nothing else. `executionId` exists only on KAS's
    /// *persisted* record, never on the wire frame — source-confirmed in
    /// `.cyril-a71q/corroboration-2026-07-26.md`. Those completions are resolved
    /// by session against the companion ledger instead.
    ///
    /// `Option` for genuinely-absent, never a sentinel: a `TurnId(0)` stand-in
    /// would collide with the first id the allocator ever issues.
    pub turn: Option<TurnId>,
    /// The agent started this frame's turn itself (cyril-lki9): `Some` exactly
    /// when the engine reported the frame as agent-initiated — KAS tags every
    /// chunk and tool frame of such a turn with `_meta.kiro.agentInitiated`.
    /// Envelope metadata beside `session_id` and `turn`, never content: the
    /// turn mediator reads it to emit one [`Notification::AgentInitiatedTurn`]
    /// per turn (cyril-lki9 C10); content consumers never need it. `None` for
    /// everything else, and always on the v2 engine.
    pub origin: Option<AgentInitiation>,
}

/// A frame of a turn the agent started without a client prompt (cyril-lki9) —
/// e.g. a KAS workflow auto-wake. `reason` is the engine's stated reason
/// (`agentInitiatedReason`, e.g. `"workflow-complete-wake"`), `None` when the
/// frame did not say.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AgentInitiation {
    reason: Option<String>,
    workflow_completion: bool,
}

impl AgentInitiation {
    /// An empty reason is treated as absent, like every other optional wire
    /// string cyril reads (CLAUDE.md "Guard partial updates").
    /// `workflow_completion` is the engine's own classification of the reason
    /// (KAS: `workflow-complete-wake`), so no consumer matches dialect strings.
    pub fn new(reason: Option<String>, workflow_completion: bool) -> Self {
        Self {
            reason: reason.filter(|r| !r.is_empty()),
            workflow_completion,
        }
    }

    pub fn reason(&self) -> Option<&str> {
        self.reason.as_deref()
    }

    /// The turn is the engine's follow-up to a workflow run ending — the one
    /// reason whose header names a run (cyril-lki9 B1).
    pub fn is_workflow_completion(&self) -> bool {
        self.workflow_completion
    }
}

impl RoutedNotification {
    /// Create a routed notification with no session scope (global or main).
    pub fn global(notification: Notification) -> Self {
        Self {
            session_id: None,
            notification,
            turn: None,
            origin: None,
        }
    }

    /// Create a routed notification scoped to a specific session.
    pub fn scoped(session_id: SessionId, notification: Notification) -> Self {
        Self {
            session_id: Some(session_id),
            notification,
            turn: None,
            origin: None,
        }
    }

    /// Stamp this notification with the turn that owns it.
    ///
    /// Used by the bridge on completions it synthesizes itself, where the owning
    /// turn is known. Wire-sourced frames keep `turn: None` — see the field docs.
    #[must_use]
    pub fn with_turn(mut self, turn: TurnId) -> Self {
        self.turn = Some(turn);
        self
    }

    /// Mark this frame as belonging to an agent-initiated turn (cyril-lki9).
    /// Set only by the bridge's inbound path, from the engine's report.
    #[must_use]
    pub fn with_origin(mut self, origin: AgentInitiation) -> Self {
        self.origin = Some(origin);
        self
    }
}

impl From<Notification> for RoutedNotification {
    fn from(notification: Notification) -> Self {
        Self::global(notification)
    }
}

/// A trust tier option from `_meta.trustOptions[]` on permission requests.
/// Represents a level of persistent trust the user can grant (e.g. "Full command",
/// "Base command") with pre-built regex patterns for storage.
#[derive(Debug, Clone)]
pub struct TrustOption {
    pub label: String,
    pub display: String,
    pub setting_key: String,
    pub patterns: Vec<String>,
}

/// A request from the agent that needs user approval.
/// NOT Clone — owns a oneshot sender for the response.
#[derive(Debug)]
pub struct PermissionRequest {
    pub session_id: SessionId,
    pub tool_call: ToolCall,
    pub message: String,
    pub options: Vec<PermissionOption>,
    pub trust_options: Vec<TrustOption>,
    /// Whether this request may offer the KAS-only rejection-feedback action.
    ///
    /// The mediator computes this once from its immutable configured engine and
    /// build features; it is not inferred from request payloads.
    pub can_reject_with_reason: bool,
    pub responder: tokio::sync::oneshot::Sender<PermissionResponse>,
    /// What a KAS request asks for (`_meta.kiro`), typed at the conversion
    /// boundary; `None` when the agent sends no consent metadata. An armed
    /// `/review` decides its step sessions' requests from this alone.
    pub consent: Option<crate::review::consent::PermissionConsent>,
    /// The workflow plan a KAS `update_workflow` request asks the user to
    /// approve (`_meta.kiro.workflowPlan`, cyril-8wh0), typed at the
    /// conversion boundary; `None` for every other request.
    pub workflow_plan: Option<Box<super::WorkflowPlan>>,
}

/// The semantic kind of a permission option. Mirrors `acp::PermissionOptionKind`.
/// Replies carry the picked option's id (`PermissionResponse::Selected`), not
/// the kind; the kind drives UI concerns — the AllowAlways trust-phase
/// transition and destructive-option styling.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PermissionOptionKind {
    AllowOnce,
    AllowAlways,
    RejectOnce,
    RejectAlways,
}

/// Unique identifier of a permission option within one request. Newtype
/// preventing labels or other strings being passed where the wire optionId
/// belongs.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct PermissionOptionId(String);

impl PermissionOptionId {
    pub fn new(id: impl Into<String>) -> Self {
        Self(id.into())
    }

    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl std::fmt::Display for PermissionOptionId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(&self.0)
    }
}

/// An option in a permission request dialog.
#[derive(Debug, Clone)]
pub struct PermissionOption {
    pub id: PermissionOptionId,
    pub label: String,
    pub kind: PermissionOptionKind,
    pub is_destructive: bool,
}

/// The user's response to a permission request.
#[derive(Debug, Clone)]
pub enum PermissionResponse {
    /// The user picked a specific option from the request's option list.
    ///
    /// `option_id` must name an option from the originating request; the
    /// converter warns at runtime if it doesn't (a foreign id would silently
    /// answer the agent with something it never offered).
    Selected {
        option_id: PermissionOptionId,
        /// Trust tier label from phase-2 selection (v2 `AllowAlways` flow).
        trust_option: Option<String>,
    },
    /// The user rejected a KAS `reject_once` option with optional feedback.
    ///
    /// The converter emits the same selected outcome as [`Self::Selected`]
    /// and only adds KAS response metadata when the option and reason satisfy
    /// the originating request's eligibility rules.
    RejectWithReason {
        option_id: PermissionOptionId,
        reason: String,
    },
    /// The user granted a KAS `allow_always` option at a chosen scope and
    /// resource (cyril-auxt). The converter emits the same selected outcome
    /// as [`Self::Selected`] and, when the option is an offered `allow_always`
    /// on the KAS engine, echoes the grant as `_meta.kiro.consent` — the only
    /// signal KAS persists an "Always allow" from.
    AlwaysAllow {
        option_id: PermissionOptionId,
        grant: crate::always_allow::AlwaysAllowGrant,
    },
    Cancel,
}

/// Commands sent from the App to the ACP bridge.
#[derive(Debug)]
pub enum BridgeCommand {
    SendPrompt {
        session_id: SessionId,
        prompt: crate::types::PromptEnvelope,
    },
    NewSession {
        cwd: std::path::PathBuf,
    },
    LoadSession {
        session_id: SessionId,
    },
    CancelRequest,
    SetMode {
        mode_id: String,
    },
    /// Request the agent switch to the given model via the standard ACP
    /// `session/set_model` method. Infrastructure-only today: `/model`
    /// currently routes through `ExecuteCommand` because Kiro does not
    /// advertise `session/set_model` in its capabilities.
    SetModel {
        model_id: String,
    },
    /// Set a standard ACP session configuration value. The agent's returned
    /// configuration is authoritative and arrives as `ConfigOptionsUpdated`.
    SetConfigOption {
        config_id: String,
        value: String,
    },
    /// Turn extended thinking on or off for the active session's current
    /// model (cyril-k3lz). `lever` comes from the snapshot that reported the
    /// model toggleable (`ThinkingState::lever`), so the bridge maps it to the
    /// matching wire request without consulting the bound engine: v2 acks as
    /// `ThinkingToggled`, KAS as `ConfigOptionSet{config_id: "thinking"}`.
    SetThinking {
        lever: ThinkingLever,
        enabled: bool,
    },
    ExtMethod {
        method: String,
        params: serde_json::Value,
    },
    /// Query Kiro's on-disk settings snapshot via `kiro.dev/settings/list`.
    /// Wire request takes empty `{}` params (non-empty hangs the agent —
    /// see `docs/cyril-acp-coverage-vs-2.4.1.md`). The response is a flat
    /// dotted-key map mirroring `~/.kiro/settings/cli.json`.
    ///
    /// Read-only. There is intentionally no `SetSetting` BridgeCommand:
    /// `kiro.dev/settings/set` is dead wire surface (tui.js has the name
    /// in its constants table with zero call sites; the TUI mutates
    /// settings by writing the cli.json file directly).
    ListSettings,
    /// Query KAS account plan, credits, bonuses, and overage state.
    QueryUsageAccount,
    QueryCommandOptions {
        command: String,
        session_id: SessionId,
    },
    /// Execute an agent command and emit the response as a notification.
    ExecuteCommand {
        command: String,
        session_id: SessionId,
        args: serde_json::Value,
    },
    // Subagent session control
    SpawnSession {
        task: String,
        name: String,
    },
    TerminateSession {
        session_id: SessionId,
    },
    SendMessage {
        session_id: SessionId,
        content: String,
    },
    /// Queue a mid-turn steer (Kiro 2.7.0+; ROADMAP K1a). Sent as an awaited
    /// `_session/steer` ExtRequest. -32601 marks the session unsupported.
    SteerSession {
        session_id: SessionId,
        message: String,
    },
    /// Drop the queued steer before pickup, via `_session/steer/clear`. Like
    /// `SteerSession`, a session already marked unsupported (prior -32601) is
    /// skipped silently — the bridge never re-sends on an unsupported session.
    ClearSteering {
        session_id: SessionId,
    },
    /// Query KAS's own hook registry via `_kiro/hooks/list` (cyril-gk17).
    ///
    /// Only meaningful under `kas_hooks = "kas"`, where the agent runs a
    /// file-watched `.kiro/hooks` loader and advertises no `hooks` command of
    /// its own. Under `"host"` cyril *serves* this same method instead, and
    /// asking the agent would query a registry it does not have.
    ListKasHooks {
        session_id: SessionId,
        /// Workspace roots to search, sent as `workspacePaths`.
        workspace_paths: Vec<std::path::PathBuf>,
    },
    /// One `/workflow` control-plane op against `_kiro/workflow/*`
    /// (ADR-0013: user-issued, whatever the workflow gate).
    /// Response-carrying like [`BridgeCommand::ListKasHooks`]: the bridge
    /// awaits the reply and answers with `WorkflowSnapshot`/`WorkflowCommand`
    /// notifications, or `BridgeError` — one outcome per op, always.
    Workflow {
        session_id: SessionId,
        /// Workspace roots, sent as `workspacePaths` where the verb requires
        /// them (`list` hard-fails with -32603 without an explicit array).
        workspace_paths: Vec<std::path::PathBuf>,
        op: WorkflowOp,
    },
    /// Flip a KAS hook's enabled flag via `_kiro/hooks/setEnabled`
    /// (cyril-gk17). The agent rewrites the flag in the backing hook **file**,
    /// so the change outlives the session.
    SetKasHookEnabled {
        session_id: SessionId,
        /// The registry's composite `"<filePath>#hook-<n>"` id. A bare hook
        /// name is not accepted by the agent.
        hook_id: crate::types::hook::HookId,
        enabled: bool,
        /// Workspace roots for the follow-up listing that reports the result.
        workspace_paths: Vec<std::path::PathBuf>,
    },
    /// Answer a workflow step parked on a question (cyril-9104): the user's
    /// text as `session/prompt` to the step session, which resumes the step
    /// and its run. Deliberately outside cyril's own turn mediation — the
    /// step's turn is not the main session's, so the main session stays free
    /// and its busy guard untouched. A failed prompt answers
    /// `Notification::WorkflowStepAnswerFailed` naming the step session;
    /// success is the run's own lifecycle frames.
    AnswerWorkflowStep {
        session_id: SessionId,
        answer: String,
    },
    Shutdown,
}

#[cfg(test)]
mod turn_stamp_tests {
    use super::*;

    fn note() -> Notification {
        Notification::TurnCompleted {
            stop_reason: crate::types::session::StopReason::EndTurn,
        }
    }

    /// STRESS FIXTURE (plan slice 2). Bug class: collapsing "no turn identity"
    /// into a sentinel such as `TurnId(0)`, which would make the identity-free
    /// KAS wire arm collide with the first id the allocator ever issues.
    /// Expected outcome, written before the implementation: the three arms are
    /// mutually distinguishable, and absent is not equal to zero.
    #[test]
    fn absent_turn_is_not_a_sentinel() {
        let synthesized = RoutedNotification::global(note()).with_turn(TurnId::new(0));
        let wire = RoutedNotification::scoped(SessionId::new("sess_main"), note());
        let v2 = RoutedNotification::global(note()).with_turn(TurnId::new(1));

        // The first-ever allocated id is 0 (slice 1). If absence were encoded as
        // TurnId(0) these two would be indistinguishable -- the whole point.
        assert_eq!(synthesized.turn, Some(TurnId::new(0)));
        assert_eq!(wire.turn, None, "wire turn_end carries no identity");
        assert_ne!(synthesized.turn, wire.turn);
        assert_ne!(synthesized.turn, v2.turn);

        // And absence must not silently coerce to a value.
        assert!(wire.turn.is_none());
        assert_ne!(wire.turn, Some(TurnId::new(0)));
    }

    #[test]
    fn constructors_default_to_unowned() {
        assert_eq!(RoutedNotification::global(note()).turn, None);
        assert_eq!(
            RoutedNotification::scoped(SessionId::new("s"), note()).turn,
            None
        );
        assert_eq!(RoutedNotification::from(note()).turn, None);
    }

    #[test]
    fn with_turn_preserves_scope() {
        let r = RoutedNotification::scoped(SessionId::new("sess_main"), note())
            .with_turn(TurnId::new(42));
        assert_eq!(r.session_id, Some(SessionId::new("sess_main")));
        assert_eq!(r.turn, Some(TurnId::new(42)));
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::test_support::must_succeed;
    use crate::types::tool_call::{ToolCallId, ToolCallStatus, ToolKind};
    use crate::types::{
        WorkflowId, WorkflowNodeId, WorkflowNodePath, WorkflowNodeStartDetails,
        WorkflowNodeStarted, WorkflowNodeType,
    };

    fn assert_send<T: Send>() {}
    fn assert_sync<T: Sync>() {}
    fn assert_clone<T: Clone>() {}

    #[test]
    fn notification_is_send_sync_clone() {
        assert_send::<Notification>();
        assert_sync::<Notification>();
        assert_clone::<Notification>();
    }

    #[test]
    fn workflow_notification_is_pointer_sized_and_owned() {
        assert_eq!(
            std::mem::size_of::<Box<WorkflowEvent>>(),
            std::mem::size_of::<usize>()
        );

        let workflow_id = must_succeed(
            WorkflowId::try_from("workflow".to_owned()),
            "non-empty workflow id",
        );
        let node_id = must_succeed(
            WorkflowNodeId::try_from("node".to_owned()),
            "non-empty node id",
        );
        let node_path = must_succeed(
            WorkflowNodePath::try_new(&workflow_id, vec!["workflow".to_owned(), "node".to_owned()]),
            "canonical node path",
        );
        let details = WorkflowNodeStartDetails::new()
            .with_agent_name("agent".to_owned())
            .with_session_id(SessionId::new("session"))
            .with_prompt("prompt".to_owned())
            .with_iteration(u32::MAX)
            .with_branch_id("branch".to_owned());
        let notification = Notification::Workflow(Box::new(WorkflowEvent::NodeStarted(
            WorkflowNodeStarted::new(
                workflow_id,
                node_id,
                node_path,
                WorkflowNodeType::Step,
                details,
            ),
        )));

        assert!(matches!(
            notification,
            Notification::Workflow(event) if event.method_name() == "node_start"
        ));
    }

    /// `WorkflowSnapshot` must stay boxed: unboxing it grows every channel
    /// message to at least the snapshot's size (648 vs 216 bytes measured on
    /// x86_64), and this comparison fails — a `Box<T>`-is-pointer-sized
    /// assert would be tautologically green forever. The unboxed
    /// `WorkflowCommandOutcome` (64 bytes) gets the inverse tripwire: if it
    /// ever outgrows the enum, inlining it has started costing every
    /// message — re-box it and flip that assert.
    #[test]
    fn workflow_payload_sizes_hold() {
        assert!(
            std::mem::size_of::<Notification>()
                < std::mem::size_of::<crate::types::WorkflowSnapshot>(),
            "WorkflowSnapshot must ride boxed"
        );
        assert!(
            std::mem::size_of::<crate::types::WorkflowCommandOutcome>()
                <= std::mem::size_of::<Notification>(),
            "WorkflowCommandOutcome outgrew the enum — re-box it"
        );
    }

    #[test]
    fn permission_request_is_send() {
        assert_send::<PermissionRequest>();
    }

    #[test]
    fn bridge_command_is_send() {
        assert_send::<BridgeCommand>();
    }

    #[test]
    fn notification_agent_message() {
        let n = Notification::AgentMessage(AgentMessage {
            text: "hello".into(),
            is_streaming: true,
        });
        assert!(matches!(n, Notification::AgentMessage(_)));
    }

    #[test]
    fn notification_tool_call_started() {
        let tc = ToolCall::new(
            ToolCallId::new("tc_1"),
            "read".into(),
            ToolKind::Read,
            ToolCallStatus::InProgress,
            None,
        );
        let n = Notification::ToolCallStarted(tc);
        assert!(matches!(n, Notification::ToolCallStarted(_)));
    }

    #[test]
    fn notification_metadata_updated() {
        use crate::types::session::EffortLevel;
        let n = Notification::MetadataUpdated {
            context_usage: Some(ContextUsage::new(75.0)),
            metering: None,
            tokens: None,
            duration_ms: None,
            effort: EffortUpdate::Set(EffortLevel::High),
            reasoning: None,
            session_id: Some(SessionId::new("sess_1")),
            refusal: None,
        };
        if let Notification::MetadataUpdated {
            context_usage,
            metering,
            tokens,
            duration_ms,
            effort,
            reasoning,
            session_id,
            refusal,
        } = n
        {
            assert!(reasoning.is_none());
            match context_usage {
                Some(ctx) => assert!((ctx.percentage() - 75.0).abs() < f64::EPSILON),
                None => panic!("context_usage should be present"),
            }
            assert!(metering.is_none());
            assert!(tokens.is_none());
            assert!(duration_ms.is_none());
            assert_eq!(effort, EffortUpdate::Set(EffortLevel::High));
            assert_eq!(session_id, Some(SessionId::new("sess_1")));
            assert!(refusal.is_none());
        } else {
            panic!("wrong variant");
        }
    }

    #[test]
    fn notification_turn_completed() {
        let n = Notification::TurnCompleted {
            stop_reason: StopReason::EndTurn,
        };
        assert!(matches!(n, Notification::TurnCompleted { .. }));
    }

    #[test]
    fn notification_bridge_disconnected() {
        let n = Notification::BridgeDisconnected {
            reason: "process exited".into(),
        };
        assert!(matches!(n, Notification::BridgeDisconnected { .. }));
    }

    #[test]
    fn notification_clone() {
        let n = Notification::AgentMessage(AgentMessage {
            text: "test".into(),
            is_streaming: false,
        });
        let n2 = n.clone();
        assert!(matches!(n2, Notification::AgentMessage(_)));
    }

    #[test]
    fn permission_option_fields() {
        let opt = PermissionOption {
            id: PermissionOptionId::new("allow_once"),
            label: "Allow Once".into(),
            kind: PermissionOptionKind::AllowOnce,
            is_destructive: false,
        };
        assert_eq!(opt.id.as_str(), "allow_once");
        assert_eq!(opt.kind, PermissionOptionKind::AllowOnce);
        assert!(!opt.is_destructive);
    }

    #[test]
    fn notification_user_message() {
        use crate::types::message::UserMessage;
        let n = Notification::UserMessage(UserMessage {
            text: "what does this do?".into(),
            is_streaming: true,
        });
        assert!(matches!(n, Notification::UserMessage(_)));
    }

    #[test]
    fn bridge_command_set_model() {
        let cmd = BridgeCommand::SetModel {
            model_id: "claude-opus-4.6".into(),
        };
        assert!(matches!(cmd, BridgeCommand::SetModel { .. }));
    }

    #[test]
    fn bridge_command_send_prompt() {
        let cmd = BridgeCommand::SendPrompt {
            session_id: SessionId::new("sess_1"),
            prompt: crate::types::PromptEnvelope::original(vec!["hello".into()]),
        };
        assert!(matches!(cmd, BridgeCommand::SendPrompt { .. }));
    }

    #[test]
    fn bridge_command_new_session() {
        let cmd = BridgeCommand::NewSession {
            cwd: std::path::PathBuf::from("/tmp"),
        };
        assert!(matches!(cmd, BridgeCommand::NewSession { .. }));
    }

    #[test]
    fn bridge_command_shutdown() {
        let cmd = BridgeCommand::Shutdown;
        assert!(matches!(cmd, BridgeCommand::Shutdown));
    }

    #[test]
    fn bridge_command_query_command_options() {
        let cmd = BridgeCommand::QueryCommandOptions {
            command: "model".into(),
            session_id: SessionId::new("sess_1"),
        };
        assert!(matches!(cmd, BridgeCommand::QueryCommandOptions { .. }));
    }

    #[test]
    fn notification_command_options_received() {
        let n = Notification::CommandOptionsReceived {
            command: "model".into(),
            options: vec![crate::types::command::CommandOption {
                label: "Claude Sonnet".into(),
                value: "claude-sonnet".into(),
                description: None,
                group: None,
                is_current: true,
            }],
        };
        if let Notification::CommandOptionsReceived { command, options } = n {
            assert_eq!(command, "model");
            assert_eq!(options.len(), 1);
            assert!(options[0].is_current);
        } else {
            panic!("wrong variant");
        }
    }

    #[test]
    fn notification_command_options_received_is_clone() {
        let n = Notification::CommandOptionsReceived {
            command: "model".into(),
            options: vec![],
        };
        let n2 = n.clone();
        assert!(matches!(n2, Notification::CommandOptionsReceived { .. }));
    }

    #[test]
    fn notification_command_executed() {
        let n = Notification::CommandExecuted {
            command: "tools".into(),
            response: serde_json::json!({"success": true, "message": "OK"}),
        };
        if let Notification::CommandExecuted { command, response } = n {
            assert_eq!(command, "tools");
            assert_eq!(response["success"], true);
            assert_eq!(response["message"], "OK");
        } else {
            panic!("wrong variant");
        }
    }

    #[test]
    fn notification_command_executed_is_clone() {
        let n = Notification::CommandExecuted {
            command: "context".into(),
            response: serde_json::json!({"success": true}),
        };
        let n2 = n.clone();
        assert!(matches!(n2, Notification::CommandExecuted { .. }));
    }

    #[test]
    fn subagent_notification_is_send_sync_clone() {
        assert_send::<crate::types::SubagentInfo>();
        assert_sync::<crate::types::SubagentInfo>();
        assert_clone::<crate::types::SubagentInfo>();
        assert_send::<crate::types::PendingStage>();
        assert_sync::<crate::types::PendingStage>();
        assert_clone::<crate::types::PendingStage>();
    }

    #[test]
    fn routed_notification_global_has_no_session_id() {
        let routed = RoutedNotification::global(Notification::TurnCompleted {
            stop_reason: StopReason::EndTurn,
        });
        assert!(routed.session_id.is_none());
        assert!(matches!(
            routed.notification,
            Notification::TurnCompleted { .. }
        ));
    }

    #[test]
    fn routed_notification_scoped_preserves_session_id() {
        let routed = RoutedNotification::scoped(
            SessionId::new("sub-1"),
            Notification::AgentMessage(AgentMessage {
                text: "hello".into(),
                is_streaming: true,
            }),
        );
        assert_eq!(
            routed.session_id.as_ref().map(|s| s.as_str()),
            Some("sub-1")
        );
    }

    #[test]
    fn notification_into_routed_is_global() {
        let routed: RoutedNotification = Notification::TurnCompleted {
            stop_reason: StopReason::EndTurn,
        }
        .into();
        assert!(routed.session_id.is_none());
    }

    #[test]
    fn subagent_list_updated_variant() {
        let n = Notification::SubagentListUpdated {
            subagents: vec![],
            pending_stages: vec![],
        };
        assert!(matches!(n, Notification::SubagentListUpdated { .. }));
    }

    #[test]
    fn inbox_notification_variant() {
        let n = Notification::InboxNotification {
            session_id: SessionId::new("main"),
            message_count: 2,
            escalation_count: 0,
            senders: vec!["subagent".into()],
        };
        if let Notification::InboxNotification {
            message_count,
            escalation_count,
            ..
        } = n
        {
            assert_eq!(message_count, 2);
            assert_eq!(escalation_count, 0);
        }
    }

    #[test]
    fn routed_notification_clone_preserves_session_id() {
        let original = RoutedNotification::scoped(
            SessionId::new("sub-1"),
            Notification::AgentMessage(AgentMessage {
                text: "hello from subagent".into(),
                is_streaming: true,
            }),
        );
        let cloned = original.clone();
        assert_eq!(
            cloned.session_id.as_ref().map(|s| s.as_str()),
            Some("sub-1")
        );
        if let Notification::AgentMessage(msg) = cloned.notification {
            assert_eq!(msg.text, "hello from subagent");
        } else {
            panic!("inner should be AgentMessage");
        }
    }

    #[test]
    fn bridge_command_execute_command() {
        let cmd = BridgeCommand::ExecuteCommand {
            command: "compact".into(),
            session_id: SessionId::new("sess_1"),
            args: serde_json::json!({}),
        };
        assert!(matches!(cmd, BridgeCommand::ExecuteCommand { .. }));
    }
}
