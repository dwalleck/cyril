//! KAS (`_kiro/*`) `session/update` specifics — the KAS analogue of
//! [`super::kiro`] for the v2 dialect. KAS rides standard ACP `session/update`
//! frames whose KAS-specific payload lives entirely in `_meta.kiro`.
//!
//! KAS-2a (cyril-j16p) Slice 1: recognise the `turn_end` lifecycle frame — the
//! signal that drives turn completion under KAS, in place of v2's prompt
//! response — and map it to [`Notification::TurnCompleted`].

use agent_client_protocol::schema::v1 as acp;

use super::kiro::{steering_message_id, steering_message_ids, steering_text};
use crate::types::{
    AgentEngine, AgentInitiation, ContextBreakdown, ContextBucket, ContextUsage, EffortMetadata,
    MeteredAmount, Notification, PermissionOptionId, StopReason, TurnMeteringUpdate, UsageAccount,
    UsageAccountBreakdown, UsageAddOnCredit, UsageBonusCredit, UsageTurnStatus,
};

pub(crate) mod notify;
pub(crate) mod powers;
pub(crate) mod workflow;
pub(crate) mod workflow_plan;

/// `_meta.kiro.workflowPlan` of a KAS `session/request_permission`
/// (cyril-8wh0): the plan an `update_workflow` approval asks the user to
/// accept before any of its steps run. `None` when the request carries no
/// plan, or (after a warning) a malformed one.
pub(crate) fn permission_workflow_plan(
    args: &acp::RequestPermissionRequest,
) -> Option<crate::types::WorkflowPlan> {
    let plan = args.meta.as_ref()?.get("kiro")?.get("workflowPlan")?;
    workflow_plan::parse(plan, &args.tool_call.tool_call_id.to_string())
}

/// `_meta.kiro.{toolId, command, consent{capability, resource, workspaceRoot}}`
/// of a KAS `session/request_permission`, with the commands the tool call's
/// `rawInput` carries. `None` when the request has no `_meta.kiro`.
pub(crate) fn permission_consent(
    args: &acp::RequestPermissionRequest,
    tool_call: &crate::types::ToolCall,
) -> Option<crate::review::consent::PermissionConsent> {
    let kiro = args.meta.as_ref()?.get("kiro")?.as_object()?;
    let text = |object: &serde_json::Map<String, serde_json::Value>, key: &str| {
        object
            .get(key)
            .and_then(serde_json::Value::as_str)
            .map(str::to_owned)
    };
    let empty = serde_json::Map::new();
    let consent = kiro
        .get("consent")
        .and_then(serde_json::Value::as_object)
        .unwrap_or(&empty);
    let raw_commands = tool_call
        .raw_input()
        .and_then(serde_json::Value::as_object)
        .map(|raw| {
            ["command", "cmd"]
                .iter()
                .filter_map(|key| text(raw, key))
                .collect()
        })
        .unwrap_or_default();
    Some(
        crate::review::consent::PermissionConsent::new(
            text(consent, "capability").as_deref(),
            text(consent, "resource"),
            text(consent, "workspaceRoot").map(std::path::PathBuf::from),
            text(kiro, "toolId"),
            text(kiro, "command"),
            raw_commands,
        )
        .with_triggering_resource(text(consent, "triggeringResource"))
        .with_explicit_ask(text(consent, "askType").as_deref() == Some("explicit")),
    )
}

/// Echo an "Always allow" grant as `_meta.kiro.consent{capability, scope,
/// resource, workspaceRoot}` on the response (cyril-auxt) — the only signal
/// KAS persists an `allow_always` from: scope `user` lands in
/// `~/.kiro/settings/permissions.yaml`, `workspace` in the workspace's
/// `permissions.yaml`, `session` widens the grant for the session. KAS reads
/// it from the response's top-level `_meta` (KAS 0.66.43 `S8e`).
///
/// Mirrors Kiro's TUI echo builder (`cw`, `kiro-tui-2.32.0.js`): `capability`
/// and `workspaceRoot` are the request's own `consent` values, verbatim, and
/// are omitted when the request has none. Only the KAS engine and an offered
/// `allow_always` option get the echo.
pub(crate) fn attach_consent_echo(
    response: acp::RequestPermissionResponse,
    args: &acp::RequestPermissionRequest,
    engine: AgentEngine,
    option_id: &PermissionOptionId,
    grant: &crate::always_allow::AlwaysAllowGrant,
) -> acp::RequestPermissionResponse {
    if engine != AgentEngine::Kas {
        return response;
    }
    // A foreign id was already reported by the converter's
    // `warn_if_foreign_permission_option`; only an offered option of another
    // kind is new information here.
    match args
        .options
        .iter()
        .find(|option| option.option_id.0.as_ref() == option_id.as_str())
    {
        None => return response,
        Some(option) if option.kind != acp::PermissionOptionKind::AllowAlways => {
            tracing::warn!(
                %option_id,
                kind = ?option.kind,
                "always-allow grant names an option that is not allow_always; answered without the consent echo"
            );
            return response;
        }
        Some(_) => {}
    }
    let requested = args
        .meta
        .as_ref()
        .and_then(|meta| meta.get("kiro"))
        .and_then(|kiro| kiro.get("consent"))
        .and_then(serde_json::Value::as_object);
    let verbatim = |key: &str| {
        requested
            .and_then(|consent| consent.get(key))
            .and_then(serde_json::Value::as_str)
            // The TUI's `oo`: a string with non-whitespace content, kept as sent.
            .filter(|value| !value.trim().is_empty())
            .map(|value| serde_json::Value::String(value.to_owned()))
    };
    let mut consent = serde_json::Map::new();
    if let Some(capability) = verbatim("capability") {
        consent.insert("capability".to_string(), capability);
    }
    consent.insert(
        "scope".to_string(),
        serde_json::Value::String(grant.scope().label().to_owned()),
    );
    consent.insert(
        "resource".to_string(),
        serde_json::Value::String(grant.resource().wire()),
    );
    if let Some(root) = verbatim("workspaceRoot") {
        consent.insert("workspaceRoot".to_string(), root);
    }
    let mut kiro = serde_json::Map::new();
    kiro.insert("consent".to_string(), serde_json::Value::Object(consent));
    let mut meta = serde_json::Map::new();
    meta.insert("kiro".to_string(), serde_json::Value::Object(kiro));
    response.meta(meta)
}

/// Attach KAS rejection feedback to the response-level metadata bag.
///
/// The generic permission converter owns the ACP outcome and dispatches here
/// only for a [`crate::types::PermissionResponse::RejectWithReason`] candidate.
/// It keeps the KAS key names and all eligibility checks in the KAS wire owner:
/// the bound engine must be KAS, the offered option ID must be exact and its
/// kind must be `reject_once`, and the reason must contain non-whitespace.
/// The accepted reason is moved into the JSON value unchanged.
pub(crate) fn attach_rejection_metadata(
    response: acp::RequestPermissionResponse,
    args: &acp::RequestPermissionRequest,
    engine: AgentEngine,
    option_id: PermissionOptionId,
    reason: String,
) -> acp::RequestPermissionResponse {
    if engine != AgentEngine::Kas || reason.trim().is_empty() {
        return response;
    }
    if !args.options.iter().any(|option| {
        option.option_id.0.as_ref() == option_id.as_str()
            && option.kind == acp::PermissionOptionKind::RejectOnce
    }) {
        return response;
    }
    let mut kiro = serde_json::Map::new();
    kiro.insert(
        "rejectionReason".to_string(),
        serde_json::Value::String(reason),
    );
    let mut meta = serde_json::Map::new();
    meta.insert("kiro".to_string(), serde_json::Value::Object(kiro));
    response.meta(meta)
}

/// Parse a select-option value's `_meta.kiro` effort block (cyril-vh69).
///
/// KAS marks effort-capable models on the `model` select option's values with
/// `{hasEffort, effortLevels[]?, defaultEffortLevel?}` (kiro-cli 2.31.1,
/// capture frame 24 of `kas-live-sweep-2.31.1.jsonl`). `hasEffort: false`
/// values carry NO effort fields at all (`auto`, `claude-sonnet-4`), so a
/// missing block is the normal case and converts silently to `None`.
///
/// The flag itself is never trusted: `hasEffort: true` with missing, empty,
/// or wrong-typed `effortLevels` (including non-string entries) warns and
/// converts to `None` rather than minting a levels-less effort model, and a
/// `defaultEffortLevel` outside the offered levels is dropped by
/// [`EffortMetadata::new`] with its own warning. A malformed block degrades
/// this ONE value to `effort: None` — it never fails the catalog around it.
pub(crate) fn effort_metadata(
    meta: Option<&serde_json::Map<String, serde_json::Value>>,
) -> Option<EffortMetadata> {
    let kiro = meta?.get("kiro")?;
    let has_effort = kiro.get("hasEffort").and_then(serde_json::Value::as_bool);
    let levels = match kiro.get("effortLevels") {
        None => None,
        Some(value) => match value.as_array() {
            Some(entries) => {
                let mut levels = Vec::with_capacity(entries.len());
                for entry in entries {
                    match entry.as_str().filter(|level| !level.is_empty()) {
                        Some(level) => levels.push(level.to_owned()),
                        None => {
                            tracing::warn!(
                                value = ?entry,
                                "KAS _meta.kiro effortLevels entry is not a non-empty string; \
                                 treating the model as effort-free"
                            );
                            return None;
                        }
                    }
                }
                Some(levels)
            }
            None => {
                tracing::warn!(
                    value = ?value,
                    "KAS _meta.kiro effortLevels is not an array; treating the model as effort-free"
                );
                return None;
            }
        },
    };
    match levels {
        Some(levels) if !levels.is_empty() => {
            let default = match kiro.get("defaultEffortLevel") {
                None | Some(serde_json::Value::Null) => None,
                Some(value) => match value.as_str().filter(|level| !level.is_empty()) {
                    Some(level) => Some(level.to_owned()),
                    None => {
                        tracing::warn!(
                            value = ?value,
                            "KAS _meta.kiro defaultEffortLevel is not a non-empty string; ignoring it"
                        );
                        None
                    }
                },
            };
            EffortMetadata::new(levels, default)
        }
        _ => {
            if has_effort == Some(true) {
                tracing::warn!(
                    "KAS _meta.kiro hasEffort is true but effortLevels is missing or empty; \
                     treating the model as effort-free"
                );
            }
            None
        }
    }
}

#[derive(Debug, thiserror::Error)]
pub(crate) enum AccountUsageParseError {
    #[error("account usage request failed: {0}")]
    Rejected(String),
    #[error("account usage response is missing {0}")]
    Missing(&'static str),
    #[error("account usage response has invalid {0}")]
    Invalid(&'static str),
}

pub(crate) fn account_usage_from_response(
    response: &serde_json::Value,
) -> Result<UsageAccount, AccountUsageParseError> {
    if response.get("success").and_then(serde_json::Value::as_bool) != Some(true) {
        let message = response
            .get("message")
            .and_then(serde_json::Value::as_str)
            .unwrap_or("agent returned success=false");
        return Err(AccountUsageParseError::Rejected(message.to_owned()));
    }
    let Some(data) = response.get("data").filter(|data| !data.is_null()) else {
        let message = response
            .get("message")
            .and_then(serde_json::Value::as_str)
            .filter(|message| !message.is_empty())
            .ok_or(AccountUsageParseError::Missing("data and message"))?;
        return Err(AccountUsageParseError::Rejected(message.to_owned()));
    };
    let breakdowns = required_array(data, "usageBreakdowns")?
        .iter()
        .map(parse_account_breakdown)
        .collect::<Result<Vec<_>, _>>()?;
    let bonus_credits = required_array(data, "bonusCredits")?
        .iter()
        .map(parse_bonus_credit)
        .collect::<Result<Vec<_>, _>>()?;
    let add_on_credits = required_array(data, "addOnCredits")?
        .iter()
        .map(parse_add_on_credit)
        .collect::<Result<Vec<_>, _>>()?;
    Ok(UsageAccount {
        plan_name: required_string(data, "planName")?.to_owned(),
        billing_cycle_reset: required_string(data, "billingCycleReset")?.to_owned(),
        overages_enabled: required_bool(data, "overagesEnabled")?,
        is_enterprise: required_bool(data, "isEnterprise")?,
        overage_capable: required_bool(data, "overageCapable")?,
        usage_breakdowns: breakdowns,
        bonus_credits,
        add_on_credits,
    })
}

fn parse_account_breakdown(
    value: &serde_json::Value,
) -> Result<UsageAccountBreakdown, AccountUsageParseError> {
    Ok(UsageAccountBreakdown {
        resource_type: required_string(value, "resourceType")?.to_owned(),
        display_name: required_string(value, "displayName")?.to_owned(),
        used: required_nonnegative(value, "used")?,
        has_limit: required_bool(value, "hasLimit")?,
        limit: required_nonnegative(value, "limit")?,
        percentage: required_percentage(value, "percentage")?,
        current_overages: required_nonnegative(value, "currentOverages")?,
        overage_rate: required_nonnegative(value, "overageRate")?,
        overage_charges: optional_nonnegative(value, "overageCharges")?,
        currency: required_string(value, "currency")?.to_owned(),
    })
}

fn parse_bonus_credit(
    value: &serde_json::Value,
) -> Result<UsageBonusCredit, AccountUsageParseError> {
    Ok(UsageBonusCredit {
        name: required_string(value, "name")?.to_owned(),
        used: required_nonnegative(value, "used")?,
        total: required_nonnegative(value, "total")?,
        days_until_expiry: value
            .get("daysUntilExpiry")
            .and_then(serde_json::Value::as_u64)
            .ok_or(AccountUsageParseError::Invalid(
                "bonusCredits[].daysUntilExpiry",
            ))?,
    })
}

fn parse_add_on_credit(
    value: &serde_json::Value,
) -> Result<UsageAddOnCredit, AccountUsageParseError> {
    Ok(UsageAddOnCredit {
        used: required_nonnegative(value, "used")?,
        total: required_nonnegative(value, "total")?,
        is_active: required_bool(value, "isActive")?,
        expires_at: optional_string(value, "expiresAt")?,
    })
}

fn optional_string(
    value: &serde_json::Value,
    field: &'static str,
) -> Result<Option<String>, AccountUsageParseError> {
    match value.get(field) {
        None | Some(serde_json::Value::Null) => Ok(None),
        Some(value) => value
            .as_str()
            .filter(|value| !value.is_empty())
            .map(|value| Some(value.to_owned()))
            .ok_or(AccountUsageParseError::Invalid(field)),
    }
}

fn required_string<'a>(
    value: &'a serde_json::Value,
    field: &'static str,
) -> Result<&'a str, AccountUsageParseError> {
    value
        .get(field)
        .and_then(serde_json::Value::as_str)
        .filter(|value| !value.is_empty())
        .ok_or(AccountUsageParseError::Invalid(field))
}

fn required_bool(
    value: &serde_json::Value,
    field: &'static str,
) -> Result<bool, AccountUsageParseError> {
    value
        .get(field)
        .and_then(serde_json::Value::as_bool)
        .ok_or(AccountUsageParseError::Invalid(field))
}

fn required_array<'a>(
    value: &'a serde_json::Value,
    field: &'static str,
) -> Result<&'a [serde_json::Value], AccountUsageParseError> {
    value
        .get(field)
        .and_then(serde_json::Value::as_array)
        .map(Vec::as_slice)
        .ok_or(AccountUsageParseError::Invalid(field))
}

fn required_nonnegative(
    value: &serde_json::Value,
    field: &'static str,
) -> Result<f64, AccountUsageParseError> {
    let amount = value
        .get(field)
        .and_then(serde_json::Value::as_f64)
        .ok_or(AccountUsageParseError::Invalid(field))?;
    if !amount.is_finite() || amount < 0.0 {
        return Err(AccountUsageParseError::Invalid(field));
    }
    Ok(amount)
}

fn optional_nonnegative(
    value: &serde_json::Value,
    field: &'static str,
) -> Result<Option<f64>, AccountUsageParseError> {
    match value.get(field) {
        None | Some(serde_json::Value::Null) => Ok(None),
        Some(_) => required_nonnegative(value, field).map(Some),
    }
}

fn required_percentage(
    value: &serde_json::Value,
    field: &'static str,
) -> Result<f64, AccountUsageParseError> {
    required_nonnegative(value, field).map(|percentage| percentage.min(100.0))
}

/// Exact workflow command exclusions: with the workflow gate on, KAS 0.66.43
/// advertises these four (`_meta.kiro.type:"workflow"`); cyril's own
/// `/workflow` family stays the user's control plane (ADR-0013 decision 4), so
/// they never become duplicate entries. Prefix matching would also suppress
/// supported agents such as workflow-creator.
const GATE_WORKFLOW_COMMANDS: [&str; 4] = [
    "workflow-run",
    "workflow-status",
    "workflow-cancel",
    "workflow-resume",
];

/// `_meta.kiro.type` values KAS runs from slash prompt text (2.31.1 audit B1):
/// custom agents and skills (LIVE: `/probe-skill hello` → `Load skill`) and
/// saved file/MCP prompts (bundle prompt `resolve` parses the same slash text
/// and substitutes `$ARGUMENTS`).
const PROMPT_COMMAND_TYPES: [&str; 3] = ["custom-agent", "skill", "prompt"];

/// KAS command advertisements are slash prompts, not V2 extension RPCs.
/// Unsupported/missing types stay out of the registry and autocomplete.
pub(crate) fn commands_to_notification(update: &acp::AvailableCommandsUpdate) -> Notification {
    let commands = update
        .available_commands
        .iter()
        .filter_map(|command| {
            if GATE_WORKFLOW_COMMANDS.contains(&command.name.as_str()) {
                tracing::debug!(
                    command = command.name,
                    "suppressing gate-advertised workflow command (ADR-0013)"
                );
                return None;
            }
            let command_type = command
                .meta
                .as_ref()
                .and_then(|meta| meta.get("kiro"))
                .and_then(|kiro| kiro.get("type"));
            match command_type {
                Some(serde_json::Value::String(kind))
                    if PROMPT_COMMAND_TYPES.contains(&kind.as_str()) => {}
                Some(serde_json::Value::String(kind)) => {
                    tracing::debug!(
                        command = command.name,
                        command_type = kind,
                        "suppressing unsupported KAS command type"
                    );
                    return None;
                }
                Some(malformed) => {
                    tracing::warn!(
                        command = command.name,
                        command_type = %malformed,
                        "suppressing KAS command with a non-string _meta.kiro.type"
                    );
                    return None;
                }
                None => {
                    tracing::debug!(
                        command = command.name,
                        "suppressing KAS command advertised without _meta.kiro.type"
                    );
                    return None;
                }
            }
            Some(crate::types::CommandInfo::new(
                command.name.clone(),
                command.description.clone(),
                None::<String>,
                command.input.is_some(),
                false,
                false,
                crate::types::AgentCommandRoute::Prompt,
            ))
        })
        .collect();
    Notification::CommandsUpdated {
        commands,
        prompts: Vec::new(),
    }
}

/// Drop a v2 `kiro.dev/commands/available` list from the shared extension
/// converter. KAS advertises commands only via ACP `available_commands_update`
/// (typed above); every entry here is bridge-only, and because each command
/// list replaces the registry's agent commands, forwarding an emptied list
/// would wipe the commands the ACP update registered.
pub(crate) fn drop_v2_command_list(notification: Notification) -> Option<Notification> {
    if let Notification::CommandsUpdated { commands, .. } = &notification {
        tracing::debug!(
            dropped = commands.len(),
            "ignoring v2 kiro.dev/commands/available on KAS"
        );
        return None;
    }
    Some(notification)
}

/// Outcome of offering an extension method to the KAS workflow adapter.
#[derive(Debug)]
pub(crate) enum WorkflowFrameOutcome {
    /// Not a workflow lifecycle method — continue through the engine's
    /// remaining extension converters.
    NotWorkflow,
    /// An exact workflow lifecycle method whose payload was malformed;
    /// the adapter warned and dropped it.
    Dropped,
    /// One converted workflow lifecycle event, boxed for its ride inside
    /// [`Notification::Workflow`].
    Converted(Box<crate::types::WorkflowEvent>),
}

/// Convert a KAS `session_info_update` to an internal notification.
///
/// KAS multiplexes turn lifecycle, metering, context telemetry, and steering
/// echoes through one `session_info_update` envelope, discriminated by
/// `_meta.kiro.kind`. Sub-kinds surfaced today:
/// - **`display_error` / `mcp_connection_error`** — the original required
///   message → [`Notification::McpConnectionError`], never a turn terminal.
/// - **`turn_start`** — the opening lifecycle signal of every KAS turn, cyril's
///   own and agent-initiated (workflow auto-wakes) alike →
///   [`Notification::TurnStarted`] (cyril-lki9 B7).
/// - **`turn_end`** — the terminal lifecycle signal → [`Notification::TurnCompleted`]
///   (KAS-2a), stop reason from `_meta.kiro.stopReason`.
/// - **`context_usage`** — the proactively-pushed per-category breakdown
///   (KAS-2b, cyril-5et2) → [`Notification::ContextBreakdownUpdated`].
/// - **`steering_queued` / `steering_injected` / `steering_cleared`** — the
///   steering-echo lifecycle (cyril-vgcm C5; fixtures captured live on
///   kiro-cli 2.12.1, KAS bundle byte-identical to 2.11.0/2.12.0). KAS keeps
///   the old-family kind names but carries ids like v2's new family; note
///   *injected*, not v2's `steering_consumed`, and Cleared fires BOTH on
///   explicit `_session/steer/clear` and routinely post-injection (findings
///   F4) — which is why [`Notification::SteeringCleared`] must stay id-scoped.
///   KAS also injects ENGINE messages through the same buffer (cyril-lki9 P6):
///   a `steering_injected` whose id starts `notify-` becomes
///   [`Notification::EngineMessageInjected`], never a steer consumption, and
///   `notify-` ids are stripped from `steering_cleared` (a list that named
///   only engine injections converts to nothing, not to the drain-all).
///
/// Every other sub-kind (`user_message_id_assigned`, `steering_inclusion`
/// fileMatch catalog, …) returns `None` — matching is exact on the `kind`
/// value, never prefix/substring. `turn_completion` maps metering only;
/// lifecycle completion keys on `kind == "turn_end"`, never frame ordering,
/// because a `context_usage` frame trails `turn_end` on the wire.
///
/// A `turn_end` whose `_meta.kiro.stopReason` is missing or unparseable still
/// completes the turn (defaults [`StopReason::EndTurn`]): silently returning
/// `None` would strand the UI in the busy state forever, so this is a runtime
/// fallback that survives release builds, not a `debug_assert!`.
pub(crate) fn session_info_to_notification(siu: &acp::SessionInfoUpdate) -> Option<Notification> {
    let kiro = siu.meta.as_ref()?.get("kiro")?;
    match kiro.get("kind").and_then(serde_json::Value::as_str) {
        Some("display_error") => {
            // KAS emits flat fields beside `kind`; `displayError` is a mirror,
            // not a separate error or an alternative required-field source.
            let Some(error_type) = kiro.get("errorType").and_then(serde_json::Value::as_str) else {
                tracing::warn!("KAS display_error is missing string `errorType`; dropped");
                return None;
            };
            if error_type != "mcp_connection_error" {
                return None;
            }
            let Some(message) = kiro
                .get("message")
                .and_then(serde_json::Value::as_str)
                .filter(|message| !message.trim().is_empty())
            else {
                tracing::warn!(
                    "KAS MCP display_error is missing nonempty string `message`; dropped"
                );
                return None;
            };
            Some(Notification::McpConnectionError {
                message: message.to_owned(),
            })
        }
        // cyril-gk17: a KAS-executed hook changed state. Carved producer:
        // `ContextualHookInvoked` / `handleHookAction` build
        // `{hook: {hookId, operationId, name, status, actionType, output?}}`,
        // where `status` comes from `mapActionStateToHookStatus`:
        // completed | failed | canceled | running | awaiting_approval.
        //
        // EVERY state surfaces, progress included. `running` and
        // `awaiting_approval` were dropped as noise on the reasoning that
        // `awaiting_approval` is already represented by the permission request
        // — the live capture refutes it: `kas-v2hooks-2.16.0.jsonl` holds ZERO
        // `session/request_permission` frames, so a dropped `awaiting_approval`
        // is represented by nothing at all. Dropping `running` is worse: a hook
        // that hangs, or is killed before it reports, then leaves NO evidence it
        // ever started — precisely the case an audit trail exists for. Under
        // `kas_hooks = "kas"` this line is the only record that agent-run shell
        // touched this host, so a duplicate line costs less than a missing one.
        Some("hook_update") => {
            let hook = kiro.get("hook")?;
            let status = hook.get("status").and_then(serde_json::Value::as_str)?;
            // A hook with no name is unattributable — surfacing "hook  failed"
            // tells the user nothing actionable, so log and drop.
            let Some(name) = hook.get("name").and_then(serde_json::Value::as_str) else {
                tracing::warn!(status, "KAS hook_update carries no name; dropped");
                return None;
            };
            Some(Notification::HookExecuted {
                name: name.to_string(),
                status: status.to_string(),
                // Only `runCommand` hooks carry an exit code, and only once the
                // run produced one. Absent means "not reported", never 0.
                exit_code: hook
                    .pointer("/output/result/exitCode")
                    .and_then(serde_json::Value::as_i64),
            })
        }
        Some("turn_completion") => Some(Notification::TurnMeteringUpdated(turn_metering_update(
            kiro,
        ))),
        // cyril-lki9 B7: the opening bracket of every KAS turn — cyril's own
        // prompt turns AND agent-initiated ones (workflow auto-wakes) that no
        // client prompt precedes. The frame carries no origin; the turn
        // mediator decides ownership.
        Some("turn_start") => Some(Notification::TurnStarted),
        Some("turn_end") => Some(Notification::TurnCompleted {
            stop_reason: turn_end_stop_reason(kiro),
        }),
        Some("context_usage") => {
            // A context_usage frame missing its required `usagePercentage` carries
            // nothing to show → drop (unlike turn_end, which must complete). When
            // present, ALWAYS return Some even if the breakdown is absent/malformed
            // — the scalar `Context: N%` must still update (the bars retain-last in
            // UiState). No unwrap; a malformed breakdown degrades to `None`.
            let Some(raw_percentage) = kiro.get("usagePercentage") else {
                tracing::warn!(
                    "KAS context_usage frame is missing `usagePercentage`; dropping frame"
                );
                return None;
            };
            let Some(raw_percentage) = raw_percentage.as_f64() else {
                tracing::warn!(
                    value = ?raw_percentage,
                    "KAS context_usage `usagePercentage` is not numeric; dropping frame"
                );
                return None;
            };
            let usage_percentage = match ContextUsage::try_new(raw_percentage) {
                Ok(usage) => usage.percentage(),
                Err(error) => {
                    tracing::warn!(
                        value = raw_percentage,
                        error = %error,
                        "KAS context_usage `usagePercentage` is outside the finite 0..=100 range; \
                         dropping frame"
                    );
                    return None;
                }
            };
            // Distinguish "missing" from "corrupt" (CLAUDE.md "Log before
            // returning None"): a frame with no `breakdown` key is the normal
            // scalar-only case (silent), but a `breakdown` that IS present yet
            // fails to parse (a bucket missing, or a `tokens`/`percent` field
            // absent or wrong-typed — e.g. a float-encoded `tokens` that
            // `as_u64` rejects) is wire drift that silently blanks the whole bar.
            // Log it so it's diagnosable — the same discipline turn_end_stop_reason
            // applies to `stopReason` below.
            let raw_breakdown = kiro.get("breakdown");
            let breakdown = parse_breakdown(raw_breakdown);
            if raw_breakdown.is_some() && breakdown.is_none() {
                tracing::warn!(
                    "KAS context_usage `breakdown` present but unparseable (bucket \
                     missing or a tokens/percent field absent/wrong-typed); \
                     degrading to scalar-only this frame"
                );
            }
            Some(Notification::ContextBreakdownUpdated {
                usage_percentage,
                breakdown,
            })
        }
        // Steering-echo lifecycle (cyril-vgcm C5). Old-family kind names,
        // new-family payloads: `{messageId, content}` beside `kind` in
        // `_meta.kiro`. Field reads and their never-drop degrade discipline
        // are shared with convert::kiro (`steering_text` /
        // `steering_message_id` / `steering_message_ids`) — only envelope
        // navigation differs (`_meta.kiro` here vs `update` there), so each
        // arm passes the already-navigated value. The "KAS " echo labels keep
        // the degrade warns distinguishable from the v2 old family's
        // identical kind names; a KAS `session_info_update` carries no
        // session id, hence `None`.
        Some("steering_queued") => Some(Notification::SteeringQueued {
            message: steering_text(Some(kiro), "content", "KAS steering_queued", None),
            message_id: steering_message_id(Some(kiro)),
        }),
        // cyril-lki9 B5/B6: KAS also injects ENGINE messages through the
        // steering buffer (busy-case workflow completion, relayed step
        // verdicts), marked by a `notify-` id. Classified on the id, never the
        // content: an operator steer may legitimately say anything.
        Some("steering_injected") => {
            let content = steering_text(Some(kiro), "content", "KAS steering_injected", None);
            match steering_message_id(Some(kiro)) {
                Some(message_id) if is_engine_injection(&message_id) => {
                    let workflow_completion =
                        message_id.starts_with(ENGINE_WORKFLOW_INJECTION_ID_PREFIX);
                    // A relayed step verdict carries KAS's own severity marker
                    // (`[notification/<sev>] <message>`); the severity is its
                    // own field, so the message is forwarded bare.
                    let content = if workflow_completion {
                        content
                    } else {
                        content.map(|c| strip_notification_prefix(&c).to_owned())
                    };
                    Some(Notification::EngineMessageInjected {
                        workflow_completion,
                        message_id,
                        content,
                        severity: kiro
                            .get("notificationSeverity")
                            .and_then(serde_json::Value::as_str)
                            .filter(|s| !s.is_empty())
                            .map(str::to_string),
                    })
                }
                message_id => Some(Notification::SteeringConsumed {
                    content,
                    message_id,
                }),
            }
        }
        Some("steering_cleared") => {
            let message_ids = steering_message_ids(Some(kiro), "KAS steering_cleared", None);
            // An empty list already means "clear everything" (absent,
            // empty, or all-corrupt ids — the v2 drain-all convention) and is
            // kept as-is. A list naming ONLY engine injections concerns no
            // operator steer: stripping it must not collapse into that
            // drain-all, so the frame converts to nothing.
            if message_ids.is_empty() {
                return Some(Notification::SteeringCleared { message_ids });
            }
            let operator_ids: Vec<String> = message_ids
                .into_iter()
                .filter(|id| !is_engine_injection(id))
                .collect();
            if operator_ids.is_empty() {
                tracing::debug!("KAS steering_cleared named only engine injections; not forwarded");
                return None;
            }
            Some(Notification::SteeringCleared {
                message_ids: operator_ids,
            })
        }
        _ => None,
    }
}

/// The agent-initiated tag of a KAS chunk / tool frame (cyril-lki9 P1/P2):
/// `Some` exactly when `_meta.kiro.agentInitiated` is the boolean `true` on an
/// agent message/thought chunk, `tool_call` or `tool_call_update`; the reason
/// is `_meta.kiro.agentInitiatedReason` (`None` when absent or empty). Any
/// other update kind, an absent or non-object `_meta.kiro`, or a non-`true`
/// flag is not agent-initiated. KAS never tags `turn_start` / `turn_end`
/// (P1), so origin is known only from a turn's first tagged frame.
pub(crate) fn agent_initiation(update: &acp::SessionUpdate) -> Option<AgentInitiation> {
    let meta = match update {
        acp::SessionUpdate::AgentMessageChunk(chunk)
        | acp::SessionUpdate::AgentThoughtChunk(chunk) => chunk.meta.as_ref(),
        acp::SessionUpdate::ToolCall(tool_call) => tool_call.meta.as_ref(),
        acp::SessionUpdate::ToolCallUpdate(update) => update.meta.as_ref(),
        _ => None,
    }?;
    let kiro = meta.get("kiro")?.as_object()?;
    if kiro.get("agentInitiated") != Some(&serde_json::Value::Bool(true)) {
        return None;
    }
    let reason = kiro
        .get("agentInitiatedReason")
        .and_then(serde_json::Value::as_str)
        .map(str::to_string);
    let workflow_completion = reason.as_deref() == Some(WORKFLOW_COMPLETION_WAKE_REASON);
    Some(AgentInitiation::new(reason, workflow_completion))
}

/// `messageId` prefix KAS gives messages the engine itself injects into a turn
/// through the steering buffer (cyril-lki9 evidence P6: `notify-<uuid>` step
/// verdicts, `notify-wf-<uuid>` busy-session workflow completions). Operator
/// steers carry `steer-<uuid>`.
const ENGINE_INJECTION_ID_PREFIX: &str = "notify-";

/// Among engine injections, the id prefix of a workflow completion delivered
/// into a busy session instead of an auto-wake turn (P6: `notify-wf-<uuid>`).
const ENGINE_WORKFLOW_INJECTION_ID_PREFIX: &str = "notify-wf-";

/// `agentInitiatedReason` of KAS's parent auto-wake on a terminal
/// `run_complete` (`autoWakeParentOnComplete`, evidence P1).
const WORKFLOW_COMPLETION_WAKE_REASON: &str = "workflow-complete-wake";

fn is_engine_injection(message_id: &str) -> bool {
    message_id.starts_with(ENGINE_INJECTION_ID_PREFIX)
}

/// Removes KAS's leading `[notification/<severity>] ` marker from a relayed
/// step verdict (evidence P6), if present; other content is returned as is.
fn strip_notification_prefix(content: &str) -> &str {
    content
        .strip_prefix("[notification/")
        .and_then(|rest| rest.split_once("] "))
        .map_or(content, |(_, message)| message)
}

fn turn_metering_update(kiro: &serde_json::Value) -> TurnMeteringUpdate {
    let duration_ms = optional_u64(kiro, "elapsedTime", "KAS turn_completion");
    let status = match kiro.get("status") {
        None => None,
        Some(value) => match value.as_str().and_then(UsageTurnStatus::from_wire) {
            Some(status) => Some(status),
            None => {
                tracing::warn!(
                    value = ?value,
                    "KAS turn_completion `status` present but invalid, ignoring"
                );
                None
            }
        },
    };

    let mut charges = Vec::new();
    let mut used_tools = Vec::new();
    match kiro.get("promptTurnSummaries") {
        None => {}
        Some(value) => match value.as_array() {
            Some(summaries) => {
                for summary in summaries {
                    if let Some(charge) = parse_metered_amount(summary) {
                        charges.push(charge);
                    }
                    match summary.get("usedTools") {
                        None => {}
                        Some(tools) => match tools.as_array() {
                            Some(tools) => {
                                for tool in tools {
                                    if let Some(tool) =
                                        tool.as_str().filter(|tool| !tool.is_empty())
                                    {
                                        used_tools.push(tool.to_owned());
                                    } else {
                                        tracing::warn!(
                                            value = ?tool,
                                            "KAS turn_completion `usedTools` entry is invalid, ignoring"
                                        );
                                    }
                                }
                            }
                            None => tracing::warn!(
                                value = ?tools,
                                "KAS turn_completion `usedTools` is not an array, ignoring"
                            ),
                        },
                    }
                }
            }
            None => tracing::warn!(
                value = ?value,
                "KAS turn_completion `promptTurnSummaries` is not an array, ignoring"
            ),
        },
    }

    let request_ids = match kiro.get("requestIds") {
        None => None,
        Some(value) => match value.as_array() {
            Some(ids) => {
                let mut parsed = Vec::with_capacity(ids.len());
                for id in ids {
                    if let Some(id) = id.as_str().filter(|id| !id.is_empty()) {
                        parsed.push(id.to_owned());
                    } else {
                        tracing::warn!(
                            value = ?id,
                            "KAS turn_completion `requestIds` entry is invalid, ignoring"
                        );
                    }
                }
                Some(parsed)
            }
            None => {
                tracing::warn!(
                    value = ?value,
                    "KAS turn_completion `requestIds` is not an array, ignoring"
                );
                None
            }
        },
    };

    TurnMeteringUpdate::new(charges, duration_ms, status, used_tools, request_ids)
}

fn parse_metered_amount(summary: &serde_json::Value) -> Option<MeteredAmount> {
    let amount = summary.get("usage").and_then(serde_json::Value::as_f64);
    let unit = summary.get("unit").and_then(serde_json::Value::as_str);
    let unit_plural = summary
        .get("unitPlural")
        .and_then(serde_json::Value::as_str);
    let (Some(amount), Some(unit), Some(unit_plural)) = (amount, unit, unit_plural) else {
        tracing::warn!(
            value = ?summary,
            "KAS turn_completion summary lacks valid usage/unit/unitPlural, ignoring charge"
        );
        return None;
    };
    match MeteredAmount::try_new(amount, unit, unit_plural) {
        Ok(charge) => Some(charge),
        Err(error) => {
            tracing::warn!(
                value = ?summary,
                error = %error,
                "KAS turn_completion summary charge is invalid, ignoring"
            );
            None
        }
    }
}

fn optional_u64(
    value: &serde_json::Value,
    field: &'static str,
    source: &'static str,
) -> Option<u64> {
    match value.get(field) {
        None => None,
        Some(value) => match value.as_u64() {
            Some(parsed) => Some(parsed),
            None => {
                tracing::warn!(value = ?value, field, source, "numeric field is invalid, ignoring");
                None
            }
        },
    }
}

/// Stop reason for a `turn_end` frame, defaulting [`StopReason::EndTurn`] when
/// `_meta.kiro.stopReason` is missing or unparseable (a dropped turn_end would
/// strand the UI busy forever — a runtime fallback, not a `debug_assert!`).
fn turn_end_stop_reason(kiro: &serde_json::Value) -> StopReason {
    let raw_stop_reason = kiro.get("stopReason");
    raw_stop_reason
        .and_then(serde_json::Value::as_str)
        .and_then(|s| {
            serde_json::from_value::<acp::StopReason>(serde_json::Value::String(s.to_owned())).ok()
        })
        .map(super::to_stop_reason)
        .unwrap_or_else(|| {
            // Distinguish "missing" from "corrupt" (CLAUDE.md): log the offending
            // value (`None` = absent, `Some(..)` = present-but-unparseable) so a
            // wire drift is diagnosable, not hidden behind a generic message.
            tracing::warn!(
                stop_reason = ?raw_stop_reason,
                "KAS turn_end `_meta.kiro.stopReason` missing or unparseable; defaulting to EndTurn"
            );
            StopReason::EndTurn
        })
}

/// Parse the `_meta.kiro.breakdown` object into a [`ContextBreakdown`]. Returns
/// `None` (treated as "no breakdown this frame") if the object is absent or any
/// of the five named buckets is missing/malformed — never an error, never a
/// panic. O(1): five fixed buckets.
fn parse_breakdown(breakdown: Option<&serde_json::Value>) -> Option<ContextBreakdown> {
    let bd = breakdown?;
    Some(ContextBreakdown::new(
        parse_bucket(bd.get("contextFiles"))?,
        parse_bucket(bd.get("sessionFiles"))?,
        parse_bucket(bd.get("tools"))?,
        parse_bucket(bd.get("yourPrompts"))?,
        parse_bucket(bd.get("kiroResponses"))?,
    ))
}

/// Parse one breakdown bucket `{tokens, percent}`. `None` if absent or either
/// field is missing/the wrong type — so a malformed bucket degrades the whole
/// breakdown to absent rather than fabricating a sentinel zero.
fn parse_bucket(bucket: Option<&serde_json::Value>) -> Option<ContextBucket> {
    let b = bucket?;
    let tokens = b.get("tokens").and_then(serde_json::Value::as_u64)?;
    let raw_percent = b.get("percent").and_then(serde_json::Value::as_f64)?;
    match ContextBucket::try_new(tokens, raw_percent) {
        Ok(bucket) => Some(bucket),
        Err(error) => {
            tracing::warn!(
                value = raw_percent,
                error = %error,
                "KAS context_usage breakdown bucket has invalid percent; \
                 degrading to scalar-only"
            );
            None
        }
    }
}

#[cfg(test)]
mod tests {
    #![allow(clippy::unwrap_used, clippy::expect_used)]

    use std::path::Path;

    use serde_json::json;

    use super::*;
    use crate::protocol::engine::{Engine, KasEngine};

    /// Deserialize a captured fixture into a `SessionNotification` — the exact
    /// layer the acp Client parses a `session/update` at (mirrors the
    /// `schema_deserializes_captured_kas_session_updates` loader in `mod.rs`).
    fn load(name: &str) -> (serde_json::Value, acp::SessionNotification) {
        let path = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("tests/fixtures/kas")
            .join(name);
        let raw = std::fs::read_to_string(&path).expect("read fixture");
        let value: serde_json::Value = serde_json::from_str(&raw).expect("fixture is JSON");
        let parsed: acp::SessionNotification =
            serde_json::from_value(value.clone()).expect("fixture deserializes");
        (value, parsed)
    }

    fn load_jsonl(name: &str) -> Vec<acp::SessionNotification> {
        let path = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("tests/fixtures/kas")
            .join(name);
        std::fs::read_to_string(&path)
            .expect("read fixture")
            .lines()
            .map(|line| serde_json::from_str(line).expect("fixture line deserializes"))
            .collect()
    }

    #[test]
    fn account_usage_response_maps_exactly() {
        let path = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("tests/fixtures/kas/workflow/terminal-aborted-2.16.2.jsonl");
        let raw = std::fs::read_to_string(path).expect("read captured sweep");
        let response = raw
            .lines()
            .map(|line| serde_json::from_str::<serde_json::Value>(line).expect("JSONL fixture"))
            .find_map(|line| {
                line.pointer("/parsed/result")
                    .filter(|result| result.pointer("/data/planName").is_some())
                    .cloned()
            })
            .expect("captured account response");
        let account = account_usage_from_response(&response).expect("captured response maps");
        assert_eq!(account.plan_name, "KIRO PRO MAX");
        assert_eq!(account.billing_cycle_reset, "2026-09-01");
        assert!(!account.overages_enabled);
        assert!(!account.is_enterprise);
        assert!(account.overage_capable);
        assert_eq!(account.usage_breakdowns.len(), 1);
        let credits = &account.usage_breakdowns[0];
        assert_eq!(credits.resource_type, "CREDIT");
        assert_eq!(credits.display_name, "Credits");
        assert_eq!(credits.used, 1075.01);
        assert!(credits.has_limit);
        assert_eq!(credits.limit, 5000.0);
        assert_eq!(credits.percentage, 21.0);
        assert_eq!(credits.current_overages, 0.0);
        assert_eq!(credits.overage_rate, 0.04);
        assert_eq!(credits.overage_charges, Some(0.0));
        assert_eq!(credits.currency, "USD");
        assert!(account.bonus_credits.is_empty());
        assert!(account.add_on_credits.is_empty());

        let with_bonus = json!({
            "success": true,
            "data": {
                "planName": "Plan",
                "billingCycleReset": "2026-09-01",
                "overagesEnabled": true,
                "isEnterprise": false,
                "overageCapable": true,
                "usageBreakdowns": [{
                    "resourceType": "CREDIT",
                    "displayName": "Credits",
                    "used": 104.0,
                    "limit": 100.0,
                    "percentage": 104,
                    "hasLimit": true,
                    "currentOverages": 4.0,
                    "overageRate": 0.04,
                    "overageCharges": 0.16,
                    "currency": "USD"
                }],
                "bonusCredits": [{
                    "name": "Welcome bonus",
                    "used": 81.96,
                    "total": 500.0,
                    "daysUntilExpiry": 12
                }],
                "addOnCredits": [{
                    "used": 2.0,
                    "total": 100.0,
                    "isActive": true,
                    "expiresAt": "2026-10-01"
                }]
            }
        });
        let account = account_usage_from_response(&with_bonus).expect("bonus maps");
        assert_eq!(account.bonus_credits[0].name, "Welcome bonus");
        assert_eq!(account.bonus_credits[0].days_until_expiry, 12);
        assert_eq!(account.usage_breakdowns[0].percentage, 100.0);
        assert_eq!(account.add_on_credits[0].total, 100.0);
        assert_eq!(
            account.add_on_credits[0].expires_at.as_deref(),
            Some("2026-10-01")
        );
        let admin_managed = json!({
            "success": true,
            "message": "Your plan is managed by admin"
        });
        assert_eq!(
            account_usage_from_response(&admin_managed)
                .expect_err("admin-managed response is unavailable")
                .to_string(),
            "account usage request failed: Your plan is managed by admin"
        );

        for invalid in [
            json!({"success": false, "message": "denied"}),
            json!({"success": true, "data": {}}),
            json!({
                "success": true,
                "data": {
                    "planName": "Plan", "billingCycleReset": "date",
                    "overagesEnabled": false, "isEnterprise": false,
                    "overageCapable": false,
                    "usageBreakdowns": [{
                        "resourceType": "CREDIT", "displayName": "Credits",
                        "used": -1, "limit": 1, "percentage": 101,
                        "hasLimit": true,
                        "currentOverages": 0, "overageRate": 0,
                        "currency": "USD"
                    }],
                    "bonusCredits": [],
                    "addOnCredits": []
                }
            }),
        ] {
            assert!(account_usage_from_response(&invalid).is_err());
        }
    }

    #[test]
    #[ignore = "reference-workstation account conversion budget"]
    fn account_usage_conversion_budget_reference() {
        let breakdowns = (0..5_000)
            .map(|index| {
                json!({
                    "resourceType": "CREDIT",
                    "displayName": format!("Credits {index}"),
                    "used": 1, "limit": 100, "percentage": 1,
                    "hasLimit": true,
                    "currentOverages": 0, "overageRate": 0.04,
                    "overageCharges": 0, "currency": "USD"
                })
            })
            .collect::<Vec<_>>();
        let bonuses = (0..5_000)
            .map(|index| {
                json!({
                    "name": format!("Bonus {index}"),
                    "used": 1, "total": 10, "daysUntilExpiry": 30
                })
            })
            .collect::<Vec<_>>();
        let response = json!({
            "success": true,
            "data": {
                "planName": "Plan", "billingCycleReset": "date",
                "overagesEnabled": false, "isEnterprise": false,
                "overageCapable": false,
                "usageBreakdowns": breakdowns, "bonusCredits": bonuses,
                "addOnCredits": []
            }
        });
        let started = std::time::Instant::now();
        let account = account_usage_from_response(&response).expect("stress response maps");
        let elapsed = started.elapsed();
        assert_eq!(account.usage_breakdowns.len(), 5_000);
        assert_eq!(account.bonus_credits.len(), 5_000);
        assert!(
            elapsed <= std::time::Duration::from_millis(25),
            "10,000-entry account conversion exceeded 25ms: {elapsed:?}"
        );
    }

    fn info_update(sn: &acp::SessionNotification) -> &acp::SessionInfoUpdate {
        match &sn.update {
            acp::SessionUpdate::SessionInfoUpdate(siu) => siu,
            other => panic!("fixture is not a session_info_update: {other:?}"),
        }
    }

    /// Build a `session_info_update` carrying `_meta.kiro = kiro`, the envelope
    /// every KAS lifecycle frame arrives in.
    fn siu(kiro: serde_json::Value) -> acp::SessionInfoUpdate {
        let sn: acp::SessionNotification = serde_json::from_value(json!({
            "sessionId": "sess_test",
            "update": { "sessionUpdate": "session_info_update", "_meta": { "kiro": kiro } }
        }))
        .expect("session_info_update envelope deserializes");
        match sn.update {
            acp::SessionUpdate::SessionInfoUpdate(siu) => siu,
            other => panic!("not a session_info_update: {other:?}"),
        }
    }

    // cyril-gk17: the hook_update frame, verbatim from the live capture
    // `kas-v2hooks-2.16.0.jsonl`. Under kas_hooks="kas" the AGENT runs these
    // commands on the host with no permission prompt, so dropping the frame
    // means shell execution with no user-visible record at all.
    #[test]
    fn hook_update_terminal_states_surface_progress_states_drop() {
        let frame = |status: &str, exit: Option<i64>| {
            let mut hook = serde_json::json!({
                "hookId": "/w/.kiro/hooks/audit.json#hook-0",
                "operationId": "7211cbc3-fca6-4c7f-a4c7-58435b8be937",
                "name": "cyril-audit-pre",
                "status": status,
                "actionType": "runCommand"
            });
            if let Some(code) = exit {
                hook["output"] = serde_json::json!({ "result": { "exitCode": code } });
            }
            siu(serde_json::json!({ "kind": "hook_update", "hook": hook }))
        };

        // Terminal states surface, carrying the exit code when reported.
        match session_info_to_notification(&frame("completed", Some(0))) {
            Some(Notification::HookExecuted {
                name,
                status,
                exit_code,
            }) => {
                assert_eq!(name, "cyril-audit-pre");
                assert_eq!(status, "completed");
                assert_eq!(exit_code, Some(0));
            }
            other => panic!("completed must surface, got {other:?}"),
        }
        for status in ["failed", "canceled"] {
            assert!(
                matches!(
                    session_info_to_notification(&frame(status, None)),
                    Some(Notification::HookExecuted {
                        exit_code: None,
                        ..
                    })
                ),
                "{status} must surface with no invented exit code"
            );
        }

        // Progress states surface too: a hook that hangs (or is killed before
        // it reports) emits `running` and nothing else, and dropping it would
        // leave the only audit trail of agent-run shell completely empty.
        // Regression fence for the cyril-gk17 review finding.
        for status in ["running", "awaiting_approval"] {
            match session_info_to_notification(&frame(status, None)) {
                Some(Notification::HookExecuted {
                    name,
                    status: got,
                    exit_code,
                }) => {
                    assert_eq!(name, "cyril-audit-pre");
                    assert_eq!(got, status, "status must surface verbatim");
                    assert_eq!(exit_code, None, "{status} reports no exit code");
                }
                other => panic!("{status} must reach the transcript, got {other:?}"),
            }
        }
    }

    #[test]
    fn hook_update_without_a_name_is_dropped() {
        // "Hook : failed" tells the user nothing actionable.
        let f = siu(serde_json::json!({
            "kind": "hook_update",
            "hook": { "status": "failed", "actionType": "runCommand" }
        }));
        assert!(session_info_to_notification(&f).is_none());
    }

    #[test]
    fn turn_end_maps_to_turn_completed_endturn() {
        let (value, sn) = load("session_info_update_turn_end.json");
        let result = session_info_to_notification(info_update(&sn));

        // Oracle: the converter reads the FLAT `_meta.kiro.stopReason`; this
        // independently reads the MIRRORED `_meta.kiro.turnEnd.stopReason` path
        // (the capture showed they agree) and maps it via the acp deserializer.
        let mirrored = value["update"]["_meta"]["kiro"]["turnEnd"]["stopReason"]
            .as_str()
            .expect("mirrored stopReason");
        let oracle = super::super::to_stop_reason(
            serde_json::from_value::<acp::StopReason>(json!(mirrored)).expect("oracle parses"),
        );
        assert_eq!(oracle, StopReason::EndTurn, "oracle precondition");
        assert!(
            matches!(result, Some(Notification::TurnCompleted { stop_reason }) if stop_reason == oracle),
            "turn_end must map to TurnCompleted with the mirrored stop reason, got {result:?}"
        );
    }

    #[test]
    fn captured_turn_completion_maps_exactly_and_is_not_terminal() {
        let notifications = load_jsonl("turn_completion_2_16_0_four.jsonl");
        let expected = [
            (0.104_566_227_363_184_09, 4442, ["read_file"].as_slice(), 2),
            (
                0.076_486_929_353_233_84,
                4223,
                ["execute_bash"].as_slice(),
                2,
            ),
            (0.081_022_536_815_920_39, 4690, ["fs_write"].as_slice(), 2),
            (
                0.123_497_716_915_422_9,
                8087,
                ["invoke_sub_agent", "subagent_response"].as_slice(),
                3,
            ),
        ];
        assert_eq!(notifications.len(), expected.len());
        for (notification, (credits, duration, tools, request_count)) in
            notifications.iter().zip(expected)
        {
            let result = session_info_to_notification(info_update(notification))
                .expect("captured turn completion converts");
            let Notification::TurnMeteringUpdated(update) = result else {
                panic!("turn_completion must map only to metering, got {result:?}");
            };
            assert_eq!(update.duration_ms(), Some(duration));
            assert_eq!(
                update.status(),
                Some(&crate::types::UsageTurnStatus::Success)
            );
            assert_eq!(
                update.request_ids().map(<[String]>::len),
                Some(request_count)
            );
            assert_eq!(
                update.used_tools(),
                tools,
                "captured usedTools must remain exact"
            );
            assert_eq!(update.charges().len(), 1);
            assert!((update.charges()[0].amount() - credits).abs() < f64::EPSILON);
            assert_eq!(update.charges()[0].unit(), "credit");
            assert_eq!(update.charges()[0].unit_plural(), "credits");
        }
    }

    #[test]
    fn other_sub_kind_is_ignored() {
        // user_message_id_assigned — guards "every session_info_update is a turn end".
        let (_v, sn) = load("session_info_update.json");
        assert!(session_info_to_notification(info_update(&sn)).is_none());
    }

    /// Synthetic `session_info_update` frame around an arbitrary `_meta.kiro`
    /// payload (renamed from `context_usage_frame` when steering tests started
    /// using it too — it was never context-specific).
    fn kiro_frame(kiro: serde_json::Value) -> acp::SessionNotification {
        serde_json::from_value(json!({
            "sessionId": "sess_x",
            "update": { "sessionUpdate": "session_info_update", "_meta": { "kiro": kiro } }
        }))
        .expect("frame deserializes")
    }

    #[test]
    fn turn_completion_presence_matrix_preserves_absence_and_units() {
        let notification = kiro_frame(json!({
            "kind": "turn_completion",
            "promptTurnSummaries": [
                {"unit": "credit", "unitPlural": "credits", "usage": 0.0},
                {"unit": "request", "unitPlural": "requests", "usage": 2.0},
                {"unit": "credit", "unitPlural": "credits", "usage": -1.0},
                {"unit": "", "unitPlural": "invalid", "usage": 4.0}
            ],
            "status": "future"
        }));
        let result = session_info_to_notification(info_update(&notification))
            .expect("turn completion converts despite optional gaps");
        let Notification::TurnMeteringUpdated(update) = result else {
            panic!("expected metering update, got {result:?}");
        };
        assert_eq!(update.duration_ms(), None);
        assert_eq!(
            update.status(),
            Some(&crate::types::UsageTurnStatus::Other("future".to_owned()))
        );
        assert_eq!(update.request_ids(), None);
        assert_eq!(update.charges().len(), 2);
        assert_eq!(
            update
                .charges()
                .iter()
                .map(|charge| (charge.unit(), charge.amount()))
                .collect::<Vec<_>>(),
            vec![("credit", 0.0), ("request", 2.0)]
        );

        let explicit_empty = kiro_frame(json!({
            "kind": "turn_completion",
            "requestIds": [],
            "status": "",
            "elapsedTime": "invalid"
        }));
        let result = session_info_to_notification(info_update(&explicit_empty))
            .expect("kind remains observable");
        let Notification::TurnMeteringUpdated(update) = result else {
            panic!("expected metering update, got {result:?}");
        };
        assert_eq!(update.request_ids(), Some([].as_slice()));
        assert_eq!(update.status(), None);
        assert_eq!(update.duration_ms(), None);
    }

    #[test]
    fn turn_completion_conversion_stays_within_budget() {
        let summaries = (0..2_500)
            .map(|index| {
                json!({
                    "unit": "credit",
                    "unitPlural": "credits",
                    "usage": 0.001,
                    "usedTools": [format!("tool_{index}")]
                })
            })
            .collect::<Vec<_>>();
        let request_ids = (0..5_000)
            .map(|index| format!("request_{index}"))
            .collect::<Vec<_>>();
        let notification = kiro_frame(json!({
            "kind": "turn_completion",
            "promptTurnSummaries": summaries,
            "elapsedTime": 1,
            "status": "success",
            "requestIds": request_ids
        }));

        let started = std::time::Instant::now();
        let result = session_info_to_notification(info_update(&notification))
            .expect("stress frame converts");
        let elapsed = started.elapsed();
        let Notification::TurnMeteringUpdated(update) = result else {
            panic!("expected metering update, got {result:?}");
        };
        assert_eq!(update.charges().len(), 2_500);
        assert_eq!(update.used_tools().len(), 2_500);
        assert_eq!(update.request_ids().map(<[String]>::len), Some(5_000));
        assert!(
            elapsed <= std::time::Duration::from_millis(25),
            "10,000-element conversion took {elapsed:?}, budget is 25ms"
        );
    }

    // cyril-vgcm C5: the three steering kinds map to the same notifications the
    // v2 families produce, off verbatim captured frames (2026-07-14, kiro-cli
    // 2.12.1 KAS — bundle byte-identical across 2.11.0–2.12.1). The expected
    // ids/text below are the capture's own values, not invented ones.
    #[test]
    fn steering_kind_queued_converts() {
        let (_v, sn) = load("session_info_update_steering_queued.json");
        let result = session_info_to_notification(info_update(&sn));
        assert!(
            matches!(
                &result,
                Some(Notification::SteeringQueued { message, message_id })
                    if message.as_deref()
                        == Some("IMPORTANT: end your reply with the single word STEERMARK_KILO")
                        && message_id.as_deref()
                            == Some("steer-8307ad8f-6404-40c3-a730-f7a1bfff4f60")
            ),
            "got {result:?}"
        );
    }

    #[test]
    fn steering_kind_injected_converts() {
        // KAS says `steering_injected` where v2's old family said consumed —
        // both mean "one queued steer drained into the turn".
        let (_v, sn) = load("session_info_update_steering_injected.json");
        let result = session_info_to_notification(info_update(&sn));
        assert!(
            matches!(
                &result,
                Some(Notification::SteeringConsumed { content, message_id })
                    if content.as_deref()
                        == Some("IMPORTANT: end your reply with the single word STEERMARK_LIMA")
                        && message_id.as_deref()
                            == Some("steer-6c7728c1-8eb8-4f99-8bdf-71d3c5a3bc26")
            ),
            "got {result:?}"
        );
    }

    #[test]
    fn steering_kind_cleared_converts() {
        let (_v, sn) = load("session_info_update_steering_cleared.json");
        let result = session_info_to_notification(info_update(&sn));
        assert!(
            matches!(
                &result,
                Some(Notification::SteeringCleared { message_ids })
                    if message_ids
                        == &vec!["steer-8307ad8f-6404-40c3-a730-f7a1bfff4f60".to_string()]
            ),
            "got {result:?}"
        );
    }

    #[test]
    fn steering_inclusion_is_not_a_queue_echo() {
        // The fileMatch steering *catalog* kind (captured same run) must stay
        // ignored — kind matching is exact, never prefix/substring: the probe
        // itself had to filter this noise, so the bug class is live.
        let (_v, sn) = load("session_info_update_steering_inclusion.json");
        assert!(session_info_to_notification(info_update(&sn)).is_none());
    }

    // cyril-vgcm C5 stress: degrade discipline (mirrors convert::kiro's).
    // Bug classes: drop-on-missing-field (chip desync), empty-string id
    // sentinel, absent-vs-empty messageIds divergence, corrupt id entries.
    #[test]
    fn steering_kinds_degrade_never_drop() {
        // Queued with id but no content -> emitted, text None.
        let sn = kiro_frame(json!({ "kind": "steering_queued", "messageId": "steer-x" }));
        assert!(matches!(
            session_info_to_notification(info_update(&sn)),
            Some(Notification::SteeringQueued { message: None, message_id })
                if message_id.as_deref() == Some("steer-x")
        ));
        // Empty-string id -> None; text still carried.
        let sn = kiro_frame(json!({
            "kind": "steering_injected", "messageId": "", "content": "still counted"
        }));
        assert!(matches!(
            session_info_to_notification(info_update(&sn)),
            Some(Notification::SteeringConsumed {
                content: Some(_),
                message_id: None
            })
        ));
        // Cleared: absent messageIds AND present-but-empty -> both empty
        // (UI drain-all semantics, C7).
        for kiro in [
            json!({ "kind": "steering_cleared" }),
            json!({ "kind": "steering_cleared", "messageIds": [] }),
        ] {
            let sn = kiro_frame(kiro);
            assert!(matches!(
                session_info_to_notification(info_update(&sn)),
                Some(Notification::SteeringCleared { message_ids }) if message_ids.is_empty()
            ));
        }
        // Corrupt entries dropped with the valid one kept.
        let sn = kiro_frame(json!({
            "kind": "steering_cleared", "messageIds": ["steer-ok", 7, ""]
        }));
        assert!(matches!(
            session_info_to_notification(info_update(&sn)),
            Some(Notification::SteeringCleared { message_ids })
                if message_ids == vec!["steer-ok".to_string()]
        ));
    }

    #[test]
    fn context_usage_maps_breakdown() {
        // Slice 3 / claim C1. The real 2.10.0 frame maps to ContextBreakdownUpdated
        // with the 5 buckets' exact tokens/percent. Expected values are the
        // independent jq oracle's (.cyril-5et2/oracle.sh on the same fixture).
        let (_v, sn) = load("session_info_update_context_usage.json");
        let result = session_info_to_notification(info_update(&sn));
        let Some(Notification::ContextBreakdownUpdated {
            usage_percentage,
            breakdown,
        }) = result
        else {
            panic!("expected ContextBreakdownUpdated, got {result:?}");
        };
        assert!((usage_percentage - 4.3).abs() < f64::EPSILON);
        let bd = breakdown.expect("breakdown present");
        for (bucket, tokens, percent) in [
            (bd.context_files(), 0u64, 0.0),
            (bd.tools(), 4662, 2.3),
            (bd.your_prompts(), 4096, 2.0),
            (bd.kiro_responses(), 0, 0.0),
            (bd.session_files(), 0, 0.0),
        ] {
            assert_eq!(bucket.tokens(), tokens);
            assert!((bucket.percent() - percent).abs() < f64::EPSILON);
        }
    }

    #[test]
    fn context_usage_reads_flat_usage_not_nested() {
        // Slice 3 / claim C2. Flat `_meta.kiro.usagePercentage` (9.9) wins over the
        // nested `contextUsage.usagePercentage` (1.1). Fails if the converter reads
        // the nested wrapper.
        let sn = kiro_frame(json!({
            "kind": "context_usage",
            "usagePercentage": 9.9,
            "contextUsage": { "usagePercentage": 1.1 }
        }));
        let result = session_info_to_notification(info_update(&sn));
        let Some(Notification::ContextBreakdownUpdated {
            usage_percentage, ..
        }) = result
        else {
            panic!("expected ContextBreakdownUpdated, got {result:?}");
        };
        assert!(
            (usage_percentage - 9.9).abs() < f64::EPSILON,
            "got {usage_percentage}"
        );
    }

    #[test]
    fn context_usage_breakdown_absent_still_carries_scalar() {
        // Slice 3 / claim C3. No `breakdown` key → Some with breakdown None, scalar
        // intact. Fails under `breakdown.unwrap()` or returning None (which would
        // drop the % update and freeze the toolbar).
        let sn = kiro_frame(json!({ "kind": "context_usage", "usagePercentage": 12.5 }));
        let result = session_info_to_notification(info_update(&sn));
        assert!(
            matches!(
                result,
                Some(Notification::ContextBreakdownUpdated { usage_percentage, breakdown: None })
                    if (usage_percentage - 12.5).abs() < f64::EPSILON
            ),
            "got {result:?}"
        );
    }

    #[test]
    fn context_usage_malformed_breakdown_degrades_to_none() {
        // Slice 3 / claim C3. A breakdown missing a bucket (here `tools`) degrades
        // the whole breakdown to None — never a fabricated sentinel-zero bucket —
        // while the scalar still updates.
        let sn = kiro_frame(json!({
            "kind": "context_usage", "usagePercentage": 3.0,
            "breakdown": {
                "contextFiles": { "tokens": 0, "percent": 0 },
                "sessionFiles": { "tokens": 0, "percent": 0 },
                "yourPrompts": { "tokens": 1, "percent": 1 },
                "kiroResponses": { "tokens": 0, "percent": 0 }
                // tools missing
            }
        }));
        let result = session_info_to_notification(info_update(&sn));
        assert!(
            matches!(
                result,
                Some(Notification::ContextBreakdownUpdated {
                    breakdown: None,
                    ..
                })
            ),
            "malformed breakdown must degrade to None, got {result:?}"
        );
    }

    #[test]
    fn context_usage_rejects_out_of_range_scalar() {
        let sn = kiro_frame(json!({
            "kind": "context_usage",
            "usagePercentage": 150.0
        }));
        assert!(
            session_info_to_notification(info_update(&sn)).is_none(),
            "invalid scalar must be rejected at the wire boundary"
        );
    }

    #[test]
    fn context_usage_rejects_out_of_range_bucket() {
        let sn = kiro_frame(json!({
            "kind": "context_usage",
            "usagePercentage": 3.0,
            "breakdown": {
                "contextFiles": { "tokens": 1, "percent": 101.0 },
                "sessionFiles": { "tokens": 0, "percent": 0.0 },
                "tools": { "tokens": 0, "percent": 0.0 },
                "yourPrompts": { "tokens": 0, "percent": 0.0 },
                "kiroResponses": { "tokens": 0, "percent": 0.0 }
            }
        }));
        assert!(matches!(
            session_info_to_notification(info_update(&sn)),
            Some(Notification::ContextBreakdownUpdated {
                usage_percentage: 3.0,
                breakdown: None
            })
        ));
    }

    #[test]
    fn turn_end_without_stop_reason_still_completes() {
        // Load-bearing fallback: a turn_end missing stopReason must NOT be
        // dropped (that strands the UI busy) — defaults EndTurn.
        let value = json!({
            "sessionId": "sess_x",
            "update": { "sessionUpdate": "session_info_update",
                        "_meta": { "kiro": { "kind": "turn_end" } } }
        });
        let sn: acp::SessionNotification = serde_json::from_value(value).unwrap();
        assert!(matches!(
            session_info_to_notification(info_update(&sn)),
            Some(Notification::TurnCompleted {
                stop_reason: StopReason::EndTurn
            })
        ));
    }

    #[test]
    fn kas_engine_routes_turn_end_to_completion() {
        let (_v, sn) = load("session_info_update_turn_end.json");
        let n = KasEngine::default().convert_session_update(&sn);
        assert!(matches!(
            n,
            Some(Notification::TurnCompleted {
                stop_reason: StopReason::EndTurn
            })
        ));
    }

    #[test]
    fn kas_engine_still_renders_agent_text() {
        // Slice 1 must NOT break text rendering: non-turn_end updates delegate
        // to the generic converter (agent_message_chunk -> AgentMessage).
        let (_v, sn) = load("agent_message_chunk.json");
        let n = KasEngine::default().convert_session_update(&sn);
        assert!(
            matches!(n, Some(Notification::AgentMessage(_))),
            "agent_message_chunk must still render via the generic path, got {n:?}"
        );
    }

    fn command_frame(commands: serde_json::Value) -> acp::SessionNotification {
        serde_json::from_value(json!({
            "sessionId": "sess_commands",
            "update": {
                "sessionUpdate": "available_commands_update",
                "availableCommands": commands
            }
        }))
        .expect("command advertisement frame")
    }

    #[tokio::test]
    async fn kas_prompt_type_advertisements_produce_prompt_intent_only() {
        use crate::commands::{CommandContext, CommandRegistry, CommandResultKind};
        use crate::types::{BridgeCommand, SessionId};

        let frame = command_frame(json!([
            {
                "name": "general-task-execution",
                "description": "Delegate a task",
                "input": {"hint": "task to delegate"},
                "_meta": {"kiro": {"type": "custom-agent"}}
            },
            {
                "name": "no-input-agent",
                "description": "Agent without input metadata",
                "_meta": {"kiro": {"type": "custom-agent"}}
            },
            // Skill and saved-prompt shapes as captured live (2.31.1 audit,
            // kas-v3c-v1-2.29.1.jsonl).
            {
                "name": "probe-skill",
                "description": "Probe skill probe-skill. Use when asked to run the probe-skill probe.",
                "input": {"hint": "optional context"},
                "_meta": {"kiro": {
                    "type": "skill",
                    "resource": {"resourceType": "skill", "source": {"origin": "user"}},
                    "originalName": "probe-skill"
                }}
            },
            {
                "name": "ws-prompt",
                "description": "(file prompt)",
                "input": {"hint": "[args]"},
                "_meta": {"kiro": {
                    "type": "prompt",
                    "resource": {"resourceType": "prompt", "source": {"origin": "workspace"}},
                    "arguments": [{"name": "args", "description": "All arguments", "required": false}]
                }}
            },
            {
                "name": "steering-document",
                "description": "Unsupported steering advertisement",
                "input": {"hint": "task to delegate"},
                "_meta": {"kiro": {"type": "steering"}}
            },
            {
                "name": "missing-type",
                "description": "Not classified",
                "input": {"hint": "task to delegate"}
            },
            {
                "name": "future-type",
                "description": "Unknown command category",
                "_meta": {"kiro": {"type": "future"}}
            },
            {
                "name": "malformed-type",
                "description": "Wrong type representation",
                "_meta": {"kiro": {"type": ["custom-agent"]}}
            }
        ]));
        let Notification::CommandsUpdated { commands, .. } = KasEngine::default()
            .convert_session_update(&frame)
            .expect("KAS advertisement")
        else {
            panic!("expected command update");
        };
        assert_eq!(
            commands
                .iter()
                .map(|command| command.name())
                .collect::<Vec<_>>(),
            [
                "general-task-execution",
                "no-input-agent",
                "probe-skill",
                "ws-prompt"
            ]
        );
        let mut registry = CommandRegistry::new();
        registry.replace_agent_commands(&commands);
        let mut session = crate::session::SessionController::new();
        session.apply_notification(&Notification::SessionCreated {
            session_id: SessionId::new("sess_commands"),
            current_mode: None,
            current_model: None,
            available_modes: Vec::new(),
            available_models: Vec::new(),
        });
        let (handle, mut outbound) =
            crate::protocol::bridge::BridgeHandle::for_tests_with_command_rx();
        let sender = handle.sender();
        let ctx = CommandContext {
            workspace: Path::new("."),
            session: &session,
            bridge: &sender,
            subagent_tracker: None,
            workflow_tracker: None,
            memory_status: None,
        };
        for input in [
            "/general-task-execution",
            "/general-task-execution \"inspect foo\"",
            "/no-input-agent",
            "/probe-skill hello",
            "/ws-prompt one \"two three\"",
        ] {
            let (command, args) = registry.parse(input).expect("supported advertisement");
            let result = command.execute(&ctx, args).await.expect("prompt intent");
            assert!(matches!(result.kind, CommandResultKind::SubmitAgentPrompt));
            assert!(
                outbound.try_recv().is_err(),
                "KAS has no V2 execute/options RPC"
            );
        }
        assert!(registry.parse("/steering-document").is_none());

        // The same ACP frame must retain V2's existing execute behavior.
        let Notification::CommandsUpdated { commands, .. } = crate::protocol::engine::V2Engine
            .convert_session_update(&frame)
            .expect("V2 advertisement")
        else {
            panic!("expected V2 command update");
        };
        assert_eq!(commands.len(), 8);
        let mut registry = CommandRegistry::new();
        registry.replace_agent_commands(&commands);
        let (command, args) = registry
            .parse("/general-task-execution inspect foo")
            .expect("V2 command");
        command.execute(&ctx, args).await.expect("V2 execute");
        assert!(matches!(
            outbound.try_recv(),
            Ok(BridgeCommand::ExecuteCommand { command, args, .. })
                if command == "general-task-execution" && args == json!({"value": "inspect foo"})
        ));
    }

    #[test]
    fn gate_workflow_commands_suppressed_exactly() {
        let frame = command_frame(json!([
            {"name": "workflow-run", "description": "run", "_meta": {"kiro": {"type": "custom-agent"}}},
            {"name": "workflow-status", "description": "status", "_meta": {"kiro": {"type": "custom-agent"}}},
            {"name": "workflow-cancel", "description": "cancel", "_meta": {"kiro": {"type": "custom-agent"}}},
            {"name": "workflow-resume", "description": "resume", "_meta": {"kiro": {"type": "custom-agent"}}},
            {"name": "workflow-creator", "description": "create", "_meta": {"kiro": {"type": "custom-agent"}}},
            {"name": "steer", "description": "steer", "_meta": {"kiro": {"type": "custom-agent"}}},
            {"name": "wörkflöw", "description": "unicode", "_meta": {"kiro": {"type": "custom-agent"}}}
        ]));
        let Notification::CommandsUpdated { commands, .. } = KasEngine::default()
            .convert_session_update(&frame)
            .expect("advertisement")
        else {
            panic!("expected command update");
        };
        assert_eq!(
            commands
                .iter()
                .map(|command| command.name())
                .collect::<Vec<_>>(),
            ["workflow-creator", "steer", "wörkflöw"],
            "exact-name suppression only — order and other entries preserved"
        );
        let empty = KasEngine::default()
            .convert_session_update(&command_frame(json!([])))
            .expect("empty advertisement");
        assert!(
            matches!(empty, Notification::CommandsUpdated { commands, .. } if commands.is_empty())
        );
    }

    #[test]
    fn kas_does_not_register_bridge_only_extension_commands() {
        let params = json!({"commands": [
            {"name": "general-task-execution", "_meta": {"kiro": {"type": "custom-agent"}}},
            {"name": "workflow-run"}
        ]});
        let kas = KasEngine::default()
            .convert_ext_notification("kiro.dev/commands/available", &params)
            .expect("KAS extension");
        // Dropped outright: an emptied list would replace (wipe) the agent
        // commands that KAS's ACP update registered.
        assert!(kas.is_none(), "got {kas:?}");
        let v2 = crate::protocol::engine::V2Engine
            .convert_ext_notification("kiro.dev/commands/available", &params)
            .expect("V2 extension");
        assert!(
            matches!(v2, Some(Notification::CommandsUpdated { commands, .. }) if commands.len() == 2)
        );
    }

    /// The adapter suite fences the adapter; this fences the engine match.
    #[test]
    fn kas_engine_drops_malformed_workflow_frame_to_ok_none() {
        let r = KasEngine::default()
            .convert_ext_notification("kiro/workflow/run_start", &json!({"inputs": {}}));
        assert!(
            matches!(r, Ok(None)),
            "malformed workflow frame must warn-and-drop to Ok(None), got {r:?}"
        );
    }

    #[test]
    fn kas_engine_drops_unknown_ext_frame() {
        // KAS-2a (cyril-j16p) Slice 3 — unknown-variant tolerance: an
        // unrecognised `_kiro/*` frame (arriving as `kiro/*` once the acp crate
        // strips the leading underscore) drops to `Ok(None)` — no error, no hang.
        // Non-workflow names continue to the existing Kiro extension handler;
        // its unknown-variant arm owns this and fences the fallback path.
        let r = KasEngine::default().convert_ext_notification("kiro/does/not/exist", &json!({}));
        assert!(
            matches!(r, Ok(None)),
            "unknown _kiro/* frame must drop to Ok(None), got {r:?}"
        );
    }

    // ---- cyril-lki9 Slice 1: turn_start and engine injections ----------------

    /// C1: `turn_start` opens every KAS turn; the v2 engine never produces it.
    #[test]
    fn turn_start_converts_to_turn_started() {
        let sn = kiro_frame(json!({
            "kind": "turn_start", "messageId": "m-turn-start", "turnStart": true
        }));
        assert!(matches!(
            session_info_to_notification(info_update(&sn)),
            Some(Notification::TurnStarted)
        ));
        let v2 = crate::protocol::engine::V2Engine.convert_session_update(&sn);
        assert!(
            !matches!(v2, Some(Notification::TurnStarted)),
            "v2 must never yield TurnStarted, got {v2:?}"
        );
    }

    /// C4: a `notify-` id marks an engine injection; classification is on the
    /// id, never the content. Stress rows: a `steer-` id whose content LOOKS like
    /// a notification, a bare `notify` id (no dash), an empty id (legacy), and
    /// severity absent / empty.
    #[test]
    fn notify_injection_is_engine_message() {
        let convert =
            |kiro: serde_json::Value| session_info_to_notification(info_update(&kiro_frame(kiro)));
        match convert(json!({
            "kind": "steering_injected", "messageId": "notify-wf-1",
            "content": "A workflow you launched (\"x\") completed.",
            "notificationSeverity": "info"
        })) {
            Some(Notification::EngineMessageInjected {
                message_id,
                content,
                severity,
                workflow_completion,
            }) => {
                assert!(workflow_completion, "notify-wf- is a workflow completion");
                assert_eq!(message_id, "notify-wf-1");
                assert_eq!(
                    content.as_deref(),
                    Some("A workflow you launched (\"x\") completed.")
                );
                assert_eq!(severity.as_deref(), Some("info"));
            }
            other => panic!("notify-wf- must be an engine injection, got {other:?}"),
        }
        match convert(json!({
            "kind": "steering_injected", "messageId": "notify-2",
            "content": "[notification/success] OK", "notificationSeverity": ""
        })) {
            Some(Notification::EngineMessageInjected {
                message_id,
                content,
                severity: None,
                workflow_completion: false,
            }) => {
                assert_eq!(message_id, "notify-2");
                assert_eq!(
                    content.as_deref(),
                    Some("OK"),
                    "KAS's severity marker stripped"
                );
            }
            other => panic!(
                "notify- with empty severity must be an engine injection with severity None, got {other:?}"
            ),
        }
        // A step verdict without the marker passes through verbatim; a
        // workflow-completion text is never stripped (it is not a verdict).
        for (kiro, want) in [
            (
                json!({ "kind": "steering_injected", "messageId": "notify-3",
                        "content": "plain verdict" }),
                "plain verdict",
            ),
            (
                json!({ "kind": "steering_injected", "messageId": "notify-wf-4",
                        "content": "[notification/info] not a verdict" }),
                "[notification/info] not a verdict",
            ),
        ] {
            match convert(kiro) {
                Some(Notification::EngineMessageInjected { content, .. }) => {
                    assert_eq!(content.as_deref(), Some(want));
                }
                other => panic!("engine injection expected, got {other:?}"),
            }
        }
        for (kiro, want_id) in [
            (
                json!({ "kind": "steering_injected", "messageId": "steer-1",
                     "content": "[notification/success] fake" }),
                Some("steer-1"),
            ),
            (
                json!({ "kind": "steering_injected", "messageId": "notify",
                     "content": "bare prefix" }),
                Some("notify"),
            ),
            (
                json!({ "kind": "steering_injected", "messageId": "",
                     "content": "legacy" }),
                None,
            ),
        ] {
            match convert(kiro) {
                Some(Notification::SteeringConsumed { message_id, .. }) => {
                    assert_eq!(message_id.as_deref(), want_id);
                }
                other => {
                    panic!("operator steer ({want_id:?}) must stay SteeringConsumed, got {other:?}")
                }
            }
        }
    }

    /// C5: `notify-` ids are stripped from `steering_cleared`; a list that named
    /// only engine injections converts to nothing — never to the empty
    /// drain-all — while an originally empty list keeps drain-all.
    #[test]
    fn cleared_strips_notify_ids() {
        let convert = |ids: serde_json::Value| {
            session_info_to_notification(info_update(&kiro_frame(
                json!({ "kind": "steering_cleared", "messageIds": ids }),
            )))
        };
        assert!(
            convert(json!(["notify-a", "notify-wf-b"])).is_none(),
            "a clear naming only engine injections must not become drain-all"
        );
        assert!(matches!(
            convert(json!(["notify-a", "steer-b"])),
            Some(Notification::SteeringCleared { message_ids }) if message_ids == ["steer-b"]
        ));
        assert!(matches!(
            convert(json!(["steer-b"])),
            Some(Notification::SteeringCleared { message_ids }) if message_ids == ["steer-b"]
        ));
        assert!(matches!(
            convert(json!([])),
            Some(Notification::SteeringCleared { message_ids }) if message_ids.is_empty()
        ));
    }

    /// C1/C4/C5 against live wire: every committed cyril-lki9 trace converts
    /// (through the production KAS path) to exactly the counts the independent
    /// `grep` census of the raw frames gives (plan.md Slice 1 oracle table).
    #[cfg(feature = "kas")]
    #[test]
    fn lki9_traces_match_raw_frame_census() {
        let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
        // (trace, TurnStarted, EngineMessageInjected, SteeringConsumed, SteeringCleared)
        let census = [
            (
                "experiments/conductor-spike/kas-workflow-channels-06615-restate-gateoff-tail-2.26.0.jsonl",
                3,
                2,
                0,
                0,
            ),
            (
                "experiments/conductor-spike/kas-workflow-new-06615-gateon-2.26.0.jsonl",
                4,
                1,
                0,
                0,
            ),
            (".cyril-lki9/lki9-live-busy-06615-2.26.0.jsonl", 2, 1, 0, 0),
            (
                ".cyril-lki9/lki9-live-cancel-06615-2.26.0.jsonl",
                2,
                1,
                0,
                0,
            ),
            (".cyril-lki9/lki9-live-steer-06615-2.26.0.jsonl", 2, 0, 1, 1),
        ];
        for (rel, want_started, want_injected, want_consumed, want_cleared) in census {
            let trace = std::fs::read_to_string(root.join(rel)).expect("read committed trace");
            let routed = crate::test_support::kas_trace_to_routed(&trace);
            let count =
                |pred: fn(&Notification) -> bool| routed.iter().filter(|(_, n)| pred(n)).count();
            let got = (
                count(|n| matches!(n, Notification::TurnStarted)),
                count(|n| matches!(n, Notification::EngineMessageInjected { .. })),
                count(|n| matches!(n, Notification::SteeringConsumed { .. })),
                count(|n| matches!(n, Notification::SteeringCleared { .. })),
            );
            assert_eq!(
                got,
                (want_started, want_injected, want_consumed, want_cleared),
                "{rel}: (TurnStarted, EngineMessageInjected, SteeringConsumed, SteeringCleared)"
            );
        }
    }

    // ---- cyril-lki9 Slice 2: agent-initiated tag extraction ---------------------

    fn update_with_meta(update: serde_json::Value) -> acp::SessionNotification {
        serde_json::from_value(json!({ "sessionId": "sess_x", "update": update }))
            .expect("session/update deserializes")
    }

    /// C2: `turn_origin` is `Some` exactly when `_meta.kiro.agentInitiated` is
    /// the boolean `true` on a chunk / thought / tool_call / tool_call_update.
    /// Stress rows: string `"true"`, a non-object `kiro`, a reason with no flag,
    /// an empty reason, and a tagged frame of another update kind.
    #[test]
    fn turn_origin_table() {
        let engine = KasEngine::default();
        let bodies = [
            (
                "agent_message_chunk",
                json!({ "sessionUpdate": "agent_message_chunk",
                "content": { "type": "text", "text": "x" } }),
            ),
            (
                "agent_thought_chunk",
                json!({ "sessionUpdate": "agent_thought_chunk",
                "content": { "type": "text", "text": "x" } }),
            ),
            (
                "tool_call",
                json!({ "sessionUpdate": "tool_call", "toolCallId": "t1",
                "title": "Read", "kind": "read", "status": "pending" }),
            ),
            (
                "tool_call_update",
                json!({ "sessionUpdate": "tool_call_update",
                "toolCallId": "t1", "status": "completed" }),
            ),
        ];
        // (meta, expected: None = not agent-initiated, Some(reason))
        let metas: [(Option<serde_json::Value>, Option<Option<&str>>); 8] = [
            (
                Some(json!({ "kiro": { "agentInitiated": true,
                "agentInitiatedReason": "workflow-complete-wake" } })),
                Some(Some("workflow-complete-wake")),
            ),
            (
                Some(json!({ "kiro": { "agentInitiated": true } })),
                Some(None),
            ),
            (
                Some(json!({ "kiro": { "agentInitiated": true, "agentInitiatedReason": "" } })),
                Some(None),
            ),
            (
                Some(json!({ "kiro": { "agentInitiated": false,
                "agentInitiatedReason": "workflow-complete-wake" } })),
                None,
            ),
            (Some(json!({ "kiro": { "agentInitiated": "true" } })), None),
            (
                Some(json!({ "kiro": { "agentInitiatedReason": "workflow-complete-wake" } })),
                None,
            ),
            (Some(json!({ "kiro": ["agentInitiated", true] })), None),
            (None, None),
        ];
        for (kind, body) in &bodies {
            for (meta, want) in &metas {
                let mut update = body.clone();
                if let Some(meta) = meta {
                    update["_meta"] = meta.clone();
                }
                let got = engine.turn_origin(&update_with_meta(update));
                assert_eq!(
                    got.as_ref().map(crate::types::AgentInitiation::reason),
                    *want,
                    "{kind} with _meta {meta:?}"
                );
                // The engine's own classification: only the workflow
                // completion reason is a workflow completion.
                assert_eq!(
                    got.as_ref()
                        .map(crate::types::AgentInitiation::is_workflow_completion),
                    want.map(|reason| reason == Some("workflow-complete-wake")),
                    "{kind} with _meta {meta:?}: workflow-completion flag"
                );
            }
        }
        // A tagged frame of a kind KAS never tags (and cyril never labels).
        let siu = update_with_meta(json!({ "sessionUpdate": "session_info_update",
            "_meta": { "kiro": { "kind": "turn_start", "agentInitiated": true } } }));
        assert_eq!(
            engine.turn_origin(&siu),
            None,
            "session_info_update is never agent-initiated"
        );
    }

    /// C2 against live wire: `turn_origin` over every committed agent->client
    /// `session/update` equals the independent `grep` census of tagged frames
    /// (evidence.md P1/P2): tail 57 / 2 / 4, gate-on 292 / 6 / 8, and reasons
    /// workflow-complete-wake 63 (tail) / 201 + send-message-wake 105 (gate-on).
    #[test]
    fn turn_origin_matches_tagged_frame_census() {
        let engine = KasEngine::default();
        let root = Path::new(env!("CARGO_MANIFEST_DIR")).join("../..");
        let census = [
            (
                "experiments/conductor-spike/kas-workflow-channels-06615-restate-gateoff-tail-2.26.0.jsonl",
                (57, 2, 4),
                vec![("workflow-complete-wake", 63)],
            ),
            (
                "experiments/conductor-spike/kas-workflow-new-06615-gateon-2.26.0.jsonl",
                (292, 6, 8),
                vec![("send-message-wake", 105), ("workflow-complete-wake", 201)],
            ),
        ];
        for (rel, want_kinds, want_reasons) in census {
            let trace = std::fs::read_to_string(root.join(rel)).expect("read committed trace");
            let (mut chunks, mut tool_calls, mut updates) = (0, 0, 0);
            let mut reasons = std::collections::BTreeMap::<String, usize>::new();
            for line in trace.lines().filter(|l| !l.is_empty()) {
                let row: serde_json::Value = serde_json::from_str(line).expect("trace row");
                if row["dir"] != "agent->client" || row["msg"]["method"] != "session/update" {
                    continue;
                }
                let sn: acp::SessionNotification =
                    serde_json::from_value(row["msg"]["params"].clone()).expect("session/update");
                let Some(origin) = engine.turn_origin(&sn) else {
                    continue;
                };
                match &sn.update {
                    acp::SessionUpdate::AgentMessageChunk(_) => chunks += 1,
                    acp::SessionUpdate::ToolCall(_) => tool_calls += 1,
                    acp::SessionUpdate::ToolCallUpdate(_) => updates += 1,
                    other => panic!("{rel}: origin on an unexpected update kind {other:?}"),
                }
                *reasons
                    .entry(origin.reason().unwrap_or("<none>").to_string())
                    .or_default() += 1;
                assert_eq!(
                    origin.is_workflow_completion(),
                    origin.reason() == Some("workflow-complete-wake"),
                    "{rel}: classification agrees with the raw reason"
                );
            }
            assert_eq!(
                (chunks, tool_calls, updates),
                want_kinds,
                "{rel}: tagged (chunk, tool_call, tool_call_update)"
            );
            let want: std::collections::BTreeMap<String, usize> = want_reasons
                .into_iter()
                .map(|(r, n)| (r.to_string(), n))
                .collect();
            assert_eq!(reasons, want, "{rel}: reasons");
        }
    }

    // --- cyril-auxt: the "Always allow" consent echo -------------------------

    /// One request/reply pair from `permission-consent-echo-2.32.0.json`,
    /// carved from the 2.32.0 audit's live KAS captures.
    fn echo_pair(name: &str) -> (acp::RequestPermissionRequest, serde_json::Value) {
        let path = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("tests/fixtures/kas_permission/permission-consent-echo-2.32.0.json");
        let raw = std::fs::read_to_string(&path).expect("read fixture");
        let fixture: serde_json::Value = serde_json::from_str(&raw).expect("fixture is JSON");
        let pair = &fixture[name];
        let request = serde_json::from_value(pair["request"].clone()).expect("request parses");
        (request, pair["reply"].clone())
    }

    fn request_consent(
        args: &acp::RequestPermissionRequest,
    ) -> crate::review::consent::PermissionConsent {
        let tool_call = crate::protocol::convert::to_tool_call_from_permission(args);
        permission_consent(args, &tool_call).expect("KAS request carries _meta.kiro")
    }

    /// The scope page row the operator picks, resolved the way the overlay does.
    fn pick(
        args: &acp::RequestPermissionRequest,
        scope: crate::always_allow::GrantScope,
        row: impl Fn(&crate::always_allow::ScopeChoice) -> bool,
        folder: Option<&str>,
    ) -> crate::types::PermissionResponse {
        use crate::always_allow::{AlwaysAllowGrant, GrantResource, ScopeChoice, scope_choices};
        let consent = request_consent(args);
        let choice = scope_choices(&consent, scope, true)
            .into_iter()
            .find(|choice| row(choice))
            .expect("row offered");
        let resource = match (&choice, folder) {
            (ScopeChoice::Folder(offer), Some(typed)) => {
                GrantResource::Folder(offer.validate(typed).expect("folder accepted"))
            }
            _ => choice.resource().expect("row grants directly"),
        };
        let options = crate::protocol::convert::to_permission_options(args);
        crate::always_allow::resolve(
            &consent,
            true,
            &options,
            PermissionOptionId::new("always-accept"),
            AlwaysAllowGrant::new(scope, resource),
        )
    }

    fn sent(
        response: crate::types::PermissionResponse,
        args: &acp::RequestPermissionRequest,
        engine: AgentEngine,
    ) -> serde_json::Value {
        let wire = crate::protocol::convert::from_permission_response(response, args, engine);
        serde_json::to_value(&wire).expect("response serializes")
    }

    /// The fixture's replies were sent by the 2.32.0 audit's probe client in
    /// the TUI's echo shape, and KAS persisted from them (live). This pins
    /// cyril's echo to that proven shape; that KAS honours cyril's own echo is
    /// the live acceptance (`.cyril-auxt/receipts/live-summary.md`).
    #[test]
    fn always_allow_exact_shell_command_matches_the_audit_echo() {
        use crate::always_allow::{GrantScope, ScopeChoice};
        for (name, scope) in [
            ("shell_user", GrantScope::User),
            ("shell_workspace", GrantScope::Workspace),
        ] {
            let (args, captured) = echo_pair(name);
            let response = pick(
                &args,
                scope,
                |row| matches!(row, ScopeChoice::Exact(_)),
                None,
            );
            assert_eq!(sent(response, &args, AgentEngine::Kas), captured, "{name}");
        }
    }

    #[test]
    fn always_allow_folder_echoes_the_folder_glob() {
        use crate::always_allow::{GrantScope, ScopeChoice};
        let (args, captured) = echo_pair("write_workspace");
        let response = pick(
            &args,
            GrantScope::Workspace,
            |row| matches!(row, ScopeChoice::Folder(_)),
            Some("src"),
        );
        let json = sent(response, &args, AgentEngine::Kas);
        let root = &args.meta.as_ref().expect("meta")["kiro"]["consent"]["workspaceRoot"];
        assert_eq!(json["outcome"], captured["outcome"]);
        assert_eq!(
            json["_meta"],
            json!({"kiro": {"consent": {
                "capability": "fs_write",
                "scope": "workspace",
                "resource": "src/**",
                "workspaceRoot": root,
            }}})
        );
    }

    #[test]
    fn always_allow_whole_tool_echoes_a_star_resource() {
        use crate::always_allow::{GrantScope, ScopeChoice};
        let (args, _) = echo_pair("shell_user");
        let response = pick(
            &args,
            GrantScope::Session,
            |row| matches!(row, ScopeChoice::WholeTool),
            None,
        );
        let json = sent(response, &args, AgentEngine::Kas);
        assert_eq!(json["_meta"]["kiro"]["consent"]["scope"], "session");
        assert_eq!(json["_meta"]["kiro"]["consent"]["resource"], "*");
        assert_eq!(json["_meta"]["kiro"]["consent"]["capability"], "shell");
    }

    #[test]
    fn consent_echo_needs_kas_and_an_offered_allow_always() {
        use crate::always_allow::{AlwaysAllowGrant, GrantResource, GrantScope};
        let (args, _) = echo_pair("shell_user");
        let grant = AlwaysAllowGrant::new(GrantScope::User, GrantResource::WholeTool);
        for (label, engine, option) in [
            ("v2 engine", AgentEngine::V2, "always-accept"),
            ("allow_once id", AgentEngine::Kas, "accept"),
            ("reject_always id", AgentEngine::Kas, "always-reject"),
            ("foreign id", AgentEngine::Kas, "nope"),
        ] {
            let json = sent(
                crate::types::PermissionResponse::AlwaysAllow {
                    option_id: PermissionOptionId::new(option),
                    grant: grant.clone(),
                },
                &args,
                engine,
            );
            assert_eq!(json["outcome"]["optionId"], option, "{label}");
            assert!(json.get("_meta").is_none(), "{label}: no echo");
        }
    }

    #[test]
    fn consent_echo_omits_what_the_request_did_not_name() {
        use crate::always_allow::{AlwaysAllowGrant, GrantResource, GrantScope};
        let (mut args, _) = echo_pair("shell_user");
        args.meta = None;
        let json = sent(
            crate::types::PermissionResponse::AlwaysAllow {
                option_id: PermissionOptionId::new("always-accept"),
                grant: AlwaysAllowGrant::new(GrantScope::Session, GrantResource::WholeTool),
            },
            &args,
            AgentEngine::Kas,
        );
        assert_eq!(
            json["_meta"],
            json!({"kiro": {"consent": {"scope": "session", "resource": "*"}}})
        );
    }

    #[test]
    fn permission_consent_reads_triggering_resource_and_ask_type() {
        let (mut args, _) = echo_pair("shell_user");
        let consent = request_consent(&args);
        assert_eq!(consent.wire_capability(), Some("shell"));
        assert_eq!(consent.triggering_resource(), Some("echo AUDITV1"));
        assert!(!consent.is_explicit_ask());

        if let Some(meta) = args.meta.as_mut() {
            meta["kiro"]["consent"]["askType"] = json!("explicit");
        }
        assert!(request_consent(&args).is_explicit_ask());
    }
}
