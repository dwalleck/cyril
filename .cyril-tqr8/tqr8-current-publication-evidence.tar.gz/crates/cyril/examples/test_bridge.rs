//! Bridge-based test harness for verifying Kiro ACP behavior.
//!
//! Spawns the bridge, sends commands, and prints every notification
//! that comes back. Tests the full v2 pipeline: bridge → kiro-cli → bridge → notification.
//!
//! Usage:
//!   cargo run --example test_bridge
//!   cargo run --example test_bridge -- --agent-command kiro-cli acp
//!   cargo run --example test_bridge -- --agent-command sacp-conductor agent "kiro-cli acp"

#![allow(clippy::unwrap_used, clippy::expect_used)]

use std::time::Duration;

use clap::Parser;

use cyril_core::protocol::bridge::spawn_bridge;
use cyril_core::types::*;

#[derive(Parser)]
#[command(name = "test_bridge", about = "Bridge-based ACP test harness")]
struct Cli {
    /// Command line for the ACP agent. First value is the program; remaining
    /// values are arguments. Defaults to `kiro-cli acp`.
    #[arg(
        long = "agent-command",
        num_args = 1..,
        default_values_t = vec!["kiro-cli".to_string(), "acp".to_string()],
    )]
    agent_command: Vec<String>,

    /// Which Kiro engine to bind (ADR-0001). `kas` needs a `--features kas`
    /// build; the KAS free path discovers its own spawn command, so
    /// `--agent-command` is ignored there (cyril-dn91 slice 7 live checks).
    #[arg(long = "agent-engine", default_value = "v2")]
    agent_engine: AgentEngine,

    /// Override the Test-9 prompt — e.g. one that forces fs/terminal host
    /// callbacks for a live KAS parity check.
    #[arg(long = "prompt")]
    prompt: Option<String>,
}

/// Keep the example's copyable URL output on a testable formatting boundary.
fn external_url_text(url: &str) -> impl std::fmt::Display + '_ {
    cyril_ui::mcp_notice::terminal_safe(url)
}

#[test]
fn external_url_output_preserves_printable_url_exactly() {
    let url = "https://example.com/authorize?state=a'b&hint=日本語#copy";
    assert_eq!(external_url_text(url).to_string(), url);
}

#[test]
fn external_url_output_escapes_only_terminal_controls() {
    let url = "https://example.com/auth?state=ok\u{1b}[31m\u{202e}\n\t";
    assert_eq!(
        external_url_text(url).to_string(),
        r"https://example.com/auth?state=ok\u{1b}[31m\u{202e}\n\t"
    );
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt()
        .with_max_level(tracing::Level::INFO)
        .with_writer(std::io::stderr)
        .with_ansi(true)
        .init();

    let cli = Cli::parse();
    let cwd = std::env::current_dir()?;

    println!("=== Cyril v2 Bridge Test Harness ===\n");
    println!("Agent: {}", cli.agent_command.join(" "));
    println!("CWD: {}\n", cwd.display());

    let agent_command = cyril_core::types::AgentCommand::try_from_argv(cli.agent_command)?;
    let bridge = spawn_bridge(
        agent_command,
        cyril_core::protocol::bridge::SpawnConfig {
            engine: cli.agent_engine,
            ..Default::default()
        },
        cwd.clone(),
    )?;
    let (sender, mut notification_rx, mut permission_rx, _source_rx, _completion_rx) =
        bridge.split();
    println!("[OK] Bridge spawned\n");

    // --- Test 1: Create session ---
    println!("--- [1] Creating session ---");
    sender
        .send(BridgeCommand::NewSession { cwd: cwd.clone() })
        .await?;

    // Drain notifications for a few seconds — session creation triggers
    // several notifications (SessionCreated, CommandsUpdated, MetadataUpdated)
    let session_id = drain_notifications(
        &mut notification_rx,
        &mut permission_rx,
        Duration::from_secs(3),
    )
    .await;

    let session_id = match session_id {
        Some(id) => {
            println!("\n[OK] Session created: {}\n", id.as_str());
            id
        }
        None => {
            println!("\n[FAIL] No SessionCreated notification received\n");
            return Ok(());
        }
    };

    // --- Test 2: Query model options ---
    println!("--- [2] Querying model options ---");
    sender
        .send(BridgeCommand::QueryCommandOptions {
            command: "model".into(),
            session_id: session_id.clone(),
        })
        .await?;
    drain_notifications(
        &mut notification_rx,
        &mut permission_rx,
        Duration::from_secs(3),
    )
    .await;
    println!();

    // --- Test 3: Query agent options ---
    println!("--- [3] Querying agent options ---");
    sender
        .send(BridgeCommand::QueryCommandOptions {
            command: "agent".into(),
            session_id: session_id.clone(),
        })
        .await?;
    drain_notifications(
        &mut notification_rx,
        &mut permission_rx,
        Duration::from_secs(3),
    )
    .await;
    println!();

    // --- Test 4: Execute /tools ---
    println!("--- [4] Executing /tools ---");
    sender
        .send(BridgeCommand::ExecuteCommand {
            command: "tools".into(),
            session_id: session_id.clone(),
            args: serde_json::json!({}),
        })
        .await?;
    drain_notifications(
        &mut notification_rx,
        &mut permission_rx,
        Duration::from_secs(3),
    )
    .await;
    println!();

    // --- Test 5: Execute /context ---
    println!("--- [5] Executing /context ---");
    sender
        .send(BridgeCommand::ExecuteCommand {
            command: "context".into(),
            session_id: session_id.clone(),
            args: serde_json::json!({}),
        })
        .await?;
    drain_notifications(
        &mut notification_rx,
        &mut permission_rx,
        Duration::from_secs(3),
    )
    .await;
    println!();

    // --- Test 6: Execute /usage ---
    println!("--- [6] Executing /usage ---");
    sender
        .send(BridgeCommand::ExecuteCommand {
            command: "usage".into(),
            session_id: session_id.clone(),
            args: serde_json::json!({}),
        })
        .await?;
    drain_notifications(
        &mut notification_rx,
        &mut permission_rx,
        Duration::from_secs(3),
    )
    .await;
    println!();

    // --- Test 7: Switch model ---
    println!("--- [7] Switching model to claude-haiku-4.5 ---");
    sender
        .send(BridgeCommand::ExecuteCommand {
            command: "model".into(),
            session_id: session_id.clone(),
            args: serde_json::json!({"value": "claude-haiku-4.5"}),
        })
        .await?;
    drain_notifications(
        &mut notification_rx,
        &mut permission_rx,
        Duration::from_secs(3),
    )
    .await;
    println!();

    // --- Test 8: Query prompt options ---
    println!("--- [8] Querying prompt options ---");
    sender
        .send(BridgeCommand::QueryCommandOptions {
            command: "prompts".into(),
            session_id: session_id.clone(),
        })
        .await?;
    drain_notifications(
        &mut notification_rx,
        &mut permission_rx,
        Duration::from_secs(3),
    )
    .await;
    println!();

    // --- Test 9: Send a prompt to trigger UsageUpdate ---
    println!("--- [9] Sending prompt (checking for UsageUpdate) ---");
    let prompt = cli
        .prompt
        .clone()
        .unwrap_or_else(|| "Say hello in one word.".to_string());
    sender
        .send(BridgeCommand::SendPrompt {
            session_id: session_id.clone(),
            prompt: cyril_core::types::PromptEnvelope::original(vec![prompt]),
        })
        .await?;
    drain_notifications(
        &mut notification_rx,
        &mut permission_rx,
        Duration::from_secs(15),
    )
    .await;
    println!();

    // --- Test 9b: Execute /stats (post-prompt; token counts should be populated if backend sends them) ---
    println!("--- [9b] Executing /stats (post-prompt token data) ---");
    sender
        .send(BridgeCommand::ExecuteCommand {
            command: "stats".into(),
            session_id: session_id.clone(),
            args: serde_json::json!({}),
        })
        .await?;
    drain_notifications(
        &mut notification_rx,
        &mut permission_rx,
        Duration::from_secs(3),
    )
    .await;
    println!();

    // --- Test 9c: Query /effort options (new in 2.4.x: thinking-effort exposure) ---
    println!("--- [9c] Querying /effort options ---");
    sender
        .send(BridgeCommand::QueryCommandOptions {
            command: "effort".into(),
            session_id: session_id.clone(),
        })
        .await?;
    drain_notifications(
        &mut notification_rx,
        &mut permission_rx,
        Duration::from_secs(3),
    )
    .await;
    println!();

    // --- Test 10: Query chat sessions ---
    println!("--- [10] Querying chat session options ---");
    sender
        .send(BridgeCommand::QueryCommandOptions {
            command: "chat".into(),
            session_id: session_id.clone(),
        })
        .await?;
    drain_notifications(
        &mut notification_rx,
        &mut permission_rx,
        Duration::from_secs(3),
    )
    .await;
    println!();

    // --- Shutdown ---
    println!("--- Shutting down ---");
    sender.send(BridgeCommand::Shutdown).await?;
    println!("[OK] Done\n");

    Ok(())
}

/// Drain all notifications for `duration`, printing each one.
/// Returns the session ID if a SessionCreated notification was received.
async fn drain_notifications(
    notification_rx: &mut tokio::sync::mpsc::Receiver<RoutedNotification>,
    permission_rx: &mut tokio::sync::mpsc::Receiver<PermissionRequest>,
    duration: Duration,
) -> Option<SessionId> {
    let deadline = tokio::time::Instant::now() + duration;
    let mut session_id = None;

    loop {
        tokio::select! {
            biased;

            Some(routed) = notification_rx.recv() => {
                if let Some(ref sid) = routed.session_id {
                    println!("  [session={}]", sid.as_str());
                }
                print_notification(&routed.notification);
                if let Notification::SessionCreated { session_id: ref id, .. } = routed.notification {
                    session_id = Some(id.clone());
                }
            }

            Some(permission) = permission_rx.recv() => {
                println!("  [PERMISSION] {}", permission.message);
                for opt in &permission.options {
                    println!("    - {} (id={}, destructive={})", opt.label, opt.id, opt.is_destructive);
                }
                // Auto-approve with first non-destructive option
                let response = permission
                    .options
                    .iter()
                    .find(|o| !o.is_destructive)
                    .map(|o| PermissionResponse::Selected {
                        option_id: o.id.clone(),
                        trust_option: None,
                    })
                    .unwrap_or(PermissionResponse::Cancel);
                if permission.responder.send(response).is_err() {
                    eprintln!("  [WARN] permission response dropped (receiver closed)");
                }
            }

            _ = tokio::time::sleep_until(deadline) => {
                break;
            }
        }
    }

    session_id
}

fn print_notification(n: &Notification) {
    match n {
        Notification::SessionCreated {
            session_id,
            current_mode,
            current_model,
            available_modes,
            available_models,
        } => {
            println!("  [SessionCreated]");
            println!("    session_id: {}", session_id.as_str());
            println!(
                "    current_mode: {}",
                current_mode
                    .as_ref()
                    .map(|m| m.as_str())
                    .unwrap_or("(none)")
            );
            println!("    available_modes: {}", available_modes.len());
            println!("    available_models: {}", available_models.len());
            println!(
                "    current_model: {}",
                current_model.as_deref().unwrap_or("(none)")
            );
        }
        Notification::TurnStarted => {
            println!("  [TurnStarted]");
        }
        Notification::AgentInitiatedTurn(origin) => {
            println!(
                "  [AgentInitiatedTurn] reason={}",
                origin.reason().unwrap_or("<none>")
            );
        }
        Notification::TurnCompleted { .. } => {
            println!("  [TurnCompleted]");
        }
        Notification::TurnStalled { quiet } => {
            println!("  [TurnStalled] quiet for {}s", quiet.as_secs());
        }
        Notification::Workflow(event) => {
            println!("  [Workflow] {}", event.method_name());
        }
        Notification::WorkflowSnapshot(snapshot) => {
            println!(
                "  [WorkflowSnapshot] {} status={}",
                snapshot.workflow_id(),
                snapshot.status()
            );
        }
        Notification::WorkflowCommand(outcome) => {
            println!("  [WorkflowCommand] {outcome:?}");
        }
        Notification::WorkflowStepAnswerFailed {
            session_id,
            message,
        } => {
            println!("  [WorkflowStepAnswerFailed] {session_id}: {message}");
        }
        Notification::WorkflowMessage(message) => {
            println!(
                "  [WorkflowMessage] {} {} → {}: {}",
                message.sender(),
                message.severity(),
                message.recipient(),
                message.message()
            );
        }
        Notification::BridgeDisconnected { reason } => {
            println!("  [BridgeDisconnected] {reason}");
        }
        Notification::AgentMessage(msg) => {
            let preview: String = msg.text.chars().take(80).collect();
            println!(
                "  [AgentMessage] streaming={} text={preview}...",
                msg.is_streaming
            );
        }
        Notification::UserMessage(msg) => {
            let preview: String = msg.text.chars().take(80).collect();
            println!(
                "  [UserMessage] streaming={} text={preview}...",
                msg.is_streaming
            );
        }
        Notification::AgentThought(thought) => {
            let preview: String = thought.text.chars().take(80).collect();
            println!("  [AgentThought] {preview}...");
        }
        Notification::ToolCallStarted(tc) => {
            println!(
                "  [ToolCallStarted] id={} title={:?} kind={:?}",
                tc.id().as_str(),
                tc.title(),
                tc.kind()
            );
        }
        Notification::ToolCallUpdated(tc) => {
            println!(
                "  [ToolCallUpdated] id={} title={:?} status={:?}",
                tc.id().as_str(),
                tc.title(),
                tc.status()
            );
        }
        Notification::PlanUpdated(plan) => {
            println!("  [PlanUpdated] {} entries", plan.entries().len());
        }
        Notification::ModeChanged { mode_id } => {
            println!("  [ModeChanged] {mode_id}");
        }
        Notification::ConfigOptionsUpdated(options)
        | Notification::ConfigOptionSet { options, .. } => {
            println!("  [ConfigOptionsUpdated] {} options", options.len());
            for opt in options {
                println!(
                    "    key={} value={:?} choices={}",
                    opt.key,
                    opt.value,
                    opt.options.len()
                );
            }
        }
        Notification::ThinkingToggled { enabled } => {
            println!("  [ThinkingToggled] enabled={enabled}");
        }
        Notification::CommandsUpdated {
            commands: cmds,
            prompts,
        } => {
            println!(
                "  [CommandsUpdated] {} commands, {} prompts",
                cmds.len(),
                prompts.len()
            );
            for cmd in cmds {
                println!(
                    "    {:<20} sel={:<5} local={:<5} {}",
                    cmd.name(),
                    cmd.is_selection(),
                    cmd.is_local(),
                    cmd.description().unwrap_or("")
                );
            }
        }
        Notification::MetadataUpdated {
            context_usage,
            metering,
            tokens,
            duration_ms,
            effort,
            reasoning,
            session_id,
            refusal,
        } => {
            println!(
                "  [MetadataUpdated] ctx={:?} metering={:?} tokens={:?} duration={duration_ms:?} effort={effort:?} reasoning={reasoning:?} session={session_id:?} refusal={refusal:?}",
                context_usage.as_ref().map(|u| u.percentage()),
                metering.as_ref().map(|m| m.credits()),
                tokens.as_ref().map(|t| (t.input(), t.output(), t.cached()))
            );
        }
        Notification::TurnMeteringUpdated(update) => {
            println!(
                "  [TurnMeteringUpdated] charges={:?} duration={:?} status={:?} tools={:?} requests={:?}",
                update.charges(),
                update.duration_ms(),
                update.status(),
                update.used_tools(),
                update.request_ids()
            );
        }
        Notification::UsageAccountUpdated {
            account,
            fetched_at_ms,
        } => {
            println!(
                "  [UsageAccountUpdated] plan={} fetched={fetched_at_ms:?}",
                account.plan_name
            );
        }
        Notification::UsageAccountQueryFailed { message } => {
            println!("  [UsageAccountQueryFailed] {message}");
        }
        Notification::AgentSwitched { name, welcome, .. } => {
            println!("  [AgentSwitched] name={name} welcome={:?}", welcome);
        }
        Notification::CompactionStatus { phase, summary } => {
            println!("  [CompactionStatus] phase={phase:?} summary={summary:?}");
        }
        Notification::ClearStatus { message } => {
            println!("  [ClearStatus] {message}");
        }
        Notification::RateLimited { message } => {
            println!("  [RateLimited] {message}");
        }
        Notification::SystemNotify { level, message } => {
            println!("  [SystemNotify] level={level:?}: {message}");
        }
        Notification::ToolCallChunk {
            tool_call_id,
            title,
            kind,
            session_id,
        } => {
            let sid = session_id.as_ref().map_or("main", |s| s.as_str());
            println!("  [ToolCallChunk] id={tool_call_id} title={title} kind={kind} session={sid}");
        }
        Notification::CommandOptionsReceived { command, options } => {
            println!(
                "  [CommandOptionsReceived] command={command} options={}",
                options.len()
            );
            for opt in options {
                println!(
                    "    {:<30} value={:<25} current={} desc={:?} group={:?}",
                    opt.label,
                    opt.value,
                    opt.is_current,
                    opt.description.as_deref().unwrap_or(""),
                    opt.group.as_deref().unwrap_or("")
                );
            }
        }
        Notification::SettingsList { settings } => {
            let pretty =
                serde_json::to_string_pretty(settings).unwrap_or_else(|_| settings.to_string());
            println!("  [SettingsList]");
            println!("    {}", pretty.replace('\n', "\n    "));
        }
        Notification::CommandExecuted { command, response } => {
            let success = response
                .get("success")
                .and_then(|s| s.as_bool())
                .unwrap_or(false);
            let message = response
                .get("message")
                .and_then(|m| m.as_str())
                .unwrap_or("");
            let has_data = response.get("data").is_some();
            println!("  [CommandExecuted] command={command} success={success} has_data={has_data}");
            println!("    message: {message}");
            if has_data {
                let data = response.get("data").unwrap();
                let pretty =
                    serde_json::to_string_pretty(data).unwrap_or_else(|_| data.to_string());
                // Print first 500 chars of data
                let preview: String = pretty.chars().take(500).collect();
                println!("    data: {preview}");
                if pretty.len() > 500 {
                    println!("    ... ({} more chars)", pretty.len() - 500);
                }
            }
        }
        Notification::McpServerInitFailure { server_name, error } => {
            println!(
                "  [McpInitFail] {server_name}: {}",
                error.as_deref().unwrap_or("(no detail)")
            );
        }
        Notification::McpOAuthRequest { server_name, url } => {
            println!("  [McpOAuth] {server_name}: {url}");
        }
        Notification::ExternalUrlRequested { url } => {
            println!(
                "  [ExternalUrlRequested] Open in browser: {}",
                external_url_text(url)
            );
        }
        Notification::McpConnectionError { message } => {
            println!("  [McpConnectionError] [error] {}", message.escape_debug());
        }
        Notification::McpServerInitialized { server_name } => {
            println!("  [McpReady] {server_name}");
        }
        Notification::AgentNotFound {
            requested,
            fallback,
        } => {
            println!(
                "  [AgentNotFound] {requested} -> {}",
                fallback.as_deref().unwrap_or("(none)")
            );
        }
        Notification::AgentConfigError { path, error } => {
            println!("  [AgentConfigError] {path}: {error}");
        }
        Notification::ModelNotFound {
            requested,
            fallback,
        } => {
            println!(
                "  [ModelNotFound] {requested} -> {}",
                fallback.as_deref().unwrap_or("(none)")
            );
        }
        Notification::SubagentListUpdated {
            subagents,
            pending_stages,
        } => {
            println!(
                "  [SubagentList] {} active, {} pending",
                subagents.len(),
                pending_stages.len()
            );
            for s in subagents {
                let status = if s.is_working() {
                    "working"
                } else {
                    "terminated"
                };
                println!("    {} ({}) — {status}", s.session_name(), s.agent_name());
            }
            for p in pending_stages {
                println!("    {} (pending, depends: {:?})", p.name(), p.depends_on());
            }
        }
        Notification::InboxNotification {
            session_id,
            message_count,
            escalation_count,
            senders,
        } => {
            println!(
                "  [Inbox] session={} msgs={message_count} escalations={escalation_count} from={senders:?}",
                session_id.as_str()
            );
        }
        Notification::SubagentSpawned { session_id, name } => {
            println!("  [SubagentSpawned] {name} ({})", session_id.as_str());
        }
        Notification::SubagentTerminated { session_id } => {
            println!("  [SubagentTerminated] ({})", session_id.as_str());
        }
        Notification::BridgeError { operation, message } => {
            println!("  [BridgeError] {operation}: {message}");
        }
        Notification::HooksChanged { hooks } => {
            println!("  [HooksChanged] {} hook(s)", hooks.len());
        }
        Notification::PowersChanged { powers } => {
            println!("  [PowersChanged] {} power(s)", powers.len());
            for power in powers {
                println!(
                    "    {} — {} (mcp: {}; steering: {})",
                    power.name(),
                    power.title(),
                    if power.mcp_server_names().is_empty() {
                        "none".to_owned()
                    } else {
                        power.mcp_server_names().join(", ")
                    },
                    power.has_steering_files()
                );
            }
        }
        Notification::HookExecuted {
            name,
            status,
            exit_code,
        } => {
            println!("  [HookExecuted] {name}: {status} (exit {exit_code:?})");
        }
        Notification::UsageUpdated { used, size, .. } => {
            let pct = *used as f64 / (*size).max(1) as f64 * 100.0;
            println!("  [UsageUpdated] {used}/{size} tokens ({pct:.1}%)");
        }
        Notification::UsageSessionStarted { session_id, origin } => {
            println!("  [UsageSessionStarted] {session_id} ({origin:?})");
        }
        Notification::TurnUsageCaptured(usage) => {
            println!(
                "  [TurnUsageCaptured] total={} input={} output={}",
                usage.total(),
                usage.input(),
                usage.output()
            );
        }
        Notification::ContextBreakdownUpdated {
            usage_percentage,
            breakdown,
        } => {
            println!(
                "  [ContextBreakdownUpdated] ctx={usage_percentage:.1}% breakdown={}",
                if breakdown.is_some() {
                    "present"
                } else {
                    "absent"
                }
            );
        }
        Notification::SteeringQueued {
            message,
            message_id,
        } => {
            println!(
                "  [SteeringQueued] {} (id={})",
                message.as_deref().unwrap_or("<no text>"),
                message_id.as_deref().unwrap_or("<none>")
            );
        }
        Notification::SteeringConsumed {
            content,
            message_id,
        } => {
            println!(
                "  [SteeringConsumed] {} (id={})",
                content.as_deref().unwrap_or("<no text>"),
                message_id.as_deref().unwrap_or("<none>")
            );
        }
        Notification::EngineMessageInjected {
            message_id,
            content,
            severity,
            ..
        } => {
            println!(
                "  [EngineMessageInjected] {} (id={message_id}, severity={})",
                content.as_deref().unwrap_or("<no text>"),
                severity.as_deref().unwrap_or("<none>")
            );
        }
        Notification::SteeringCleared { message_ids } => {
            println!("  [SteeringCleared] ids={message_ids:?}");
        }
        Notification::SteeringUnsupported { message } => {
            println!("  [SteeringUnsupported] {message}");
        }
        Notification::SteeringClearUnsupported { message } => {
            println!("  [SteeringClearUnsupported] {message}");
        }
    }
}
